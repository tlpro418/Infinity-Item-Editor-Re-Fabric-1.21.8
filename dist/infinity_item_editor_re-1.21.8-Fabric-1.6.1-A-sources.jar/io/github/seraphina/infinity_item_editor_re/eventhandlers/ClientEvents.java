package io.github.seraphina.infinity_item_editor_re.eventhandlers;

import io.github.seraphina.infinity_item_editor_re.Config;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.ClientCreativeTabData;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.client.screen.ItemEditorScreen;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.data.voids.VoidController;
import io.github.seraphina.infinity_item_editor_re.init.CreativeTabRegistry;
import io.github.seraphina.infinity_item_editor_re.mixin.client.AbstractContainerScreenAccessor;
import io.github.seraphina.infinity_item_editor_re.mixin.client.ConnectionAccessor;
import io.github.seraphina.infinity_item_editor_re.mixin.client.CreativeModeInventoryScreenAccessor;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.netty.channel.Channel;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_11362;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1809;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2744;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_8942;
import java.util.Optional;

public final class ClientEvents {
    private static final String VOID_HANDLER = ModSource.MODID + "_void_handler";
    private static final String BLOCK_ENTITY_TAG = "BlockEntityTag";
    private static final String BLOCK_ENTITY_ID_TAG = "id";
    private static final String DISPLAY_TAG = "display";
    private static final String LORE_TAG = "Lore";
    private static final String SKULL_OWNER_TAG = "SkullOwner";
    private static final String COPIED_NBT_LORE = "\"(+NBT)\"";

    private ClientEvents() {
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(ClientEvents::onClientTick);
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> onChatReceived(message));
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> onChatReceived(message));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> onServerConnection(handler.method_48296()));
    }

    private static void onClientTick(class_310 minecraft) {
        if (minecraft.field_1724 == null || minecraft.field_1687 == null || minecraft.field_1755 != null) {
            return;
        }

        while (ClientKeyMappings.SAVE_REALM.method_1436()) {
            RealmController realmController = ModSource.getOrCreateRealmController(minecraft.field_1697);
            if (realmController != null) {
                class_1799 heldStack = minecraft.field_1724.method_6047();
                if (realmController.addItemStack(minecraft.field_1724, heldStack.method_7972())) {
                    CreativeTabRefresher.refreshRealm(minecraft);
                }
            }
        }

        while (ClientKeyMappings.OPEN_EDITOR.method_1436()) {
            class_1799 heldStack = minecraft.field_1724.method_6047();
            if (heldStack.method_7960()) {
                minecraft.field_1724.method_7353(class_2561.method_43471("message." + ModSource.MODID + ".editor_no_item"), true);
            } else {
                minecraft.method_1507(new ItemEditorScreen(heldStack.method_7972()));
            }
        }

        while (ClientKeyMappings.COPY_TARGET.method_1436()) {
            copyTarget(minecraft);
        }
    }

    public static boolean handleScreenKeyPressed(class_437 screen, int keyCode, int scanCode) {
        return handleContainerKeyShortcut(screen, keyCode, scanCode);
    }

    public static boolean handleScreenMousePressed(class_437 screen, int button) {
        return handleContainerMouseShortcut(screen, button);
    }

    private static void onChatReceived(class_2561 message) {
        if (!Config.getIsVoidEnabled() && !Config.getIsThiefTabEnabled()) {
            return;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null) {
            return;
        }

        message.method_27658((style, text) -> {
            handleHoverItem(minecraft, style);
            return Optional.empty();
        }, class_2583.field_24360);
    }

    private static void onServerConnection(class_2535 connection) {
        if (!Config.getIsVoidEnabled()) {
            return;
        }

        Channel channel = ((ConnectionAccessor) connection).infinityItemEditorRe$getChannel();
        if (channel == null || channel.pipeline().get(VOID_HANDLER) != null) {
            return;
        }

        channel.pipeline().addBefore("packet_handler", VOID_HANDLER, new ChannelDuplexHandler() {
            @Override
            public void channelRead(ChannelHandlerContext context, Object message) throws Exception {
                if (message instanceof class_2744 packet) {
                    ModSource.voidBuffer.put(packet);
                }
                super.channelRead(context, message);
            }
        });
    }

    private static boolean handleContainerKeyShortcut(class_437 screen, int keyCode, int scanCode) {
        if (!(screen instanceof class_465<?> containerScreen)) {
            return false;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null || minecraft.field_1687 == null) {
            return false;
        }

        class_1735 slot = ((AbstractContainerScreenAccessor) containerScreen).infinityItemEditorRe$getHoveredSlot();
        if (slot == null) {
            return false;
        }

        if (class_437.method_25438(keyCode)) {
            return copyHoveredStack(minecraft, slot);
        }
        if (class_437.method_25437(keyCode)) {
            return pasteHoveredStack(minecraft, slot);
        }
        if (ClientKeyMappings.OPEN_EDITOR.method_1417(keyCode, scanCode)) {
            return openHoveredSlotEditor(minecraft, containerScreen, slot);
        }
        if (ClientKeyMappings.SAVE_REALM.method_1417(keyCode, scanCode)) {
            return saveHoveredStack(minecraft, screen, slot);
        }
        return false;
    }

    private static boolean handleContainerMouseShortcut(class_437 screen, int button) {
        if (!(screen instanceof class_465<?> containerScreen)) {
            return false;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null || minecraft.field_1687 == null) {
            return false;
        }

        class_1735 slot = ((AbstractContainerScreenAccessor) containerScreen).infinityItemEditorRe$getHoveredSlot();
        if (slot == null) {
            return false;
        }

        if (ClientKeyMappings.OPEN_EDITOR.method_1433(button)) {
            return openHoveredSlotEditor(minecraft, containerScreen, slot);
        }
        if (ClientKeyMappings.SAVE_REALM.method_1433(button)) {
            return saveHoveredStack(minecraft, screen, slot);
        }
        return false;
    }

    private static boolean openHoveredSlotEditor(class_310 minecraft, class_465<?> containerScreen, class_1735 slot) {
        if (!PlayerInventorySlots.isPlayerInventorySlot(minecraft.field_1724, slot)
                || !containerScreen.method_17577().method_34255().method_7960()) {
            return false;
        }

        int containerSlot = PlayerInventorySlots.toContainerSlot(slot);
        if (containerSlot < 0) {
            return false;
        }

        minecraft.method_1507(new ItemEditorScreen(slot.method_7677().method_7972(), containerSlot));
        return true;
    }

    private static boolean saveHoveredStack(class_310 minecraft, class_437 screen, class_1735 slot) {
        class_1799 stack = slot.method_7677();
        if (stack.method_7960() || minecraft.field_1724 == null) {
            return false;
        }

        RealmController realmController = ModSource.getOrCreateRealmController(minecraft.field_1697);
        if (realmController != null) {
            boolean realmChanged;
            if (isRealmCreativeTabSlot(minecraft, screen, slot)) {
                realmChanged = realmController.removeItemStack(minecraft.field_1724, stack);
            } else {
                realmChanged = realmController.addItemStack(minecraft.field_1724, stack.method_7972());
            }
            if (realmChanged) {
                CreativeTabRefresher.refreshRealm(minecraft);
            }
        }

        if (Config.getIsVoidEnabled()) {
            new VoidController(stack).addItemStack(minecraft.field_1724, stack.method_7972(), minecraft.field_1724.method_5667().toString().replace("-", ""));
        }
        return true;
    }

    private static boolean isRealmCreativeTabSlot(class_310 minecraft, class_437 screen, class_1735 slot) {
        if (!(screen instanceof class_481) || PlayerInventorySlots.isPlayerInventorySlot(minecraft.field_1724, slot)
                || CreativeTabRegistry.REALM == null) {
            return false;
        }

        class_1761 selectedTab = CreativeModeInventoryScreenAccessor.infinityItemEditorRe$getSelectedTab();
        return selectedTab == CreativeTabRegistry.REALM;
    }

    private static void handleHoverItem(class_310 minecraft, class_2583 style) {
        class_2568 hoverEvent = style.method_10969();
        if (hoverEvent == null) {
            return;
        }

        if (!(hoverEvent instanceof class_2568.class_10612 showItem)) {
            return;
        }

        class_1799 stack = showItem.comp_3509();
        if (stack.method_7960()) {
            return;
        }

        if (Config.getIsVoidEnabled()) {
            new VoidController(stack).addItemStack(minecraft.field_1724, stack.method_7972(), "chat");
        }
        if (Config.getIsThiefTabEnabled() && ClientCreativeTabData.rememberChatLinkedItem(stack)) {
            CreativeTabRefresher.refreshThief(minecraft);
        }
    }

    private static boolean copyHoveredStack(class_310 minecraft, class_1735 slot) {
        if (!slot.method_7681()) {
            return false;
        }

        minecraft.field_1774.method_1455(GiveHelper.getStringFromItemStack(slot.method_7677()));
        return true;
    }

    private static boolean pasteHoveredStack(class_310 minecraft, class_1735 slot) {
        if (minecraft.field_1724 == null || minecraft.field_1687 == null || minecraft.field_1761 == null
                || !PlayerInventorySlots.isPlayerInventorySlot(minecraft.field_1724, slot)) {
            return false;
        }

        int containerSlot = PlayerInventorySlots.toContainerSlot(slot);
        if (containerSlot < 0) {
            return false;
        }

        if (!minecraft.field_1724.method_31549().field_7477) {
            minecraft.field_1724.method_7353(class_2561.method_43471("message." + ModSource.MODID + ".copy_requires_creative"), true);
            return true;
        }

        class_1799 pastedStack = GiveHelper.getItemStackFromString(
                minecraft.field_1774.method_1460(),
                minecraft.field_1687.method_30349()
        );
        if (pastedStack.method_7960()) {
            return false;
        }

        PlayerInventorySlots.setStack(minecraft.field_1724, containerSlot, pastedStack);
        minecraft.field_1761.method_2909(pastedStack.method_7972(), containerSlot);
        return true;
    }

    private static void copyTarget(class_310 minecraft) {
        if (minecraft.field_1724 == null || minecraft.field_1761 == null) {
            return;
        }

        class_1297 target = minecraft.field_1692;
        if (target == null && minecraft.field_1765 instanceof class_3966 entityHitResult) {
            target = entityHitResult.method_17782();
        }

        if (target instanceof class_1309 livingEntity) {
            copyTargetEquipment(minecraft, livingEntity);
            return;
        }

        if (minecraft.field_1765 instanceof class_3965 blockHitResult) {
            copyTargetBlock(minecraft, blockHitResult);
            return;
        }

        minecraft.field_1724.method_7353(class_2561.method_43471("message." + ModSource.MODID + ".copy_no_target"), true);
    }

    private static void copyTargetEquipment(class_310 minecraft, class_1309 livingEntity) {
        if (!minecraft.field_1724.method_31549().field_7477) {
            minecraft.field_1724.method_7353(class_2561.method_43471("message." + ModSource.MODID + ".copy_requires_creative"), true);
            return;
        }

        copyEquipmentSlot(minecraft, livingEntity, class_1304.field_6173, 36 + minecraft.field_1724.method_31548().method_67532());
        copyEquipmentSlot(minecraft, livingEntity, class_1304.field_6171, PlayerInventorySlots.OFFHAND_CONTAINER_SLOT);
        copyEquipmentSlot(minecraft, livingEntity, class_1304.field_6169, PlayerInventorySlots.HEAD_CONTAINER_SLOT);
        copyEquipmentSlot(minecraft, livingEntity, class_1304.field_6174, PlayerInventorySlots.CHEST_CONTAINER_SLOT);
        copyEquipmentSlot(minecraft, livingEntity, class_1304.field_6172, PlayerInventorySlots.LEGS_CONTAINER_SLOT);
        copyEquipmentSlot(minecraft, livingEntity, class_1304.field_6166, PlayerInventorySlots.FEET_CONTAINER_SLOT);

        minecraft.field_1724.method_7353(class_2561.method_43469("message." + ModSource.MODID + ".copying", livingEntity.method_5476()), true);
    }

    private static void copyTargetBlock(class_310 minecraft, class_3965 blockHitResult) {
        if (minecraft.field_1724 == null || minecraft.field_1687 == null || minecraft.field_1761 == null) {
            return;
        }

        class_2338 blockPos = blockHitResult.method_17777();
        class_2680 blockState = minecraft.field_1687.method_8320(blockPos);
        if (blockState.method_26215()) {
            minecraft.field_1724.method_7353(class_2561.method_43471("message." + ModSource.MODID + ".copy_no_target"), true);
            return;
        }

        boolean controlDown = class_437.method_25441();
        class_1799 stack = blockState.method_65171(minecraft.field_1687, blockPos, controlDown);
        if (stack.method_7960()) {
            minecraft.field_1724.method_7353(class_2561.method_43471("message." + ModSource.MODID + ".copy_empty_block"), true);
            return;
        }

        if (controlDown && blockState.method_31709()) {
            class_2586 blockEntity = minecraft.field_1687.method_8321(blockPos);
            if (blockEntity != null) {
                addCustomNbtData(stack, blockEntity);
            }
        }

        stack.method_7939(1);
        minecraft.field_1774.method_1455(GiveHelper.getStringFromItemStack(stack));
        if (controlDown) {
            RealmController realmController = ModSource.getOrCreateRealmController(minecraft.field_1697);
            if (realmController != null) {
                if (realmController.addItemStack(minecraft.field_1724, stack.method_7972())) {
                    CreativeTabRefresher.refreshRealm(minecraft);
                }
            }
        }

        if (!minecraft.field_1724.method_31549().field_7477) {
            if (!controlDown) {
                minecraft.field_1724.method_7353(class_2561.method_43471("message." + ModSource.MODID + ".copy_requires_creative"), true);
            }
            return;
        }

        setPickedItem(minecraft, stack);
        minecraft.field_1761.method_2909(minecraft.field_1724.method_31548().method_7391(), 36 + minecraft.field_1724.method_31548().method_67532());
        minecraft.field_1724.method_7353(class_2561.method_43469("message." + ModSource.MODID + ".copying", stack.method_7964()), true);
    }

    private static void addCustomNbtData(class_1799 stack, class_2586 blockEntity) {
        class_11362 blockEntityOutput = class_11362.method_71459(class_8942.field_60348, ItemStackNbt.provider());
        blockEntity.method_71401(blockEntityOutput);
        blockEntity.method_57569(blockEntityOutput);
        class_1747.method_57338(stack, blockEntity.method_11017(), blockEntityOutput);
        stack.method_57365(blockEntity.method_57590());
        if (stack.method_7909() instanceof class_1809) {
            class_2487 stackTag = ItemStackNbt.get(stack);
            if (stackTag != null && stackTag.method_10545(BLOCK_ENTITY_TAG)) {
                class_2487 stackBlockEntityTag = stackTag.method_68568(BLOCK_ENTITY_TAG);
                if (stackBlockEntityTag.method_10545(SKULL_OWNER_TAG)) {
                    stackTag.method_10566(SKULL_OWNER_TAG, stackBlockEntityTag.method_68568(SKULL_OWNER_TAG));
                    stackBlockEntityTag.method_10551(SKULL_OWNER_TAG);
                    cleanupCopiedBlockEntityTag(stackTag, stackBlockEntityTag);
                    return;
                }
            }
        }

        if (hasCopiedBlockEntityData(stack)) {
            addCopiedNbtLore(stack);
        }
    }

    private static void cleanupCopiedBlockEntityTag(class_2487 stackTag, class_2487 blockEntityTag) {
        blockEntityTag.method_10551("x");
        blockEntityTag.method_10551("y");
        blockEntityTag.method_10551("z");
        if (blockEntityTag.method_33133() || isOnlyBlockEntityId(blockEntityTag)) {
            stackTag.method_10551(BLOCK_ENTITY_TAG);
        } else {
            stackTag.method_10566(BLOCK_ENTITY_TAG, blockEntityTag);
        }
    }

    private static boolean isOnlyBlockEntityId(class_2487 blockEntityTag) {
        return blockEntityTag.method_10546() == 1 && blockEntityTag.method_10545(BLOCK_ENTITY_ID_TAG);
    }

    private static boolean hasCopiedBlockEntityData(class_1799 stack) {
        class_2487 tag = ItemStackNbt.get(stack);
        return tag != null && tag.method_10545(BLOCK_ENTITY_TAG);
    }

    private static void addCopiedNbtLore(class_1799 stack) {
        class_2487 displayTag = ItemStackNbt.getOrCreateElement(stack, DISPLAY_TAG);
        class_2499 lore = displayTag.method_10545(LORE_TAG)
                ? displayTag.method_68569(LORE_TAG).method_10612()
                : new class_2499();
        lore.add(class_2519.method_23256(COPIED_NBT_LORE));
        displayTag.method_10566(LORE_TAG, lore);
    }

    private static void setPickedItem(class_310 minecraft, class_1799 stack) {
        class_1661 inventory = minecraft.field_1724.method_31548();
        int slot = inventory.method_7395(stack);
        if (slot != -1) {
            if (class_1661.method_7380(slot)) {
                inventory.method_61496(slot);
            } else {
                inventory.method_7365(slot);
            }
        } else {
            inventory.method_65126(stack);
        }
    }

    private static void copyEquipmentSlot(class_310 minecraft, class_1309 source, class_1304 slot, int containerSlot) {
        class_1799 stack = source.method_6118(slot).method_7972();
        if (!stack.method_7960()) {
            stack.method_7939(1);
        }
        minecraft.field_1761.method_2909(stack, containerSlot);

        switch (slot) {
            case field_6173 -> minecraft.field_1724.method_31548().method_5447(minecraft.field_1724.method_31548().method_67532(), stack);
            case field_6171 -> minecraft.field_1724.method_5673(class_1304.field_6171, stack);
            case field_6169, field_6174, field_6172, field_6166 -> minecraft.field_1724.method_5673(slot, stack);
        }
    }
}
