package io.github.seraphina.infinity_item_editor_re.util;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/** Verifies that the server kept the item that was written to a slot. */
public final class SaveVerifier {
    private static String expectedNbt;
    private static class_1799 sentStack;
    private static int slot = -1;
    private static int ticks;

    private SaveVerifier() {
    }

    public static void expect(class_1799 stack, String nbt, int inventorySlot) {
        if (inventorySlot < 0 || inventorySlot >= 41) {
            return;
        }
        sentStack = stack.method_7972();
        expectedNbt = nbt;
        slot = inventorySlot;
        ticks = 0;
    }

    public static void tick(class_310 minecraft) {
        if (slot < 0 || expectedNbt == null) {
            return;
        }
        if (minecraft == null || minecraft.field_1724 == null) {
            return;
        }

        ticks++;
        String current;
        try {
            current = ItemStackNbt.save(minecraft.field_1724.method_31548().method_5438(slot)).toString();
        } catch (RuntimeException exception) {
            current = "<unreadable>";
        }
        if (current.equals(expectedNbt)) {
            clear();
            return;
        }
        if (ticks < 60) {
            return;
        }

        ModSource.LOGGER.warn("Infinity Item Editor: the server rewrote the saved item. sent={} received={}",
                expectedNbt, current);
        minecraft.field_1724.method_7353(
                class_2561.method_43471("message." + ModSource.MODID + ".editor_server_rewrote"), false);
        if (sentStack != null && !sentStack.method_7960()) {
            minecraft.field_1774.method_1455(GiveHelper.getStringFromItemStack(sentStack));
            minecraft.field_1724.method_7353(
                    class_2561.method_43471("message." + ModSource.MODID + ".editor_give_copied"), false);
        }
        clear();
    }

    private static void clear() {
        expectedNbt = null;
        sentStack = null;
        slot = -1;
        ticks = 0;
    }
}
