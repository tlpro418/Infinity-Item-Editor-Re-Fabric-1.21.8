package io.github.seraphina.infinity_item_editor_re.client;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackCompat;

import io.github.seraphina.infinity_item_editor_re.util.ComponentCompat;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import io.github.seraphina.infinity_item_editor_re.client.screen.BannerPatternCatalog;
import io.github.seraphina.infinity_item_editor_re.util.NbtCompat;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1746;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_2573;
import net.minecraft.class_2586;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_9283;
public final class ClientCreativeTabData {
    private static final int HOTBAR_SIZE = 9;
    private static final int MAX_CHAT_LINKED_ITEMS = 256;
    private static final class_9283.class_1782[] FIREWORK_SHAPES = {
            class_9283.class_1782.field_7976,
            class_9283.class_1782.field_7977,
            class_9283.class_1782.field_7973,
            class_9283.class_1782.field_7974,
            class_9283.class_1782.field_7970
    };
    private static final List<class_1799> CHAT_LINKED_ITEMS = new ArrayList<>();

    private ClientCreativeTabData() {
    }

    public static void addPlayerHeads(List<class_1799> heads) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null || minecraft.field_1687 == null) {
            return;
        }

        addPlayerHead(heads, minecraft.field_1724);
        for (class_1657 player : minecraft.field_1687.method_18456()) {
            if (player != minecraft.field_1724) {
                addPlayerHead(heads, player);
            }
        }
    }

    public static void addThiefItems(List<class_1799> stacks) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null || minecraft.field_1687 == null) {
            addChatLinkedItems(stacks);
            return;
        }

        for (class_1657 player : minecraft.field_1687.method_18456()) {
            if (player == minecraft.field_1724 || player.method_5667().equals(minecraft.field_1724.method_5667())) {
                continue;
            }
            addPlayerEquipment(stacks, player);
        }

        addChatLinkedItems(stacks);
    }

    public static boolean rememberChatLinkedItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }

        class_1799 copy = stack.method_7972();
        copy.method_7939(1);
        for (class_1799 existingStack : CHAT_LINKED_ITEMS) {
            if (ItemStackCompat.isSameItemSameTags(existingStack, copy)) {
                return false;
            }
        }

        CHAT_LINKED_ITEMS.add(0, copy);
        while (CHAT_LINKED_ITEMS.size() > MAX_CHAT_LINKED_ITEMS) {
            CHAT_LINKED_ITEMS.remove(CHAT_LINKED_ITEMS.size() - 1);
        }
        return true;
    }

    public static void addFireworkVariants(List<class_1799> stacks) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null) {
            return;
        }

        class_1799 currentStar = class_1799.field_8037;
        class_1799 currentRocket = class_1799.field_8037;
        int size = Math.min(HOTBAR_SIZE, minecraft.field_1724.method_31548().method_5439());
        for (int slot = 0; slot < size; slot++) {
            class_1799 stack = minecraft.field_1724.method_31548().method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }

            if (currentStar.method_7960() && stack.method_31574(class_1802.field_8450)) {
                currentStar = stack;
            } else if (currentRocket.method_7960() && stack.method_31574(class_1802.field_8639)) {
                currentRocket = stack;
            }
        }

        addRocketFlightVariants(stacks, currentRocket);
        if (currentStar.method_7960() || ItemStackNbt.getElement(currentStar, "Explosion") == null) {
            addDefaultFireworkStars(stacks);
            return;
        }

        addStarToggleVariants(stacks, currentStar);
        addRocketWithStar(stacks, currentRocket, currentStar);
    }

    public static void addBannerVariants(List<class_1799> stacks) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null) {
            return;
        }

        class_1799 currentBanner = class_1799.field_8037;
        int size = Math.min(HOTBAR_SIZE, minecraft.field_1724.method_31548().method_5439());
        for (int slot = 0; slot < size; slot++) {
            class_1799 stack = minecraft.field_1724.method_31548().method_5438(slot);
            if (isBannerEditable(stack)) {
                currentBanner = stack;
                break;
            }
        }

        if (currentBanner.method_7960()) {
            addPlacedBannerItems(stacks, minecraft);
            return;
        }

        addBannerSwapVariant(stacks, currentBanner);
        addBannerPatternVariants(stacks, currentBanner);
    }

    private static void addPlayerHead(List<class_1799> heads, class_1657 player) {
        if (player == null || player.method_7334() == null) {
            return;
        }

        String owner = player.method_7334().getName();
        if (owner == null || owner.isBlank()) {
            return;
        }

        addUnique(heads, createPlayerHead(owner));
    }

    private static void addPlayerEquipment(List<class_1799> stacks, class_1657 player) {
        boolean addedNote = false;
        class_1799 note = createNote("Stolen from " + player.method_5477().getString());
        for (int slot = 0; slot < class_1661.method_7368(); slot++) {
            addedNote = addStackWithNote(stacks, player.method_31548().method_5438(slot), note, addedNote);
        }
        addedNote = addStackWithNote(stacks, player.method_6118(class_1304.field_6171), note, addedNote);
        for (class_1304 slot : class_1304.values()) {
            if (slot.method_46643()) {
                addedNote = addStackWithNote(stacks, player.method_6118(slot), note, addedNote);
            }
        }
    }

    private static void addChatLinkedItems(List<class_1799> stacks) {
        boolean addedNote = false;
        class_1799 note = createNote("Linked in chat", "Items linked in chat, such as death messages");
        for (class_1799 stack : CHAT_LINKED_ITEMS) {
            addedNote = addStackWithNote(stacks, stack, note, addedNote);
        }
    }

    private static boolean addStackWithNote(List<class_1799> stacks, class_1799 stack, class_1799 note, boolean addedNote) {
        if (stack == null || stack.method_7960() || containsStack(stacks, stack)) {
            return addedNote;
        }

        if (!addedNote) {
            addUnique(stacks, note);
            addedNote = true;
        }
        addUnique(stacks, stack);
        return true;
    }

    private static void addRocketFlightVariants(List<class_1799> stacks, class_1799 currentRocket) {
        if (currentRocket.method_7960() || ItemStackNbt.getElement(currentRocket, "Fireworks") == null) {
            return;
        }

        for (byte flight = 1; flight <= 4; flight++) {
            class_1799 rocket = currentRocket.method_7972();
            rocket.method_7939(1);
            ItemStackNbt.getOrCreateElement(rocket, "Fireworks").method_10567("Flight", flight);
            addUnique(stacks, rocket);
        }
    }

    private static void addDefaultFireworkStars(List<class_1799> stacks) {
        for (byte type = 0; type < 5; type++) {
            for (class_1767 color : class_1767.values()) {
                class_1799 star = new class_1799(class_1802.field_8450);
                class_2487 explosion = ItemStackNbt.getOrCreateElement(star, "Explosion");
                explosion.method_10567("Type", (byte) getFireworkShape(type).method_7816());
                explosion.method_10539("Colors", new int[]{color.method_7790()});
                addUnique(stacks, star);
            }
        }
    }

    private static class_9283.class_1782 getFireworkShape(int type) {
        if (type < 0 || type >= FIREWORK_SHAPES.length) {
            return class_9283.class_1782.field_7976;
        }
        return FIREWORK_SHAPES[type];
    }

    private static void addStarToggleVariants(List<class_1799> stacks, class_1799 currentStar) {
        addStarToggleVariant(stacks, currentStar, "Flicker", false);
        addStarToggleVariant(stacks, currentStar, "Flicker", true);
        addStarToggleVariant(stacks, currentStar, "Trail", false);
        addStarToggleVariant(stacks, currentStar, "Trail", true);
    }

    private static void addStarToggleVariant(List<class_1799> stacks, class_1799 currentStar, String key, boolean enabled) {
        class_1799 star = currentStar.method_7972();
        star.method_7939(1);
        ItemStackNbt.getOrCreateElement(star, "Explosion").method_10556(key, enabled);
        addUnique(stacks, star);
    }

    private static void addRocketWithStar(List<class_1799> stacks, class_1799 currentRocket, class_1799 currentStar) {
        class_2487 starExplosion = ItemStackNbt.getElement(currentStar, "Explosion");
        if (starExplosion == null) {
            return;
        }

        class_1799 rocket = currentRocket.method_7960() ? new class_1799(class_1802.field_8639) : currentRocket.method_7972();
        rocket.method_7939(1);
        class_2487 fireworks = ItemStackNbt.getOrCreateElement(rocket, "Fireworks");
        class_2499 explosions = fireworks.method_10545("Explosions")
                ? fireworks.method_68569("Explosions").method_10612()
                : new class_2499();

        if (explosions.isEmpty()) {
            explosions.add(starExplosion.method_10553());
        } else if (starExplosion.method_10545("Colors")) {
            int[] fadeColors = NbtCompat.getIntArray(starExplosion, "Colors");
            for (int index = 0; index < explosions.size(); index++) {
                explosions.method_68582(index).method_10539("FadeColors", fadeColors);
            }
        } else {
            explosions.add(starExplosion.method_10553());
        }

        fireworks.method_10566("Explosions", explosions);
        addUnique(stacks, rocket);
    }

    private static void addPlacedBannerItems(List<class_1799> stacks, class_310 minecraft) {
        if (minecraft.field_1687 == null || minecraft.field_1724 == null) {
            return;
        }

        class_1923 center = minecraft.field_1724.method_31476();
        int radius = Math.max(2, minecraft.field_1690.method_38521());
        for (int chunkZ = center.field_9180 - radius; chunkZ <= center.field_9180 + radius; chunkZ++) {
            for (int chunkX = center.field_9181 - radius; chunkX <= center.field_9181 + radius; chunkX++) {
                class_2818 chunk = minecraft.field_1687.method_2935().method_2857(chunkX, chunkZ, class_2806.field_12803, false);
                if (chunk == null) {
                    continue;
                }

                for (class_2586 blockEntity : chunk.method_12214().values()) {
                    if (blockEntity instanceof class_2573 bannerBlockEntity) {
                        addUnique(stacks, bannerBlockEntity.method_10907());
                    }
                }
            }
        }
    }

    private static void addBannerSwapVariant(List<class_1799> stacks, class_1799 currentBanner) {
        class_1767 baseColor = getBannerBaseColor(currentBanner);
        class_1799 swapped;
        if (currentBanner.method_31574(class_1802.field_8255)) {
            swapped = new class_1799(BannerPatternCatalog.itemByDyeId(baseColor.method_7789()));
            copyBannerBlockEntity(currentBanner, swapped);
            removeBannerBaseColor(swapped);
        } else {
            swapped = new class_1799(class_1802.field_8255);
            copyBannerBlockEntity(currentBanner, swapped);
            ItemStackNbt.getOrCreateElement(swapped, "BlockEntityTag").method_10569("Base", baseColor.method_7789());
        }

        addUnique(stacks, swapped);
    }

    private static void addBannerPatternVariants(List<class_1799> stacks, class_1799 currentBanner) {
        class_1767 baseColor = getBannerBaseColor(currentBanner);
        for (String patternHash : BannerPatternCatalog.patternHashes()) {
            for (class_1767 color : class_1767.values()) {
                class_1799 variant = currentBanner.method_7972();
                variant.method_7939(1);
                class_2487 blockEntity = ItemStackNbt.getOrCreateElement(variant, "BlockEntityTag");
                if (variant.method_31574(class_1802.field_8255) && !blockEntity.method_10545("Base")) {
                    blockEntity.method_10569("Base", baseColor.method_7789());
                }

                class_2499 patterns = blockEntity.method_10545("Patterns")
                        ? blockEntity.method_68569("Patterns").method_10612()
                        : new class_2499();
                class_2487 pattern = new class_2487();
                pattern.method_10582("Pattern", patternHash);
                pattern.method_10569("Color", color.method_7789());
                patterns.add(pattern);
                blockEntity.method_10566("Patterns", patterns);
                addUnique(stacks, variant);
            }
        }
    }

    private static boolean isBannerEditable(class_1799 stack) {
        return stack != null && !stack.method_7960() && (stack.method_7909() instanceof class_1746 || stack.method_31574(class_1802.field_8255));
    }

    private static class_1767 getBannerBaseColor(class_1799 stack) {
        if (stack.method_7909() instanceof class_1746 bannerItem) {
            return bannerItem.method_7706();
        }

        class_2487 blockEntity = ItemStackNbt.getElement(stack, "BlockEntityTag");
        if (blockEntity != null && blockEntity.method_10545("Base")) {
            return class_1767.method_7791(blockEntity.method_68083("Base", 0));
        }

        return class_1767.field_7952;
    }

    private static void copyBannerBlockEntity(class_1799 source, class_1799 target) {
        class_2487 blockEntity = ItemStackNbt.getElement(source, "BlockEntityTag");
        if (blockEntity != null) {
            ItemStackNbt.getOrCreate(target).method_10566("BlockEntityTag", blockEntity.method_10553());
        }
    }

    private static void removeBannerBaseColor(class_1799 stack) {
        class_2487 tag = ItemStackNbt.get(stack);
        if (tag == null) {
            return;
        }

        class_2487 blockEntity = tag.method_68568("BlockEntityTag");
        blockEntity.method_10551("Base");
        if (blockEntity.method_33133()) {
            tag.method_10551("BlockEntityTag");
        } else {
            tag.method_10566("BlockEntityTag", blockEntity);
        }
        if (tag.method_33133()) {
            ItemStackNbt.set(stack, null);
        }
    }

    private static class_1799 createPlayerHead(String owner) {
        class_1799 stack = new class_1799(class_1802.field_8575);
        ItemStackNbt.getOrCreate(stack).method_10582("SkullOwner", owner);
        class_2487 display = ItemStackNbt.getOrCreateElement(stack, "display");
        display.method_10582("Name", ComponentCompat.toJson(net.minecraft.class_2561.method_43470(owner + "'s Head")));
        return stack;
    }

    private static class_1799 createNote(String noteName, String... lore) {
        class_1799 stack = new class_1799(class_1802.field_8407);
        ItemStackCompat.setHoverName(stack, class_2561.method_43470(noteName));
        if (lore != null && lore.length > 0) {
            class_2499 loreTag = new class_2499();
            for (String line : lore) {
                loreTag.add(class_2519.method_23256(ComponentCompat.toJson(class_2561.method_43470(line))));
            }
            ItemStackNbt.getOrCreateElement(stack, "display").method_10566("Lore", loreTag);
        }
        return stack;
    }

    private static boolean containsStack(List<class_1799> stacks, class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }

        for (class_1799 existingStack : stacks) {
            if (ItemStackCompat.isSameItemSameTags(existingStack, stack)) {
                return true;
            }
        }
        return false;
    }

    private static void addUnique(List<class_1799> stacks, class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return;
        }

        class_1799 copy = stack.method_7972();
        copy.method_7939(1);
        for (class_1799 existingStack : stacks) {
            if (ItemStackCompat.isSameItemSameTags(existingStack, copy)) {
                return;
            }
        }

        stacks.add(copy);
    }
}
