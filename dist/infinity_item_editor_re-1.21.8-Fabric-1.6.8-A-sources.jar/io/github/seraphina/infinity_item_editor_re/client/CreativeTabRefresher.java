package io.github.seraphina.infinity_item_editor_re.client;

import io.github.seraphina.infinity_item_editor_re.init.CreativeTabRegistry;
import io.github.seraphina.infinity_item_editor_re.mixin.client.CreativeModeInventoryScreenAccessor;
import net.minecraft.class_1761;
import net.minecraft.class_310;
import net.minecraft.class_481;
import net.minecraft.class_7706;

public final class CreativeTabRefresher {
    private CreativeTabRefresher() {
    }

    public static void refreshRealm(class_310 minecraft) {
        if (CreativeTabRegistry.REALM == null) {
            return;
        }

        refresh(minecraft, CreativeTabRegistry.REALM);
    }

    public static void refreshThief(class_310 minecraft) {
        if (CreativeTabRegistry.THIEF == null) {
            return;
        }

        refresh(minecraft, CreativeTabRegistry.THIEF);
    }

    public static void rebuildAllTabs(class_310 minecraft) {
        if (minecraft == null || minecraft.field_1724 == null) {
            return;
        }

        class_1761.class_8128 parameters = createParameters(minecraft);
        class_7706.method_47341().stream()
                .filter(tab -> tab.method_47312() == class_1761.class_7916.field_41052)
                .forEach(tab -> tab.method_47306(parameters));
        class_7706.method_47341().stream()
                .filter(tab -> tab.method_47312() != class_1761.class_7916.field_41052)
                .forEach(tab -> tab.method_47306(parameters));
        refreshOpenScreen(minecraft);
    }

    private static void refresh(class_310 minecraft, class_1761 tab) {
        if (minecraft == null || minecraft.field_1724 == null) {
            return;
        }

        tab.method_47306(createParameters(minecraft));
        refreshOpenScreen(minecraft, tab);
    }

    private static class_1761.class_8128 createParameters(class_310 minecraft) {
        boolean hasPermissions = minecraft.field_1724.method_7338() && minecraft.field_1690.method_47395().method_41753();
        return new class_1761.class_8128(
                minecraft.field_1724.field_3944.method_45735(),
                hasPermissions,
                minecraft.field_1724.method_37908().method_30349()
        );
    }

    private static void refreshOpenScreen(class_310 minecraft) {
        if (!(minecraft.field_1755 instanceof class_481 creativeScreen)) {
            return;
        }

        class_1761 selectedTab = CreativeModeInventoryScreenAccessor.infinityItemEditorRe$getSelectedTab();
        CreativeModeInventoryScreenAccessor accessor = (CreativeModeInventoryScreenAccessor) creativeScreen;
        if (!selectedTab.method_47311()) {
            accessor.infinityItemEditorRe$selectTab(class_7706.method_47328());
            return;
        }

        accessor.infinityItemEditorRe$refreshCurrentTabContents(selectedTab.method_47313());
    }

    private static void refreshOpenScreen(class_310 minecraft, class_1761 tab) {
        if (minecraft.field_1755 instanceof class_481
                && CreativeModeInventoryScreenAccessor.infinityItemEditorRe$getSelectedTab() == tab) {
            ((CreativeModeInventoryScreenAccessor) minecraft.field_1755).infinityItemEditorRe$refreshCurrentTabContents(tab.method_47313());
        }
    }
}
