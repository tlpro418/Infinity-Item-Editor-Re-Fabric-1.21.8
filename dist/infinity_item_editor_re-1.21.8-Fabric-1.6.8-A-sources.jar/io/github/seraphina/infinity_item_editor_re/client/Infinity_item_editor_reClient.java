package io.github.seraphina.infinity_item_editor_re.client;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.eventhandlers.ClientEvents;
import io.github.seraphina.infinity_item_editor_re.eventhandlers.ClientKeyMappings;
import io.github.seraphina.infinity_item_editor_re.init.CreativeTabRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_310;

public class Infinity_item_editor_reClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        class_310 minecraft = class_310.method_1551();
        ModSource.initClientStorage(minecraft.field_1697);
        CreativeTabRegistry.register();
        ClientKeyMappings.register();
        ClientEvents.register();
        ModSource.startVoidConsumer();
    }
}



