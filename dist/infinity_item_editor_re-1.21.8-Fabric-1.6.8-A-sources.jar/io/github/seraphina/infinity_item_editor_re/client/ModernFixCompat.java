package io.github.seraphina.infinity_item_editor_re.client;

import java.lang.reflect.Field;
import net.minecraft.class_1761;
import net.minecraft.class_7706;

public final class ModernFixCompat {
    private static Field CACHE_FIELD;
    private static boolean LOADED = false;

    static {
        try {
            CACHE_FIELD = class_1761.class.getDeclaredField("mfix$oldParameters");
            CACHE_FIELD.setAccessible(true);
            LOADED = true;
        } catch (NoSuchFieldException ignored) {}
    }

    public static void clearAllCaches() {
        if (!LOADED) return;
        try {
            for (class_1761 tab : class_7706.method_47341()) {
                CACHE_FIELD.set(tab, null);
            }
        } catch (Exception ignored) {}
    }

    public static void clearCache(class_1761 tab) {
        if (LOADED) {
            try {
                CACHE_FIELD.set(tab, null);
            } catch (IllegalAccessException ignored) {}
        }
    }
}
