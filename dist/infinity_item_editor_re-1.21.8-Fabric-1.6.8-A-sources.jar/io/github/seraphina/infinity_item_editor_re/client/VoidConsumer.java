package io.github.seraphina.infinity_item_editor_re.client;

import com.mojang.datafixers.util.Pair;
import io.github.seraphina.infinity_item_editor_re.data.voids.VoidBuffer;
import io.github.seraphina.infinity_item_editor_re.data.voids.VoidController;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2744;
import net.minecraft.class_310;

public class VoidConsumer implements Runnable {
    private final VoidBuffer buffer;

    public VoidConsumer(VoidBuffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            class_2744 packet = buffer.get();
            if (packet == null) {
                continue;
            }

            class_310 minecraft = class_310.method_1551();
            minecraft.execute(() -> processPacket(minecraft, packet));
        }
    }

    private static void processPacket(class_310 minecraft, class_2744 packet) {
        if (minecraft.field_1687 == null || minecraft.field_1724 == null) {
            return;
        }

        class_1297 entity = minecraft.field_1687.method_8469(packet.method_11820());
        String uuid = entity instanceof class_1657 player ? player.method_5845().replace("-", "") : null;

        for (Pair<class_1304, class_1799> slot : packet.method_30145()) {
            class_1799 stack = slot.getSecond();
            if (!stack.method_7960()) {
                new VoidController(stack).addItemStack(minecraft.field_1724, stack.method_7972(), uuid);
            }
        }
    }
}
