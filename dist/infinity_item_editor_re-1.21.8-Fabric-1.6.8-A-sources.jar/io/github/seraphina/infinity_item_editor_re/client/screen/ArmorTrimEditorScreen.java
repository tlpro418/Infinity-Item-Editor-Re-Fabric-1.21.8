package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1642;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_6880;
import net.minecraft.class_8053;
import net.minecraft.class_8054;
import net.minecraft.class_8056;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import io.github.seraphina.infinity_item_editor_re.util.Tooltips;

final class ArmorTrimEditorScreen extends class_437 {
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 6;
    private static final int SCREEN_MARGIN = 10;
    private static final int PANEL_TOP = 34;
    private static final int PANEL_PADDING = 8;
    private static final int DROPDOWN_HEIGHT = 20;
    private static final int DROPDOWN_ROW_HEIGHT = 18;
    private static final int DROPDOWN_MAX_ROWS = 7;
    private static final int TRIM_ROW_HEIGHT = 12;
    private static final int PANEL_FILL = 0xDE323232;
    private static final int PANEL_SHADOW = 0xAA000000;
    private static final int FIELD_FILL = 0xFF1F1F1F;
    private static final int FIELD_DISABLED = 0xFF262626;
    private static final int ROW_HOVER = 0x171FFFFF;
    private static final int ROW_SELECTED = 0x332880FF;
    private static final int TEXT_PRIMARY = 0xFFFFFFFF;
    private static final int TEXT_MUTED = 0xFFAAAAAA;
    private static final int STATUS_GOOD = 0xFF32CC64;
    private static final int STATUS_BAD = 0xFFF44262;
    private static final int STATUS_NEUTRAL = 0xFFFFD966;
    private static final int PREVIEW_ARMOR_STAND = 0;
    private static final int PREVIEW_PLAYER = 1;
    private static final int PREVIEW_ZOMBIE = 2;
    private static final String ARMOR_TRIMS_CUSTOM_DATA_TAG = "InfinityItemEditorArmorTrims";
    private static final String ARMOR_TRIM_MATERIAL_TAG = "material";
    private static final String ARMOR_TRIM_PATTERN_TAG = "pattern";

    private final ItemEditorScreen lastScreen;
    private class_1799 armorStack;
    private class_2561 status = class_2561.method_43473();
    private int statusColor = STATUS_NEUTRAL;
    private int selectedMaterialIndex;
    private int selectedPatternIndex;
    private int previewEntity = PREVIEW_ARMOR_STAND;
    private int materialDropdownScroll;
    private int patternDropdownScroll;
    private int trimListScroll;
    private int lastMouseX;
    private int lastMouseY;
    private boolean materialDropdownOpen;
    private boolean patternDropdownOpen;
    private class_1531 armorStandPreview;
    private class_1642 zombiePreview;

    ArmorTrimEditorScreen(ItemEditorScreen lastScreen, class_1799 stack) {
        super(class_2561.method_43471(key("armortrim")));
        this.lastScreen = lastScreen;
        this.armorStack = stack.method_7972();
        syncSelectionFromStack();
    }

    @Override
    protected void method_25426() {
        addControls();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            returnToLastScreen();
            return true;
        }
        if (isInventoryKey(keyCode, scanCode)) {
            returnToLastScreen();
            return true;
        }
        if (class_437.method_25441() && keyCode == 83) {
            applySelectedTrim();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.lastMouseX = mouseX;
        this.lastMouseY = mouseY;
        TrimEditorLayout layout = layout();

        EditorBackgrounds.render(guiGraphics, this.field_22789, this.field_22790);
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 10, InfinityEditorButton.MAIN_COLOR);

        renderTrimList(guiGraphics, layout, mouseX, mouseY);
        renderPreview(guiGraphics, layout);
        renderControlPanel(guiGraphics, layout, mouseX, mouseY);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderOpenDropdown(guiGraphics, layout, mouseX, mouseY);

        if (!this.status.getString().isEmpty()) {
            drawCenteredClipped(guiGraphics, this.status, layout.previewCenterX(),
                    layout.bottom() - 14, layout.previewWidth() - 12, this.statusColor);
        }
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && handleDropdownClick(mouseX, mouseY)) {
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        int direction = -(int) Math.signum(scrollY);
        if (direction == 0) {
            return true;
        }

        TrimEditorLayout layout = layout();
        if (this.materialDropdownOpen && isMouseOverDropdown(mouseX, mouseY, layout, true, getMaterials().size())) {
            scrollMaterialDropdown(direction);
            return true;
        }
        if (this.patternDropdownOpen && isMouseOverDropdown(mouseX, mouseY, layout, false, getPatterns().size())) {
            scrollPatternDropdown(direction);
            return true;
        }
        if (isMouseIn(mouseX, mouseY, layout.leftX(), layout.leftY(), layout.leftWidth(), layout.height())) {
            scrollTrimList(direction);
            return true;
        }

        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void method_25419() {
        returnToLastScreen();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void addControls() {
        List<ArmorTrimMaterialEntry> materials = getMaterials();
        List<ArmorTrimPatternEntry> patterns = getPatterns();
        clampSelection(materials, patterns);
        TrimEditorLayout layout = layout();

        int x = controlX(layout);
        int buttonWidth = twoColumnButtonWidth(layout);
        int fullWidth = controlWidth(layout);
        int previewButtonY = previewButtonY(layout);
        int actionTop = actionButtonsY(layout);

        method_37063(new InfinityEditorButton(x, previewButtonY, fullWidth, BUTTON_HEIGHT,
                class_2561.method_43469(key("armortrim.preview"), getPreviewEntityName()),
                button -> cyclePreviewEntity()));

        InfinityEditorButton apply = method_37063(new InfinityEditorButton(x, actionTop, buttonWidth, BUTTON_HEIGHT,
                class_2561.method_43471(key("armortrim.apply")), button -> applySelectedTrim()));
        apply.field_22763 = !materials.isEmpty() && !patterns.isEmpty();

        InfinityEditorButton add = method_37063(new InfinityEditorButton(x + buttonWidth + BUTTON_GAP, actionTop,
                buttonWidth, BUTTON_HEIGHT, class_2561.method_43471(key("armortrim.add")), button -> addSelectedTrim()));
        add.field_22763 = !materials.isEmpty() && !patterns.isEmpty();

        int secondRowY = actionTop + BUTTON_HEIGHT + BUTTON_GAP;
        InfinityEditorButton remove = method_37063(new InfinityEditorButton(x, secondRowY,
                buttonWidth, BUTTON_HEIGHT, class_2561.method_43471(key("armortrim.remove_last")), button -> removeLastTrim()));
        remove.field_22763 = getTrimCount() > 0;

        InfinityEditorButton clear = method_37063(new InfinityEditorButton(x + buttonWidth + BUTTON_GAP, secondRowY,
                buttonWidth, BUTTON_HEIGHT, class_2561.method_43471(key("armortrim.clear")), button -> clearTrims()));
        clear.field_22763 = getTrimCount() > 0 || this.armorStack.method_57826(class_9334.field_49607);

        method_37063(new InfinityEditorButton(x, secondRowY + BUTTON_HEIGHT + BUTTON_GAP,
                fullWidth, BUTTON_HEIGHT, class_2561.method_43471(key("back")), button -> returnToLastScreen()));
    }

    private TrimEditorLayout layout() {
        int top = PANEL_TOP;
        int bottom = Math.max(top + 130, this.field_22790 - SCREEN_MARGIN);
        int usableWidth = Math.max(1, this.field_22789 - SCREEN_MARGIN * 2);
        int sideMax = Math.max(80, usableWidth / 3);
        int leftWidth = class_3532.method_15340(this.field_22789 / 4, Math.min(118, sideMax), Math.min(184, sideMax));
        int rightWidth = class_3532.method_15340(this.field_22789 / 4, Math.min(138, sideMax), Math.min(212, sideMax));
        int previewWidth = usableWidth - leftWidth - rightWidth - BUTTON_GAP * 2;
        if (previewWidth < 96) {
            int needed = 96 - previewWidth;
            int leftReduction = Math.min(needed / 2 + needed % 2, Math.max(0, leftWidth - 86));
            leftWidth -= leftReduction;
            needed -= leftReduction;
            rightWidth -= Math.min(needed, Math.max(0, rightWidth - 96));
        }

        int leftX = SCREEN_MARGIN;
        int rightX = Math.max(leftX + leftWidth + BUTTON_GAP + 1, this.field_22789 - SCREEN_MARGIN - rightWidth);
        int previewLeft = leftX + leftWidth + BUTTON_GAP;
        int previewRight = Math.max(previewLeft + 1, rightX - BUTTON_GAP);
        return new TrimEditorLayout(leftX, top, leftWidth, rightX, top, rightWidth, previewLeft, top,
                previewRight, bottom, bottom);
    }

    private int controlX(TrimEditorLayout layout) {
        return layout.rightX() + PANEL_PADDING;
    }

    private int controlWidth(TrimEditorLayout layout) {
        return Math.max(1, layout.rightWidth() - PANEL_PADDING * 2);
    }

    private int twoColumnButtonWidth(TrimEditorLayout layout) {
        return Math.max(1, (controlWidth(layout) - BUTTON_GAP) / 2);
    }

    private int materialDropdownY(TrimEditorLayout layout) {
        return layout.rightY() + 42;
    }

    private int patternDropdownY(TrimEditorLayout layout) {
        return materialDropdownY(layout) + DROPDOWN_HEIGHT + 28;
    }

    private int previewButtonY(TrimEditorLayout layout) {
        int preferredY = layout.bottom() - BUTTON_HEIGHT * 4 - BUTTON_GAP * 3 - PANEL_PADDING;
        int minY = patternDropdownY(layout) + DROPDOWN_HEIGHT + 14;
        return Math.max(minY, preferredY);
    }

    private int actionButtonsY(TrimEditorLayout layout) {
        return previewButtonY(layout) + BUTTON_HEIGHT + BUTTON_GAP;
    }

    private void renderTrimList(class_332 guiGraphics, TrimEditorLayout layout, int mouseX, int mouseY) {
        drawLegacyPanel(guiGraphics, layout.leftX(), layout.leftY(), layout.leftRight(), layout.bottom());
        int textX = layout.leftX() + PANEL_PADDING;
        int y = layout.leftY() + PANEL_PADDING;
        drawClippedString(guiGraphics, class_2561.method_43471(key("armortrim.trims")).getString(),
                textX, y, layout.leftWidth() - PANEL_PADDING * 2, TEXT_PRIMARY);

        List<String> rows = getTrimDisplayRows();
        int listTop = y + 18;
        int listBottom = layout.bottom() - PANEL_PADDING;
        int visibleRows = Math.max(1, (listBottom - listTop) / TRIM_ROW_HEIGHT);
        this.trimListScroll = class_3532.method_15340(this.trimListScroll, 0, Math.max(0, rows.size() - visibleRows));

        if (rows.isEmpty()) {
            drawClippedString(guiGraphics, class_2561.method_43471(key("armortrim.no_trims")).getString(),
                    textX, listTop, layout.leftWidth() - PANEL_PADDING * 2, TEXT_MUTED);
            return;
        }

        guiGraphics.method_44379(layout.leftX() + 2, listTop - 2, layout.leftRight() - 2, listBottom + 2);
        int end = Math.min(rows.size(), this.trimListScroll + visibleRows);
        for (int i = this.trimListScroll; i < end; i++) {
            int rowY = listTop + (i - this.trimListScroll) * TRIM_ROW_HEIGHT;
            boolean hovered = isMouseIn(mouseX, mouseY, textX - 4, rowY - 2,
                    layout.leftWidth() - PANEL_PADDING * 2 + 8, TRIM_ROW_HEIGHT);
            if (hovered || (i == 0 && this.armorStack.method_57826(class_9334.field_49607))) {
                drawLegacySelection(guiGraphics, textX - 4, rowY - 2, layout.leftRight() - PANEL_PADDING + 4, rowY + 10, hovered);
            }
            int color = i == 0 && this.armorStack.method_57826(class_9334.field_49607) ? InfinityEditorButton.CONTRAST_COLOR : TEXT_PRIMARY;
            drawClippedString(guiGraphics, rows.get(i), textX, rowY, layout.leftWidth() - PANEL_PADDING * 2, color);
        }
        guiGraphics.method_44380();
    }

    private void renderPreview(class_332 guiGraphics, TrimEditorLayout layout) {
        int previewTop = layout.previewTop() + 10;
        int previewBottom = Math.max(previewTop + 64, layout.previewBottom() - 48);
        int centerX = layout.previewCenterX();
        int previewWidth = layout.previewWidth();
        renderArmorTrimEntityPreview(guiGraphics, layout.previewLeft(), previewTop, layout.previewRight(), previewBottom);

        ArmorTrimMaterialEntry material = getSelectedMaterialEntry();
        ArmorTrimPatternEntry pattern = getSelectedPatternEntry();
        int infoY = Math.min(layout.bottom() - 28, previewBottom + 8);
        if (material == null || pattern == null) {
            guiGraphics.method_27534(this.field_22793, class_2561.method_43471(key(material == null
                    ? "armortrim.no_materials"
                    : "armortrim.no_patterns")), centerX, infoY, STATUS_BAD);
            return;
        }

        drawCenteredClipped(guiGraphics, class_2561.method_43469(key("armortrim.selected"),
                        getPatternName(pattern, material), getMaterialName(material)),
                centerX, infoY, previewWidth - 12, InfinityEditorButton.MAIN_COLOR);
        guiGraphics.method_27534(this.field_22793, class_2561.method_43469(key("armortrim.count"), getTrimCount()),
                centerX, infoY + 12, InfinityEditorButton.ALT_COLOR);
    }

    private void renderControlPanel(class_332 guiGraphics, TrimEditorLayout layout, int mouseX, int mouseY) {
        drawLegacyPanel(guiGraphics, layout.rightX(), layout.rightY(), layout.rightRight(), layout.bottom());
        int x = controlX(layout);
        int width = controlWidth(layout);
        int titleY = layout.rightY() + PANEL_PADDING;
        guiGraphics.method_51427(this.armorStack, x, titleY);
        guiGraphics.method_51431(this.field_22793, this.armorStack, x, titleY);
        drawClippedString(guiGraphics, class_2561.method_43471(key("armortrim.options")).getString(),
                x + 22, titleY + 4, Math.max(1, width - 22), TEXT_PRIMARY);

        renderDropdownField(guiGraphics, layout, true, mouseX, mouseY);
        renderDropdownField(guiGraphics, layout, false, mouseX, mouseY);
    }

    private void renderDropdownField(class_332 guiGraphics, TrimEditorLayout layout, boolean material, int mouseX, int mouseY) {
        int x = controlX(layout);
        int y = material ? materialDropdownY(layout) : patternDropdownY(layout);
        int width = controlWidth(layout);
        boolean open = material ? this.materialDropdownOpen : this.patternDropdownOpen;
        boolean active = material ? !getMaterials().isEmpty() : !getPatterns().isEmpty();
        String label = class_2561.method_43471(key(material ? "armortrim.material_select" : "armortrim.pattern_select")).getString();
        drawClippedString(guiGraphics, label, x, y - 11, width, TEXT_MUTED);

        drawLegacyField(guiGraphics, x, y, x + width, y + DROPDOWN_HEIGHT, open, active);
        String value = material ? getSelectedMaterialDisplayText() : getSelectedPatternDisplayText();
        int textColor = active ? TEXT_PRIMARY : 0xFF6D7875;
        drawClippedString(guiGraphics, value, x + 6, y + 6, Math.max(1, width - 20), textColor);
        guiGraphics.method_51433(this.field_22793, open ? "^" : "v", x + width - 11, y + 6, textColor, false);

        if (isMouseIn(mouseX, mouseY, x, y, width, DROPDOWN_HEIGHT) && this.field_22793.method_1727(value) > width - 20) {
            Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43470(value), mouseX, mouseY);
        }
    }

    private void renderOpenDropdown(class_332 guiGraphics, TrimEditorLayout layout, int mouseX, int mouseY) {
        if (this.materialDropdownOpen) {
            renderMaterialDropdown(guiGraphics, layout, mouseX, mouseY);
        }
        if (this.patternDropdownOpen) {
            renderPatternDropdown(guiGraphics, layout, mouseX, mouseY);
        }
    }

    private void renderMaterialDropdown(class_332 guiGraphics, TrimEditorLayout layout, int mouseX, int mouseY) {
        List<ArmorTrimMaterialEntry> materials = getMaterials();
        this.materialDropdownScroll = clampDropdownScroll(this.materialDropdownScroll, materials.size());
        int listTop = dropdownListTop(layout, true, materials.size());
        renderDropdownRows(guiGraphics, mouseX, mouseY, layout, true, materials.size(), this.materialDropdownScroll,
                index -> getMaterialDisplayText(materials.get(index)), this.selectedMaterialIndex);
        renderDropdownScrollbar(guiGraphics, layout, true, materials.size(), this.materialDropdownScroll, listTop);
    }

    private void renderPatternDropdown(class_332 guiGraphics, TrimEditorLayout layout, int mouseX, int mouseY) {
        List<ArmorTrimPatternEntry> patterns = getPatterns();
        this.patternDropdownScroll = clampDropdownScroll(this.patternDropdownScroll, patterns.size());
        int listTop = dropdownListTop(layout, false, patterns.size());
        renderDropdownRows(guiGraphics, mouseX, mouseY, layout, false, patterns.size(), this.patternDropdownScroll,
                index -> getPatternDisplayText(patterns.get(index)), this.selectedPatternIndex);
        renderDropdownScrollbar(guiGraphics, layout, false, patterns.size(), this.patternDropdownScroll, listTop);
    }

    private void renderDropdownRows(class_332 guiGraphics, int mouseX, int mouseY, TrimEditorLayout layout,
                                    boolean material, int size, int scroll, DropdownTextProvider textProvider, int selectedIndex) {
        if (size <= 0) {
            return;
        }

        int x = controlX(layout);
        int width = controlWidth(layout);
        int visibleRows = dropdownVisibleRows(size);
        int listTop = dropdownListTop(layout, material, size);
        int listHeight = dropdownListHeight(size);
        drawLegacyPanel(guiGraphics, x, listTop, x + width, listTop + listHeight);

        for (int row = 0; row < visibleRows; row++) {
            int index = scroll + row;
            if (index >= size) {
                break;
            }
            int rowY = listTop + 1 + row * DROPDOWN_ROW_HEIGHT;
            boolean hovered = isMouseIn(mouseX, mouseY, x + 1, rowY, width - 2, DROPDOWN_ROW_HEIGHT);
            boolean selected = index == selectedIndex;
            if (hovered || selected) {
                drawLegacySelection(guiGraphics, x + 2, rowY + 1, x + width - 2, rowY + DROPDOWN_ROW_HEIGHT - 1, selected);
            }
            String text = textProvider.get(index);
            drawClippedString(guiGraphics, text, x + 7, rowY + 5, Math.max(1, width - 16),
                    selected ? InfinityEditorButton.CONTRAST_COLOR : TEXT_PRIMARY);
            if (hovered && this.field_22793.method_1727(text) > width - 16) {
                Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43470(text), mouseX, mouseY);
            }
        }
    }

    private void renderDropdownScrollbar(class_332 guiGraphics, TrimEditorLayout layout, boolean material,
                                         int size, int scroll, int listTop) {
        int visibleRows = dropdownVisibleRows(size);
        if (size <= visibleRows || visibleRows <= 0) {
            return;
        }

        int x = controlX(layout) + controlWidth(layout) - 5;
        int height = dropdownListHeight(size) - 4;
        int trackTop = listTop + 2;
        int thumbHeight = Math.max(8, height * visibleRows / size);
        int maxScroll = Math.max(1, size - visibleRows);
        int thumbY = trackTop + (height - thumbHeight) * scroll / maxScroll;
        guiGraphics.method_25294(x, trackTop, x + 2, trackTop + height, InfinityEditorButton.ALT_COLOR);
        guiGraphics.method_25294(x - 1, thumbY, x + 3, thumbY + thumbHeight, InfinityEditorButton.CONTRAST_COLOR);
    }

    private boolean handleDropdownClick(double mouseX, double mouseY) {
        TrimEditorLayout layout = layout();
        if (handleDropdownFieldClick(mouseX, mouseY, layout, true) || handleDropdownFieldClick(mouseX, mouseY, layout, false)) {
            return true;
        }

        if (this.materialDropdownOpen && handleDropdownRowClick(mouseX, mouseY, layout, true)) {
            return true;
        }
        if (this.patternDropdownOpen && handleDropdownRowClick(mouseX, mouseY, layout, false)) {
            return true;
        }

        if (this.materialDropdownOpen || this.patternDropdownOpen) {
            this.materialDropdownOpen = false;
            this.patternDropdownOpen = false;
            return true;
        }
        return false;
    }

    private boolean handleDropdownFieldClick(double mouseX, double mouseY, TrimEditorLayout layout, boolean material) {
        int x = controlX(layout);
        int y = material ? materialDropdownY(layout) : patternDropdownY(layout);
        if (!isMouseIn(mouseX, mouseY, x, y, controlWidth(layout), DROPDOWN_HEIGHT)) {
            return false;
        }

        if (material) {
            if (getMaterials().isEmpty()) {
                return true;
            }
            this.materialDropdownOpen = !this.materialDropdownOpen;
            this.patternDropdownOpen = false;
            scrollMaterialDropdown(0);
        } else {
            if (getPatterns().isEmpty()) {
                return true;
            }
            this.patternDropdownOpen = !this.patternDropdownOpen;
            this.materialDropdownOpen = false;
            scrollPatternDropdown(0);
        }
        return true;
    }

    private boolean handleDropdownRowClick(double mouseX, double mouseY, TrimEditorLayout layout, boolean material) {
        int size = material ? getMaterials().size() : getPatterns().size();
        if (!isMouseOverDropdown(mouseX, mouseY, layout, material, size)) {
            return false;
        }

        int listTop = dropdownListTop(layout, material, size);
        int row = ((int) mouseY - listTop - 1) / DROPDOWN_ROW_HEIGHT;
        int index = (material ? this.materialDropdownScroll : this.patternDropdownScroll) + row;
        if (row < 0 || row >= dropdownVisibleRows(size) || index < 0 || index >= size) {
            return true;
        }

        if (material) {
            this.selectedMaterialIndex = index;
            this.materialDropdownOpen = false;
        } else {
            this.selectedPatternIndex = index;
            this.patternDropdownOpen = false;
        }
        return true;
    }

    private boolean isMouseOverDropdown(double mouseX, double mouseY, TrimEditorLayout layout, boolean material, int size) {
        if (size <= 0) {
            return false;
        }
        int x = controlX(layout);
        int listTop = dropdownListTop(layout, material, size);
        return isMouseIn(mouseX, mouseY, x, listTop, controlWidth(layout), dropdownListHeight(size));
    }

    private int dropdownVisibleRows(int size) {
        return Math.min(DROPDOWN_MAX_ROWS, Math.max(0, size));
    }

    private int dropdownListHeight(int size) {
        return dropdownVisibleRows(size) * DROPDOWN_ROW_HEIGHT + 2;
    }

    private int dropdownListTop(TrimEditorLayout layout, boolean material, int size) {
        int fieldY = material ? materialDropdownY(layout) : patternDropdownY(layout);
        int listHeight = dropdownListHeight(size);
        int below = fieldY + DROPDOWN_HEIGHT + 2;
        if (below + listHeight > layout.bottom() - PANEL_PADDING && fieldY - listHeight - 2 >= layout.rightY() + PANEL_PADDING) {
            return fieldY - listHeight - 2;
        }
        return below;
    }

    private int clampDropdownScroll(int scroll, int size) {
        int visibleRows = dropdownVisibleRows(size);
        return class_3532.method_15340(scroll, 0, Math.max(0, size - visibleRows));
    }

    private void scrollMaterialDropdown(int direction) {
        List<ArmorTrimMaterialEntry> materials = getMaterials();
        int visibleRows = dropdownVisibleRows(materials.size());
        int target = direction == 0 ? this.selectedMaterialIndex - visibleRows / 2 : this.materialDropdownScroll + direction;
        this.materialDropdownScroll = class_3532.method_15340(target, 0, Math.max(0, materials.size() - visibleRows));
    }

    private void scrollPatternDropdown(int direction) {
        List<ArmorTrimPatternEntry> patterns = getPatterns();
        int visibleRows = dropdownVisibleRows(patterns.size());
        int target = direction == 0 ? this.selectedPatternIndex - visibleRows / 2 : this.patternDropdownScroll + direction;
        this.patternDropdownScroll = class_3532.method_15340(target, 0, Math.max(0, patterns.size() - visibleRows));
    }

    private void scrollTrimList(int direction) {
        TrimEditorLayout layout = layout();
        List<String> rows = getTrimDisplayRows();
        int listTop = layout.leftY() + PANEL_PADDING + 18;
        int listBottom = layout.bottom() - PANEL_PADDING;
        int visibleRows = Math.max(1, (listBottom - listTop) / TRIM_ROW_HEIGHT);
        this.trimListScroll = class_3532.method_15340(this.trimListScroll + direction, 0, Math.max(0, rows.size() - visibleRows));
    }

    private boolean isInventoryKey(int keyCode, int scanCode) {
        return this.field_22787 != null
                && this.field_22787.field_1690.field_1822.method_1417(keyCode, scanCode);
    }

    @Override
    protected void method_41843() {
        method_37067();
        addControls();
    }

    private void returnToLastScreen() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.lastScreen);
        }
    }

    private void applySelectedTrim() {
        if (!isArmorTrimApplicable(this.armorStack)) {
            return;
        }
        if (!setSelectedTrimComponent()) {
            this.status = class_2561.method_43471(key("armortrim.no_patterns"));
            this.statusColor = STATUS_BAD;
            return;
        }

        commitStack(class_2561.method_43469(messageKey("editor_armor_trim_updated"),
                getSelectedPatternName(), getSelectedMaterialName()), STATUS_GOOD);
    }

    private void addSelectedTrim() {
        if (!isArmorTrimApplicable(this.armorStack)) {
            return;
        }

        ArmorTrimMaterialEntry material = getSelectedMaterialEntry();
        ArmorTrimPatternEntry pattern = getSelectedPatternEntry();
        if (material == null || pattern == null) {
            this.status = class_2561.method_43471(key(material == null ? "armortrim.no_materials" : "armortrim.no_patterns"));
            this.statusColor = STATUS_BAD;
            return;
        }

        class_9279.method_57452(class_9334.field_49628, this.armorStack, tag -> {
            class_2499 trims = tag.method_10545(ARMOR_TRIMS_CUSTOM_DATA_TAG)
                    ? tag.method_68569(ARMOR_TRIMS_CUSTOM_DATA_TAG).method_10612()
                    : new class_2499();
            class_2487 entry = new class_2487();
            entry.method_10582(ARMOR_TRIM_MATERIAL_TAG, material.id().toString());
            entry.method_10582(ARMOR_TRIM_PATTERN_TAG, pattern.id().toString());
            trims.add(entry);
            tag.method_10566(ARMOR_TRIMS_CUSTOM_DATA_TAG, trims);
        });
        setSelectedTrimComponent();
        commitStack(class_2561.method_43469(messageKey("editor_armor_trim_added"),
                getPatternName(pattern, material), getMaterialName(material)), STATUS_GOOD);
    }

    private void removeLastTrim() {
        if (getTrimCount() <= 0) {
            return;
        }

        final ArmorTrimEntry[] activeEntry = new ArmorTrimEntry[1];
        class_9279.method_57452(class_9334.field_49628, this.armorStack, tag -> {
            if (!tag.method_10545(ARMOR_TRIMS_CUSTOM_DATA_TAG)) {
                return;
            }

            class_2499 trims = tag.method_68569(ARMOR_TRIMS_CUSTOM_DATA_TAG).method_10612();
            if (trims.isEmpty()) {
                tag.method_10551(ARMOR_TRIMS_CUSTOM_DATA_TAG);
                return;
            }

            trims.method_10536(trims.size() - 1);
            if (trims.isEmpty()) {
                tag.method_10551(ARMOR_TRIMS_CUSTOM_DATA_TAG);
                return;
            }

            tag.method_10566(ARMOR_TRIMS_CUSTOM_DATA_TAG, trims);
            class_2487 last = trims.method_68582(trims.size() - 1);
            class_2960 materialId = class_2960.method_12829(last.method_68564(ARMOR_TRIM_MATERIAL_TAG, ""));
            class_2960 patternId = class_2960.method_12829(last.method_68564(ARMOR_TRIM_PATTERN_TAG, ""));
            if (materialId != null && patternId != null) {
                activeEntry[0] = new ArmorTrimEntry(materialId, patternId);
            }
        });

        if (activeEntry[0] == null) {
            this.armorStack.method_57381(class_9334.field_49607);
        } else {
            applyTrimEntry(activeEntry[0]);
        }
        syncSelectionFromStack();
        commitStack(class_2561.method_43471(messageKey("editor_armor_trim_removed")), STATUS_GOOD);
    }

    private void clearTrims() {
        class_9279.method_57452(class_9334.field_49628, this.armorStack, tag -> tag.method_10551(ARMOR_TRIMS_CUSTOM_DATA_TAG));
        this.armorStack.method_57381(class_9334.field_49607);
        syncSelectionFromStack();
        commitStack(class_2561.method_43471(messageKey("editor_armor_trim_cleared")), STATUS_GOOD);
    }

    private void cycleMaterial(int direction) {
        List<ArmorTrimMaterialEntry> materials = getMaterials();
        if (materials.isEmpty()) {
            return;
        }

        this.selectedMaterialIndex = class_3532.method_15387(this.selectedMaterialIndex + direction, materials.size());
        method_41843();
    }

    private void cyclePattern(int direction) {
        List<ArmorTrimPatternEntry> patterns = getPatterns();
        if (patterns.isEmpty()) {
            return;
        }

        this.selectedPatternIndex = class_3532.method_15387(this.selectedPatternIndex + direction, patterns.size());
        method_41843();
    }

    private void cyclePreviewEntity() {
        this.previewEntity = class_3532.method_15387(this.previewEntity + 1, 3);
        this.status = class_2561.method_43469(messageKey("editor_armor_trim_preview_updated"), getPreviewEntityName());
        this.statusColor = STATUS_NEUTRAL;
        method_41843();
    }

    private void commitStack(class_2561 status, int statusColor) {
        this.lastScreen.applyArmorTrimEditedStack(this.armorStack);
        this.armorStack = this.lastScreen.previewStack.method_7972();
        this.status = status;
        this.statusColor = statusColor;
        syncSelectionFromStack();
        method_41843();
    }

    private void syncSelectionFromStack() {
        List<ArmorTrimMaterialEntry> materials = getMaterials();
        List<ArmorTrimPatternEntry> patterns = getPatterns();
        if (materials.isEmpty() || patterns.isEmpty()) {
            this.selectedMaterialIndex = 0;
            this.selectedPatternIndex = 0;
            return;
        }

        class_2960 materialId = null;
        class_2960 patternId = null;
        class_8053 trim = this.armorStack.method_58694(class_9334.field_49607);
        if (trim != null) {
            materialId = CompatRegistries.TRIM_MATERIALS.getKey(trim.comp_3179().comp_349());
            patternId = CompatRegistries.TRIM_PATTERNS.getKey(trim.comp_3180().comp_349());
        }
        if (materialId == null || patternId == null) {
            ArmorTrimEntry entry = getLastTrimEntry();
            if (entry != null) {
                materialId = entry.materialId();
                patternId = entry.patternId();
            }
        }

        this.selectedMaterialIndex = findMaterialIndex(materials, materialId);
        this.selectedPatternIndex = findPatternIndex(patterns, patternId);
        clampSelection(materials, patterns);
    }

    private List<ArmorTrimMaterialEntry> getMaterials() {
        List<ArmorTrimMaterialEntry> entries = new ArrayList<>();
        for (var holder : CompatRegistries.TRIM_MATERIALS.getHolders()) {
            class_2960 id = CompatRegistries.TRIM_MATERIALS.getKey(holder.comp_349());
            if (id != null) {
                entries.add(new ArmorTrimMaterialEntry(id, holder));
            }
        }
        entries.sort(Comparator.comparing(entry -> entry.id().toString()));
        return entries;
    }

    private List<ArmorTrimPatternEntry> getPatterns() {
        List<ArmorTrimPatternEntry> entries = new ArrayList<>();
        for (var holder : CompatRegistries.TRIM_PATTERNS.getHolders()) {
            class_2960 id = CompatRegistries.TRIM_PATTERNS.getKey(holder.comp_349());
            if (id != null) {
                entries.add(new ArmorTrimPatternEntry(id, holder));
            }
        }
        entries.sort(Comparator.comparing(entry -> entry.id().toString()));
        return entries;
    }

    private ArmorTrimMaterialEntry getSelectedMaterialEntry() {
        List<ArmorTrimMaterialEntry> materials = getMaterials();
        clampSelection(materials, getPatterns());
        return materials.isEmpty() ? null : materials.get(this.selectedMaterialIndex);
    }

    private ArmorTrimPatternEntry getSelectedPatternEntry() {
        List<ArmorTrimPatternEntry> patterns = getPatterns();
        clampSelection(getMaterials(), patterns);
        return patterns.isEmpty() ? null : patterns.get(this.selectedPatternIndex);
    }

    private class_6880<class_8054> getSelectedMaterialHolder() {
        ArmorTrimMaterialEntry entry = getSelectedMaterialEntry();
        return entry == null ? null : entry.material();
    }

    private class_6880<class_8056> getSelectedPatternHolder() {
        ArmorTrimPatternEntry entry = getSelectedPatternEntry();
        return entry == null ? null : entry.pattern();
    }

    private void clampSelection(List<ArmorTrimMaterialEntry> materials, List<ArmorTrimPatternEntry> patterns) {
        this.selectedMaterialIndex = materials.isEmpty()
                ? 0
                : class_3532.method_15340(this.selectedMaterialIndex, 0, materials.size() - 1);
        this.selectedPatternIndex = patterns.isEmpty()
                ? 0
                : class_3532.method_15340(this.selectedPatternIndex, 0, patterns.size() - 1);
    }

    private int findMaterialIndex(List<ArmorTrimMaterialEntry> materials, class_2960 id) {
        if (id == null) {
            return 0;
        }
        for (int i = 0; i < materials.size(); i++) {
            if (id.equals(materials.get(i).id())) {
                return i;
            }
        }
        return 0;
    }

    private int findPatternIndex(List<ArmorTrimPatternEntry> patterns, class_2960 id) {
        if (id == null) {
            return 0;
        }
        for (int i = 0; i < patterns.size(); i++) {
            if (id.equals(patterns.get(i).id())) {
                return i;
            }
        }
        return 0;
    }

    private class_2561 getMaterialName(ArmorTrimMaterialEntry entry) {
        return entry == null ? class_2561.method_43471(key("armortrim.no_materials")) : entry.material().comp_349().comp_1212();
    }

    private class_2561 getPatternName(ArmorTrimPatternEntry entry, ArmorTrimMaterialEntry material) {
        if (entry == null) {
            return class_2561.method_43471(key("armortrim.no_patterns"));
        }
        if (material != null) {
            return entry.pattern().comp_349().method_48446(material.material());
        }
        return entry.pattern().comp_349().comp_1215();
    }

    private class_2561 getSelectedMaterialName() {
        return getMaterialName(getSelectedMaterialEntry());
    }

    private class_2561 getSelectedPatternName() {
        return getPatternName(getSelectedPatternEntry(), getSelectedMaterialEntry());
    }

    private class_2561 getPreviewEntityName() {
        return switch (this.previewEntity) {
            case PREVIEW_PLAYER -> class_2561.method_43471(key("armortrim.preview.player"));
            case PREVIEW_ZOMBIE -> class_2561.method_43471(key("armortrim.preview.zombie"));
            default -> class_2561.method_43471(key("armortrim.preview.armor_stand"));
        };
    }

    private List<ArmorTrimEntry> getTrimEntries() {
        class_9279 data = this.armorStack.method_58694(class_9334.field_49628);
        if (data == null) {
            return List.of();
        }

        class_2487 tag = data.method_57461();
        if (!tag.method_10545(ARMOR_TRIMS_CUSTOM_DATA_TAG)) {
            return List.of();
        }

        List<ArmorTrimEntry> entries = new ArrayList<>();
        class_2499 list = tag.method_68569(ARMOR_TRIMS_CUSTOM_DATA_TAG);
        for (int i = 0; i < list.size(); i++) {
            class_2487 entryTag = list.method_68582(i);
            class_2960 materialId = class_2960.method_12829(entryTag.method_68564(ARMOR_TRIM_MATERIAL_TAG, ""));
            class_2960 patternId = class_2960.method_12829(entryTag.method_68564(ARMOR_TRIM_PATTERN_TAG, ""));
            if (materialId != null && patternId != null) {
                entries.add(new ArmorTrimEntry(materialId, patternId));
            }
        }
        return entries;
    }

    private ArmorTrimEntry getLastTrimEntry() {
        List<ArmorTrimEntry> entries = getTrimEntries();
        return entries.isEmpty() ? null : entries.get(entries.size() - 1);
    }

    private int getTrimCount() {
        return getTrimEntries().size();
    }

    private boolean setSelectedTrimComponent() {
        class_6880<class_8054> material = getSelectedMaterialHolder();
        class_6880<class_8056> pattern = getSelectedPatternHolder();
        if (material == null || pattern == null) {
            return false;
        }

        this.armorStack.method_57379(class_9334.field_49607, new class_8053(material, pattern));
        return true;
    }

    private boolean applyTrimEntry(ArmorTrimEntry entry) {
        class_6880<class_8054> material = CompatRegistries.TRIM_MATERIALS.getHolder(entry.materialId());
        class_6880<class_8056> pattern = CompatRegistries.TRIM_PATTERNS.getHolder(entry.patternId());
        if (material == null || pattern == null) {
            return false;
        }

        this.armorStack.method_57379(class_9334.field_49607, new class_8053(material, pattern));
        return true;
    }

    private void renderArmorTrimEntityPreview(class_332 guiGraphics, int left, int top, int right, int bottom) {
        class_1304 slot = getArmorTrimEquipmentSlot(this.armorStack);
        if (slot == null || this.field_22787 == null || this.field_22787.field_1687 == null) {
            return;
        }

        class_1799 trimmed = this.armorStack.method_46651(1);
        class_6880<class_8054> material = getSelectedMaterialHolder();
        class_6880<class_8056> pattern = getSelectedPatternHolder();
        if (material != null && pattern != null) {
            trimmed.method_57379(class_9334.field_49607, new class_8053(material, pattern));
        }

        if (this.previewEntity == PREVIEW_PLAYER) {
            renderPlayerPreview(guiGraphics, left, top, right, bottom, slot, trimmed);
            return;
        }

        class_1309 entity = getPreviewEntity();
        if (entity == null) {
            return;
        }

        setPreviewEquipment(entity, slot, trimmed);
        renderLivingEntity(guiGraphics, left, top, right, bottom, entity);
    }

    private void renderPlayerPreview(class_332 guiGraphics, int left, int top, int right, int bottom,
                                     class_1304 slot, class_1799 trimmed) {
        if (this.field_22787.field_1724 == null) {
            return;
        }

        List<class_1799> previousEquipment = new ArrayList<>();
        for (class_1304 equipmentSlot : class_1304.field_54086) {
            previousEquipment.add(this.field_22787.field_1724.method_6118(equipmentSlot));
        }

        try {
            setPreviewEquipment(this.field_22787.field_1724, slot, trimmed);
            renderLivingEntity(guiGraphics, left, top, right, bottom, this.field_22787.field_1724);
        } finally {
            for (int i = 0; i < class_1304.field_54086.size(); i++) {
                this.field_22787.field_1724.method_5673(class_1304.field_54086.get(i), previousEquipment.get(i));
            }
        }
    }

    private class_1309 getPreviewEntity() {
        if (this.field_22787 == null || this.field_22787.field_1687 == null) {
            return null;
        }

        if (this.previewEntity == PREVIEW_ZOMBIE) {
            if (this.zombiePreview == null || this.zombiePreview.method_37908() != this.field_22787.field_1687) {
                this.zombiePreview = class_1299.field_6051.method_5883(this.field_22787.field_1687, class_3730.field_52444);
            }
            return this.zombiePreview;
        }

        if (this.armorStandPreview == null || this.armorStandPreview.method_37908() != this.field_22787.field_1687) {
            class_1531 armorStand = new class_1531(this.field_22787.field_1687, 0.0D, 0.0D, 0.0D);
            armorStand.method_6913(true);
            armorStand.method_6907(true);
            armorStand.method_5648(false);
            this.armorStandPreview = armorStand;
        }
        return this.armorStandPreview;
    }

    private void setPreviewEquipment(class_1309 entity, class_1304 slot, class_1799 trimmed) {
        for (class_1304 equipmentSlot : class_1304.field_54086) {
            entity.method_5673(equipmentSlot, class_1799.field_8037);
        }
        entity.method_5673(slot, trimmed);
    }

    private void renderLivingEntity(class_332 guiGraphics, int left, int top, int right, int bottom, class_1309 entity) {
        int height = Math.max(1, bottom - top);
        int scale = this.previewEntity == PREVIEW_ARMOR_STAND
                ? class_3532.method_15340(height / 3, 24, 38)
                : class_3532.method_15340(height / 2, 34, 48);
        float yOffset = this.previewEntity == PREVIEW_ARMOR_STAND ? 0.05F : 0.0F;
        class_490.method_2486(guiGraphics, left, top, right, bottom,
                scale, yOffset, this.lastMouseX, this.lastMouseY, entity);
    }

    private static boolean isArmorTrimApplicable(class_1799 stack) {
        return getArmorTrimEquipmentSlot(stack) != null;
    }

    private static class_1304 getArmorTrimEquipmentSlot(class_1799 stack) {
        var equippable = stack.method_58694(class_9334.field_54196);
        if (equippable == null || !isArmorTrimSlot(equippable.comp_3174())) {
            return null;
        }
        return equippable.comp_3174();
    }

    private static boolean isArmorTrimSlot(class_1304 slot) {
        return slot == class_1304.field_6169
                || slot == class_1304.field_6174
                || slot == class_1304.field_6172
                || slot == class_1304.field_6166;
    }

    private void drawLegacyPanel(class_332 guiGraphics, int left, int top, int right, int bottom) {
        guiGraphics.method_25294(left + 2, top + 2, right + 2, bottom + 2, PANEL_SHADOW);
        guiGraphics.method_25294(left, top, right, bottom, PANEL_FILL);
        guiGraphics.method_25294(left, top, right, top + 1, InfinityEditorButton.MAIN_COLOR);
        guiGraphics.method_25294(left, top, left + 1, bottom, InfinityEditorButton.MAIN_COLOR);
        guiGraphics.method_25294(right - 1, top, right, bottom, InfinityEditorButton.ALT_COLOR);
        guiGraphics.method_25294(left, bottom - 1, right, bottom, InfinityEditorButton.ALT_COLOR);
    }

    private void drawLegacyField(class_332 guiGraphics, int left, int top, int right, int bottom,
                                 boolean focused, boolean active) {
        int border = focused && active ? InfinityEditorButton.CONTRAST_COLOR : InfinityEditorButton.MAIN_COLOR;
        guiGraphics.method_25294(left, top, right, bottom, border);
        guiGraphics.method_25294(left + 1, top + 1, right - 1, bottom - 1, active ? FIELD_FILL : FIELD_DISABLED);
    }

    private void drawLegacySelection(class_332 guiGraphics, int left, int top, int right, int bottom, boolean selected) {
        guiGraphics.method_25294(left, top, right, bottom, selected ? ROW_SELECTED : ROW_HOVER);
    }
    private boolean isMouseIn(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    private void drawClippedString(class_332 guiGraphics, String text, int x, int y, int maxWidth, int color) {
        String value = text;
        if (this.field_22793.method_1727(value) > maxWidth) {
            String ellipsis = "...";
            value = this.field_22793.method_27523(value, Math.max(0, maxWidth - this.field_22793.method_1727(ellipsis))) + ellipsis;
        }
        guiGraphics.method_51433(this.field_22793, value, x, y, color, false);
    }

    private List<String> getTrimDisplayRows() {
        List<String> rows = new ArrayList<>();
        class_8053 current = this.armorStack.method_58694(class_9334.field_49607);
        if (current != null) {
            class_2960 materialId = CompatRegistries.TRIM_MATERIALS.getKey(current.comp_3179().comp_349());
            class_2960 patternId = CompatRegistries.TRIM_PATTERNS.getKey(current.comp_3180().comp_349());
            rows.add(class_2561.method_43469(key("armortrim.current"),
                    getTrimPatternDisplayText(patternId, materialId), getTrimMaterialDisplayText(materialId)).getString());
        }

        List<ArmorTrimEntry> entries = getTrimEntries();
        for (int i = 0; i < entries.size(); i++) {
            ArmorTrimEntry entry = entries.get(i);
            rows.add(class_2561.method_43469(key("armortrim.appended"), i + 1,
                    getTrimPatternDisplayText(entry.patternId(), entry.materialId()), getTrimMaterialDisplayText(entry.materialId())).getString());
        }
        return rows;
    }

    private String getSelectedMaterialDisplayText() {
        ArmorTrimMaterialEntry entry = getSelectedMaterialEntry();
        return entry == null
                ? class_2561.method_43471(key("armortrim.no_materials")).getString()
                : getMaterialDisplayText(entry);
    }

    private String getSelectedPatternDisplayText() {
        ArmorTrimPatternEntry entry = getSelectedPatternEntry();
        return entry == null
                ? class_2561.method_43471(key("armortrim.no_patterns")).getString()
                : getPatternDisplayText(entry);
    }

    private String getMaterialDisplayText(ArmorTrimMaterialEntry entry) {
        return getMaterialName(entry).getString() + " (" + entry.id() + ")";
    }

    private String getPatternDisplayText(ArmorTrimPatternEntry entry) {
        return getPatternName(entry, getSelectedMaterialEntry()).getString() + " (" + entry.id() + ")";
    }


    private String getTrimMaterialDisplayText(class_2960 id) {
        ArmorTrimMaterialEntry entry = findMaterialEntry(id);
        return entry == null ? String.valueOf(id) : getMaterialName(entry).getString();
    }

    private String getTrimPatternDisplayText(class_2960 patternId, class_2960 materialId) {
        ArmorTrimPatternEntry entry = findPatternEntry(patternId);
        ArmorTrimMaterialEntry material = findMaterialEntry(materialId);
        return entry == null ? String.valueOf(patternId) : getPatternName(entry, material).getString();
    }

    private ArmorTrimMaterialEntry findMaterialEntry(class_2960 id) {
        if (id == null) {
            return null;
        }
        for (ArmorTrimMaterialEntry entry : getMaterials()) {
            if (id.equals(entry.id())) {
                return entry;
            }
        }
        return null;
    }

    private ArmorTrimPatternEntry findPatternEntry(class_2960 id) {
        if (id == null) {
            return null;
        }
        for (ArmorTrimPatternEntry entry : getPatterns()) {
            if (id.equals(entry.id())) {
                return entry;
            }
        }
        return null;
    }

    @FunctionalInterface
    private interface DropdownTextProvider {
        String get(int index);
    }

    private record TrimEditorLayout(int leftX, int leftY, int leftWidth, int rightX, int rightY, int rightWidth,
                                    int previewLeft, int previewTop, int previewRight, int previewBottom, int bottom) {
        int leftRight() {
            return this.leftX + this.leftWidth;
        }

        int rightRight() {
            return this.rightX + this.rightWidth;
        }

        int height() {
            return this.bottom - this.leftY;
        }

        int previewWidth() {
            return this.previewRight - this.previewLeft;
        }

        int previewCenterX() {
            return this.previewLeft + previewWidth() / 2;
        }
    }

    private void drawCenteredClipped(class_332 guiGraphics, class_2561 text, int centerX, int y, int maxWidth, int color) {
        String value = text.getString();
        if (this.field_22793.method_1727(value) > maxWidth) {
            String ellipsis = "...";
            value = this.field_22793.method_27523(value, Math.max(0, maxWidth - this.field_22793.method_1727(ellipsis))) + ellipsis;
        }
        guiGraphics.method_25300(this.field_22793, value, centerX, y, color);
    }

    private static String key(String suffix) {
        return "screen." + ModSource.MODID + "." + suffix;
    }

    private static String messageKey(String suffix) {
        return "message." + ModSource.MODID + "." + suffix;
    }
}
