package io.github.seraphina.infinity_item_editor_re.client.screen;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public final class BannerPatternCatalog {
    static final class_1792[] ITEMS_BY_DYE = {
            class_1802.field_8539,
            class_1802.field_8824,
            class_1802.field_8671,
            class_1802.field_8379,
            class_1802.field_8049,
            class_1802.field_8778,
            class_1802.field_8329,
            class_1802.field_8617,
            class_1802.field_8855,
            class_1802.field_8629,
            class_1802.field_8405,
            class_1802.field_8128,
            class_1802.field_8124,
            class_1802.field_8295,
            class_1802.field_8586,
            class_1802.field_8572
    };

    static final List<BannerPatternEntry> PATTERNS = List.of(
            new BannerPatternEntry("square_bottom_left", "bl"),
            new BannerPatternEntry("square_bottom_right", "br"),
            new BannerPatternEntry("square_top_left", "tl"),
            new BannerPatternEntry("square_top_right", "tr"),
            new BannerPatternEntry("stripe_bottom", "bs"),
            new BannerPatternEntry("stripe_top", "ts"),
            new BannerPatternEntry("stripe_left", "ls"),
            new BannerPatternEntry("stripe_right", "rs"),
            new BannerPatternEntry("stripe_center", "cs"),
            new BannerPatternEntry("stripe_middle", "ms"),
            new BannerPatternEntry("stripe_downright", "drs"),
            new BannerPatternEntry("stripe_downleft", "dls"),
            new BannerPatternEntry("small_stripes", "ss"),
            new BannerPatternEntry("cross", "cr"),
            new BannerPatternEntry("straight_cross", "sc"),
            new BannerPatternEntry("triangle_bottom", "bt"),
            new BannerPatternEntry("triangle_top", "tt"),
            new BannerPatternEntry("triangles_bottom", "bts"),
            new BannerPatternEntry("triangles_top", "tts"),
            new BannerPatternEntry("diagonal_left", "ld"),
            new BannerPatternEntry("diagonal_up_right", "rd"),
            new BannerPatternEntry("diagonal_up_left", "lud"),
            new BannerPatternEntry("diagonal_right", "rud"),
            new BannerPatternEntry("circle", "mc"),
            new BannerPatternEntry("rhombus", "mr"),
            new BannerPatternEntry("half_vertical", "vh"),
            new BannerPatternEntry("half_horizontal", "hh"),
            new BannerPatternEntry("half_vertical_right", "vhr"),
            new BannerPatternEntry("half_horizontal_bottom", "hhb"),
            new BannerPatternEntry("border", "bo"),
            new BannerPatternEntry("curly_border", "cbo"),
            new BannerPatternEntry("gradient", "gra"),
            new BannerPatternEntry("gradient_up", "gru"),
            new BannerPatternEntry("bricks", "bri"),
            new BannerPatternEntry("globe", "glb"),
            new BannerPatternEntry("creeper", "cre"),
            new BannerPatternEntry("skull", "sku"),
            new BannerPatternEntry("flower", "flo"),
            new BannerPatternEntry("mojang", "moj"),
            new BannerPatternEntry("piglin", "pig")
    );

    private BannerPatternCatalog() {
    }

    public static class_1792 itemByDyeId(int dyeId) {
        return ITEMS_BY_DYE[Math.floorMod(dyeId, ITEMS_BY_DYE.length)];
    }

    public static List<String> patternHashes() {
        return PATTERNS.stream()
                .map(BannerPatternEntry::hash)
                .toList();
    }
}
