package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ComponentCompat;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.screen.legacy.LegacyTextEditBox;
import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_10799;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_3872;
import net.minecraft.class_437;
import net.minecraft.class_474;
import net.minecraft.class_5244;
import net.minecraft.class_9301;
final class BookItemScreen extends class_437 {
    private static final int TEXT_WIDTH = 114;
    private static final int TEXT_HEIGHT = 128;
    private static final int IMAGE_WIDTH = 192;
    private static final int PAGE_LEFT_OFFSET = 36;
    private static final int PAGE_TOP_OFFSET = 32;
    private static final int LINE_HEIGHT = 9;
    private static final int PAGE_LINES = TEXT_HEIGHT / LINE_HEIGHT;
    private static final int MAX_PAGE_LENGTH = class_9301.field_49370;
    private static final int MAX_PAGES = class_9301.field_51411;
    private static final int FORMAT_BUTTON_WIDTH = 13;
    private static final int FORMAT_BUTTON_HEIGHT = 15;
    private static final int FORMAT_BUTTON_Y_OFFSET = 30;
    private static final int FORMAT_BUTTON_ROWS = 2;

    private final ItemEditorScreen lastScreen;
    private final class_1799 bookStack;
    private final List<String> pages = new ArrayList<>();
    private final List<class_342> lineBoxes = new ArrayList<>();
    private int currentPage;
    private class_474 forwardButton;
    private class_474 backButton;
    private InfinityEditorButton deletePageButton;
    private class_342 lastFocusedLineBox;
    private boolean syncingLineBoxes;
    private boolean modified;

    BookItemScreen(ItemEditorScreen lastScreen, class_1799 bookStack) {
        super(class_2561.method_43471(key("book.edit_pages")));
        this.lastScreen = lastScreen;
        this.bookStack = bookStack;
        readPagesFromStack();
    }

    @Override
    protected void method_25426() {
        this.lineBoxes.clear();
        int left = getBookLeft();
        int pageX = left + PAGE_LEFT_OFFSET;
        for (int line = 0; line < PAGE_LINES; line++) {
            class_342 lineBox = new LegacyTextEditBox(this.field_22793, pageX, PAGE_TOP_OFFSET + line * LINE_HEIGHT,
                    TEXT_WIDTH, LINE_HEIGHT, class_2561.method_43469(key("book.line"), line + 1));
            int lineIndex = line;
            lineBox.method_1858(false);
            lineBox.method_1868(0);
            lineBox.method_1860(0xFF555555);
            lineBox.method_1880(MAX_PAGE_LENGTH);
            lineBox.method_1852(getPageLine(currentPage, lineIndex));
            lineBox.method_1863(value -> updatePageLine(lineIndex, value));
            this.lineBoxes.add(method_37063(lineBox));
        }

        method_37063(new InfinityEditorButton(this.field_22789 / 2 + 2, 196, 98, 20,
                class_5244.field_24334, button -> returnToLastScreen()));
        this.deletePageButton = method_37063(new InfinityEditorButton(this.field_22789 / 2 - 100, 196, 98, 20,
                class_2561.method_43471(key("book.delete_page")), button -> deleteCurrentPage()));
        this.forwardButton = method_37063(new class_474(left + 116, 159, true, button -> pageForward(), true));
        this.backButton = method_37063(new class_474(left + 43, 159, false, button -> pageBack(), true));
        addFormatButtons();
        updateButtonVisibility();
        focusLine(class_3532.method_15340(getFocusedLineIndex(), 0, this.lineBoxes.size() - 1));
    }

    @Override
    public void method_25393() {
        for (class_342 lineBox : this.lineBoxes) {
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            returnToLastScreen();
            return true;
        }
        if (isInventoryKey(keyCode, scanCode) && !isLineBoxFocused()) {
            returnToLastScreen();
            return true;
        }

        if (keyCode == 257 || keyCode == 335) {
            int focusedLine = getFocusedLineIndex();
            if (focusedLine >= 0) {
                if (focusedLine < PAGE_LINES - 1) {
                    focusLine(focusedLine + 1);
                } else {
                    pageForward();
                    focusLine(0);
                }
                return true;
            }
        }

        if (keyCode == 264) {
            int focusedLine = getFocusedLineIndex();
            if (focusedLine >= 0 && focusedLine < PAGE_LINES - 1) {
                focusLine(focusedLine + 1);
                return true;
            }
        }

        if (keyCode == 265) {
            int focusedLine = getFocusedLineIndex();
            if (focusedLine > 0) {
                focusLine(focusedLine - 1);
                return true;
            }
        }

        if (keyCode == 266) {
            pageBack();
            return true;
        }

        if (keyCode == 267) {
            pageForward();
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean handled = super.method_25402(mouseX, mouseY, button);
        updateLastFocusedLineBox();
        return handled;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        EditorBackgrounds.render(guiGraphics, this.field_22789, this.field_22790);
        int left = getBookLeft();
        guiGraphics.method_25290(class_10799.field_56883, class_3872.field_17117, left, 2,
                0.0F, 0.0F, IMAGE_WIDTH, IMAGE_WIDTH, 256, 256);
        class_2561 pageMsg = class_2561.method_43469("book.pageIndicator", this.currentPage + 1, Math.max(this.pages.size(), 1));
        guiGraphics.method_51439(this.field_22793, pageMsg, left - this.field_22793.method_27525(pageMsg) + IMAGE_WIDTH - 44, 18, 0, false);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void method_25419() {
        returnToLastScreen();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private boolean isInventoryKey(int keyCode, int scanCode) {
        return this.field_22787 != null
                && this.field_22787.field_1690.field_1822.method_1417(keyCode, scanCode);
    }

    private boolean isLineBoxFocused() {
        for (class_342 lineBox : this.lineBoxes) {
            if (lineBox.method_25370()) {
                return true;
            }
        }
        return false;
    }

    private int getBookLeft() {
        return (this.field_22789 - IMAGE_WIDTH) / 2;
    }

    private void pageBack() {
        if (this.currentPage <= 0) {
            return;
        }

        captureCurrentPageLines();
        this.currentPage--;
        syncLineBoxesFromPage();
        updateButtonVisibility();
    }

    private void pageForward() {
        captureCurrentPageLines();
        if (this.currentPage < this.pages.size() - 1) {
            this.currentPage++;
        } else if (this.pages.size() < MAX_PAGES) {
            this.pages.add("");
            this.currentPage = this.pages.size() - 1;
        } else {
            return;
        }

        syncLineBoxesFromPage();
        updateButtonVisibility();
    }

    private void deleteCurrentPage() {
        captureCurrentPageLines();
        if (this.pages.size() <= 1) {
            this.pages.set(0, "");
        } else {
            this.pages.remove(this.currentPage);
            this.currentPage = class_3532.method_15340(this.currentPage, 0, this.pages.size() - 1);
        }

        this.modified = true;
        writePagesToStack();
        syncLineBoxesFromPage();
        updateButtonVisibility();
    }

    private void updateButtonVisibility() {
        if (this.backButton != null) {
            this.backButton.field_22764 = this.currentPage > 0;
        }
        if (this.forwardButton != null) {
            this.forwardButton.field_22764 = this.currentPage < this.pages.size() - 1 || this.pages.size() < MAX_PAGES;
        }
        if (this.deletePageButton != null) {
            this.deletePageButton.field_22763 = this.pages.size() > 1 || !getCurrentPageText().isEmpty();
        }
    }

    private void syncLineBoxesFromPage() {
        this.syncingLineBoxes = true;
        for (int line = 0; line < this.lineBoxes.size(); line++) {
            this.lineBoxes.get(line).method_1852(getPageLine(this.currentPage, line));
        }
        this.syncingLineBoxes = false;
    }

    private void captureCurrentPageLines() {
        if (this.lineBoxes.isEmpty()) {
            return;
        }

        List<String> lines = new ArrayList<>();
        for (class_342 lineBox : this.lineBoxes) {
            lines.add(lineBox.method_1882());
        }
        String text = joinPageLines(lines);
        if (!text.equals(getCurrentPageText())) {
            setPageText(this.currentPage, text);
            this.modified = true;
        }
    }

    private void updatePageLine(int line, String value) {
        if (this.syncingLineBoxes) {
            return;
        }

        List<String> lines = splitPageLines(getCurrentPageText());
        while (lines.size() <= line) {
            lines.add("");
        }
        lines.set(line, value);
        setPageText(this.currentPage, joinPageLines(lines));
        this.modified = true;
        writePagesToStack();
        updateButtonVisibility();
    }

    private void setPageText(int page, String text) {
        ensurePageExists(page);
        this.pages.set(page, text);
    }

    private String getCurrentPageText() {
        return getPageText(this.currentPage);
    }

    private String getPageText(int page) {
        if (page < 0 || page >= this.pages.size()) {
            return "";
        }
        return this.pages.get(page);
    }

    private String getPageLine(int page, int line) {
        List<String> lines = splitPageLines(getPageText(page));
        return line >= 0 && line < lines.size() ? lines.get(line) : "";
    }

    private void ensurePageExists(int page) {
        while (this.pages.size() <= page) {
            this.pages.add("");
        }
    }

    private void focusLine(int line) {
        if (line < 0 || line >= this.lineBoxes.size()) {
            return;
        }
        class_342 lineBox = this.lineBoxes.get(line);
        for (class_342 box : this.lineBoxes) {
            box.method_25365(box == lineBox);
        }
        method_25395(lineBox);
        this.lastFocusedLineBox = lineBox;
    }

    private int getFocusedLineIndex() {
        for (int line = 0; line < this.lineBoxes.size(); line++) {
            if (this.lineBoxes.get(line).method_25370()) {
                return line;
            }
        }
        return this.lastFocusedLineBox == null ? -1 : this.lineBoxes.indexOf(this.lastFocusedLineBox);
    }

    private void updateLastFocusedLineBox() {
        class_364 focused = method_25399();
        if (focused instanceof class_342 editBox && this.lineBoxes.contains(editBox)) {
            this.lastFocusedLineBox = editBox;
        }
    }

    private void addFormatButtons() {
        class_124[] formats = class_124.values();
        int colorAmount = 2 + formats.length;
        int columns = colorAmount / FORMAT_BUTTON_ROWS;
        int startX = this.field_22789 - 1 - FORMAT_BUTTON_WIDTH * ((colorAmount + FORMAT_BUTTON_ROWS) / FORMAT_BUTTON_ROWS);
        int startY = this.field_22790 - FORMAT_BUTTON_Y_OFFSET;

        method_37063(new InfinityEditorButton(startX + FORMAT_BUTTON_WIDTH, startY,
                FORMAT_BUTTON_WIDTH, FORMAT_BUTTON_HEIGHT,
                class_2561.method_43470(String.valueOf(class_124.field_33292)), button -> insertFocusedText(String.valueOf(class_124.field_33292))));
        method_37063(new InfinityEditorButton(startX + FORMAT_BUTTON_WIDTH * 2, startY,
                FORMAT_BUTTON_WIDTH, FORMAT_BUTTON_HEIGHT,
                class_2561.method_43470(class_124.field_1079 + "%"), button -> stripFocusedFormatting()));

        for (int i = 2; i < colorAmount; i++) {
            class_124 format = formats[i - 2];
            int x = startX + FORMAT_BUTTON_WIDTH * ((i % columns) + 1);
            int y = startY + FORMAT_BUTTON_HEIGHT * (i / columns);
            method_37063(new InfinityEditorButton(x, y, FORMAT_BUTTON_WIDTH, FORMAT_BUTTON_HEIGHT,
                    class_2561.method_43470(format.toString() + format.method_36145()), button -> insertFocusedText(format.toString())));
        }
    }

    private void insertFocusedText(String text) {
        class_342 focused = getTargetLineBox();
        if (focused == null) {
            return;
        }
        focused.method_1867(text);
        this.lastFocusedLineBox = focused;
        focusLine(this.lineBoxes.indexOf(focused));
    }

    private void stripFocusedFormatting() {
        class_342 focused = getTargetLineBox();
        if (focused == null) {
            return;
        }
        focused.method_1852(Objects.requireNonNullElse(class_124.method_539(focused.method_1882()), ""));
        this.lastFocusedLineBox = focused;
        focusLine(this.lineBoxes.indexOf(focused));
    }

    @Nullable
    private class_342 getTargetLineBox() {
        updateLastFocusedLineBox();
        if (this.lastFocusedLineBox != null && this.lineBoxes.contains(this.lastFocusedLineBox)) {
            return this.lastFocusedLineBox;
        }
        return this.lineBoxes.isEmpty() ? null : this.lineBoxes.get(0);
    }

    private void readPagesFromStack() {
        this.pages.clear();
        class_2487 tag = ItemStackNbt.get(this.bookStack);
        if (tag != null && tag.method_10545(ItemEditorScreenState.BOOK_PAGES_TAG)) {
            class_2499 pageTags = tag.method_68569(ItemEditorScreenState.BOOK_PAGES_TAG);
            for (int i = 0; i < pageTags.size(); i++) {
                this.pages.add(readPageForEditing(pageTags.method_68577(i, "")));
            }
        }

        if (this.pages.isEmpty()) {
            this.pages.add("");
        }
        this.currentPage = class_3532.method_15340(this.currentPage, 0, this.pages.size() - 1);
    }

    private String readPageForEditing(String raw) {
        if (!this.bookStack.method_31574(class_1802.field_8360)) {
            return raw;
        }

        class_2561 parsed = this.lastScreen.readBookPageComponent(raw);
        return parsed.getString();
    }

    private void writePagesToStack() {
        List<String> savedPages = new ArrayList<>(this.pages);
        removeEmptyTrailingPages(savedPages);

        class_2487 tag = ItemStackNbt.getOrCreate(this.bookStack);
        if (savedPages.isEmpty()) {
            tag.method_10551(ItemEditorScreenState.BOOK_PAGES_TAG);
        } else {
            class_2499 pageTags = new class_2499();
            for (String page : savedPages) {
                pageTags.add(class_2519.method_23256(writePageForStack(page)));
            }
            tag.method_10566(ItemEditorScreenState.BOOK_PAGES_TAG, pageTags);
        }
        tag.method_10551(ItemEditorScreenState.BOOK_FILTERED_PAGES_TAG);
        if (tag.method_33133()) {
            ItemStackNbt.set(this.bookStack, null);
        }
    }

    private String writePageForStack(String page) {
        if (this.bookStack.method_31574(class_1802.field_8360)) {
            return ComponentCompat.toJson(this.lastScreen.readBookPageComponent(page));
        }
        return page;
    }

    private void returnToLastScreen() {
        captureCurrentPageLines();
        if (this.modified) {
            writePagesToStack();
        }
        this.lastScreen.refreshAfterBookEdit();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.lastScreen);
        }
    }

    private static void removeEmptyTrailingPages(List<String> pages) {
        for (int i = pages.size() - 1; i >= 0 && pages.get(i).isEmpty(); i--) {
            pages.remove(i);
        }
    }

    private static List<String> splitPageLines(String page) {
        String[] split = page.split("\n", -1);
        List<String> lines = new ArrayList<>(Math.max(split.length, PAGE_LINES));
        for (String line : split) {
            lines.add(line);
        }
        return lines;
    }

    private static String joinPageLines(List<String> lines) {
        int end = Math.min(lines.size(), PAGE_LINES);
        while (end > 0 && lines.get(end - 1).isEmpty()) {
            end--;
        }
        return String.join("\n", lines.subList(0, end));
    }

    private static String key(String suffix) {
        return "screen." + ModSource.MODID + "." + suffix;
    }
}
