package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.Config;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernUi;
import java.util.function.IntConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_357;

class ColorSlider extends class_357 {
    private final class_2561 label;
    private final IntConsumer responder;
    private float hoverAmount;

    ColorSlider(int x, int y, int width, int height, class_2561 label, int value, IntConsumer responder) {
        super(x, y, width, height, class_2561.method_43473(), class_3532.method_15340(value, 0, 255) / 255.0D);
        this.label = label;
        this.responder = responder;
        method_25346();
    }

    int getIntValue() {
        return class_3532.method_15340((int) Math.round(this.field_22753 * 255.0D), 0, 255);
    }

    void setIntValue(int value) {
        this.field_22753 = class_3532.method_15340(value, 0, 255) / 255.0D;
        method_25346();
    }

    @Override
    protected void method_25346() {
        method_25355(class_2561.method_43470(this.label.getString() + ": " + getIntValue()));
    }

    @Override
    protected void method_25344() {
        this.responder.accept(getIntValue());
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (Config.getItemGuiMode() != Config.ItemEditorUiMode.SIDEBAR) {
            super.method_48579(guiGraphics, mouseX, mouseY, partialTick);
            return;
        }

        updateHoverAmount(partialTick);

        int x = method_46426();
        int y = method_46427();
        int width = method_25368();
        int height = method_25364();
        boolean highlighted = this.method_25367() && this.field_22763;
        ModernUi.fillToolButton(guiGraphics, x, y, x + width, y + height, highlighted, this.field_22763, this.hoverAmount);

        int trackLeft = x + 7;
        int trackRight = x + width - 7;
        int trackY = y + height - 5;
        ModernUi.fillRounded(guiGraphics, trackLeft, trackY - 2, trackRight, trackY + 3, 2, ModernUi.alpha(0x000000, 92));
        guiGraphics.method_25294(trackLeft + 1, trackY - 1, trackRight - 1, trackY, ModernUi.alpha(0xFFFFFF, 24));
        int knobX = (int) (trackLeft + (trackRight - trackLeft) * this.field_22753);
        ModernUi.fillRounded(guiGraphics, trackLeft + 1, trackY - 1, knobX, trackY + 2, 2,
                ModernUi.lerpColor(ModernUi.ACCENT, ModernUi.WARM, this.hoverAmount));
        ModernUi.fillRounded(guiGraphics, knobX - 5, trackY - 5, knobX + 6, trackY + 7, 3, ModernUi.SHADOW_SOFT);
        ModernUi.fillRounded(guiGraphics, knobX - 4, trackY - 5, knobX + 5, trackY + 6, 3,
                ModernUi.lerpColor(ModernUi.ACCENT, ModernUi.ACCENT_HOVER, this.hoverAmount));
        guiGraphics.method_25294(knobX - 2, trackY - 3, knobX + 3, trackY - 2, ModernUi.alpha(0xFFFFFF, 95));
        guiGraphics.method_25294(knobX - 2, trackY + 3, knobX + 3, trackY + 4, ModernUi.alpha(0x000000, 70));

        var font = class_310.method_1551().field_1772;
        int textColor = ModernUi.lerpColor(ModernUi.TEXT_PRIMARY, ModernUi.ACCENT_HOVER, this.hoverAmount);
        guiGraphics.method_27534(font, method_25369(), x + width / 2, y + 4, textColor);
    }

    private void updateHoverAmount(float partialTick) {
        float target = this.field_22763 && this.method_25367() ? 1.0F : 0.0F;
        float speed = 0.16F + Math.min(partialTick, 1.0F) * 0.10F;
        this.hoverAmount += (target - this.hoverAmount) * speed;
        if (Math.abs(this.hoverAmount - target) < 0.01F) {
            this.hoverAmount = target;
        }
    }
}
