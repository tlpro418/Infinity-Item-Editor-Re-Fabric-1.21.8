package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;
import net.minecraft.class_11352;
import net.minecraft.class_11362;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_8942;

final class ContainerItemInventory implements class_1263 {
    private static final String BLOCK_ENTITY_TAG = "BlockEntityTag";
    private static final String CONTAINER_ITEMS_TAG = "Items";
    private static final int SIZE = 27;

    private final class_1799 containerStack;
    private final class_2371<class_1799> items = class_2371.method_10213(SIZE, class_1799.field_8037);

    ContainerItemInventory(class_1799 containerStack) {
        this.containerStack = containerStack;
        class_1262.method_5429(class_11352.method_71417(class_8942.field_60348, ItemStackNbt.provider(),
                ItemStackNbt.getOrCreateElement(containerStack, BLOCK_ENTITY_TAG)), this.items);
    }

    class_2561 getDisplayName() {
        return this.containerStack.method_7964();
    }

    @Override
    public int method_5439() {
        return SIZE;
    }

    @Override
    public boolean method_5442() {
        for (class_1799 stack : this.items) {
            if (!stack.method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public class_1799 method_5438(int slot) {
        return isValidSlot(slot) ? this.items.get(slot) : class_1799.field_8037;
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        class_1799 removed = class_1262.method_5430(this.items, slot, amount);
        if (!removed.method_7960()) {
            method_5431();
        }
        return removed;
    }

    @Override
    public class_1799 method_5441(int slot) {
        if (!isValidSlot(slot)) {
            return class_1799.field_8037;
        }
        class_1799 removed = class_1262.method_5428(this.items, slot);
        if (!removed.method_7960()) {
            saveToStack();
        }
        return removed;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        if (!isValidSlot(slot)) {
            return;
        }
        this.items.set(slot, stack);
        if (!stack.method_7960() && stack.method_7947() > method_5444()) {
            stack.method_7939(method_5444());
        }
        method_5431();
    }

    @Override
    public void method_5431() {
        saveToStack();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
        for (int slot = 0; slot < this.items.size(); slot++) {
            this.items.set(slot, class_1799.field_8037);
        }
        method_5431();
    }

    private void saveToStack() {
        class_2487 blockEntity = ItemStackNbt.getOrCreateElement(this.containerStack, BLOCK_ENTITY_TAG);
        class_11362 output = class_11362.method_71459(class_8942.field_60348, ItemStackNbt.provider());
        class_1262.method_5426(output, this.items);
        class_2487 written = output.method_71475();
        if (written.method_10545(CONTAINER_ITEMS_TAG)) {
            blockEntity.method_10566(CONTAINER_ITEMS_TAG, written.method_10580(CONTAINER_ITEMS_TAG));
        }
        if (method_5442()) {
            blockEntity.method_10551(CONTAINER_ITEMS_TAG);
        }
        cleanupBlockEntityTag(blockEntity);
    }

    private boolean isValidSlot(int slot) {
        return slot >= 0 && slot < this.items.size();
    }

    private void cleanupBlockEntityTag(class_2487 blockEntity) {
        class_2487 tag = ItemStackNbt.get(this.containerStack);
        if (tag == null) {
            return;
        }

        if (blockEntity.method_33133()) {
            tag.method_10551(BLOCK_ENTITY_TAG);
        } else {
            tag.method_10566(BLOCK_ENTITY_TAG, blockEntity);
        }

        if (tag.method_33133()) {
            ItemStackNbt.set(this.containerStack, null);
        }
    }
}
