package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import net.minecraft.class_10630;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_476;
final class ContainerItemScreen extends class_476 {
    private static final int INVENTORY_CLONE_COLOR = 0x7C2C87;

    private final class_437 lastScreen;
    private final class_1661 copiedInventory;

    static ContainerItemScreen create(ItemEditorScreen lastScreen, class_1657 player, class_1799 containerStack) {
        class_1661 copiedInventory = copyInventory(player.method_31548());
        ContainerItemInventory containerInventory = new ContainerItemInventory(containerStack);
        class_1707 menu = class_1707.method_19245(0, copiedInventory, containerInventory);
        return new ContainerItemScreen(lastScreen, menu, copiedInventory, containerInventory.getDisplayName());
    }

    private ContainerItemScreen(class_437 lastScreen, class_1707 menu, class_1661 copiedInventory, class_2561 title) {
        super(menu, copiedInventory, title);
        this.lastScreen = lastScreen;
        this.copiedInventory = copiedInventory;
    }

    @Override
    protected void method_2383(class_1735 slot, int slotId, int mouseButton, class_1713 clickType) {
        if (this.field_22787 == null || this.field_22787.field_1724 == null) {
            return;
        }
        if (slot != null) {
            slotId = slot.field_7874;
        }
        if (clickType == class_1713.field_7791) {
            handleLocalSwap(slot, mouseButton);
            return;
        }

        this.field_2797.method_7593(slotId, mouseButton, clickType, this.field_22787.field_1724);
        this.field_2797.method_7623();
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        method_37063(new InfinityEditorButton(this.field_2776 + this.field_2792 + 4, this.field_2800, 80, 20,
                class_2561.method_43471("screen." + ModSource.MODID + ".pick"), button -> openPickScreen()));
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        EditorBackgrounds.render(guiGraphics, this.field_22789, this.field_22790);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256 || isInventoryKey(keyCode, scanCode)) {
            returnToLastScreen();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    protected void method_2388(class_332 guiGraphics, int mouseX, int mouseY) {
        super.method_2388(guiGraphics, mouseX, mouseY);
        class_2561 cloneLabel = class_2561.method_43471("screen." + ModSource.MODID + ".container.inventory_clone");
        guiGraphics.method_51439(this.field_22793, cloneLabel, (this.field_2792 - this.field_22793.method_27525(cloneLabel)) / 2, -10,
                INVENTORY_CLONE_COLOR, false);
    }

    @Override
    public void method_25419() {
        returnToLastScreen();
    }

    private boolean isInventoryKey(int keyCode, int scanCode) {
        return this.field_22787 != null
                && this.field_22787.field_1690.field_1822.method_1417(keyCode, scanCode);
    }

    private void returnToLastScreen() {
        if (this.lastScreen instanceof ItemEditorScreen editorScreen) {
            editorScreen.refreshAfterContainerEdit();
        }
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.lastScreen);
        }
    }

    private void openPickScreen() {
        if (this.field_22787 == null) {
            return;
        }
        this.field_22787.method_1507(new ItemPickScreen(this, this::setPickedStack, this::getPickedStack));
    }

    private void setPickedStack(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return;
        }
        this.field_2797.method_34254(stack.method_7972());
        this.field_2797.method_7623();
    }

    private class_1799 getPickedStack() {
        return this.field_2797.method_34255();
    }

    private void handleLocalSwap(class_1735 slot, int inventorySlot) {
        if (slot == null || inventorySlot < 0 || inventorySlot >= this.copiedInventory.method_5439()
                || this.field_22787 == null || this.field_22787.field_1724 == null || !this.field_2797.method_34255().method_7960()) {
            return;
        }

        class_1657 player = this.field_22787.field_1724;
        class_1799 inventoryStack = this.copiedInventory.method_5438(inventorySlot);
        class_1799 slotStack = slot.method_7677();
        if (inventoryStack.method_7960() && slotStack.method_7960()) {
            return;
        }

        if (inventoryStack.method_7960()) {
            if (slot.method_7674(player)) {
                this.copiedInventory.method_5447(inventorySlot, slotStack.method_7972());
                slot.method_53512(class_1799.field_8037);
                slot.method_7667(player, slotStack);
            }
        } else if (slotStack.method_7960()) {
            if (slot.method_7680(inventoryStack)) {
                class_1799 moved = splitForSlot(slot, inventoryStack);
                slot.method_53512(moved);
                this.copiedInventory.method_5447(inventorySlot, inventoryStack.method_7960() ? class_1799.field_8037 : inventoryStack);
            }
        } else if (slot.method_7674(player) && slot.method_7680(inventoryStack)) {
            class_1799 moved = splitForSlot(slot, inventoryStack);
            slot.method_53512(moved);
            if (inventoryStack.method_7960()) {
                this.copiedInventory.method_5447(inventorySlot, slotStack.method_7972());
            } else if (!this.copiedInventory.method_7394(slotStack.method_7972())) {
                this.field_2797.method_34254(slotStack.method_7972());
            }
            slot.method_7667(player, slotStack);
        }

        this.field_2797.method_7623();
    }

    private static class_1799 splitForSlot(class_1735 slot, class_1799 stack) {
        int max = slot.method_7676(stack);
        if (stack.method_7947() > max) {
            return stack.method_7971(max);
        }

        class_1799 moved = stack.method_7972();
        stack.method_7939(0);
        return moved;
    }

    private static class_1661 copyInventory(class_1661 source) {
        class_1661 copied = new class_1661(source.field_7546, new class_10630());
        for (int slot = 0; slot < source.method_5439(); slot++) {
            copied.method_5447(slot, source.method_5438(slot).method_7972());
        }
        copied.method_61496(source.method_67532());
        return copied;
    }
}
