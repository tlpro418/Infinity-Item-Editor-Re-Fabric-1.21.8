package io.github.seraphina.infinity_item_editor_re.client.screen;

import net.minecraft.class_310;
import net.minecraft.class_332;

/** Keeps tooltip bounds and scissor rectangles in sync with the scaled editor canvas. */
final class EditorGuiGraphics extends class_332 {
    private final EditorViewport viewport;

    EditorGuiGraphics(class_310 minecraft, class_332 target, EditorViewport viewport) {
        super(minecraft, target.field_59826);
        this.viewport = viewport;
        method_51448().set(target.method_51448());
        method_51448().scale((float) viewport.scale(), (float) viewport.scale());
    }

    @Override
    public int method_51421() {
        return this.viewport.width();
    }

    @Override
    public int method_51443() {
        return this.viewport.height();
    }

}
