package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.Config;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernUi;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_437;

class FixedDigitEditBox extends class_342 {
    private static final int DISABLED_COLOR = 0xFF707070;

    private final class_327 font;
    private final int digits;
    private final int minValue;
    private final int maxValue;
    private int digitCursor;
    private int cursorFrame;

    FixedDigitEditBox(class_327 font, int x, int y, int width, int height, int digits, int minValue, int maxValue) {
        super(font, x, y, width, height, class_2561.method_43473());
        this.font = font;
        this.digits = Math.max(1, digits);
        this.minValue = minValue;
        this.maxValue = maxValue;
        super.method_1880(this.digits + (minValue < 0 ? 1 : 0));
        super.method_1868(InfinityEditorButton.MAIN_COLOR);
        super.method_1860(DISABLED_COLOR);
        setFixedValue(minValue);
    }

    public void tick() {
        this.cursorFrame++;
    }

    @Override
    public void method_1852(String value) {
        setFixedValue(parseFixedValue(value));
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (!this.field_22763 || !method_20315()) {
            return false;
        }

        if (class_437.method_25438(keyCode)) {
            class_310.method_1551().field_1774.method_1455(method_1882());
            return true;
        }
        if (class_437.method_25437(keyCode)) {
            return true;
        }
        if (class_437.method_25436(keyCode)) {
            class_310.method_1551().field_1774.method_1455(method_1882());
            setFixedValue(0);
            return true;
        }

        return switch (keyCode) {
            case 259, 261 -> {
                replaceDigit('0');
                yield true;
            }
            case 262 -> {
                moveDigitCursor(1);
                yield true;
            }
            case 263 -> {
                moveDigitCursor(-1);
                yield true;
            }
            case 268 -> {
                setDigitCursorPosition(0);
                yield true;
            }
            case 269 -> {
                setDigitCursorPosition(this.digits - 1);
                yield true;
            }
            default -> false;
        };
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        if (!this.field_22763 || !method_20315()) {
            return false;
        }

        if (codePoint == '-' && this.minValue < 0) {
            setFixedValue(-Math.abs(parseFixedValue(method_1882())));
            return true;
        }
        if (codePoint == '+' && this.maxValue >= 0) {
            setFixedValue(Math.abs(parseFixedValue(method_1882())));
            return true;
        }
        if (codePoint >= '0' && codePoint <= '9') {
            replaceDigit(codePoint);
            moveDigitCursor(1);
            return true;
        }
        return true;
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        int localX = class_3532.method_15357(mouseX) - method_46426() - 4;
        String value = method_1882();
        int cursor = this.font.method_27523(value, Math.max(0, localX)).length();
        if (value.startsWith("-")) {
            cursor--;
        }
        setDigitCursorPosition(cursor);
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!method_1885()) {
            return;
        }

        boolean sidebarUi = Config.getItemGuiMode() == Config.ItemEditorUiMode.SIDEBAR;
        int color = this.field_22763 ? (sidebarUi ? ModernUi.TEXT_PRIMARY : InfinityEditorButton.MAIN_COLOR) : DISABLED_COLOR;
        if (sidebarUi) {
            ModernUi.fillInset(guiGraphics, method_46426() - 2, method_46427() + 1, method_46426() + method_25368() + 2, method_46427() + method_25364() - 1,
                    6, this.field_22763 && (method_25370() || method_25405(mouseX, mouseY)), this.field_22763);
        } else {
            guiGraphics.method_25294(method_46426() - 1, method_46427() - 1, method_46426() + method_25368() + 1, method_46427() + method_25364() + 1, color);
            guiGraphics.method_25294(method_46426(), method_46427(), method_46426() + method_25368(), method_46427() + method_25364(), InfinityEditorButton.ALT_COLOR);
        }

        String value = method_1882();
        int textX = method_46426() + 4;
        int textY = method_46427() + (method_25364() - 8) / 2;
        int cursorStringPosition = getCursorStringPosition();
        int cursorX = textX;

        if (!value.isEmpty()) {
            String beforeCursor = value.substring(0, Math.min(cursorStringPosition, value.length()));
            if (!beforeCursor.isEmpty()) {
                guiGraphics.method_51433(this.font, beforeCursor, textX, textY, color, !sidebarUi);
                cursorX = textX + this.font.method_1727(beforeCursor) - 1;
            }

            if (cursorStringPosition < value.length()) {
                guiGraphics.method_51433(this.font, value.substring(cursorStringPosition), cursorX, textY, color, !sidebarUi);
            }
        }

        if (method_25370() && this.cursorFrame / 6 % 2 == 0) {
            guiGraphics.method_51433(this.font, "_", cursorX, textY,
                    sidebarUi ? ModernUi.ACCENT_HOVER : InfinityEditorButton.CONTRAST_COLOR, !sidebarUi);
        }
    }

    private void replaceDigit(char digit) {
        char[] characters = getDigitCharacters();
        characters[this.digitCursor] = digit;
        int value = parseFixedValue(new String(characters));
        if (method_1882().startsWith("-")) {
            value = -value;
        }
        int cursor = this.digitCursor;
        setFixedValue(value);
        setDigitCursorPosition(cursor);
    }

    private void moveDigitCursor(int amount) {
        setDigitCursorPosition(this.digitCursor + amount);
    }

    private void setDigitCursorPosition(int position) {
        this.digitCursor = class_3532.method_15340(position, 0, this.digits - 1);
        syncSuperCursor();
    }

    private void setFixedValue(int value) {
        int clamped = class_3532.method_15340(value, this.minValue, this.maxValue);
        super.method_1852(formatFixedValue(clamped));
        this.digitCursor = class_3532.method_15340(this.digitCursor, 0, this.digits - 1);
        syncSuperCursor();
    }

    private void syncSuperCursor() {
        int cursor = getCursorStringPosition();
        super.method_1875(cursor);
        super.method_1884(cursor);
    }

    private int getCursorStringPosition() {
        return method_1882().startsWith("-") ? this.digitCursor + 1 : this.digitCursor;
    }

    private char[] getDigitCharacters() {
        String value = method_1882();
        String rawDigits = value.startsWith("-") ? value.substring(1) : value;
        if (rawDigits.length() < this.digits) {
            rawDigits = "0".repeat(this.digits - rawDigits.length()) + rawDigits;
        } else if (rawDigits.length() > this.digits) {
            rawDigits = rawDigits.substring(rawDigits.length() - this.digits);
        }
        return rawDigits.toCharArray();
    }

    private String formatFixedValue(int value) {
        boolean negative = value < 0;
        String rawDigits = Integer.toString(Math.abs(value));
        if (rawDigits.length() < this.digits) {
            rawDigits = "0".repeat(this.digits - rawDigits.length()) + rawDigits;
        }
        return negative ? "-" + rawDigits : rawDigits;
    }

    private int parseFixedValue(String value) {
        if (value == null || value.isBlank()) {
            return 0;
        }

        boolean negative = value.startsWith("-");
        long parsed = 0L;
        for (int i = negative ? 1 : 0; i < value.length(); i++) {
            char character = value.charAt(i);
            if (character >= '0' && character <= '9') {
                parsed = parsed * 10L + character - '0';
                if (parsed > Integer.MAX_VALUE) {
                    return negative ? Integer.MIN_VALUE : Integer.MAX_VALUE;
                }
            }
        }
        return (int) (negative ? -parsed : parsed);
    }
}
