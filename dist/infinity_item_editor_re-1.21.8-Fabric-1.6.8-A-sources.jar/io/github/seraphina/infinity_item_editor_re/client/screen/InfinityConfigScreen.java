package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.Config;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_5481;
public class InfinityConfigScreen extends class_437 {
    private static final int LIST_TOP = 32;
    private static final int LIST_BOTTOM_PADDING = 40;
    private static final int ROW_HEIGHT = 48;
    private static final int BUTTON_WIDTH = 74;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 6;
    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int MUTED_TEXT_COLOR = 0xFFB0B0B0;
    private static final int SAVED_TEXT_COLOR = 0xFF55FF55;

    private final class_437 parent;
    private Config.ItemEditorUiMode pendingItemGuiMode;
    private final Map<Config.BooleanEntry, Boolean> pendingValues = new LinkedHashMap<>();
    private class_2561 status = class_2561.method_43473();
    private ConfigList configList;

    public InfinityConfigScreen(class_437 parent) {
        super(class_2561.method_43471(key("title")));
        this.parent = parent;
        this.pendingItemGuiMode = Config.getItemGuiMode();
        for (Config.BooleanEntry entry : Config.booleanEntries()) {
            this.pendingValues.put(entry, entry.get());
        }
    }

    @Override
    protected void method_25426() {
        int listBottom = this.field_22790 - LIST_BOTTOM_PADDING;
        this.configList = new ConfigList(this, this.field_22787, this.field_22789, this.field_22790, LIST_TOP, listBottom);
        this.method_37063(this.configList);

        int totalButtonWidth = BUTTON_WIDTH * 3 + BUTTON_GAP * 2;
        int x = (this.field_22789 - totalButtonWidth) / 2;
        int y = this.field_22790 - 27;
        this.method_37063(class_4185.method_46430(class_2561.method_43471(key("save")), button -> saveChanges())
                .method_46434(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                .method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43471(key("reset")), button -> resetToDefaults())
                .method_46434(x + BUTTON_WIDTH + BUTTON_GAP, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                .method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43471(key("done")), button -> saveAndClose())
                .method_46434(x + (BUTTON_WIDTH + BUTTON_GAP) * 2, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        EditorBackgrounds.render(guiGraphics, this.field_22789, this.field_22790);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, TEXT_COLOR);
        if (!this.status.getString().isEmpty()) {
            guiGraphics.method_27534(this.field_22793, this.status, this.field_22789 / 2, this.field_22790 - 38, SAVED_TEXT_COLOR);
        }
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void method_25419() {
        saveAndClose();
    }

    private boolean getPendingValue(Config.BooleanEntry entry) {
        return this.pendingValues.getOrDefault(entry, entry.get());
    }

    private void toggle(Config.BooleanEntry entry) {
        this.pendingValues.put(entry, !getPendingValue(entry));
        this.status = class_2561.method_43473();
    }

    private Config.ItemEditorUiMode getPendingItemGuiMode() {
        return this.pendingItemGuiMode;
    }

    private void cycleItemGuiMode() {
        this.pendingItemGuiMode = this.pendingItemGuiMode == Config.ItemEditorUiMode.LEGACY
                ? Config.ItemEditorUiMode.SIDEBAR
                : Config.ItemEditorUiMode.LEGACY;
        this.status = class_2561.method_43473();
    }

    private void resetToDefaults() {
        this.pendingItemGuiMode = Config.ItemEditorUiMode.LEGACY;
        for (Config.BooleanEntry entry : Config.booleanEntries()) {
            this.pendingValues.put(entry, entry.defaultValue());
        }
        saveChanges();
    }

    private void saveChanges() {
        Config.setItemGuiMode(this.pendingItemGuiMode);
        for (Map.Entry<Config.BooleanEntry, Boolean> entry : this.pendingValues.entrySet()) {
            entry.getKey().set(entry.getValue());
        }
        Config.syncPublicFields();
        Config.save();
        CreativeTabRefresher.rebuildAllTabs(this.field_22787);
        this.status = class_2561.method_43471(key("saved"));
    }

    private void saveAndClose() {
        saveChanges();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    private static String key(String suffix) {
        return "config." + ModSource.MODID + "." + suffix;
    }

    private static class_2561 booleanText(boolean value) {
        return class_2561.method_43471(key(value ? "on" : "off"));
    }

    private static class_2561 itemGuiModeText(Config.ItemEditorUiMode mode) {
        return class_2561.method_43471("screen." + ModSource.MODID + ".ui.mode." + mode.name().toLowerCase(java.util.Locale.ROOT));
    }
    private static final class ConfigList extends class_4280<ConfigEntry> {
        private ConfigList(InfinityConfigScreen screen, class_310 minecraft, int width, int height, int top, int bottom) {
            super(minecraft, width, bottom - top, top, ROW_HEIGHT);
            this.method_25321(new ConfigEntry(screen, null));
            for (Config.BooleanEntry entry : Config.booleanEntries()) {
                this.method_25321(new ConfigEntry(screen, entry));
            }
        }

        @Override
        public int method_25322() {
            return Math.min(560, Math.max(260, this.field_22758 - 72));
        }

        @Override
        protected int method_65507() {
            return Math.min(this.field_22758 - 8, this.method_31383() + 6);
        }

        @Override
        protected void method_57715(class_332 guiGraphics) {
        }

        @Override
        protected void method_57713(class_332 guiGraphics) {
        }

        @Override
        protected void method_44398(class_332 guiGraphics, int top, int width, int height, int outerColor, int innerColor) {
        }
    }
    private static final class ConfigEntry extends class_4280.class_4281<ConfigEntry> {
        private static final int TOGGLE_WIDTH = 58;
        private static final int TOGGLE_HEIGHT = 20;
        private static final int TOGGLE_TEXT_COLOR = 0xFFFFFFFF;
        private static final int ENABLED_FILL = 0xFF246B3A;
        private static final int DISABLED_FILL = 0xFF6B2836;
        private static final int BORDER_COLOR = 0xFF000000;
        private static final int HOVER_FILL = 0x33000000;

        private final InfinityConfigScreen screen;
        private final Config.BooleanEntry entry;

        private ConfigEntry(InfinityConfigScreen screen, Config.BooleanEntry entry) {
            this.screen = screen;
            this.entry = entry;
        }

        @Override
        public void method_25343(class_332 guiGraphics, int index, int top, int left, int width, int height,
                           int mouseX, int mouseY, boolean hovered, float partialTick) {
            if (hovered) {
                guiGraphics.method_25294(left - 4, top - 1, left + width + 4, top + height - 3, HOVER_FILL);
            }

            int toggleX = left + width - TOGGLE_WIDTH - 2;
            int toggleY = top + (height - TOGGLE_HEIGHT) / 2 - 2;
            int textWidth = Math.max(1, toggleX - left - 12);
            if (this.entry == null) {
                class_2561 modeTitle = class_2561.method_43471(key("item_gui_mode.title"));
                class_2561 modeDescription = class_2561.method_43471(key("item_gui_mode.description"));
                class_2561 modeText = itemGuiModeText(this.screen.getPendingItemGuiMode());
                guiGraphics.method_27535(this.screen.field_22793, modeTitle, left, top + 4, TEXT_COLOR);
                List<class_5481> description = this.screen.field_22793.method_1728(modeDescription, textWidth);
                for (int line = 0; line < Math.min(2, description.size()); line++) {
                    guiGraphics.method_35720(this.screen.field_22793, description.get(line), left, top + 17 + line * 10, MUTED_TEXT_COLOR);
                }
                guiGraphics.method_25294(toggleX - 1, toggleY - 1, toggleX + TOGGLE_WIDTH + 1, toggleY + TOGGLE_HEIGHT + 1, BORDER_COLOR);
                guiGraphics.method_25294(toggleX, toggleY, toggleX + TOGGLE_WIDTH, toggleY + TOGGLE_HEIGHT, 0xFF30345F);
                int modeTextX = toggleX + (TOGGLE_WIDTH - this.screen.field_22793.method_27525(modeText)) / 2;
                guiGraphics.method_27535(this.screen.field_22793, modeText, modeTextX, toggleY + 6, TOGGLE_TEXT_COLOR);
                return;
            }

            boolean value = this.screen.getPendingValue(this.entry);
            guiGraphics.method_27535(this.screen.field_22793, class_2561.method_43471(this.entry.titleKey()), left, top + 4, TEXT_COLOR);
            List<class_5481> description = this.screen.field_22793.method_1728(
                    class_2561.method_43471(this.entry.descriptionKey()),
                    textWidth
            );
            for (int line = 0; line < Math.min(2, description.size()); line++) {
                guiGraphics.method_35720(this.screen.field_22793, description.get(line), left, top + 17 + line * 10, MUTED_TEXT_COLOR);
            }

            guiGraphics.method_25294(toggleX - 1, toggleY - 1, toggleX + TOGGLE_WIDTH + 1, toggleY + TOGGLE_HEIGHT + 1, BORDER_COLOR);
            guiGraphics.method_25294(toggleX, toggleY, toggleX + TOGGLE_WIDTH, toggleY + TOGGLE_HEIGHT,
                    value ? ENABLED_FILL : DISABLED_FILL);
            class_2561 text = booleanText(value);
            int textX = toggleX + (TOGGLE_WIDTH - this.screen.field_22793.method_27525(text)) / 2;
            guiGraphics.method_27535(this.screen.field_22793, text, textX, toggleY + 6, TOGGLE_TEXT_COLOR);
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            if (button != 0) {
                return false;
            }
            if (this.entry == null) {
                this.screen.cycleItemGuiMode();
                return true;
            }
            this.screen.toggle(this.entry);
            return true;
        }

        @Override
        public class_2561 method_37006() {
            if (this.entry == null) {
                return class_2561.method_43473()
                        .method_10852(class_2561.method_43471(key("item_gui_mode.title")))
                        .method_27693(" ")
                        .method_10852(itemGuiModeText(this.screen.getPendingItemGuiMode()));
            }

            return class_2561.method_43473()
                    .method_10852(class_2561.method_43471(this.entry.titleKey()))
                    .method_27693(" ")
                    .method_10852(booleanText(this.screen.getPendingValue(this.entry)));
        }
    }
}
