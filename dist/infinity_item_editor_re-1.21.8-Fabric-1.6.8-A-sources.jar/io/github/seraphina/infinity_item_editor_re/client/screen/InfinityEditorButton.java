package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.Config;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernUi;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6382;

public class InfinityEditorButton extends class_4264 {
    public static final int MAIN_COLOR = 0xFF9600C8;
    public static final int ALT_COLOR = 0xFF32144B;
    public static final int CONTRAST_COLOR = 0xFF0064FF;
    private static final int DISABLED_COLOR = 0xFFF44262;
    private static final int LIGHT_SHADE = 0x1AFFFFFF;
    private static final int DARK_SHADE = 0x32000000;

    private final PressAction onPress;
    private float hoverAmount;

    public InfinityEditorButton(int x, int y, int width, int height, class_2561 message, PressAction onPress) {
        super(x, y, width, height, message);
        this.onPress = onPress;
    }

    @Override
    public void method_25306() {
        this.onPress.onPress(this);
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateHoverAmount(partialTick);
        if (Config.getItemGuiMode() == Config.ItemEditorUiMode.SIDEBAR) {
            renderSidebarWidget(guiGraphics);
            return;
        }

        int x = method_46426();
        int y = method_46427();
        int width = method_25368();
        int height = method_25364();

        guiGraphics.method_25294(x, y, x + width, y + height, ALT_COLOR);
        guiGraphics.method_25294(x, y, x + width, y + 1, LIGHT_SHADE);
        guiGraphics.method_25294(x, y, x + 1, y + height, LIGHT_SHADE);
        guiGraphics.method_25294(x, y + height - 1, x + width, y + height, DARK_SHADE);
        guiGraphics.method_25294(x + width - 1, y, x + width, y + height, DARK_SHADE);

        int textColor = this.field_22763 ? (this.method_25367() ? CONTRAST_COLOR : MAIN_COLOR) : DISABLED_COLOR;
        method_49604(guiGraphics, class_310.method_1551().field_1772, 2, textColor);
    }

    private void renderSidebarWidget(class_332 guiGraphics) {
        int x = method_46426();
        int y = method_46427();
        int width = method_25368();
        int height = method_25364();
        boolean highlighted = this.method_25367() && this.field_22763;
        if (width <= 16 || height <= 16) {
            ModernUi.fillToolPaletteCell(guiGraphics, x, y, x + width, y + height, highlighted, this.field_22763);
        } else {
            ModernUi.fillToolButton(guiGraphics, x, y, x + width, y + height, highlighted, this.field_22763, this.hoverAmount);
        }

        var font = class_310.method_1551().field_1772;
        int textColor = this.field_22763
                ? ModernUi.lerpColor(ModernUi.TEXT_PRIMARY, ModernUi.ACCENT_HOVER, this.hoverAmount)
                : 0xFF6D7875;
        int inset = width <= 20 ? 1 : 7;
        renderCenteredModernText(guiGraphics, font, x + inset, y, x + width - inset, y + height, textColor);
    }

    private void renderCenteredModernText(class_332 guiGraphics, class_327 font, int left, int top, int right, int bottom, int color) {
        int maxWidth = Math.max(0, right - left);
        int centerX = (left + right) / 2;
        int textY = top + (bottom - top - 8) / 2;
        class_2561 message = method_25369();
        if (font.method_27525(message) <= maxWidth) {
            guiGraphics.method_27534(font, message, centerX, textY, color);
            return;
        }

        String ellipsis = "...";
        int ellipsisWidth = font.method_1727(ellipsis);
        String text = message.getString();
        String clipped = maxWidth <= ellipsisWidth
                ? font.method_27523(text, maxWidth)
                : font.method_27523(text, maxWidth - ellipsisWidth) + ellipsis;
        guiGraphics.method_25300(font, clipped, centerX, textY, color);
    }

    private void updateHoverAmount(float partialTick) {
        float target = this.field_22763 && this.method_25367() ? 1.0F : 0.0F;
        float speed = 0.18F + Math.min(partialTick, 1.0F) * 0.12F;
        this.hoverAmount += (target - this.hoverAmount) * speed;
        if (Math.abs(this.hoverAmount - target) < 0.01F) {
            this.hoverAmount = target;
        }
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {
        method_37021(narrationElementOutput);
    }

    @FunctionalInterface
    public interface PressAction {
        void onPress(InfinityEditorButton button);
    }
}
