package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import io.github.seraphina.infinity_item_editor_re.ModSource;
final class ItemCommandBlockEditorScreen extends class_437 {
    private static final int BUTTON_HEIGHT = 20;
    private static final int EDITOR_MARGIN = 18;
    private static final int EDITOR_TOP = 44;
    private static final int EDITOR_TOP_WITH_OPTIONS = 68;
    private static final int OPTIONS_Y = 40;
    private static final int EDITOR_BOTTOM_MARGIN = 52;
    private static final int STATUS_GOOD = 0xFF32CC64;
    private static final int STATUS_NEUTRAL = 0xFFFFD966;
    private static final String BLOCK_ENTITY_TAG = "BlockEntityTag";
    private static final String BLOCK_STATE_TAG = "BlockStateTag";
    private static final String ENTITY_TAG = "EntityTag";
    private static final String ENTITY_ID_TAG = "id";
    private static final String COMMAND_BLOCK_MINECART_ENTITY_ID = "minecraft:command_block_minecart";
    private static final String COMMAND_TAG = "Command";
    private static final String AUTO_TAG = "auto";
    private static final String CONDITIONAL_TAG = "conditional";

    private final ItemEditorScreen lastScreen;
    private final boolean supportsCommandBlockOptions;
    private class_1799 commandStack;
    private String commandText;
    private String appliedCommandText;
    private boolean unconditional;
    private boolean appliedUnconditional;
    private boolean alwaysActive;
    private boolean appliedAlwaysActive;
    private ItemJsonEditorScreen.JsonCodeEditBox commandBox;
    private InfinityEditorButton conditionButton;
    private InfinityEditorButton activationButton;
    private class_2561 status = class_2561.method_43473();
    private int statusColor = STATUS_NEUTRAL;
    private boolean discardArmed;

    ItemCommandBlockEditorScreen(ItemEditorScreen lastScreen, class_1799 stack) {
        super(class_2561.method_43471(key("commandblock")));
        this.lastScreen = lastScreen;
        this.commandStack = stack.method_7972();
        this.supportsCommandBlockOptions = supportsCommandBlockOptions(this.commandStack);
        this.commandText = readCommand(this.commandStack);
        this.appliedCommandText = this.commandText;
        this.unconditional = readUnconditional(this.commandStack);
        this.appliedUnconditional = this.unconditional;
        this.alwaysActive = readAlwaysActive(this.commandStack);
        this.appliedAlwaysActive = this.alwaysActive;
    }

    @Override
    protected void method_25426() {
        if (this.supportsCommandBlockOptions) {
            int optionGap = 4;
            int optionWidth = class_3532.method_15340((this.field_22789 - EDITOR_MARGIN * 2 - optionGap) / 2, 104, 160);
            int totalWidth = optionWidth * 2 + optionGap;
            int optionX = (this.field_22789 - totalWidth) / 2;
            this.conditionButton = method_37063(new InfinityEditorButton(optionX, OPTIONS_Y, optionWidth, BUTTON_HEIGHT,
                    conditionModeText(), button -> toggleUnconditional()));
            this.activationButton = method_37063(new InfinityEditorButton(optionX + optionWidth + optionGap, OPTIONS_Y,
                    optionWidth, BUTTON_HEIGHT, activationModeText(), button -> toggleAlwaysActive()));
        }

        int editorWidth = Math.max(180, this.field_22789 - EDITOR_MARGIN * 2);
        int editorTop = this.supportsCommandBlockOptions ? EDITOR_TOP_WITH_OPTIONS : EDITOR_TOP;
        int editorHeight = Math.max(80, this.field_22790 - editorTop - EDITOR_BOTTOM_MARGIN);
        this.commandBox = method_37063(new ItemJsonEditorScreen.JsonCodeEditBox(this.field_22793, EDITOR_MARGIN, editorTop,
                editorWidth, editorHeight, class_2561.method_43471(key("commandblock.placeholder"))));
        this.commandBox.useCommandCompletions();
        this.commandBox.setValue(this.commandText);
        this.commandBox.setValueListener(value -> {
            this.commandText = value;
            this.discardArmed = false;
        });
        method_25395(this.commandBox);
        this.commandBox.method_25365(true);

        int buttons = 4;
        int buttonWidth = class_3532.method_15340((this.field_22789 - EDITOR_MARGIN * 2 - (buttons - 1) * 4) / buttons, 58, 86);
        int totalWidth = buttonWidth * buttons + (buttons - 1) * 4;
        int x = (this.field_22789 - totalWidth) / 2;
        int buttonY = this.field_22790 - 28;
        method_37063(new InfinityEditorButton(x, buttonY, buttonWidth, BUTTON_HEIGHT,
                class_2561.method_43471(key("back")), button -> returnToLastScreen()));
        method_37063(new InfinityEditorButton(x + (buttonWidth + 4), buttonY, buttonWidth, BUTTON_HEIGHT,
                class_2561.method_43471(key("reset")), button -> resetCommand()));
        method_37063(new InfinityEditorButton(x + (buttonWidth + 4) * 2, buttonY, buttonWidth, BUTTON_HEIGHT,
                class_2561.method_43471(key("clear")), button -> clearCommand()));
        method_37063(new InfinityEditorButton(x + (buttonWidth + 4) * 3, buttonY, buttonWidth, BUTTON_HEIGHT,
                class_2561.method_43471(key("commandblock.apply")), button -> applyCommand(false)));
    }

    @Override
    public void method_25393() {
        if (this.commandBox != null) {
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256 && this.commandBox != null && this.commandBox.closeCompletions()) {
            return true;
        }
        if (keyCode == 256) {
            returnToLastScreen();
            return true;
        }
        if (isInventoryKey(keyCode, scanCode) && !isCommandBoxFocused()) {
            returnToLastScreen();
            return true;
        }
        if (class_437.method_25441() && keyCode == 83) {
            applyCommand(false);
            return true;
        }
        if ((keyCode == 257 || keyCode == 335) && class_437.method_25441()) {
            applyCommand(false);
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        EditorBackgrounds.render(guiGraphics, this.field_22789, this.field_22790);
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 10, InfinityEditorButton.MAIN_COLOR);
        guiGraphics.method_51427(this.commandStack, 20, 12);
        guiGraphics.method_51431(this.field_22793, this.commandStack, 20, 12);
        guiGraphics.method_27534(this.field_22793, class_2561.method_43471(key("commandblock.target")),
                this.field_22789 / 2, 26, InfinityEditorButton.ALT_COLOR);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        if (!this.status.getString().isEmpty()) {
            guiGraphics.method_27534(this.field_22793, clippedStatus(), this.field_22789 / 2, this.field_22790 - 42, this.statusColor);
        }
        if (this.commandBox != null) {
            this.commandBox.renderCompletions(guiGraphics);
        }
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void method_25419() {
        returnToLastScreen();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private boolean isInventoryKey(int keyCode, int scanCode) {
        return this.field_22787 != null
                && this.field_22787.field_1690.field_1822.method_1417(keyCode, scanCode);
    }

    private boolean isCommandBoxFocused() {
        return this.commandBox != null && this.commandBox.method_25370();
    }

    private void applyCommand(boolean returnAfterApply) {
        class_1799 updated = this.commandStack.method_7972();
        writeCommand(updated, normalizedCommand(currentText()));
        if (this.supportsCommandBlockOptions) {
            writeUnconditional(updated, this.unconditional);
            writeAlwaysActive(updated, this.alwaysActive);
        }
        this.commandStack = updated;
        this.lastScreen.applyCommandBlockEditedStack(updated);
        this.commandText = readCommand(this.commandStack);
        this.appliedCommandText = this.commandText;
        this.unconditional = readUnconditional(this.commandStack);
        this.appliedUnconditional = this.unconditional;
        this.alwaysActive = readAlwaysActive(this.commandStack);
        this.appliedAlwaysActive = this.alwaysActive;
        this.discardArmed = false;
        if (this.commandBox != null) {
            this.commandBox.setValue(this.commandText);
            this.commandBox.clearError();
        }
        syncOptionButtons();
        this.status = class_2561.method_43471(messageKey("editor_command_block_applied"));
        this.statusColor = STATUS_GOOD;
        if (returnAfterApply) {
            returnToLastScreen();
        }
    }

    private void resetCommand() {
        this.commandStack = this.lastScreen.previewStack.method_7972();
        this.commandText = readCommand(this.commandStack);
        this.appliedCommandText = this.commandText;
        this.unconditional = readUnconditional(this.commandStack);
        this.appliedUnconditional = this.unconditional;
        this.alwaysActive = readAlwaysActive(this.commandStack);
        this.appliedAlwaysActive = this.alwaysActive;
        this.discardArmed = false;
        if (this.commandBox != null) {
            this.commandBox.setValue(this.commandText);
            this.commandBox.clearError();
        }
        syncOptionButtons();
        this.status = class_2561.method_43471(messageKey("editor_command_block_reset"));
        this.statusColor = STATUS_NEUTRAL;
    }

    private void clearCommand() {
        this.commandText = "";
        this.discardArmed = false;
        if (this.commandBox != null) {
            this.commandBox.setValue("");
            this.commandBox.clearError();
        }
        this.status = class_2561.method_43471(messageKey("editor_command_block_cleared"));
        this.statusColor = STATUS_NEUTRAL;
    }

    private void returnToLastScreen() {
        if (isDirty() && !this.discardArmed) {
            this.discardArmed = true;
            this.status = class_2561.method_43471(messageKey("editor_command_block_unsaved"));
            this.statusColor = STATUS_NEUTRAL;
            if (this.commandBox != null) {
                method_25395(this.commandBox);
                this.commandBox.method_25365(true);
            }
            return;
        }
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.lastScreen);
        }
    }

    private boolean isDirty() {
        return !currentText().equals(this.appliedCommandText)
                || (this.supportsCommandBlockOptions
                        && (this.unconditional != this.appliedUnconditional || this.alwaysActive != this.appliedAlwaysActive));
    }

    private String currentText() {
        return this.commandBox == null ? this.commandText : this.commandBox.getValue();
    }

    private String normalizedCommand(String value) {
        return value == null ? "" : value.replace('\r', ' ').replace('\n', ' ').trim();
    }

    private class_2561 clippedStatus() {
        int maxWidth = Math.max(40, this.field_22789 - 20);
        String text = this.status.getString();
        if (this.field_22793.method_1727(text) <= maxWidth) {
            return this.status;
        }
        return class_2561.method_43470(this.field_22793.method_27523(text, maxWidth - this.field_22793.method_1727("...")) + "...");
    }

    private String readCommand(class_1799 stack) {
        class_2487 commandData = ItemStackNbt.getElement(stack, dataTagKey(stack));
        return commandData == null ? "" : commandData.method_68564(COMMAND_TAG, "");
    }

    private boolean readUnconditional(class_1799 stack) {
        class_2487 blockState = ItemStackNbt.getElement(stack, BLOCK_STATE_TAG);
        return blockState == null || !"true".equalsIgnoreCase(blockState.method_68564(CONDITIONAL_TAG, ""));
    }

    private boolean readAlwaysActive(class_1799 stack) {
        class_2487 commandData = ItemStackNbt.getElement(stack, BLOCK_ENTITY_TAG);
        return commandData != null && commandData.method_68566(AUTO_TAG, false);
    }

    private void writeCommand(class_1799 stack, String command) {
        String tagKey = dataTagKey(stack);
        class_2487 rootTag = ItemStackNbt.get(stack);
        class_2487 commandData = rootTag == null ? new class_2487() : rootTag.method_68568(tagKey);
        if (command.isEmpty()) {
            commandData.method_10551(COMMAND_TAG);
            removeOnlyCommandMinecartEntityId(stack, commandData);
        } else {
            commandData.method_10582(COMMAND_TAG, command);
            ensureCommandMinecartEntityId(stack, commandData);
        }

        putOrRemoveTag(stack, rootTag, tagKey, commandData);
    }

    private void ensureCommandMinecartEntityId(class_1799 stack, class_2487 commandData) {
        if (stack.method_31574(class_1802.field_8220) && !commandData.method_10545(ENTITY_ID_TAG)) {
            commandData.method_10582(ENTITY_ID_TAG, COMMAND_BLOCK_MINECART_ENTITY_ID);
        }
    }

    private void removeOnlyCommandMinecartEntityId(class_1799 stack, class_2487 commandData) {
        if (stack.method_31574(class_1802.field_8220) && isOnlyCommandMinecartEntityId(commandData)) {
            commandData.method_10551(ENTITY_ID_TAG);
        }
    }

    private boolean isOnlyCommandMinecartEntityId(class_2487 commandData) {
        return commandData.method_10546() == 1
                && commandData.method_10545(ENTITY_ID_TAG)
                && COMMAND_BLOCK_MINECART_ENTITY_ID.equals(commandData.method_68564(ENTITY_ID_TAG, ""));
    }

    private void writeUnconditional(class_1799 stack, boolean unconditional) {
        class_2487 rootTag = ItemStackNbt.get(stack);
        class_2487 blockState = rootTag == null ? new class_2487() : rootTag.method_68568(BLOCK_STATE_TAG);
        if (unconditional) {
            blockState.method_10551(CONDITIONAL_TAG);
        } else {
            blockState.method_10582(CONDITIONAL_TAG, "true");
        }
        putOrRemoveTag(stack, rootTag, BLOCK_STATE_TAG, blockState);
    }

    private void writeAlwaysActive(class_1799 stack, boolean alwaysActive) {
        class_2487 rootTag = ItemStackNbt.get(stack);
        class_2487 commandData = rootTag == null ? new class_2487() : rootTag.method_68568(BLOCK_ENTITY_TAG);
        if (alwaysActive) {
            commandData.method_10556(AUTO_TAG, true);
        } else {
            commandData.method_10551(AUTO_TAG);
        }
        putOrRemoveTag(stack, rootTag, BLOCK_ENTITY_TAG, commandData);
    }

    private void putOrRemoveTag(class_1799 stack, class_2487 rootTag, String tagKey, class_2487 data) {
        if (data.method_33133()) {
            if (rootTag != null) {
                rootTag.method_10551(tagKey);
                if (rootTag.method_33133()) {
                    ItemStackNbt.set(stack, null);
                }
            }
            return;
        }

        ItemStackNbt.getOrCreate(stack).method_10566(tagKey, data);
    }

    private void toggleUnconditional() {
        this.unconditional = !this.unconditional;
        this.discardArmed = false;
        syncOptionButtons();
    }

    private void toggleAlwaysActive() {
        this.alwaysActive = !this.alwaysActive;
        this.discardArmed = false;
        syncOptionButtons();
    }

    private void syncOptionButtons() {
        if (this.conditionButton != null) {
            this.conditionButton.method_25355(conditionModeText());
        }
        if (this.activationButton != null) {
            this.activationButton.method_25355(activationModeText());
        }
    }

    private class_2561 conditionModeText() {
        return class_2561.method_43469(key("commandblock.condition_mode"),
                class_2561.method_43471(key(this.unconditional ? "commandblock.unconditional" : "commandblock.conditional")));
    }

    private class_2561 activationModeText() {
        return class_2561.method_43469(key("commandblock.activation_mode"),
                class_2561.method_43471(key(this.alwaysActive ? "commandblock.always_active" : "commandblock.needs_redstone")));
    }

    private String dataTagKey(class_1799 stack) {
        return stack.method_31574(class_1802.field_8220) ? ENTITY_TAG : BLOCK_ENTITY_TAG;
    }

    private boolean supportsCommandBlockOptions(class_1799 stack) {
        return stack.method_31574(class_1802.field_8866)
                || stack.method_31574(class_1802.field_8799)
                || stack.method_31574(class_1802.field_8468);
    }

    private static String key(String suffix) {
        return "screen." + ModSource.MODID + "." + suffix;
    }

    private static String messageKey(String suffix) {
        return "message." + ModSource.MODID + "." + suffix;
    }
}
