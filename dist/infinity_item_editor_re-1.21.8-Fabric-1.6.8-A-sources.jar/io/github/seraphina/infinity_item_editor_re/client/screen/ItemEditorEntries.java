package io.github.seraphina.infinity_item_editor_re.client.screen;

import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_8054;
import net.minecraft.class_8056;

record EnchantmentEntry(class_2960 id, class_1887 enchantment, int level) {
}

record EnchantmentGroupEntry(String namespace, List<class_1887> enchantments) {
}

record PotionGroupEntry(String namespace, List<class_1291> effects) {
}

record AttributeEntry(int tagIndex, String attributeName, class_1320 attribute, double amount, int operation, String slotName) {
}

record AttributeGroupEntry(String namespace, List<class_1320> attributes) {
}

record NbtRow(String path, String displayText, boolean isExpandable, int depth) {
}

record BannerPatternEntry(String name, String hash) {
}

record PotterySherdEntry(String name, class_1792 item) {
}

record SpawnEggEntityEntry(class_2960 id, class_1299<?> type) {
}

record ArmorTrimMaterialEntry(class_2960 id, class_6880<class_8054> material) {
}

record ArmorTrimPatternEntry(class_2960 id, class_6880<class_8056> pattern) {
}

record ArmorTrimEntry(class_2960 materialId, class_2960 patternId) {
}
