package io.github.seraphina.infinity_item_editor_re.client.screen;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
public class ItemEditorScreen extends ItemEditorScreenRendering {
    private static final int ADAPTIVE_BASE_WIDTH = 854;
    private static final int ADAPTIVE_BASE_HEIGHT = 480;
    private EditorViewport viewport = new EditorViewport(ADAPTIVE_BASE_WIDTH, ADAPTIVE_BASE_HEIGHT, 1.0D);
    private boolean adaptiveLayoutInitialized;

    public ItemEditorScreen(class_1799 stack) {
        this(stack, -1);
    }

    public ItemEditorScreen(class_1799 stack, int targetContainerSlot) {
        this(stack, targetContainerSlot, null, -1, -1);
    }

    ItemEditorScreen(class_1799 stack, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        this(stack, -1, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

    private ItemEditorScreen(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
        this.expandedNbtPaths.add("tag");
        this.attributeSlot = getDefaultAttributeSlot(this.previewStack);
        readMainFieldsFromStack(this.previewStack);
        syncNbtEditorValuesFromStack();
        this.colorHexValue = formatColorHex(getEditorColor());
        ensureLorePainterRows();
    }

    @Override
    protected void method_25426() {
        updateAdaptiveLayout();
        captureFieldValues();
        this.midX = isSidebarUi() ? safeLeft() + contentWidth() / 2 : this.field_22789 / 2;
        this.midY = this.field_22790 / 2;

        this.tickingBoxes.clear();
        this.mainTextBoxes.clear();
        this.loreBoxes.clear();
        this.signBoxes.clear();
        this.loreActionButtons.clear();
        this.itemIdBox = null;
        this.countBox = null;
        this.damageBox = null;
        this.nameBox = null;
        this.rawNbtBox = null;
        this.componentFilterBox = null;
        this.componentValueSearchBox = null;
        this.componentNumberBox = null;
        this.componentNbtBox = null;
        this.enchantFilterBox = null;
        this.enchantLevelBox = null;
        this.potionFilterBox = null;
        this.potionLevelBox = null;
        this.potionTimeBox = null;
        this.attributeAmountBox = null;
        this.attributeDecimalBox = null;
        this.colorHexBox = null;
        this.signCommandBox = null;
        this.bookTitleBox = null;
        this.bookAuthorBox = null;
        this.headOwnerBox = null;
        this.headUuidBox = null;
        this.headTextureBox = null;
        this.headTextureSignatureBox = null;
        this.containerSlotNbtBox = null;
        this.bannerPatternFilterBox = null;
        this.potterySherdFilterBox = null;
        this.spawnEggEntityFilterBox = null;
        this.spawnEggCustomNameBox = null;
        this.spawnEggOwnerBox = null;
        this.tradeItemNbtBox = null;
        this.tradeUsesBox = null;
        this.tradeMaxUsesBox = null;
        this.tradeXpBox = null;
        this.tradePriceMultiplierBox = null;
        this.tradeSpecialPriceBox = null;
        this.tradeDemandBox = null;
        this.attributeInfinityButton = null;
        this.attributeOperationButton = null;
        this.attributeSlotButton = null;
        this.lorePainterScaleButton = null;
        this.lorePainterAddRowButton = null;
        this.lorePainterRemoveRowButton = null;
        this.lorePainterAddColumnButton = null;
        this.lorePainterRemoveColumnButton = null;
        this.lorePainterPreviewButton = null;
        this.redSlider = null;
        this.greenSlider = null;
        this.blueSlider = null;
        this.componentRedSlider = null;
        this.componentGreenSlider = null;
        this.componentBlueSlider = null;
        this.copyLoreButton = null;

        switch (this.activePanel) {
            case ITEM -> addItemPanel();
            case NBT -> addNbtPanel();
            case COMPONENTS -> addComponentsPanel();
            case NBT_ADVANCED -> addNbtAdvancedPanel();
            case HIDE_FLAGS -> addHideFlagsPanel();
            case ENCHANTMENTS -> addEnchantmentsPanel();
            case POTION -> addPotionPanel();
            case ATTRIBUTES -> addAttributesPanel();
            case COLOR -> addColorPanel();
            case SIGN -> addSignPanel();
            case HEAD -> addHeadPanel();
            case ARMOR_STAND -> addArmorStandPanel();
            case FIREWORK -> addFireworkPanel();
            case CONTAINER -> addContainerPanel();
            case BANNER -> addBannerPanel();
            case DECORATED_POT -> addDecoratedPotPanel();
            case SPAWN_EGG -> addSpawnEggPanel();
            case TRADES -> addTradesPanel();
            case TRADE -> addTradePanel();
            case BOOK -> addBookPanel();
            case LORE -> addLorePanel();
            case LORE_PAINTER -> addLorePainterPanel();
        }

        addBottomButtons();
    }

    private void updateAdaptiveLayout() {
        if (this.adaptiveLayoutInitialized) {
            return;
        }
        this.viewport = EditorViewport.fit(this.field_22789, this.field_22790, ADAPTIVE_BASE_WIDTH, ADAPTIVE_BASE_HEIGHT);
        this.field_22789 = this.viewport.width();
        this.field_22790 = this.viewport.height();
        this.adaptiveLayoutInitialized = true;
    }

    @Override
    protected void method_48640() {
        this.adaptiveLayoutInitialized = false;
        this.draggingLoreScroll = false;
        this.lorePainterDragging = false;
        method_25398(false);
        super.method_48640();
    }

    @Override
    public void method_25393() {
        for (class_342 box : this.tickingBoxes) {
        }

        if ((this.activePanel == Panel.ENCHANTMENTS || this.activePanel == Panel.POTION || this.activePanel == Panel.ATTRIBUTES)
                && Math.abs(this.mouseDist - getRingRadius()) >= RING_HOVER_WIDTH) {
            this.rotOff++;
        }
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (this.viewport.scale() == 1.0D) {
            renderEditor(guiGraphics, mouseX, mouseY, partialTick);
            return;
        }

        class_332 editorGraphics = new EditorGuiGraphics(this.field_22787, guiGraphics, this.viewport);
        renderEditor(editorGraphics, class_3532.method_15357(this.viewport.toLayout(mouseX)),
                class_3532.method_15357(this.viewport.toLayout(mouseY)), partialTick);
    }

    private void renderEditor(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (this.activePanel == Panel.NBT_ADVANCED) {
            renderEditorBackground(guiGraphics, mouseX, mouseY, partialTick);
            renderNbtAdvancedPanel(guiGraphics, mouseX, mouseY);
            super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            return;
        }

        renderEditorBackground(guiGraphics, mouseX, mouseY, partialTick);

        switch (this.activePanel) {
            case ITEM -> renderItemPanel(guiGraphics, mouseX, mouseY);
            case NBT -> renderNbtPanel(guiGraphics, mouseX, mouseY);
            case COMPONENTS -> renderComponentsPanel(guiGraphics, mouseX, mouseY);
            case HIDE_FLAGS -> renderHideFlagsPanel(guiGraphics);
            case ENCHANTMENTS -> renderEnchantmentsPanel(guiGraphics, mouseX, mouseY, partialTick);
            case POTION -> renderPotionPanel(guiGraphics, mouseX, mouseY, partialTick);
            case ATTRIBUTES -> renderAttributesPanel(guiGraphics, mouseX, mouseY, partialTick);
            case COLOR -> renderColorPanel(guiGraphics);
            case SIGN -> renderSignPanel(guiGraphics);
            case HEAD -> renderHeadPanel(guiGraphics);
            case ARMOR_STAND -> renderArmorStandPanel(guiGraphics);
            case FIREWORK -> renderFireworkPanel(guiGraphics);
            case CONTAINER -> renderContainerPanel(guiGraphics);
            case BANNER -> renderBannerPanel(guiGraphics);
            case DECORATED_POT -> renderDecoratedPotPanel(guiGraphics);
            case SPAWN_EGG -> renderSpawnEggPanel(guiGraphics);
            case TRADES -> renderTradesPanel(guiGraphics, mouseX, mouseY);
            case TRADE -> renderTradePanel(guiGraphics);
            case BOOK -> renderBookPanel(guiGraphics);
            case LORE -> renderLorePanel(guiGraphics, mouseX, mouseY);
            case LORE_PAINTER -> renderLorePainterPanel(guiGraphics, mouseX, mouseY);
            case NBT_ADVANCED -> {
            }
        }

        if (!this.status.getString().isEmpty()) {
            guiGraphics.method_27534(this.field_22793, this.status, this.midX, this.field_22790 - 58, 0xFFFFD966);
        }

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderPanelTooltips(guiGraphics, mouseX, mouseY);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            goBack();
            return true;
        }

        if (isInventoryKey(keyCode, scanCode)) {
            return true;
        }

        if (keyCode == 257 || keyCode == 335) {
            if (this.activePanel == Panel.ITEM) {
                if (isTradeSlotEditor()) {
                    applyTradeSlotEditorAndReturn();
                    return true;
                }
                applyToSelectedSlot();
                return true;
            }
            if (this.activePanel == Panel.NBT) {
                updateRawNbt();
                return true;
            }
            if (this.activePanel == Panel.COLOR) {
                applyColorFromHex(true);
                return true;
            }
            if (this.activePanel == Panel.CONTAINER) {
                updateContainerSlotFromNbt();
                return true;
            }
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private boolean isInventoryKey(int keyCode, int scanCode) {
        return this.field_22787 != null
                && this.field_22787.field_1690.field_1822.method_1417(keyCode, scanCode);
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        if (this.activePanel == Panel.ENCHANTMENTS && this.enchantFilterBox != null && this.enchantFilterBox.method_25370()) {
            return this.enchantFilterBox.method_25400(Character.toLowerCase(codePoint), modifiers);
        }
        if (this.activePanel == Panel.POTION && this.potionFilterBox != null && this.potionFilterBox.method_25370()) {
            return this.potionFilterBox.method_25400(Character.toLowerCase(codePoint), modifiers);
        }
        if (this.activePanel == Panel.COMPONENTS && this.componentFilterBox != null && this.componentFilterBox.method_25370()) {
            return this.componentFilterBox.method_25400(Character.toLowerCase(codePoint), modifiers);
        }
        if (this.activePanel == Panel.COMPONENTS && this.componentValueSearchBox != null && this.componentValueSearchBox.method_25370()) {
            return this.componentValueSearchBox.method_25400(Character.toLowerCase(codePoint), modifiers);
        }
        if (this.activePanel == Panel.BANNER && this.bannerPatternFilterBox != null && this.bannerPatternFilterBox.method_25370()) {
            return this.bannerPatternFilterBox.method_25400(Character.toLowerCase(codePoint), modifiers);
        }
        if (this.activePanel == Panel.DECORATED_POT && this.potterySherdFilterBox != null && this.potterySherdFilterBox.method_25370()) {
            return this.potterySherdFilterBox.method_25400(Character.toLowerCase(codePoint), modifiers);
        }
        if (this.activePanel == Panel.SPAWN_EGG && this.spawnEggEntityFilterBox != null && this.spawnEggEntityFilterBox.method_25370()) {
            return this.spawnEggEntityFilterBox.method_25400(Character.toLowerCase(codePoint), modifiers);
        }
        return super.method_25400(codePoint, modifiers);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        mouseX = this.viewport.toLayout(mouseX);
        mouseY = this.viewport.toLayout(mouseY);
        boolean handled = super.method_25402(mouseX, mouseY, button);
        if (handled) {
            return handled;
        }

        updateMouseDistance((int) mouseX, (int) mouseY);
        if (this.activePanel == Panel.TRADES && (button == 0 || button == 1)) {
            return handleTradesClick(mouseX, mouseY, button);
        }
        if (this.activePanel == Panel.TRADE && (button == 0 || button == 1)) {
            return handleTradeClick(mouseX, mouseY);
        }
        if (button != 0) {
            return false;
        }
        return switch (this.activePanel) {
            case ENCHANTMENTS -> handleEnchantingClick(mouseX, mouseY);
            case POTION -> handlePotionClick(mouseX, mouseY);
            case ATTRIBUTES -> handleAttributesClick(mouseX, mouseY);
            case COMPONENTS -> handleComponentListClick(mouseX, mouseY);
            case COLOR -> handleColorClick(mouseX, mouseY);
            case CONTAINER -> handleContainerClick(mouseX, mouseY);
            case BANNER -> handleBannerClick(mouseX, mouseY);
            case DECORATED_POT -> handleDecoratedPotClick(mouseX, mouseY);
            case SPAWN_EGG -> handleSpawnEggClick(mouseX, mouseY);
            case NBT_ADVANCED -> handleNbtAdvancedClick(mouseX, mouseY);
            case LORE -> handleLoreClick(mouseX, mouseY);
            case LORE_PAINTER -> handleLorePainterClick(mouseX, mouseY);
            default -> false;
        };
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        mouseX = this.viewport.toLayout(mouseX);
        mouseY = this.viewport.toLayout(mouseY);
        if (this.activePanel == Panel.NBT_ADVANCED) {
            int rows = buildNbtRows().size();
            int visible = getNbtAdvancedVisibleRows();
            this.advancedScroll = class_3532.method_15340(this.advancedScroll - (int) Math.signum(scrollY), 0, Math.max(0, rows - visible));
            return true;
        }

        if (this.activePanel == Panel.LORE) {
            setLoreScroll(this.loreScroll - (int) Math.signum(scrollY));
            return true;
        }

        if (this.activePanel == Panel.COMPONENTS) {
            return scrollComponentList(scrollY);
        }

        if (this.activePanel == Panel.BANNER) {
            setBannerPatternScroll(this.bannerPatternScroll - (int) Math.signum(scrollY));
            return true;
        }

        if (this.activePanel == Panel.DECORATED_POT) {
            setPotterySherdScroll(this.potterySherdScroll - (int) Math.signum(scrollY));
            return true;
        }

        if (this.activePanel == Panel.SPAWN_EGG) {
            if (isMouseIn(mouseX, mouseY, spawnEggEntityListX(), getSpawnEggEntityRowY(0) - 1,
                    spawnEggEntityListWidth(), SPAWN_EGG_ENTITY_ROWS * 10 + 2)) {
                setSpawnEggEntityScroll(this.spawnEggEntityScroll - (int) Math.signum(scrollY));
                method_41843();
            } else {
                setSpawnEggTagScroll(this.spawnEggTagScroll - (int) Math.signum(scrollY));
                method_41843();
            }
            return true;
        }

        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        mouseX = this.viewport.toLayout(mouseX);
        mouseY = this.viewport.toLayout(mouseY);
        dragX = this.viewport.toLayout(dragX);
        dragY = this.viewport.toLayout(dragY);
        if (this.activePanel == Panel.LORE && this.draggingLoreScroll) {
            updateLoreScrollFromMouse(mouseY);
            return true;
        }
        if (this.activePanel == Panel.COMPONENTS && this.draggingComponentListScroll) {
            dragComponentListScrollbar(mouseY);
            return true;
        }
        if (this.activePanel == Panel.LORE_PAINTER && this.lorePainterDragging) {
            paintLorePainterAt(mouseX, mouseY);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        mouseX = this.viewport.toLayout(mouseX);
        mouseY = this.viewport.toLayout(mouseY);
        this.draggingLoreScroll = false;
        this.lorePainterDragging = false;
        this.draggingComponentListScroll = false;
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        super.method_16014(this.viewport.toLayout(mouseX), this.viewport.toLayout(mouseY));
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
