package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ComponentCompat;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernUi;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.NbtCompat;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1299;
import net.minecraft.class_1746;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1826;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_8526;
import net.minecraft.class_9334;
abstract class ItemEditorScreenBannerSpawn extends ItemEditorScreenItemData {
    protected ItemEditorScreenBannerSpawn(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

protected void addSelectedBannerPattern() {
        if (!isBannerEditableItem(this.previewStack)) {
            return;
        }

        List<BannerPatternEntry> patterns = getFilteredBannerPatterns();
        clampBannerPatternSelection(patterns);
        if (patterns.isEmpty()) {
            this.status = class_2561.method_43471(key("banner.no_match"));
            return;
        }

        BannerPatternEntry entry = patterns.get(this.selectedBannerPatternIndex);
        class_1767 color = getBannerPatternColor();
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        class_2487 blockEntity = getOrCreateBannerBlockEntityTag();
        if (this.previewStack.method_31574(class_1802.field_8255) && !blockEntity.method_10545(BANNER_BASE_TAG)) {
            blockEntity.method_10569(BANNER_BASE_TAG, getBannerBaseColor().method_7789());
        }

        class_2499 bannerPatterns = blockEntity.method_10545(BANNER_PATTERNS_TAG)
                ? blockEntity.method_68569(BANNER_PATTERNS_TAG).method_10612()
                : new class_2499();
        class_2487 patternTag = new class_2487();
        patternTag.method_10582(BANNER_PATTERN_TAG, entry.hash());
        patternTag.method_10569(BANNER_COLOR_TAG, color.method_7789());
        bannerPatterns.add(patternTag);
        blockEntity.method_10566(BANNER_PATTERNS_TAG, bannerPatterns);
        cleanupBlockEntityTag(tag, blockEntity);
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43469(messageKey("editor_banner_pattern_added"), getBannerPatternName(entry, color));
        method_41843();
    }

    protected void removeLastBannerPattern() {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        if (!blockEntity.method_10545(BANNER_PATTERNS_TAG)) {
            return;
        }

        class_2499 patterns = blockEntity.method_68569(BANNER_PATTERNS_TAG);
        if (patterns.isEmpty()) {
            return;
        }

        patterns.method_10536(patterns.size() - 1);
        if (patterns.isEmpty()) {
            blockEntity.method_10551(BANNER_PATTERNS_TAG);
        } else {
            blockEntity.method_10566(BANNER_PATTERNS_TAG, patterns);
        }
        cleanupBlockEntityTag(tag, blockEntity);
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_banner_pattern_removed"));
        method_41843();
    }

    protected void clearBannerPatterns() {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        if (!blockEntity.method_10545(BANNER_PATTERNS_TAG)) {
            return;
        }

        blockEntity.method_10551(BANNER_PATTERNS_TAG);
        cleanupBlockEntityTag(tag, blockEntity);
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_banner_patterns_cleared"));
        method_41843();
    }

    protected void cycleBannerBaseColor(int direction) {
        class_1767 color = class_1767.method_7791(class_3532.method_15387(getBannerBaseColor().method_7789() + direction, class_1767.values().length));
        setBannerBaseColor(color);
        this.status = class_2561.method_43469(messageKey("editor_banner_base_updated"), getDyeColorName(color));
        method_41843();
    }

    protected void cycleBannerPatternColor(int direction) {
        this.bannerPatternColor = class_3532.method_15387(this.bannerPatternColor + direction, class_1767.values().length);
        method_41843();
    }

    protected void cycleSelectedBannerPattern(int direction) {
        List<BannerPatternEntry> patterns = getFilteredBannerPatterns();
        if (patterns.isEmpty()) {
            return;
        }

        this.selectedBannerPatternIndex = class_3532.method_15387(this.selectedBannerPatternIndex + direction, patterns.size());
        scrollBannerPatternSelectionIntoView(patterns);
    }

    protected void setBannerPatternScroll(int value) {
        List<BannerPatternEntry> patterns = getFilteredBannerPatterns();
        int maxScroll = Math.max(0, patterns.size() - BANNER_PATTERN_ROWS);
        this.bannerPatternScroll = class_3532.method_15340(value, 0, maxScroll);
        clampBannerPatternSelection(patterns);
        if (!patterns.isEmpty()) {
            int lastVisible = Math.min(patterns.size() - 1, this.bannerPatternScroll + BANNER_PATTERN_ROWS - 1);
            this.selectedBannerPatternIndex = class_3532.method_15340(this.selectedBannerPatternIndex, this.bannerPatternScroll, lastVisible);
        }
    }

    protected void scrollBannerPatternSelectionIntoView(List<BannerPatternEntry> patterns) {
        clampBannerPatternSelection(patterns);
        if (patterns.isEmpty()) {
            return;
        }

        if (this.selectedBannerPatternIndex < this.bannerPatternScroll) {
            this.bannerPatternScroll = this.selectedBannerPatternIndex;
        } else if (this.selectedBannerPatternIndex >= this.bannerPatternScroll + BANNER_PATTERN_ROWS) {
            this.bannerPatternScroll = this.selectedBannerPatternIndex - BANNER_PATTERN_ROWS + 1;
        }
        this.bannerPatternScroll = class_3532.method_15340(this.bannerPatternScroll, 0, Math.max(0, patterns.size() - BANNER_PATTERN_ROWS));
    }

    protected void clampBannerPatternSelection(List<BannerPatternEntry> patterns) {
        if (patterns.isEmpty()) {
            this.selectedBannerPatternIndex = 0;
            this.bannerPatternScroll = 0;
            return;
        }

        this.selectedBannerPatternIndex = class_3532.method_15340(this.selectedBannerPatternIndex, 0, patterns.size() - 1);
        this.bannerPatternScroll = class_3532.method_15340(this.bannerPatternScroll, 0, Math.max(0, patterns.size() - BANNER_PATTERN_ROWS));
    }

    protected int getBannerPatternRowY(int row) {
        return sideListStartY() + row * 10;
    }

    protected List<BannerPatternEntry> getFilteredBannerPatterns() {
        String filter = this.bannerPatternFilterValue == null ? "" : this.bannerPatternFilterValue.trim().toLowerCase(Locale.ROOT);
        if (filter.isEmpty()) {
            return new ArrayList<>(BannerPatternCatalog.PATTERNS);
        }

        class_1767 color = getBannerPatternColor();
        List<BannerPatternEntry> patterns = new ArrayList<>();
        for (BannerPatternEntry entry : BannerPatternCatalog.PATTERNS) {
            String idName = entry.name().toLowerCase(Locale.ROOT);
            String spacedName = idName.replace('_', ' ');
            String hash = entry.hash().toLowerCase(Locale.ROOT);
            String displayName = getBannerPatternName(entry, color).getString().toLowerCase(Locale.ROOT);
            if (idName.contains(filter) || spacedName.contains(filter) || hash.contains(filter) || displayName.contains(filter)) {
                patterns.add(entry);
            }
        }
        return patterns;
    }

    protected class_2561 getBannerPatternName(BannerPatternEntry entry, class_1767 color) {
        return class_2561.method_43471("block.minecraft.banner." + entry.name() + "." + color.method_7792());
    }

    protected void renderBannerPatternLayers(class_332 guiGraphics) {
        class_2499 patterns = getBannerPatterns();
        int x = this.midX - 70;
        int y = 124;
        if (isSidebarUi()) {
            ModernUi.fillPanel(guiGraphics, x - 8, y - 8, x + 164, y + 94, 8, ModernUi.SURFACE, ModernUi.BORDER);
        }
        guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("banner.layers")), x, y,
                isSidebarUi() ? ModernUi.TEXT_MUTED : MAIN_COLOR);
        if (patterns.isEmpty()) {
            guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("banner.no_layers")), x, y + 12,
                    isSidebarUi() ? ModernUi.TEXT_SECONDARY : ALT_COLOR);
            return;
        }

        int first = Math.max(0, patterns.size() - 7);
        for (int i = first; i < patterns.size(); i++) {
            class_2487 patternTag = patterns.method_68582(i);
            class_1767 color = class_1767.method_7791(patternTag.method_68083(BANNER_COLOR_TAG, 0));
            BannerPatternEntry entry = getBannerPatternEntry(patternTag.method_68564(BANNER_PATTERN_TAG, ""));
            class_2561 name = entry == null
                    ? class_2561.method_43470(patternTag.method_68564(BANNER_PATTERN_TAG, ""))
                    : getBannerPatternName(entry, color);
            String text = (i + 1) + ". " + name.getString();
            guiGraphics.method_25303(this.field_22793, this.field_22793.method_27523(text, 150), x, y + 12 + (i - first) * 10,
                    isSidebarUi() ? ModernUi.TEXT_PRIMARY : MAIN_COLOR);
        }
    }

    protected void swapBannerAndShield() {
        if (!isBannerEditableItem(this.previewStack)) {
            return;
        }

        class_1767 baseColor = getBannerBaseColor();
        if (this.previewStack.method_31574(class_1802.field_8255)) {
            replacePreviewItem(BannerPatternCatalog.ITEMS_BY_DYE[baseColor.method_7789()]);
            removeBannerBaseColorTag();
        } else {
            replacePreviewItem(class_1802.field_8255);
            class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
            class_2487 blockEntity = getOrCreateBannerBlockEntityTag();
            blockEntity.method_10569(BANNER_BASE_TAG, baseColor.method_7789());
            cleanupBlockEntityTag(tag, blockEntity);
        }

        this.bannerBaseColor = getBannerBaseColor().method_7789();
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_banner_swapped"));
        method_41843();
    }

    protected void setBannerBaseColor(class_1767 color) {
        this.bannerBaseColor = color.method_7789();
        if (this.previewStack.method_31574(class_1802.field_8255)) {
            class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
            class_2487 blockEntity = getOrCreateBannerBlockEntityTag();
            blockEntity.method_10569(BANNER_BASE_TAG, color.method_7789());
            cleanupBlockEntityTag(tag, blockEntity);
        } else if (this.previewStack.method_7909() instanceof class_1746) {
            replacePreviewItem(BannerPatternCatalog.ITEMS_BY_DYE[color.method_7789()]);
            removeBannerBaseColorTag();
        }
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected void replacePreviewItem(class_1792 item) {
        class_2487 tag = ItemStackNbt.get(this.previewStack) == null ? null : ItemStackNbt.get(this.previewStack).method_10553();
        int count = this.previewStack.method_7947() <= 0 ? 1 : this.previewStack.method_7947();
        int damage = this.previewStack.method_7919();
        this.previewStack = new class_1799(item, count);
        ItemStackNbt.set(this.previewStack, tag);
        this.damageValue = Integer.toString(Math.min(getDamageMaxForField(this.previewStack), Math.max(0, damage)));
        this.previewStack.method_7974(Integer.parseInt(this.damageValue));
        class_2960 id = CompatRegistries.ITEMS.getKey(item);
        this.itemIdValue = id == null ? "air" : stripMinecraftNamespace(id);
        this.attributeSlot = getDefaultAttributeSlot(this.previewStack);
    }

    protected void removeBannerBaseColorTag() {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        blockEntity.method_10551(BANNER_BASE_TAG);
        cleanupBlockEntityTag(tag, blockEntity);
    }

    protected class_1767 getBannerBaseColor() {
        if (this.previewStack.method_7909() instanceof class_1746 bannerItem) {
            return bannerItem.method_7706();
        }
        if (this.previewStack.method_31574(class_1802.field_8255)) {
            class_2487 blockEntity = ItemStackNbt.getElement(this.previewStack, BLOCK_ENTITY_TAG);
            if (blockEntity != null && blockEntity.method_10545(BANNER_BASE_TAG)) {
                return class_1767.method_7791(blockEntity.method_68083(BANNER_BASE_TAG, 0));
            }
        }
        return class_1767.field_7952;
    }

    protected class_1767 getBannerPatternColor() {
        this.bannerPatternColor = class_3532.method_15387(this.bannerPatternColor, class_1767.values().length);
        return class_1767.method_7791(this.bannerPatternColor);
    }

    protected class_2561 getDyeColorName(class_1767 color) {
        return class_2561.method_43471("color.minecraft." + color.method_7792());
    }

    protected int getBannerPatternCount() {
        return getBannerPatterns().size();
    }

    protected class_2499 getBannerPatterns() {
        class_2487 blockEntity = ItemStackNbt.getElement(this.previewStack, BLOCK_ENTITY_TAG);
        if (blockEntity == null || !blockEntity.method_10545(BANNER_PATTERNS_TAG)) {
            return new class_2499();
        }
        return blockEntity.method_68569(BANNER_PATTERNS_TAG);
    }

    protected class_2487 getOrCreateBannerBlockEntityTag() {
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        tag.method_10566(BLOCK_ENTITY_TAG, blockEntity);
        return blockEntity;
    }

    protected BannerPatternEntry getBannerPatternEntry(String hash) {
        for (BannerPatternEntry entry : BannerPatternCatalog.PATTERNS) {
            if (entry.hash().equals(hash)) {
                return entry;
            }
        }
        return null;
    }

    protected void applySelectedPotterySherd() {
        if (!isDecoratedPotItem(this.previewStack)) {
            return;
        }

        List<PotterySherdEntry> sherds = getFilteredPotterySherds();
        clampPotterySherdSelection(sherds);
        if (sherds.isEmpty()) {
            this.status = class_2561.method_43471(key("decorated_pot.no_match"));
            return;
        }

        PotterySherdEntry entry = sherds.get(this.selectedPotterySherdIndex);
        setDecoratedPotSideItem(this.selectedDecoratedPotSide, entry.item());
        this.status = class_2561.method_43469(messageKey("editor_decorated_pot_side_updated"),
                getDecoratedPotSideName(this.selectedDecoratedPotSide), getPotterySherdName(entry));
        readDecoratedPotFieldsFromStack(this.previewStack);
        method_41843();
    }

    protected void clearDecoratedPotSide() {
        if (!isDecoratedPotItem(this.previewStack)) {
            return;
        }

        setDecoratedPotSideItem(this.selectedDecoratedPotSide, class_1802.field_8621);
        this.status = class_2561.method_43469(messageKey("editor_decorated_pot_side_cleared"),
                getDecoratedPotSideName(this.selectedDecoratedPotSide));
        readDecoratedPotFieldsFromStack(this.previewStack);
        method_41843();
    }

    protected void clearDecoratedPotDecorations() {
        if (!isDecoratedPotItem(this.previewStack)) {
            return;
        }

        this.previewStack.method_57379(class_9334.field_49621, class_8526.field_44707);
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_decorated_pot_cleared"));
        readDecoratedPotFieldsFromStack(this.previewStack);
        method_41843();
    }

    protected void selectDecoratedPotSide(int side) {
        this.selectedDecoratedPotSide = normalizeDecoratedPotSide(side);
        readDecoratedPotFieldsFromStack(this.previewStack);
        method_41843();
    }

    protected void cycleSelectedPotterySherd(int direction) {
        List<PotterySherdEntry> sherds = getFilteredPotterySherds();
        if (sherds.isEmpty()) {
            return;
        }

        this.selectedPotterySherdIndex = class_3532.method_15387(this.selectedPotterySherdIndex + direction, sherds.size());
        scrollPotterySherdSelectionIntoView(sherds);
    }

    protected void setPotterySherdScroll(int value) {
        List<PotterySherdEntry> sherds = getFilteredPotterySherds();
        int maxScroll = Math.max(0, sherds.size() - POTTERY_SHERD_ROWS);
        this.potterySherdScroll = class_3532.method_15340(value, 0, maxScroll);
        clampPotterySherdSelection(sherds);
        if (!sherds.isEmpty()) {
            int lastVisible = Math.min(sherds.size() - 1, this.potterySherdScroll + POTTERY_SHERD_ROWS - 1);
            this.selectedPotterySherdIndex = class_3532.method_15340(this.selectedPotterySherdIndex, this.potterySherdScroll, lastVisible);
        }
    }

    protected void scrollPotterySherdSelectionIntoView(List<PotterySherdEntry> sherds) {
        clampPotterySherdSelection(sherds);
        if (sherds.isEmpty()) {
            return;
        }

        if (this.selectedPotterySherdIndex < this.potterySherdScroll) {
            this.potterySherdScroll = this.selectedPotterySherdIndex;
        } else if (this.selectedPotterySherdIndex >= this.potterySherdScroll + POTTERY_SHERD_ROWS) {
            this.potterySherdScroll = this.selectedPotterySherdIndex - POTTERY_SHERD_ROWS + 1;
        }
        this.potterySherdScroll = class_3532.method_15340(this.potterySherdScroll, 0, Math.max(0, sherds.size() - POTTERY_SHERD_ROWS));
    }

    protected void clampPotterySherdSelection(List<PotterySherdEntry> sherds) {
        if (sherds.isEmpty()) {
            this.selectedPotterySherdIndex = 0;
            this.potterySherdScroll = 0;
            return;
        }

        this.selectedPotterySherdIndex = class_3532.method_15340(this.selectedPotterySherdIndex, 0, sherds.size() - 1);
        this.potterySherdScroll = class_3532.method_15340(this.potterySherdScroll, 0, Math.max(0, sherds.size() - POTTERY_SHERD_ROWS));
    }

    protected int getPotterySherdRowY(int row) {
        return sideListStartY() + row * 10;
    }

    protected List<PotterySherdEntry> getFilteredPotterySherds() {
        String filter = this.potterySherdFilterValue == null ? "" : this.potterySherdFilterValue.trim().toLowerCase(Locale.ROOT);
        if (filter.isEmpty()) {
            return new ArrayList<>(PotterySherdCatalog.SHERDS);
        }

        List<PotterySherdEntry> sherds = new ArrayList<>();
        for (PotterySherdEntry entry : PotterySherdCatalog.SHERDS) {
            class_2960 id = CompatRegistries.ITEMS.getKey(entry.item());
            String itemId = id == null ? "" : id.toString().toLowerCase(Locale.ROOT);
            String displayName = getPotterySherdName(entry).getString().toLowerCase(Locale.ROOT);
            if (entry.name().contains(filter)
                    || entry.name().replace('_', ' ').contains(filter)
                    || itemId.contains(filter)
                    || displayName.contains(filter)) {
                sherds.add(entry);
            }
        }
        return sherds;
    }

    protected class_2561 getPotterySherdName(PotterySherdEntry entry) {
        if (entry.item() == class_1802.field_8621) {
            return class_2561.method_43471(key("decorated_pot.no_pattern"));
        }
        return entry.item().method_7854().method_7964();
    }

    protected class_2561 getDecoratedPotSideName(int side) {
        return class_2561.method_43471(key("decorated_pot.side." + getDecoratedPotSideKey(side)));
    }

    protected class_2561 getDecoratedPotSideItemName(int side) {
        class_1792 item = getDecoratedPotSideItem(side);
        if (item == class_1802.field_8621) {
            return class_2561.method_43471(key("decorated_pot.no_pattern"));
        }
        return item.method_7854().method_7964();
    }

    protected int getDecoratedPotDecorationCount() {
        int count = 0;
        for (class_1792 item : getDecoratedPotOrderedItems()) {
            if (item != class_1802.field_8621) {
                count++;
            }
        }
        return count;
    }

    protected void renderDecoratedPotSides(class_332 guiGraphics) {
        int x = this.midX - 78;
        int y = 124;
        if (isSidebarUi()) {
            ModernUi.fillPanel(guiGraphics, x - 8, y - 8, x + 178, y + 58, 8, ModernUi.SURFACE, ModernUi.BORDER);
        }

        guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("decorated_pot.sides")), x, y,
                isSidebarUi() ? ModernUi.TEXT_MUTED : MAIN_COLOR);
        for (int i = 0; i < DECORATED_POT_DISPLAY_SIDES.length; i++) {
            int side = DECORATED_POT_DISPLAY_SIDES[i];
            boolean selected = side == this.selectedDecoratedPotSide;
            int color = isSidebarUi()
                    ? (selected ? ModernUi.ACCENT_HOVER : ModernUi.TEXT_PRIMARY)
                    : (selected ? CONTRAST_COLOR : MAIN_COLOR);
            class_2561 text = class_2561.method_43469(key("decorated_pot.side_state"),
                    getDecoratedPotSideName(side), getDecoratedPotSideItemName(side));
            guiGraphics.method_25303(this.field_22793, this.field_22793.method_27523(text.getString(), 164),
                    x, y + 12 + i * 10, color);
        }
    }

    protected void readDecoratedPotFieldsFromStack(class_1799 stack) {
        this.selectedDecoratedPotSide = normalizeDecoratedPotSide(this.selectedDecoratedPotSide);
        if (!isDecoratedPotItem(stack)) {
            this.potterySherdScroll = 0;
            this.selectedPotterySherdIndex = 0;
            return;
        }

        class_1792 current = getDecoratedPotSideItem(this.selectedDecoratedPotSide);
        List<PotterySherdEntry> sherds = getFilteredPotterySherds();
        for (int i = 0; i < sherds.size(); i++) {
            if (sherds.get(i).item() == current) {
                this.selectedPotterySherdIndex = i;
                scrollPotterySherdSelectionIntoView(sherds);
                return;
            }
        }
        clampPotterySherdSelection(sherds);
    }

    protected void setDecoratedPotSideItem(int side, class_1792 item) {
        if (!isDecoratedPotItem(this.previewStack)) {
            return;
        }

        class_1792[] ordered = getDecoratedPotOrderedItems();
        ordered[normalizeDecoratedPotSide(side)] = item == null ? class_1802.field_8621 : item;
        class_8526 decorations = new class_8526(ordered[0], ordered[1], ordered[2], ordered[3]);
        this.previewStack.method_57379(class_9334.field_49621, decorations);
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected class_1792 getDecoratedPotSideItem(int side) {
        return getDecoratedPotOrderedItems()[normalizeDecoratedPotSide(side)];
    }

    protected class_1792[] getDecoratedPotOrderedItems() {
        class_1792[] items = {class_1802.field_8621, class_1802.field_8621, class_1802.field_8621, class_1802.field_8621};
        List<class_1792> ordered = this.previewStack.method_58695(class_9334.field_49621, class_8526.field_44707).method_51512();
        for (int i = 0; i < Math.min(items.length, ordered.size()); i++) {
            items[i] = ordered.get(i) == null ? class_1802.field_8621 : ordered.get(i);
        }
        return items;
    }

    protected int normalizeDecoratedPotSide(int side) {
        return switch (side) {
            case DECORATED_POT_SIDE_LEFT -> DECORATED_POT_SIDE_LEFT;
            case DECORATED_POT_SIDE_RIGHT -> DECORATED_POT_SIDE_RIGHT;
            case DECORATED_POT_SIDE_FRONT -> DECORATED_POT_SIDE_FRONT;
            default -> DECORATED_POT_SIDE_BACK;
        };
    }

    protected String getDecoratedPotSideKey(int side) {
        return switch (normalizeDecoratedPotSide(side)) {
            case DECORATED_POT_SIDE_LEFT -> "left";
            case DECORATED_POT_SIDE_RIGHT -> "right";
            case DECORATED_POT_SIDE_FRONT -> "front";
            default -> "back";
        };
    }

    protected void applySelectedSpawnEggEntity() {
        SpawnEggEntityEntry entry = getSelectedSpawnEggEntityEntry();
        if (entry == null) {
            this.status = class_2561.method_43471(key("spawnegg.no_match"));
            return;
        }

        writeSpawnEggEntityId(entry);
        this.status = class_2561.method_43469(messageKey("editor_spawn_egg_entity_updated"), getSpawnEggEntityName(entry));
        readSpawnEggFieldsFromStack(this.previewStack);
        method_41843();
    }

    protected void syncSpawnEggToSelectedEntityItem() {
        if (!isSpawnEggItem(this.previewStack)) {
            return;
        }

        SpawnEggEntityEntry entry = getSelectedSpawnEggEntityEntry();
        if (entry == null) {
            this.status = class_2561.method_43471(key("spawnegg.no_match"));
            return;
        }

        class_1826 eggItem = class_1826.method_8019(entry.type());
        if (eggItem == null) {
            this.status = class_2561.method_43469(messageKey("editor_spawn_egg_no_matching_item"), getSpawnEggEntityName(entry));
            return;
        }

        replacePreviewItem(eggItem);
        writeSpawnEggEntityId(entry);
        readMainFieldsFromStack(this.previewStack);
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43469(messageKey("editor_spawn_egg_synced"), getSpawnEggEntityName(entry));
        method_41843();
    }

    protected void writeSpawnEggEntityId(SpawnEggEntityEntry entry) {
        class_2487 entityTag = getOrCreateSpawnEditorEntityTag();
        entityTag.method_10582(ENTITY_ID_TAG, entry.id().toString());
        cleanupSpawnEggEntityTag(entityTag);
        if (isSpawnerItem(this.previewStack) && !isTrialSpawnerItem(this.previewStack)) {
            clearSpawnerSpawnPotentials();
        }
    }

    protected void clearSpawnEggEntityTag() {
        if (!hasSpawnEditorEntityData(this.previewStack)) {
            return;
        }

        if (isSpawnEggItem(this.previewStack)) {
            class_2487 tag = ItemStackNbt.get(this.previewStack);
            if (tag != null) {
                tag.method_10551(ENTITY_TAG);
                cleanupEmptyTag();
            }
        } else if (isSpawnerItem(this.previewStack)) {
            clearSpawnerSpawnData();
        }
        this.spawnEggCustomNameValue = "";
        this.spawnEggOwnerValue = "";
        this.spawnEggNumberValueOverrides.clear();
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey(getSpawnEditorTagClearedMessageKey()));
        readSpawnEggFieldsFromStack(this.previewStack);
        method_41843();
    }

    protected void toggleSpawnEggBoolean(SpawnEggTagRow row) {
        if (!isSpawnEditorItem(this.previewStack)) {
            return;
        }

        class_2487 entityTag = getOrCreateSpawnEditorEntityTag();
        if (getSpawnEggBooleanValue(row)) {
            removeSpawnEggTagValue(entityTag, row.tagKey());
        } else {
            putSpawnEggBooleanValue(entityTag, row.tagKey(), true);
        }
        cleanupSpawnEggEntityTag(entityTag);
        this.status = class_2561.method_43469(messageKey("editor_spawn_egg_field_updated"),
                class_2561.method_43471(key("spawnegg." + row.translationSuffix())));
        method_41843();
    }

    protected void toggleSpawnEggPresence(SpawnEggTagRow row) {
        if (!isSpawnEditorItem(this.previewStack)) {
            return;
        }

        class_2487 entityTag = getOrCreateSpawnEditorEntityTag();
        if (getSpawnEggPresenceValue(row)) {
            removeSpawnEggTagValue(entityTag, row.tagKey());
        } else {
            putSpawnEggPresenceValue(entityTag, row.tagKey());
        }
        cleanupSpawnEggEntityTag(entityTag);
        this.status = class_2561.method_43469(messageKey("editor_spawn_egg_field_updated"),
                class_2561.method_43471(key("spawnegg." + row.translationSuffix())));
        method_41843();
    }

    protected void applySpawnEggCustomName(String value) {
        if (!isSpawnEditorItem(this.previewStack)) {
            return;
        }

        class_2487 entityTag = getOrCreateSpawnEditorEntityTag();
        String normalized = value == null ? "" : value.trim();
        if (normalized.isEmpty()) {
            entityTag.method_10551(ENTITY_CUSTOM_NAME_TAG);
        } else {
            entityTag.method_10582(ENTITY_CUSTOM_NAME_TAG, ComponentCompat.toJson(class_2561.method_43470(value)));
        }
        cleanupSpawnEggEntityTag(entityTag);
    }

    protected void applySpawnEggOwner(String value) {
        if (!isSpawnEditorItem(this.previewStack)) {
            return;
        }

        class_2487 entityTag = getOrCreateSpawnEditorEntityTag();
        String normalized = value == null ? "" : value.trim();
        if (normalized.isEmpty()) {
            entityTag.method_10551(ENTITY_OWNER_TAG);
        } else {
            UUID uuid = parseUuidOrNull(normalized);
            if (uuid == null) {
                entityTag.method_10582(ENTITY_OWNER_TAG, normalized);
            } else {
                NbtCompat.putUUID(entityTag, ENTITY_OWNER_TAG, uuid);
            }
        }
        cleanupSpawnEggEntityTag(entityTag);
    }

    protected void applySpawnEggNumber(SpawnEggTagRow row, String value) {
        if (!isSpawnEditorItem(this.previewStack)) {
            return;
        }

        String normalized = value == null ? "" : value.trim();
        this.spawnEggNumberValueOverrides.put(row.tagKey(), normalized);
        class_2487 entityTag = getOrCreateSpawnEditorEntityTag();
        if (normalized.isEmpty()) {
            removeSpawnEggTagValue(entityTag, row.tagKey());
            this.spawnEggNumberValueOverrides.remove(row.tagKey());
            cleanupSpawnEggEntityTag(entityTag);
            return;
        }
        if (isPartialSpawnEggNumber(normalized)) {
            return;
        }

        try {
            double parsed = row.numberType() == SpawnEggNumberType.FLOAT
                    ? Double.parseDouble(normalized)
                    : Long.parseLong(normalized);
            if (parsed < row.minValue() || parsed > row.maxValue()) {
                this.status = class_2561.method_43469(messageKey("editor_spawn_egg_invalid_number"),
                        class_2561.method_43471(key("spawnegg." + row.translationSuffix())),
                        formatSpawnEggNumber(row.minValue()),
                        formatSpawnEggNumber(row.maxValue()));
                return;
            }

            double storedValue = row.toStoredNumber(parsed);
            putSpawnEggNumberValue(entityTag, row, storedValue);
            cleanupSpawnEggEntityTag(entityTag);
        } catch (NumberFormatException exception) {
            this.status = class_2561.method_43469(messageKey("editor_spawn_egg_invalid_number"),
                    class_2561.method_43471(key("spawnegg." + row.translationSuffix())),
                    formatSpawnEggNumber(row.minValue()),
                    formatSpawnEggNumber(row.maxValue()));
        }
    }

    protected void cycleSpawnEggChoice(SpawnEggTagRow row) {
        if (!isSpawnEditorItem(this.previewStack) || row.choices() == null || row.choices().isEmpty()) {
            return;
        }

        class_2487 entityTag = getOrCreateSpawnEditorEntityTag();
        String currentValue = getSpawnEggChoiceValue(row);
        int currentIndex = getSpawnEggChoiceIndex(row, currentValue);
        int nextIndex = currentIndex < 0 ? 0 : class_3532.method_15387(currentIndex + 1, row.choices().size());
        SpawnEggChoiceOption nextOption = row.choices().get(nextIndex);
        if (nextOption.value().isEmpty()) {
            removeSpawnEggTagValue(entityTag, row.tagKey());
        } else if (row.choiceStorage() == SpawnEggChoiceStorage.INT) {
            putSpawnEggIntValue(entityTag, row.tagKey(), Integer.parseInt(nextOption.value()));
        } else {
            putSpawnEggStringValue(entityTag, row.tagKey(), nextOption.value());
        }
        cleanupSpawnEggEntityTag(entityTag);
        this.status = class_2561.method_43469(messageKey("editor_spawn_egg_field_updated"),
                class_2561.method_43471(key("spawnegg." + row.translationSuffix())));
        method_41843();
    }

    protected class_2487 getOrCreateSpawnEditorEntityTag() {
        if (isSpawnerItem(this.previewStack)) {
            return getOrCreateSpawnerEntityTag();
        }

        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        class_2487 entityTag = tag.method_68568(ENTITY_TAG);
        tag.method_10566(ENTITY_TAG, entityTag);
        return entityTag;
    }

    protected void cleanupSpawnEggEntityTag(class_2487 entityTag) {
        if (isSpawnerItem(this.previewStack)) {
            cleanupSpawnerEntityTag(entityTag);
            return;
        }

        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        if (entityTag.method_33133()) {
            tag.method_10551(ENTITY_TAG);
        } else {
            tag.method_10566(ENTITY_TAG, entityTag);
        }
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected class_2487 getOrCreateSpawnerEntityTag() {
        if (isTrialSpawnerItem(this.previewStack)) {
            return getOrCreateTrialSpawnerEntityTag();
        }

        class_2487 blockEntity = getOrCreateSpawnerBlockEntityTag();
        class_2487 spawnData = blockEntity.method_68568(SPAWNER_SPAWN_DATA_TAG);
        class_2487 entityTag = getSpawnerEntityFromSpawnData(spawnData);
        if (entityTag == null) {
            entityTag = getFirstSpawnerPotentialEntity(blockEntity);
        }
        if (entityTag == null) {
            entityTag = new class_2487();
        }
        if (!entityTag.method_10545(ENTITY_ID_TAG)) {
            SpawnEggEntityEntry entry = getSelectedSpawnEggEntityEntry();
            if (entry != null) {
                entityTag.method_10582(ENTITY_ID_TAG, entry.id().toString());
            }
        }
        putSpawnerSpawnData(blockEntity, spawnData, entityTag);
        return entityTag;
    }

    protected class_2487 getOrCreateTrialSpawnerEntityTag() {
        class_2487 blockEntity = getOrCreateSpawnerBlockEntityTag();
        class_2487 entityTag = getTrialSpawnerEntityTag(blockEntity);
        if (entityTag == null) {
            entityTag = new class_2487();
        }
        if (!entityTag.method_10545(ENTITY_ID_TAG)) {
            SpawnEggEntityEntry entry = getSelectedSpawnEggEntityEntry();
            if (entry != null) {
                entityTag.method_10582(ENTITY_ID_TAG, entry.id().toString());
            }
        }
        putTrialSpawnerSpawnData(blockEntity, entityTag);
        return entityTag;
    }

    protected class_2487 getOrCreateSpawnerBlockEntityTag() {
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        blockEntity.method_10582(ENTITY_ID_TAG, getSpawnerBlockEntityId(this.previewStack));
        tag.method_10566(BLOCK_ENTITY_TAG, blockEntity);
        return blockEntity;
    }

    protected void cleanupSpawnerEntityTag(class_2487 entityTag) {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        if (isTrialSpawnerItem(this.previewStack)) {
            if (entityTag.method_33133()) {
                clearTrialSpawnerEntityData(blockEntity);
            } else {
                putTrialSpawnerSpawnData(blockEntity, entityTag);
                blockEntity.method_10582(ENTITY_ID_TAG, TRIAL_SPAWNER_BLOCK_ENTITY_ID);
            }
            cleanupSpawnerBlockEntityTag(blockEntity);
            this.rawNbtValue = getInitialNbt(this.previewStack);
            return;
        }

        if (entityTag.method_33133()) {
            class_2487 spawnData = blockEntity.method_68568(SPAWNER_SPAWN_DATA_TAG);
            spawnData.method_10551(SPAWNER_ENTITY_TAG);
            if (spawnData.method_33133()) {
                blockEntity.method_10551(SPAWNER_SPAWN_DATA_TAG);
            } else {
                blockEntity.method_10566(SPAWNER_SPAWN_DATA_TAG, spawnData);
            }
        } else {
            class_2487 spawnData = blockEntity.method_68568(SPAWNER_SPAWN_DATA_TAG);
            putSpawnerSpawnData(blockEntity, spawnData, entityTag);
            blockEntity.method_10582(ENTITY_ID_TAG, SPAWNER_BLOCK_ENTITY_ID);
        }
        cleanupSpawnerBlockEntityTag(blockEntity);
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected void clearSpawnerSpawnData() {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null || !tag.method_10545(BLOCK_ENTITY_TAG)) {
            return;
        }

        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        if (isTrialSpawnerItem(this.previewStack)) {
            clearTrialSpawnerEntityData(blockEntity);
            cleanupSpawnerBlockEntityTag(blockEntity);
            this.rawNbtValue = getInitialNbt(this.previewStack);
            return;
        }

        blockEntity.method_10551(SPAWNER_SPAWN_DATA_TAG);
        blockEntity.method_10551(SPAWNER_SPAWN_POTENTIALS_TAG);
        cleanupSpawnerBlockEntityTag(blockEntity);
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected void clearSpawnerSpawnPotentials() {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null || !tag.method_10545(BLOCK_ENTITY_TAG)) {
            return;
        }

        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        if (isTrialSpawnerItem(this.previewStack)) {
            clearTrialSpawnerSpawnPotentials(blockEntity);
            cleanupSpawnerBlockEntityTag(blockEntity);
            this.rawNbtValue = getInitialNbt(this.previewStack);
            return;
        }

        blockEntity.method_10551(SPAWNER_SPAWN_POTENTIALS_TAG);
        cleanupSpawnerBlockEntityTag(blockEntity);
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected void cleanupSpawnerBlockEntityTag(class_2487 blockEntity) {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        if (blockEntity.method_33133() || isOnlySpawnerBlockEntityId(blockEntity)) {
            tag.method_10551(BLOCK_ENTITY_TAG);
        } else {
            tag.method_10566(BLOCK_ENTITY_TAG, blockEntity);
        }
        cleanupEmptyTag();
    }

    protected boolean isOnlySpawnerBlockEntityId(class_2487 blockEntity) {
        return blockEntity.method_10546() == 1
                && blockEntity.method_10545(ENTITY_ID_TAG)
                && (SPAWNER_BLOCK_ENTITY_ID.equals(blockEntity.method_68564(ENTITY_ID_TAG, ""))
                || TRIAL_SPAWNER_BLOCK_ENTITY_ID.equals(blockEntity.method_68564(ENTITY_ID_TAG, "")));
    }

    protected class_2561 getSpawnEggBooleanText(SpawnEggTagRow row) {
        return class_2561.method_43469(key("spawnegg.option_state"),
                class_2561.method_43471(key("spawnegg." + row.translationSuffix())),
                class_2561.method_43471(key("spawnegg.state." + (getSpawnEggBooleanValue(row) ? 1 : 0))));
    }

    protected class_2561 getSpawnEggPresenceText(SpawnEggTagRow row) {
        return class_2561.method_43469(key("spawnegg.option_state"),
                class_2561.method_43471(key("spawnegg." + row.translationSuffix())),
                class_2561.method_43471(key("spawnegg.state." + (getSpawnEggPresenceValue(row) ? 1 : 0))));
    }

    protected class_2561 getSpawnEggChoiceText(SpawnEggTagRow row) {
        return class_2561.method_43469(key("spawnegg.option_state"),
                class_2561.method_43471(key("spawnegg." + row.translationSuffix())),
                getSpawnEggChoiceOptionText(row));
    }

    protected class_2561 getSpawnEggChoiceOptionText(SpawnEggTagRow row) {
        String currentValue = getSpawnEggChoiceValue(row);
        int index = getSpawnEggChoiceIndex(row, currentValue);
        if (index >= 0) {
            SpawnEggChoiceOption option = row.choices().get(index);
            return class_2561.method_43471(key("spawnegg." + row.translationSuffix() + "." + option.translationSuffix()));
        }
        return currentValue.isEmpty()
                ? class_2561.method_43471(key("spawnegg.choice.empty"))
                : class_2561.method_43470(currentValue);
    }

    protected String getSpawnEggChoiceValue(SpawnEggTagRow row) {
        class_2487 entityTag = getSpawnEditorEntityTag(this.previewStack);
        class_2487 parent = getSpawnEggTagParent(entityTag, row.tagKey(), false);
        if (parent == null) {
            return "";
        }

        String leafKey = getSpawnEggLeafTagKey(row.tagKey());
        if (row.choiceStorage() == SpawnEggChoiceStorage.INT) {
            return parent.method_10545(leafKey) ? Integer.toString(parent.method_68083(leafKey, 0)) : "";
        }
        return parent.method_10545(leafKey) ? parent.method_68564(leafKey, "") : "";
    }

    protected int getSpawnEggChoiceIndex(SpawnEggTagRow row, String value) {
        for (int i = 0; i < row.choices().size(); i++) {
            if (Objects.equals(row.choices().get(i).value(), value)) {
                return i;
            }
        }
        return -1;
    }

    protected boolean getSpawnEggBooleanValue(SpawnEggTagRow row) {
        class_2487 entityTag = getSpawnEditorEntityTag(this.previewStack);
        class_2487 parent = getSpawnEggTagParent(entityTag, row.tagKey(), false);
        if (parent == null) {
            return false;
        }
        String leafKey = getSpawnEggLeafTagKey(row.tagKey());
        return parent.method_10545(leafKey) && parent.method_68566(leafKey, false);
    }

    protected boolean getSpawnEggPresenceValue(SpawnEggTagRow row) {
        class_2487 entityTag = getSpawnEditorEntityTag(this.previewStack);
        class_2487 parent = getSpawnEggTagParent(entityTag, row.tagKey(), false);
        if (parent == null) {
            return false;
        }

        String leafKey = getSpawnEggLeafTagKey(row.tagKey());
        return parent.method_10545(leafKey) && NbtCompat.getIntArray(parent, leafKey).length == 3;
    }

    protected String getSpawnEggNumberValue(SpawnEggTagRow row) {
        String override = this.spawnEggNumberValueOverrides.get(row.tagKey());
        if (override != null) {
            return override;
        }

        class_2487 entityTag = getSpawnEditorEntityTag(this.previewStack);
        class_2487 parent = getSpawnEggTagParent(entityTag, row.tagKey(), false);
        if (parent == null) {
            return "";
        }

        String leafKey = getSpawnEggLeafTagKey(row.tagKey());
        if (!parent.method_10545(leafKey)) {
            return "";
        }
        return switch (row.numberType()) {
            case BYTE -> formatSpawnEggNumber(row.toDisplayNumber(parent.method_68562(leafKey, (byte) 0)));
            case SHORT -> formatSpawnEggNumber(row.toDisplayNumber(parent.method_68565(leafKey, (short) 0)));
            case INT -> formatSpawnEggNumber(row.toDisplayNumber(parent.method_68083(leafKey, 0)));
            case FLOAT -> Float.toString((float) row.toDisplayNumber(parent.method_66563(leafKey, 0.0F)));
        };
    }

    protected int getSpawnEggTagTextMaxLength(SpawnEggTagRow row) {
        return switch (row.type()) {
            case CUSTOM_NAME -> 256;
            case OWNER -> SPAWN_EGG_OWNER_MAX_LENGTH;
            default -> 16;
        };
    }

    protected String getSpawnEggTagTextValue(SpawnEggTagRow row) {
        return switch (row.type()) {
            case CUSTOM_NAME -> this.spawnEggCustomNameValue;
            case OWNER -> this.spawnEggOwnerValue;
            default -> getSpawnEggNumberValue(row);
        };
    }

    protected class_2487 getSpawnEggTagParent(class_2487 entityTag, String tagPath, boolean create) {
        if (entityTag == null) {
            return null;
        }

        String[] parts = tagPath.split("\\.");
        class_2487 current = entityTag;
        for (int i = 0; i < parts.length - 1; i++) {
            String part = parts[i];
            if (!current.method_10545(part)) {
                if (!create) {
                    return null;
                }
                current.method_10566(part, new class_2487());
            }
            current = current.method_68568(part);
        }
        return current;
    }

    protected String getSpawnEggLeafTagKey(String tagPath) {
        int dot = tagPath.lastIndexOf('.');
        return dot < 0 ? tagPath : tagPath.substring(dot + 1);
    }

    protected void putSpawnEggBooleanValue(class_2487 entityTag, String tagPath, boolean value) {
        class_2487 parent = getSpawnEggTagParent(entityTag, tagPath, true);
        if (parent != null) {
            parent.method_10556(getSpawnEggLeafTagKey(tagPath), value);
        }
    }

    protected void putSpawnEggPresenceValue(class_2487 entityTag, String tagPath) {
        class_2487 parent = getSpawnEggTagParent(entityTag, tagPath, true);
        if (parent != null) {
            parent.method_10539(getSpawnEggLeafTagKey(tagPath), new int[]{0, 0, 0});
        }
    }

    protected void putSpawnEggStringValue(class_2487 entityTag, String tagPath, String value) {
        class_2487 parent = getSpawnEggTagParent(entityTag, tagPath, true);
        if (parent != null) {
            parent.method_10582(getSpawnEggLeafTagKey(tagPath), value);
        }
    }

    protected void putSpawnEggIntValue(class_2487 entityTag, String tagPath, int value) {
        class_2487 parent = getSpawnEggTagParent(entityTag, tagPath, true);
        if (parent != null) {
            parent.method_10569(getSpawnEggLeafTagKey(tagPath), value);
        }
    }

    protected void putSpawnEggNumberValue(class_2487 entityTag, SpawnEggTagRow row, double storedValue) {
        class_2487 parent = getSpawnEggTagParent(entityTag, row.tagKey(), true);
        if (parent == null) {
            return;
        }

        String leafKey = getSpawnEggLeafTagKey(row.tagKey());
        switch (row.numberType()) {
            case BYTE -> parent.method_10567(leafKey, (byte) storedValue);
            case SHORT -> parent.method_10575(leafKey, (short) storedValue);
            case INT -> parent.method_10569(leafKey, (int) storedValue);
            case FLOAT -> parent.method_10548(leafKey, (float) storedValue);
        }
    }

    protected void removeSpawnEggTagValue(class_2487 entityTag, String tagPath) {
        if (entityTag == null) {
            return;
        }
        removeSpawnEggTagValue(entityTag, tagPath.split("\\."), 0);
    }

    protected boolean removeSpawnEggTagValue(class_2487 current, String[] parts, int index) {
        if (index >= parts.length - 1) {
            current.method_10551(parts[index]);
            return current.method_33133();
        }

        String part = parts[index];
        if (!current.method_10545(part)) {
            return current.method_33133();
        }

        class_2487 child = current.method_68568(part);
        if (removeSpawnEggTagValue(child, parts, index + 1)) {
            current.method_10551(part);
        } else {
            current.method_10566(part, child);
        }
        return current.method_33133();
    }

    protected boolean isAllowedSpawnEggNumber(String value, SpawnEggNumberType type) {
        if (value == null || value.isEmpty()) {
            return true;
        }
        return type == SpawnEggNumberType.FLOAT
                ? value.matches("-?\\d*(\\.\\d*)?")
                : value.matches("-?\\d*");
    }

    protected boolean isPartialSpawnEggNumber(String value) {
        return "-".equals(value) || ".".equals(value) || "-.".equals(value);
    }

    protected String formatSpawnEggNumber(double value) {
        if (value == (long) value) {
            return Long.toString((long) value);
        }
        return Double.toString(value);
    }

    protected void setSpawnEggEntityScroll(int value) {
        List<SpawnEggEntityEntry> entities = getFilteredSpawnEggEntities();
        int maxScroll = Math.max(0, entities.size() - SPAWN_EGG_ENTITY_ROWS);
        this.spawnEggEntityScroll = class_3532.method_15340(value, 0, maxScroll);
        clampSpawnEggEntitySelection(entities);
        if (!entities.isEmpty()) {
            int lastVisible = Math.min(entities.size() - 1, this.spawnEggEntityScroll + SPAWN_EGG_ENTITY_ROWS - 1);
            this.selectedSpawnEggEntityIndex = class_3532.method_15340(this.selectedSpawnEggEntityIndex, this.spawnEggEntityScroll, lastVisible);
        }
    }

    protected void setSpawnEggTagScroll(int value) {
        int maxScroll = Math.max(0, getSpawnEggTagRows().size() - SPAWN_EGG_TAG_ROWS);
        this.spawnEggTagScroll = class_3532.method_15340(value, 0, maxScroll);
    }

    protected void cycleSelectedSpawnEggEntity(int direction) {
        List<SpawnEggEntityEntry> entities = getFilteredSpawnEggEntities();
        if (entities.isEmpty()) {
            return;
        }

        this.selectedSpawnEggEntityIndex = class_3532.method_15387(this.selectedSpawnEggEntityIndex + direction, entities.size());
        this.spawnEggTagScroll = 0;
        scrollSpawnEggSelectionIntoView(entities);
        method_41843();
    }

    protected void scrollSpawnEggSelectionIntoView(List<SpawnEggEntityEntry> entities) {
        clampSpawnEggEntitySelection(entities);
        if (entities.isEmpty()) {
            return;
        }

        if (this.selectedSpawnEggEntityIndex < this.spawnEggEntityScroll) {
            this.spawnEggEntityScroll = this.selectedSpawnEggEntityIndex;
        } else if (this.selectedSpawnEggEntityIndex >= this.spawnEggEntityScroll + SPAWN_EGG_ENTITY_ROWS) {
            this.spawnEggEntityScroll = this.selectedSpawnEggEntityIndex - SPAWN_EGG_ENTITY_ROWS + 1;
        }
        this.spawnEggEntityScroll = class_3532.method_15340(this.spawnEggEntityScroll, 0, Math.max(0, entities.size() - SPAWN_EGG_ENTITY_ROWS));
    }

    protected void clampSpawnEggEntitySelection(List<SpawnEggEntityEntry> entities) {
        if (entities.isEmpty()) {
            this.selectedSpawnEggEntityIndex = 0;
            this.spawnEggEntityScroll = 0;
            return;
        }

        this.selectedSpawnEggEntityIndex = class_3532.method_15340(this.selectedSpawnEggEntityIndex, 0, entities.size() - 1);
        this.spawnEggEntityScroll = class_3532.method_15340(this.spawnEggEntityScroll, 0, Math.max(0, entities.size() - SPAWN_EGG_ENTITY_ROWS));
    }

    protected int getSpawnEggEntityRowY(int row) {
        return sideListStartY() + row * 10;
    }

    protected int getSpawnEggTagRowY(int row) {
        return 138 + row * SPAWN_EGG_TAG_ROW_HEIGHT;
    }

    protected int getSpawnEggControlsX() {
        int width = getSpawnEggControlsWidth();
        return rightControlsX(width, spawnEggEntityListX(), spawnEggEntityListWidth());
    }

    protected int getSpawnEggControlsWidth() {
        return isSidebarUi() ? contentLimitedWidth(132, 88, 20) : 132;
    }

    protected SpawnEggEntityEntry getSelectedSpawnEggEntityEntry() {
        List<SpawnEggEntityEntry> entities = getFilteredSpawnEggEntities();
        clampSpawnEggEntitySelection(entities);
        if (entities.isEmpty()) {
            return null;
        }
        return entities.get(this.selectedSpawnEggEntityIndex);
    }

    protected List<SpawnEggEntityEntry> getFilteredSpawnEggEntities() {
        String filter = this.spawnEggEntityFilterValue == null ? "" : this.spawnEggEntityFilterValue.trim().toLowerCase(Locale.ROOT);
        List<SpawnEggEntityEntry> entities = new ArrayList<>();
        for (class_1299<?> type : CompatRegistries.ENTITY_TYPES.getValues()) {
            if (!type.method_5896()) {
                continue;
            }

            class_2960 id = CompatRegistries.ENTITY_TYPES.getKey(type);
            if (id == null) {
                continue;
            }

            String idString = id.toString().toLowerCase(Locale.ROOT);
            String path = id.method_12832().toLowerCase(Locale.ROOT);
            String name = type.method_5897().getString().toLowerCase(Locale.ROOT);
            if (filter.isEmpty() || idString.contains(filter) || path.contains(filter) || name.contains(filter)) {
                entities.add(new SpawnEggEntityEntry(id, type));
            }
        }

        entities.sort(Comparator
                .comparing((SpawnEggEntityEntry entry) -> entry.type().method_5897().getString(), String.CASE_INSENSITIVE_ORDER)
                .thenComparing(entry -> entry.id().toString()));
        return entities;
    }

    protected String formatSpawnEggEntityEntry(SpawnEggEntityEntry entry) {
        return getSpawnEggEntityName(entry).getString() + " (" + stripMinecraftNamespace(entry.id()) + ")";
    }

    protected class_2561 getSpawnEggEntityName(SpawnEggEntityEntry entry) {
        return entry.type().method_5897();
    }

    protected class_2561 getCurrentSpawnEggEntityName() {
        class_1299<?> type = getCurrentSpawnEggEntityType(this.previewStack);
        if (type != null) {
            return type.method_5897();
        }

        String rawId = getSpawnEggEntityIdOverride(this.previewStack);
        return rawId.isEmpty() ? class_2561.method_43471(key(getSpawnEditorDefaultEntityKey())) : class_2561.method_43470(rawId);
    }

    protected class_1299<?> getCurrentSpawnEggEntityType(class_1799 stack) {
        String rawId = getSpawnEggEntityIdOverride(stack);
        if (!rawId.isEmpty()) {
            class_2960 id = class_2960.method_12829(rawId);
            class_1299<?> type = id == null ? null : CompatRegistries.ENTITY_TYPES.getValue(id);
            if (type != null) {
                return type;
            }
        }

        if (stack.method_7909() instanceof class_1826 spawnEggItem) {
            return spawnEggItem.method_8015(ItemStackNbt.registryAccess(), stack);
        }
        return null;
    }

    protected String getSpawnEggEntityIdOverride(class_1799 stack) {
        class_2487 entityTag = getSpawnEditorEntityTag(stack);
        if (entityTag != null && entityTag.method_10545(ENTITY_ID_TAG)) {
            return entityTag.method_68564(ENTITY_ID_TAG, "");
        }
        return "";
    }

    protected class_2487 getSpawnEditorEntityTag(class_1799 stack) {
        if (isSpawnerItem(stack)) {
            return getSpawnerEntityTag(stack);
        }
        return ItemStackNbt.getElement(stack, ENTITY_TAG);
    }

    protected class_2487 getSpawnerEntityTag(class_1799 stack) {
        class_2487 blockEntity = ItemStackNbt.getElement(stack, BLOCK_ENTITY_TAG);
        if (blockEntity == null) {
            return null;
        }
        if (isTrialSpawnerItem(stack)) {
            return getTrialSpawnerEntityTag(blockEntity);
        }
        if (blockEntity.method_10545(SPAWNER_SPAWN_DATA_TAG)) {
            class_2487 spawnData = blockEntity.method_68568(SPAWNER_SPAWN_DATA_TAG);
            class_2487 entityTag = getSpawnerEntityFromSpawnData(spawnData);
            if (entityTag != null) {
                return entityTag;
            }
        }
        return getFirstSpawnerPotentialEntity(blockEntity);
    }

    protected class_2487 getTrialSpawnerEntityTag(class_2487 blockEntity) {
        class_2487 entityTag = getFirstTrialSpawnerConfigEntity(blockEntity, TRIAL_SPAWNER_NORMAL_CONFIG_TAG);
        if (entityTag != null) {
            return entityTag;
        }
        if (blockEntity.method_10545(TRIAL_SPAWNER_SPAWN_DATA_TAG)) {
            entityTag = getSpawnerEntityFromSpawnData(blockEntity.method_68568(TRIAL_SPAWNER_SPAWN_DATA_TAG));
            if (entityTag != null) {
                return entityTag;
            }
        }
        return getFirstTrialSpawnerConfigEntity(blockEntity, TRIAL_SPAWNER_OMINOUS_CONFIG_TAG);
    }

    protected class_2487 getFirstTrialSpawnerConfigEntity(class_2487 blockEntity, String configKey) {
        class_2487 config = getTrialSpawnerConfig(blockEntity, configKey, false);
        return config == null ? null : getFirstSpawnerPotentialEntity(config);
    }

    protected class_2487 getTrialSpawnerConfig(class_2487 blockEntity, String configKey, boolean create) {
        if (!blockEntity.method_10545(configKey)) {
            if (!create) {
                return null;
            }
            blockEntity.method_10566(configKey, new class_2487());
        }
        return blockEntity.method_68568(configKey);
    }

    protected class_2487 getFirstSpawnerPotentialEntity(class_2487 blockEntity) {
        if (blockEntity.method_10545(SPAWNER_SPAWN_POTENTIALS_TAG)) {
            class_2499 potentials = blockEntity.method_68569(SPAWNER_SPAWN_POTENTIALS_TAG);
            if (!potentials.isEmpty()) {
                class_2487 potential = potentials.method_68582(0);
                class_2487 entityTag = getSpawnerEntityFromPotential(potential);
                if (entityTag != null) {
                    return entityTag;
                }
            }
        }
        if (blockEntity.method_10545(TRIAL_SPAWNER_SPAWN_POTENTIALS_TAG)) {
            class_2499 potentials = blockEntity.method_68569(TRIAL_SPAWNER_SPAWN_POTENTIALS_TAG);
            if (!potentials.isEmpty()) {
                class_2487 potential = potentials.method_68582(0);
                class_2487 entityTag = getSpawnerEntityFromPotential(potential);
                if (entityTag != null) {
                    return entityTag;
                }
            }
        }
        return null;
    }

    protected class_2487 getSpawnerEntityFromPotential(class_2487 potential) {
        if (potential.method_10545(SPAWNER_POTENTIAL_DATA_TAG)) {
            class_2487 entityTag = getSpawnerEntityFromSpawnData(potential.method_68568(SPAWNER_POTENTIAL_DATA_TAG));
            if (entityTag != null) {
                return entityTag;
            }
        }
        if (potential.method_10545(SPAWNER_ENTITY_TAG)
                || potential.method_10545(ENTITY_ID_TAG)) {
            class_2487 entityTag = getSpawnerEntityFromSpawnData(potential);
            if (entityTag != null) {
                return entityTag;
            }
        }
        if (potential.method_10545(SPAWNER_POTENTIAL_LEGACY_ENTITY_TAG)) {
            return potential.method_68568(SPAWNER_POTENTIAL_LEGACY_ENTITY_TAG).method_10553();
        }
        return null;
    }

    protected class_2487 getSpawnerEntityFromSpawnData(class_2487 spawnData) {
        if (spawnData.method_10545(SPAWNER_ENTITY_TAG)) {
            return spawnData.method_68568(SPAWNER_ENTITY_TAG).method_10553();
        }
        if (spawnData.method_10545(ENTITY_ID_TAG)) {
            return spawnData.method_10553();
        }
        return null;
    }

    protected void putSpawnerSpawnData(class_2487 blockEntity, class_2487 originalSpawnData, class_2487 entityTag) {
        class_2487 spawnData = new class_2487();
        if (originalSpawnData.method_10545(SPAWNER_CUSTOM_SPAWN_RULES_TAG)) {
            spawnData.method_10566(SPAWNER_CUSTOM_SPAWN_RULES_TAG, originalSpawnData.method_68568(SPAWNER_CUSTOM_SPAWN_RULES_TAG).method_10553());
        }
        spawnData.method_10566(SPAWNER_ENTITY_TAG, entityTag);
        blockEntity.method_10566(SPAWNER_SPAWN_DATA_TAG, spawnData);
    }

    protected void putTrialSpawnerSpawnData(class_2487 blockEntity, class_2487 entityTag) {
        class_2487 config = getTrialSpawnerConfig(blockEntity, TRIAL_SPAWNER_NORMAL_CONFIG_TAG, true);
        class_2499 potentials = new class_2499();
        class_2487 potential = new class_2487();
        class_2487 spawnData = new class_2487();
        spawnData.method_10566(SPAWNER_ENTITY_TAG, entityTag.method_10553());
        potential.method_10566(SPAWNER_POTENTIAL_DATA_TAG, spawnData);
        potential.method_10569(SPAWNER_POTENTIAL_WEIGHT_TAG, 1);
        potentials.add(potential);
        config.method_10566(TRIAL_SPAWNER_SPAWN_POTENTIALS_TAG, potentials);
        blockEntity.method_10566(TRIAL_SPAWNER_NORMAL_CONFIG_TAG, config);
        blockEntity.method_10551(TRIAL_SPAWNER_SPAWN_DATA_TAG);
    }

    protected void clearTrialSpawnerEntityData(class_2487 blockEntity) {
        blockEntity.method_10551(TRIAL_SPAWNER_SPAWN_DATA_TAG);
        clearTrialSpawnerSpawnPotentials(blockEntity);
    }

    protected void clearTrialSpawnerSpawnPotentials(class_2487 blockEntity) {
        clearTrialSpawnerConfigSpawnPotentials(blockEntity, TRIAL_SPAWNER_NORMAL_CONFIG_TAG);
        clearTrialSpawnerConfigSpawnPotentials(blockEntity, TRIAL_SPAWNER_OMINOUS_CONFIG_TAG);
    }

    protected void clearTrialSpawnerConfigSpawnPotentials(class_2487 blockEntity, String configKey) {
        class_2487 config = getTrialSpawnerConfig(blockEntity, configKey, false);
        if (config == null) {
            return;
        }

        config.method_10551(TRIAL_SPAWNER_SPAWN_POTENTIALS_TAG);
        if (config.method_33133()) {
            blockEntity.method_10551(configKey);
        } else {
            blockEntity.method_10566(configKey, config);
        }
    }

    protected String getSpawnerBlockEntityId(class_1799 stack) {
        return isTrialSpawnerItem(stack) ? TRIAL_SPAWNER_BLOCK_ENTITY_ID : SPAWNER_BLOCK_ENTITY_ID;
    }

    protected boolean hasSpawnEditorEntityData(class_1799 stack) {
        if (isSpawnerItem(stack)) {
            class_2487 blockEntity = ItemStackNbt.getElement(stack, BLOCK_ENTITY_TAG);
            if (isTrialSpawnerItem(stack)) {
                return blockEntity != null && getTrialSpawnerEntityTag(blockEntity) != null;
            }
            return blockEntity != null
                    && (blockEntity.method_10545(SPAWNER_SPAWN_DATA_TAG)
                    || blockEntity.method_10545(SPAWNER_SPAWN_POTENTIALS_TAG));
        }
        return ItemStackNbt.getElement(stack, ENTITY_TAG) != null;
    }

    protected String getSpawnEditorTitleKey() {
        if (isTrialSpawnerItem(this.previewStack)) {
            return "trial_spawner";
        }
        return isSpawnerItem(this.previewStack) ? "spawner" : "spawnegg";
    }

    protected String getSpawnEditorClearKey() {
        if (isTrialSpawnerItem(this.previewStack)) {
            return "trial_spawner.clear_entity_tag";
        }
        return isSpawnerItem(this.previewStack) ? "spawner.clear_entity_tag" : "spawnegg.clear_entity_tag";
    }

    protected String getSpawnEditorDefaultEntityKey() {
        if (isTrialSpawnerItem(this.previewStack)) {
            return "trial_spawner.default_entity";
        }
        return isSpawnerItem(this.previewStack) ? "spawner.default_entity" : "spawnegg.default_entity";
    }

    protected String getSpawnEditorTagClearedMessageKey() {
        if (isTrialSpawnerItem(this.previewStack)) {
            return "editor_trial_spawner_tag_cleared";
        }
        return isSpawnerItem(this.previewStack) ? "editor_spawner_tag_cleared" : "editor_spawn_egg_tag_cleared";
    }

    protected List<SpawnEggTagRow> getSpawnEggTagRows() {
        SpawnEggEntityEntry entry = getSelectedSpawnEggEntityEntry();
        String path = entry == null ? "" : entry.id().method_12832();
        List<SpawnEggTagRow> rows = new ArrayList<>(SpawnEggTagRows.GENERAL);
        rows.addAll(SpawnEggTagRows.forEntity(path));
        return rows;
    }
}
