package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernUi;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_124;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
abstract class ItemEditorScreenColorLore extends ItemEditorScreenEffects {
    protected ItemEditorScreenColorLore(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

protected void applyColorFromHex(boolean updateStatus) {
        String text = this.colorHexBox == null ? this.colorHexValue : this.colorHexBox.method_1882();
        String normalized = text == null ? "" : text.trim();
        if (normalized.startsWith("#")) {
            normalized = normalized.substring(1);
        }

        if (normalized.length() != 6) {
            if (updateStatus && !normalized.isBlank()) {
                this.status = class_2561.method_43471(messageKey("editor_invalid_color"));
            }
            return;
        }

        try {
            setEditorColor(Integer.parseInt(normalized, 16));
            syncColorControlsFromStack();
            if (updateStatus) {
                this.status = class_2561.method_43469(messageKey("editor_color_updated"), this.colorHexValue);
            }
        } catch (NumberFormatException exception) {
            this.status = class_2561.method_43471(messageKey("editor_invalid_color"));
        }
    }

    protected void setColorComponent(int shift, int value) {
        int color = getEditorColor();
        color &= ~(0xFF << shift);
        color |= (class_3532.method_15340(value, 0, 255) << shift);
        setEditorColor(color);
        syncColorControlsFromStack();
    }

    protected void syncColorControlsFromStack() {
        int color = getEditorColor();
        this.colorHexValue = formatColorHex(color);
        this.syncingColorControls = true;
        if (this.colorHexBox != null) {
            this.colorHexBox.method_1852(this.colorHexValue);
        }
        if (this.redSlider != null) {
            this.redSlider.setIntValue(getRed(color));
        }
        if (this.greenSlider != null) {
            this.greenSlider.setIntValue(getGreen(color));
        }
        if (this.blueSlider != null) {
            this.blueSlider.setIntValue(getBlue(color));
        }
        this.syncingColorControls = false;
    }

    protected int getEditorColor() {
        if (isPotionItem(this.previewStack)) {
            return PotionCompat.getColor(this.previewStack) & 0xFFFFFF;
        }
        if (isMapItem(this.previewStack)) {
            class_2487 display = ItemStackNbt.getElement(this.previewStack, DISPLAY_TAG);
            return display == null ? 0 : display.method_68083(MAP_COLOR_TAG, 0) & 0xFFFFFF;
        }
        if (this.previewStack.method_31573(class_3489.field_48803)) {
            return class_9282.method_57470(this.previewStack, class_9282.field_49314) & 0xFFFFFF;
        }
        return 0;
    }

    protected void setEditorColor(int color) {
        color &= 0xFFFFFF;
        if (isPotionItem(this.previewStack)) {
            PotionCompat.setCustomColor(this.previewStack, color);
        } else if (isMapItem(this.previewStack)) {
            class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
            class_2487 display = tag.method_68568(DISPLAY_TAG);
            display.method_10569(MAP_COLOR_TAG, color);
            tag.method_10566(DISPLAY_TAG, display);
        } else if (this.previewStack.method_31573(class_3489.field_48803)) {
            this.previewStack.method_57379(class_9334.field_49644, new class_9282(color));
        }
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected void addDyeToColor(class_1767 dyeColor) {
        if (!this.previewStack.method_31573(class_3489.field_48803)) {
            return;
        }

        int[] totals = new int[3];
        int totalBrightness = 0;
        int colors = 0;
        if (this.previewStack.method_57826(class_9334.field_49644)) {
            int current = this.previewStack.method_58695(class_9334.field_49644, new class_9282(class_9282.field_49314)).comp_2384();
            int red = getRed(current);
            int green = getGreen(current);
            int blue = getBlue(current);
            totalBrightness += Math.max(red, Math.max(green, blue));
            totals[0] += red;
            totals[1] += green;
            totals[2] += blue;
            colors++;
        }

        int dyeRgb = dyeColor.method_7787();
        int red = getRed(dyeRgb);
        int green = getGreen(dyeRgb);
        int blue = getBlue(dyeRgb);
        totalBrightness += Math.max(red, Math.max(green, blue));
        totals[0] += red;
        totals[1] += green;
        totals[2] += blue;
        colors++;

        int mixedRed = totals[0] / colors;
        int mixedGreen = totals[1] / colors;
        int mixedBlue = totals[2] / colors;
        float averageBrightness = (float) totalBrightness / (float) colors;
        float maxMixed = Math.max(mixedRed, Math.max(mixedGreen, mixedBlue));
        if (maxMixed > 0.0F) {
            mixedRed = (int) (mixedRed * averageBrightness / maxMixed);
            mixedGreen = (int) (mixedGreen * averageBrightness / maxMixed);
            mixedBlue = (int) (mixedBlue * averageBrightness / maxMixed);
        }
        setEditorColor((mixedRed << 16) | (mixedGreen << 8) | mixedBlue);
    }

    protected void renderDyeGrid(class_332 guiGraphics) {
        if (!shouldShowDyeGrid() || this.blueSlider == null) {
            return;
        }

        int columns = dyeGridColumns();
        int cellSize = dyeGridCellSize();
        int gridWidth = columns * cellSize;
        int gridHeight = dyeGridRows(columns) * cellSize;
        int gridX = dyeGridX(columns, cellSize);
        int gridY = this.blueSlider.method_46427() + this.blueSlider.method_25364() + 10;
        if (isSidebarUi()) {
            ModernUi.fillPanel(guiGraphics, gridX - 5, gridY - 5, gridX + gridWidth + 5, gridY + gridHeight + 5, 7,
                    ModernUi.SURFACE, ModernUi.BORDER);
        }
        int index = 0;
        for (class_1767 dyeColor : class_1767.values()) {
            int x = gridX + cellSize * (index % columns);
            int y = gridY + cellSize * (index / columns);
            if (isSidebarUi()) {
                ModernUi.fillRounded(guiGraphics, x + 1, y + 1, x + cellSize - 1, y + cellSize - 1, 4, argb(210, dyeColor.method_16357()));
                guiGraphics.method_25294(x + 3, y + 2, x + cellSize - 3, y + 3, ModernUi.alpha(0xFFFFFF, 45));
            } else {
                guiGraphics.method_25294(x, y, x + cellSize, y + cellSize, argb(159, dyeColor.method_16357()));
            }
            class_1769 dyeItem = class_1769.method_7803(dyeColor);
            if (dyeItem != null) {
                guiGraphics.method_51427(new class_1799(dyeItem), x + (cellSize - ITEM_SIZE) / 2, y + (cellSize - ITEM_SIZE) / 2);
            }
            index++;
        }
    }

    protected int dyeGridColumns() {
        return isSidebarUi() && this.blueSlider != null && this.blueSlider.method_25368() < 160 ? 4 : 8;
    }

    protected int dyeGridCellSize() {
        return 20;
    }

    protected int dyeGridRows(int columns) {
        return (class_1767.values().length + columns - 1) / columns;
    }

    protected int dyeGridX(int columns, int cellSize) {
        if (this.blueSlider == null) {
            return 0;
        }

        int gridWidth = columns * cellSize;
        return this.blueSlider.method_46426() + (this.blueSlider.method_25368() - gridWidth) / 2;
    }

    protected boolean shouldShowDyeGrid() {
        return this.previewStack.method_31573(class_3489.field_48803);
    }

    protected void ensureLorePainterRows() {
        while (this.lorePainterRows.size() < this.lorePainterHeight) {
            List<LorePixel> row = new ArrayList<>();
            for (int i = 0; i < this.lorePainterWidth; i++) {
                row.add(this.currentLorePixel.copy());
            }
            this.lorePainterRows.add(row);
        }
        while (this.lorePainterRows.size() > this.lorePainterHeight) {
            this.lorePainterRows.remove(this.lorePainterRows.size() - 1);
        }
        for (List<LorePixel> row : this.lorePainterRows) {
            while (row.size() < this.lorePainterWidth) {
                row.add(this.currentLorePixel.copy());
            }
            while (row.size() > this.lorePainterWidth) {
                row.remove(row.size() - 1);
            }
        }
    }

    protected void addLorePainterRow() {
        List<LorePixel> row = new ArrayList<>();
        for (int i = 0; i < this.lorePainterWidth; i++) {
            row.add(this.currentLorePixel.copy());
        }
        this.lorePainterRows.add(row);
        this.lorePainterHeight++;
    }

    protected void removeLorePainterRow() {
        if (this.lorePainterHeight <= 1) {
            return;
        }
        this.lorePainterRows.remove(this.lorePainterRows.size() - 1);
        this.lorePainterHeight--;
    }

    protected void addLorePainterColumn() {
        for (List<LorePixel> row : this.lorePainterRows) {
            row.add(this.currentLorePixel.copy());
        }
        this.lorePainterWidth++;
    }

    protected void removeLorePainterColumn() {
        if (this.lorePainterWidth <= 1) {
            return;
        }
        for (List<LorePixel> row : this.lorePainterRows) {
            row.remove(row.size() - 1);
        }
        this.lorePainterWidth--;
    }

    protected void insertLorePainterRows() {
        ensureLorePainterRows();
        for (List<LorePixel> row : this.lorePainterRows) {
            this.loreValues.add(buildLorePainterRow(row));
        }
        applyLoreToStack();
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_lore_painted"));
    }

    protected void cycleGuiScale() {
        if (this.field_22787 == null) {
            return;
        }
        int current = this.field_22787.field_1690.method_42474().method_41753();
        int next = current >= 4 ? 0 : current + 1;
        this.field_22787.field_1690.method_42474().method_41748(next);
        this.field_22787.method_15993();
        method_41843();
    }

    protected void paintLorePainterAt(double mouseX, double mouseY) {
        ensureLorePainterRows();
        int gridX = getLorePainterGridX();
        int gridY = getLorePainterGridY();
        if (isMouseIn(mouseX, mouseY, gridX, gridY, getLorePainterSizeX(), getLorePainterSizeY())) {
            int x = class_3532.method_15340(((int) mouseX - gridX) / 9, 0, this.lorePainterWidth - 1);
            int y = class_3532.method_15340(((int) mouseY - gridY) / 9, 0, this.lorePainterHeight - 1);
            this.lorePainterRows.get(y).set(x, this.currentLorePixel.copy());
            return;
        }

        if (isMouseIn(mouseX, mouseY, 0, 0, LoreSymbol.values().length * 9, 9)) {
            int index = class_3532.method_15340((int) mouseX / 9, 0, LoreSymbol.values().length - 1);
            this.currentLorePixel.symbol = LoreSymbol.values()[index];
            return;
        }

        int colorX = getLorePainterColorX();
        if (isMouseIn(mouseX, mouseY, colorX, 0, class_1767.values().length * 9, 9)) {
            int index = class_3532.method_15340(((int) mouseX - colorX) / 9, 0, class_1767.values().length - 1);
            this.currentLorePixel.color = class_1767.values()[index];
        }
    }

    protected String buildLorePainterRow(List<LorePixel> row) {
        StringBuilder builder = new StringBuilder();
        for (LorePixel pixel : row) {
            builder.append(pixel);
        }
        return builder.toString();
    }

    protected String buildLorePainterSymbols() {
        StringBuilder builder = new StringBuilder();
        for (LoreSymbol symbol : LoreSymbol.values()) {
            if (symbol == LoreSymbol.FULL_SPACE) {
                builder.append(class_124.field_1056).append(class_124.field_1067).append("E");
            } else {
                builder.append(new LorePixel(this.currentLorePixel.color, symbol));
            }
        }
        return builder.toString();
    }

    protected String buildLorePainterColors() {
        StringBuilder builder = new StringBuilder();
        for (class_1767 color : class_1767.values()) {
            builder.append(new LorePixel(color, this.currentLorePixel.symbol));
        }
        return builder.toString();
    }

    protected int getLorePainterColorX() {
        return this.field_22789 - this.field_22793.method_1727(buildLorePainterColors());
    }

    protected int getLorePainterGridX() {
        return this.midX - getLorePainterSizeX() / 2;
    }

    protected int getLorePainterGridY() {
        return this.midY - getLorePainterSizeY() / 2;
    }

    protected int getLorePainterSizeX() {
        return 9 * this.lorePainterWidth;
    }

    protected int getLorePainterSizeY() {
        return 9 * this.lorePainterHeight;
    }
}
