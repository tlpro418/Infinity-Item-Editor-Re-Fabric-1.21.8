package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackCompat;

import io.github.seraphina.infinity_item_editor_re.util.ComponentCompat;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;
import io.github.seraphina.infinity_item_editor_re.util.LegacyText;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.Config;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.NbtCompat;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1746;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1809;
import net.minecraft.class_1822;
import net.minecraft.class_1826;
import net.minecraft.class_1887;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2480;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2522;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_342;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3708;
import net.minecraft.class_6880;
import net.minecraft.class_9283;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
abstract class ItemEditorScreenCommon extends ItemEditorScreenState {
    protected ItemEditorScreenCommon(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

protected void updateMouseDistance(int mouseX, int mouseY) {
        int distX = contentMidX() - mouseX;
        int distY = this.midY - mouseY;
        this.mouseDist = (int) Math.sqrt(distX * distX + distY * distY);
    }

    protected int getRingRadius() {
        int verticalRadius = this.field_22790 / 3;
        if (!isSidebarUi()) {
            return verticalRadius;
        }

        return Math.max(42, Math.min(verticalRadius, contentWidth() / 3));
    }

    protected boolean isMouseOverCenter(double mouseX, double mouseY) {
        int centerX = contentMidX();
        return mouseX > centerX - CENTER_HIT_RADIUS
                && mouseX < centerX + CENTER_HIT_RADIUS
                && mouseY > this.midY - CENTER_HIT_RADIUS
                && mouseY < this.midY + CENTER_HIT_RADIUS;
    }

    protected boolean isSidebarUi() {
        return Config.getItemGuiMode() == Config.ItemEditorUiMode.SIDEBAR;
    }

    protected int sidebarWidth() {
        return class_3532.method_15340(this.field_22789 / 5, SIDEBAR_WIDTH_MIN, SIDEBAR_WIDTH_MAX);
    }

    protected int contentLeft() {
        return isSidebarUi() ? sidebarWidth() + SIDEBAR_CONTENT_GAP : 0;
    }

    protected int safeLeft() {
        return isSidebarUi() ? contentLeft() + SIDEBAR_SAFE_MARGIN : SIDEBAR_SAFE_MARGIN;
    }

    protected int safeRight() {
        return this.field_22789 - SIDEBAR_SAFE_MARGIN;
    }

    protected int safeTop() {
        return SIDEBAR_SAFE_MARGIN;
    }

    protected int safeBottom() {
        return this.field_22790 - SIDEBAR_SAFE_MARGIN;
    }

    protected int contentWidth() {
        return Math.max(1, safeRight() - safeLeft());
    }

    protected int contentMidX() {
        if (!isSidebarUi()) {
            return this.midX;
        }

        return safeLeft() + contentWidth() / 2;
    }

    protected int centeredContentX(int width) {
        int x = contentMidX() - width / 2;
        if (!isSidebarUi()) {
            return x;
        }

        return class_3532.method_15340(x, safeLeft(), Math.max(safeLeft(), safeRight() - width));
    }

    protected int contentLimitedWidth(int preferred, int minWidth, int margin) {
        int available = isSidebarUi() ? contentWidth() - margin * 2 : this.field_22789 - margin * 2;
        return class_3532.method_15340(preferred, Math.min(minWidth, Math.max(1, available)), Math.max(1, available));
    }

    protected int editorControlLeft() {
        return isSidebarUi() ? safeLeft() + 8 : 15;
    }

    protected int editorListTextLeft() {
        return isSidebarUi() ? safeLeft() + 10 : 5;
    }

    protected int itemPreviewCenterX() {
        return isSidebarUi() ? sidebarWidth() / 2 : this.midX;
    }

    protected int itemPreviewCenterY() {
        return isSidebarUi() ? 45 : 40;
    }

    protected boolean isCompactSidebarItemPanel() {
        return isSidebarUi() && this.activePanel == Panel.ITEM && contentWidth() < 420;
    }

    protected boolean isNarrowSidebarItemPanel() {
        return isSidebarUi() && this.activePanel == Panel.ITEM && contentWidth() < 260;
    }

    protected boolean isShortSidebarItemPanel() {
        return isCompactSidebarItemPanel() && this.field_22790 < 300;
    }

    protected int sidebarItemLabelRightX() {
        if (isNarrowSidebarItemPanel()) {
            return safeLeft() + 8;
        }

        return safeLeft() + (isCompactSidebarItemPanel() ? 74 : 88);
    }

    protected int sidebarItemFieldX() {
        if (isNarrowSidebarItemPanel()) {
            return safeLeft() + 8;
        }

        return sidebarItemLabelRightX() + 10;
    }

    protected int sidebarItemDetailsY() {
        return isCompactSidebarItemPanel() ? 204 : 76;
    }

    protected int sidebarItemDetailsX(int detailsWidth) {
        if (isCompactSidebarItemPanel()) {
            return safeLeft();
        }

        return sidebarDetailsX(detailsWidth);
    }

    protected int sidebarDetailsX(int detailsWidth) {
        int x = safeRight() - detailsWidth;
        if (x < safeLeft() + 268) {
            return safeLeft();
        }

        return x;
    }

    protected int sidebarItemFieldWidth(int detailsX) {
        int maxRight = isCompactSidebarItemPanel() ? safeRight() : detailsX - SIDEBAR_CONTENT_GAP;
        if (isNarrowSidebarItemPanel()) {
            return Math.max(48, maxRight - sidebarItemFieldX());
        }

        return class_3532.method_15340(maxRight - sidebarItemFieldX(), 96, 240);
    }

    protected int sidebarItemCoreHeight() {
        return isNarrowSidebarItemPanel() ? 128 : 124;
    }

    protected int sidebarItemNameY() {
        if (isNarrowSidebarItemPanel() || isShortSidebarItemPanel()) {
            return 184;
        }

        return sidebarItemDetailsY();
    }

    protected int sidebarItemIdY() {
        return isNarrowSidebarItemPanel() ? 76 : 78;
    }

    protected int sidebarItemCountY() {
        return isNarrowSidebarItemPanel() ? 112 : 108;
    }

    protected int sidebarItemDamageY() {
        return isNarrowSidebarItemPanel() ? 148 : 138;
    }

    protected int sidebarVisibleLoreLines() {
        if (isCompactSidebarItemPanel()) {
            return 0;
        }

        int maxBottom = sidebarBottomButtonY() - 8;
        int maxLines = (maxBottom - sidebarItemNameY() - 76) / 26;
        return class_3532.method_15340(Math.min(this.loreValues.size() + 1, maxLines), 0, 6);
    }

    protected boolean canShowSidebarLoreButton() {
        return sidebarNameCardBottom() <= sidebarBottomButtonY() - 8;
    }

    protected int sidebarNameCardBottom() {
        int visibleLoreLines = sidebarVisibleLoreLines();
        if (visibleLoreLines == 0) {
            return sidebarItemNameY() + 48;
        }

        return sidebarItemNameY() + 50 + 26 * visibleLoreLines + 26;
    }

    protected boolean canShowSidebarActionGrid() {
        int actionY = getActionGridY();
        if (!isCompactSidebarItemPanel()) {
            return actionY + SIDEBAR_BUTTON_HEIGHT <= sidebarBottomButtonY() - 8;
        }

        return actionY >= sidebarNameCardBottom() + SIDEBAR_CONTENT_GAP
                && actionY + SIDEBAR_BUTTON_HEIGHT <= sidebarBottomButtonY() - 8;
    }

    protected int getActionGridY() {
        if (isCompactSidebarItemPanel()) {
            return Math.max(sidebarNameCardBottom() + SIDEBAR_CONTENT_GAP, safeBottom() - 78);
        }

        return 184;
    }

    protected int sidebarBottomButtonY() {
        return this.field_22790 - 34;
    }

    protected int sidebarBottomButtonHeight() {
        return 22;
    }

    protected int sidebarBottomButtonWidth(int count, int gap) {
        int availableWidth = Math.max(24, this.field_22789 - contentLeft() - 32);
        int fittedWidth = (availableWidth - (count - 1) * gap) / count;
        return class_3532.method_15340(fittedWidth, 24, 66);
    }

    protected int sidebarBottomStartX(int count, int buttonWidth, int gap) {
        int totalWidth = count * buttonWidth + (count - 1) * gap;
        return class_3532.method_15340(contentMidX() - totalWidth / 2, contentLeft() + 16, this.field_22789 - 16 - totalWidth);
    }

    protected int sidebarItemDropButtonX() {
        int gap = 6;
        int buttonWidth = sidebarBottomButtonWidth(4, gap);
        return sidebarBottomStartX(4, buttonWidth, gap) + 3 * (buttonWidth + gap);
    }

    protected int sidebarItemDropButtonWidth() {
        return sidebarBottomButtonWidth(4, 6);
    }

    protected int sidebarUiModeButtonY() {
        int formatRows = (2 + class_124.values().length + 7) / 8;
        int formatTop = Math.max(82, this.field_22790 - 38 - formatRows * 15);
        return Math.max(54, formatTop - 28);
    }

    protected int legacyUiModeButtonY() {
        return this.midX - 90 <= 90 ? 5 : this.field_22790 - 25;
    }

    protected int searchFilterWidth() {
        return isSidebarUi() ? Math.min(140, Math.max(92, contentWidth() / 4)) : 100;
    }

    protected int searchFilterX() {
        return isSidebarUi() ? contentMidX() - searchFilterWidth() / 2 : this.field_22789 - 115;
    }

    protected int searchFilterY() {
        return isSidebarUi() ? 58 : this.field_22790 - 33;
    }

    protected int sideListSearchY() {
        return isSidebarUi() ? 48 : 28;
    }

    protected int sideListStartY() {
        return isSidebarUi() ? 80 : 58;
    }

    protected int bannerPatternListX() {
        return isSidebarUi() ? safeLeft() + 10 : 10;
    }

    protected int bannerPatternListWidth() {
        if (!isSidebarUi()) {
            return 150;
        }

        int maxWidth = Math.max(1, Math.min(176, contentWidth() - 20));
        return class_3532.method_15340(contentWidth() / 4, Math.min(132, maxWidth), maxWidth);
    }

    protected int potterySherdListX() {
        return isSidebarUi() ? safeLeft() + 10 : 10;
    }

    protected int potterySherdListWidth() {
        if (!isSidebarUi()) {
            return 170;
        }

        int maxWidth = Math.max(1, Math.min(210, contentWidth() - 20));
        return class_3532.method_15340(contentWidth() / 4, Math.min(150, maxWidth), maxWidth);
    }

    protected int spawnEggEntityListX() {
        return isSidebarUi() ? safeLeft() + 10 : 10;
    }

    protected int spawnEggEntityListWidth() {
        if (!isSidebarUi()) {
            return 170;
        }

        int maxWidth = Math.max(1, Math.min(210, contentWidth() - 20));
        return class_3532.method_15340(contentWidth() / 4, Math.min(150, maxWidth), maxWidth);
    }

    protected int rightControlsX(int width, int listX, int listWidth) {
        if (!isSidebarUi()) {
            return Math.max(this.midX + 76, this.field_22789 - width - 10);
        }

        int rightAligned = safeRight() - width;
        int afterList = listX + listWidth + SIDEBAR_CONTENT_GAP;
        int x = afterList <= rightAligned ? rightAligned : Math.max(safeLeft(), rightAligned);
        return class_3532.method_15340(x, safeLeft(), Math.max(safeLeft(), safeRight() - width));
    }

    protected int nbtEditorWidth() {
        if (isSidebarUi()) {
            return Math.max(120, contentWidth() - 48);
        }

        return contentLimitedWidth(this.field_22789 / 2, 120, 32);
    }

    protected int nbtEditorX() {
        if (isSidebarUi()) {
            return safeLeft() + 24;
        }

        return centeredContentX(nbtEditorWidth());
    }

    protected int nbtEditorBoxY() {
        return isSidebarUi() ? 96 : 80;
    }

    protected int nbtEditorButtonWidth() {
        if (isSidebarUi()) {
            return Math.min(96, nbtEditorWidth());
        }

        return contentLimitedWidth(this.field_22789 / 7, 70, 32);
    }

    protected int nbtEditorButtonX(int buttonWidth) {
        if (isSidebarUi()) {
            return nbtEditorX() + nbtEditorWidth() - buttonWidth;
        }

        return centeredContentX(buttonWidth);
    }

    protected int nbtEditorButtonY() {
        return isSidebarUi() ? 128 : 100;
    }

    protected int lorePanelLeft() {
        return isSidebarUi() ? safeLeft() + 18 : 100;
    }

    protected int lorePanelRight() {
        return isSidebarUi() ? safeRight() - 18 : this.field_22789 - 100;
    }

    protected int lorePanelWidth() {
        return Math.max(80, lorePanelRight() - lorePanelLeft());
    }

    protected int loreLineLabelRightX() {
        return isSidebarUi() ? lorePanelLeft() - 10 : 90;
    }

    protected int loreFieldWidth() {
        int actionButtonWidth = 66;
        return Math.max(80, lorePanelWidth() - actionButtonWidth);
    }

    protected int loreScrollBarX() {
        return isSidebarUi() ? safeRight() - 10 : this.field_22789 - 15;
    }

    protected int loreScrollTop() {
        return 50;
    }

    protected int loreScrollBottom() {
        return isSidebarUi() ? sidebarBottomButtonY() - 10 : this.field_22790 - 50;
    }

    protected int loreScrollHeight() {
        return Math.max(1, loreScrollBottom() - loreScrollTop() + 1);
    }

    protected int lorePreviewCenterX() {
        return contentMidX();
    }

    protected class_2561 getUiModeButtonText() {
        return class_2561.method_43469(key("ui.mode"), getUiModeDisplayName(Config.getItemGuiMode()));
    }

    protected class_2561 getUiModeDisplayName(Config.ItemEditorUiMode mode) {
        return class_2561.method_43471(key("ui.mode." + mode.name().toLowerCase(Locale.ROOT)));
    }

    protected void toggleUiMode() {
        captureFieldValues();
        Config.ItemEditorUiMode mode = Config.toggleItemGuiMode();
        this.status = class_2561.method_43469(messageKey("editor_ui_mode_updated"), getUiModeDisplayName(mode));
        method_41843();
    }

    protected void insertFormattingPrefix() {
        insertFocusedText(String.valueOf(class_124.field_33292));
    }

    protected void stripFocusedFormatting() {
        class_342 focused = getFocusedTextBox();
        if (focused == null) {
            return;
        }
        focused.method_1852(Objects.requireNonNullElse(class_124.method_539(focused.method_1882()), ""));
    }

    protected void insertFocusedText(String text) {
        class_342 focused = getFocusedTextBox();
        if (focused != null) {
            focused.method_1867(text);
        }
    }

    protected class_342 getFocusedTextBox() {
        for (class_342 box : this.mainTextBoxes) {
            if (box.method_25370()) {
                return box;
            }
        }
        for (class_342 box : this.loreBoxes) {
            if (box.method_25370()) {
                return box;
            }
        }
        for (class_342 box : this.signBoxes) {
            if (box.method_25370()) {
                return box;
            }
        }
        if (this.rawNbtBox != null && this.rawNbtBox.method_25370()) {
            return this.rawNbtBox;
        }
        if (this.componentFilterBox != null && this.componentFilterBox.method_25370()) {
            return this.componentFilterBox;
        }
        if (this.componentNbtBox != null && this.componentNbtBox.method_25370()) {
            return this.componentNbtBox;
        }
        return null;
    }

    protected List<class_2561> getPrettyNbtLines() {
        return NbtFormatter.prettyLines(ItemStackNbt.get(this.previewStack));
    }

    protected List<NbtRow> buildNbtRows() {
        return NbtFormatter.rows(ItemStackNbt.get(this.previewStack), this.expandedNbtPaths);
    }

    protected int getNbtAdvancedVisibleRows() {
        int bottom = isSidebarUi() ? sidebarBottomButtonY() - 10 : this.field_22790 - 20;
        return Math.max(1, (bottom - 48) / 12);
    }

    protected void readMainFieldsFromStack(class_1799 stack) {
        class_2960 id = CompatRegistries.ITEMS.getKey(stack.method_7909());
        this.itemIdValue = id == null ? "air" : stripMinecraftNamespace(id);
        this.countValue = Integer.toString(Math.max(1, stack.method_7947()));
        this.damageValue = Integer.toString(Math.max(0, Math.min(getDamageMaxForField(stack), stack.method_7919())));
        this.nameValue = ItemStackCompat.hasCustomHoverName(stack)
                ? LegacyText.toLegacyOrPlain(stack.method_7964())
                : stack.method_7964().getString();
        this.loreValues.clear();

        if (stack.method_57826(class_9334.field_49632)) {
            class_9290 lore = stack.method_58694(class_9334.field_49632);
            if (lore != null) {
                for (class_2561 line : lore.comp_2400()) {
                    this.loreValues.add(LegacyText.toLegacyOrPlain(line));
                }
            }
        } else {
            class_2487 display = ItemStackNbt.getElement(stack, DISPLAY_TAG);
            if (display != null && display.method_10545(LORE_TAG)) {
                class_2499 lore = display.method_68569(LORE_TAG);
                for (int i = 0; i < lore.size(); i++) {
                    this.loreValues.add(readLoreLine(lore.method_68577(i, "")));
                }
            }
        }

        readSignFieldsFromStack(stack);
        readBookFieldsFromStack(stack);
        readHeadFieldsFromStack(stack);
        readBannerFieldsFromStack(stack);
        readFireworkFieldsFromStack(stack);
        readContainerFieldsFromStack(stack);
        readDecoratedPotFieldsFromStack(stack);
        readSpawnEggFieldsFromStack(stack);
        readTradeFieldsFromStack(stack);
    }

    protected String readLoreLine(String raw) {
        if (raw == null) {
            return "";
        }
        raw = LegacyText.unwrapJsonString(raw);
        if (raw.startsWith("{") || raw.startsWith("[")) {
            try {
                class_2561 component = ComponentCompat.fromJson(raw);
                if (component != null) {
                    return LegacyText.toLegacyOrPlain(component);
                }
            } catch (RuntimeException ignored) {
            }
        }
        return raw;
    }

    protected void readSignFieldsFromStack(class_1799 stack) {
        Arrays.fill(this.signLineValues, "");
        this.signCommandValue = "";
        if (!isSignItem(stack)) {
            return;
        }

        class_2487 blockEntity = ItemStackNbt.getElement(stack, BLOCK_ENTITY_TAG);
        if (blockEntity == null) {
            return;
        }

        boolean readModernMessages = false;
        if (blockEntity.method_10545(SIGN_FRONT_TEXT_TAG)) {
            class_2487 frontText = blockEntity.method_68568(SIGN_FRONT_TEXT_TAG);
            if (frontText.method_10545(SIGN_MESSAGES_TAG)) {
                class_2499 messages = frontText.method_68569(SIGN_MESSAGES_TAG);
                for (int i = 0; i < SIGN_LINES && i < messages.size(); i++) {
                    readSignLine(i, messages.method_68577(i, ""));
                }
                readModernMessages = !messages.isEmpty();
            }
        }

        if (!readModernMessages) {
            for (int i = 0; i < SIGN_LINES; i++) {
                String key = LEGACY_SIGN_TEXT_TAG_PREFIX + (i + 1);
                if (blockEntity.method_10545(key)) {
                    readSignLine(i, blockEntity.method_68564(key, ""));
                }
            }
        }
    }

    protected void readSignLine(int line, String raw) {
        class_2561 component = readSerializedComponent(raw);
        this.signLineValues[line] = component.getString();
        if (line == 0) {
            class_2558 clickEvent = component.method_10866().method_10970();
            if (clickEvent instanceof class_2558.class_10609 runCommand) {
                this.signCommandValue = runCommand.comp_3506();
            }
        }
    }

    protected void readBookFieldsFromStack(class_1799 stack) {
        this.bookTitleValue = "";
        this.bookAuthorValue = "";
        if (!isBookEditableItem(stack)) {
            this.rememberedSignedBookData = null;
            return;
        }

        class_2487 tag = ItemStackNbt.get(stack);
        if (tag == null) {
            return;
        }

        this.bookTitleValue = tag.method_68564(BOOK_TITLE_TAG, "");
        this.bookAuthorValue = tag.method_68564(BOOK_AUTHOR_TAG, "");
    }

    protected void readHeadFieldsFromStack(class_1799 stack) {
        this.headOwnerValue = "";
        this.headUuidValue = "";
        this.headTextureValue = "";
        this.headTextureSignatureValue = "";
        if (!isPlayerHeadItem(stack)) {
            return;
        }

        class_2487 tag = ItemStackNbt.get(stack);
        if (tag == null) {
            return;
        }

        if (tag.method_10545(SKULL_OWNER_TAG)) {
            this.headOwnerValue = tag.method_68564(SKULL_OWNER_TAG, "");
            return;
        }

        if (!tag.method_10545(SKULL_OWNER_TAG)) {
            return;
        }

        class_2487 skullOwner = tag.method_68568(SKULL_OWNER_TAG);
        if (skullOwner.method_10545(SKULL_OWNER_NAME_TAG)) {
            this.headOwnerValue = skullOwner.method_68564(SKULL_OWNER_NAME_TAG, "");
        }
        if (NbtCompat.hasUUID(skullOwner, SKULL_OWNER_ID_TAG)) {
            this.headUuidValue = NbtCompat.getUUID(skullOwner, SKULL_OWNER_ID_TAG).toString();
        }
        class_2487 properties = skullOwner.method_68568(SKULL_PROPERTIES_TAG);
        if (properties.method_10545(SKULL_TEXTURES_TAG)) {
            class_2499 textures = properties.method_68569(SKULL_TEXTURES_TAG);
            if (!textures.isEmpty()) {
                class_2487 texture = textures.method_68582(0);
                this.headTextureValue = texture.method_68564(SKULL_TEXTURE_VALUE_TAG, "");
                this.headTextureSignatureValue = texture.method_68564(SKULL_TEXTURE_SIGNATURE_TAG, "");
            }
        }
    }

    protected void readFireworkFieldsFromStack(class_1799 stack) {
        this.fireworkExplosionType = 0;
        this.fireworkColor = class_1767.field_7964.method_7789();
        this.fireworkFadeColor = -1;
        this.fireworkFlicker = false;
        this.fireworkTrail = false;
        if (!isFireworkEditableItem(stack)) {
            return;
        }

        class_2487 explosion = getFireworkExplosionForFields(stack);
        if (explosion == null) {
            return;
        }

        this.fireworkExplosionType = class_3532.method_15340(class_9283.class_1782.method_7813(explosion.method_68562(FIREWORK_TYPE_TAG, (byte) 0)).method_7816(), 0, FIREWORK_EXPLOSION_TYPES - 1);
        this.fireworkFlicker = explosion.method_68566(FIREWORK_FLICKER_TAG, false);
        this.fireworkTrail = explosion.method_68566(FIREWORK_TRAIL_TAG, false);

        int[] colors = NbtCompat.getIntArray(explosion, FIREWORK_COLORS_TAG);
        if (colors.length > 0) {
            this.fireworkColor = getNearestFireworkDyeColorId(colors[0]);
        }
        int[] fadeColors = NbtCompat.getIntArray(explosion, FIREWORK_FADE_COLORS_TAG);
        if (fadeColors.length > 0) {
            this.fireworkFadeColor = getNearestFireworkDyeColorId(fadeColors[0]);
        }
    }

    protected void readContainerFieldsFromStack(class_1799 stack) {
        this.selectedContainerSlot = class_3532.method_15340(this.selectedContainerSlot, 0, CONTAINER_SIZE - 1);
        if (!isContainerEditableItem(stack)) {
            this.containerSlotNbtValue = "{}";
            return;
        }
        this.containerSlotNbtValue = getContainerSlotNbt(getContainerSlotItem(this.selectedContainerSlot));
    }

    protected class_2487 getFireworkExplosionForFields(class_1799 stack) {
        if (stack.method_31574(class_1802.field_8450)) {
            class_2487 tag = ItemStackNbt.get(stack);
            if (tag != null && tag.method_10545(FIREWORK_EXPLOSION_TAG)) {
                return tag.method_68568(FIREWORK_EXPLOSION_TAG);
            }
            return null;
        }

        class_2487 fireworks = ItemStackNbt.getElement(stack, FIREWORKS_TAG);
        if (fireworks == null || !fireworks.method_10545(FIREWORK_EXPLOSIONS_TAG)) {
            return null;
        }
        class_2499 explosions = fireworks.method_68569(FIREWORK_EXPLOSIONS_TAG);
        return explosions.isEmpty() ? null : explosions.method_68582(explosions.size() - 1);
    }

    protected void readBannerFieldsFromStack(class_1799 stack) {
        this.bannerBaseColor = class_1767.field_7952.method_7789();
        if (isBannerEditableItem(stack)) {
            this.bannerBaseColor = getBannerBaseColor().method_7789();
            class_2499 patterns = getBannerPatterns();
            if (!patterns.isEmpty()) {
                this.bannerPatternColor = class_1767.method_7791(patterns.method_68582(patterns.size() - 1).method_68083(BANNER_COLOR_TAG, 0)).method_7789();
            }
        }
        this.bannerPatternColor = class_3532.method_15387(this.bannerPatternColor, class_1767.values().length);
        clampBannerPatternSelection(getFilteredBannerPatterns());
    }

    protected void readSpawnEggFieldsFromStack(class_1799 stack) {
        this.spawnEggCustomNameValue = "";
        this.spawnEggOwnerValue = "";
        this.spawnEggNumberValueOverrides.clear();
        this.spawnEggTagScroll = 0;
        if (!isSpawnEditorItem(stack)) {
            return;
        }

        class_2487 entityTag = getSpawnEditorEntityTag(stack);
        if (entityTag != null) {
            if (entityTag.method_10545(ENTITY_CUSTOM_NAME_TAG)) {
                this.spawnEggCustomNameValue = readSerializedComponent(entityTag.method_68564(ENTITY_CUSTOM_NAME_TAG, "")).getString();
            }
            if (NbtCompat.hasUUID(entityTag, ENTITY_OWNER_TAG)) {
                this.spawnEggOwnerValue = NbtCompat.getUUID(entityTag, ENTITY_OWNER_TAG).toString();
            } else if (entityTag.method_10545(ENTITY_OWNER_TAG)) {
                this.spawnEggOwnerValue = entityTag.method_68564(ENTITY_OWNER_TAG, "");
            }
        }

        class_1299<?> type = getCurrentSpawnEggEntityType(stack);
        class_2960 id = type == null ? null : CompatRegistries.ENTITY_TYPES.getKey(type);
        if (id == null) {
            clampSpawnEggEntitySelection(getFilteredSpawnEggEntities());
            return;
        }

        List<SpawnEggEntityEntry> filtered = getFilteredSpawnEggEntities();
        for (int i = 0; i < filtered.size(); i++) {
            if (id.equals(filtered.get(i).id())) {
                this.selectedSpawnEggEntityIndex = i;
                scrollSpawnEggSelectionIntoView(filtered);
                return;
            }
        }
        clampSpawnEggEntitySelection(filtered);
    }

    protected class_2561 readSerializedComponent(String raw) {
        if (raw == null || raw.isBlank()) {
            return class_2561.method_43473();
        }
        try {
            class_2561 component = ComponentCompat.fromJson(raw);
            return component == null ? class_2561.method_43470(raw) : component;
        } catch (RuntimeException exception) {
            try {
                class_2561 component = ComponentCompat.fromJsonLenient(raw);
                return component == null ? class_2561.method_43470(raw) : component;
            } catch (RuntimeException ignored) {
                return class_2561.method_43470(raw);
            }
        }
    }

    protected void updateLoreScrollFromMouse(double mouseY) {
        int spaces = loreLineSpaces();
        int max = Math.max(0, this.loreValues.size() - spaces);
        if (max == 0) {
            setLoreScroll(0);
            return;
        }
        float perc = (float) ((mouseY - loreScrollTop()) / (double) loreScrollHeight());
        setLoreScroll(class_3532.method_15340(Math.round(max * perc), 0, max));
    }

    protected void setLoreScroll(int value) {
        int clamped = class_3532.method_15340(value, 0, Math.max(0, this.loreValues.size() - loreLineSpaces()));
        if (this.loreScroll != clamped) {
            this.loreScroll = clamped;
            method_41843();
        }
    }

    protected void captureFieldValues() {
        if (this.itemIdBox != null) {
            this.itemIdValue = this.itemIdBox.method_1882();
        }
        if (this.countBox != null) {
            this.countValue = this.countBox.method_1882();
        }
        if (this.damageBox != null) {
            this.damageValue = this.damageBox.method_1882();
        }
        if (this.nameBox != null) {
            this.nameValue = this.nameBox.method_1882();
        }
        if (this.rawNbtBox != null) {
            this.rawNbtValue = this.rawNbtBox.method_1882();
        }
        if (this.componentFilterBox != null) {
            this.componentFilterValue = this.componentFilterBox.method_1882();
        }
        if (this.componentValueSearchBox != null) {
            this.componentValueFilterValue = this.componentValueSearchBox.method_1882();
        }
        if (this.componentNbtBox != null) {
            this.componentNbtValue = this.componentNbtBox.method_1882();
        }
        if (this.enchantFilterBox != null) {
            this.enchantFilterValue = this.enchantFilterBox.method_1882();
        }
        if (this.enchantLevelBox != null) {
            this.enchantLevelValue = this.enchantLevelBox.method_1882();
        }
        if (this.potionFilterBox != null) {
            this.potionFilterValue = this.potionFilterBox.method_1882();
        }
        if (this.potionLevelBox != null) {
            this.potionLevelValue = this.potionLevelBox.method_1882();
        }
        if (this.potionTimeBox != null) {
            this.potionTimeValue = this.potionTimeBox.method_1882();
        }
        if (this.attributeFilterBox != null) {
            this.attributeFilterValue = this.attributeFilterBox.method_1882();
        }
        if (this.attributeAmountBox != null) {
            this.attributeAmountValue = this.attributeAmountBox.method_1882();
        }
        if (this.attributeDecimalBox != null) {
            this.attributeDecimalValue = this.attributeDecimalBox.method_1882();
        }
        if (this.colorHexBox != null) {
            this.colorHexValue = this.colorHexBox.method_1882();
        }
        for (int i = 0; i < SIGN_LINES && i < this.signBoxes.size(); i++) {
            this.signLineValues[i] = this.signBoxes.get(i).method_1882();
        }
        if (this.signCommandBox != null) {
            this.signCommandValue = this.signCommandBox.method_1882();
        }
        if (this.bookTitleBox != null) {
            this.bookTitleValue = this.bookTitleBox.method_1882();
        }
        if (this.bookAuthorBox != null) {
            this.bookAuthorValue = this.bookAuthorBox.method_1882();
        }
        if (this.headOwnerBox != null) {
            this.headOwnerValue = this.headOwnerBox.method_1882();
        }
        if (this.headUuidBox != null) {
            this.headUuidValue = this.headUuidBox.method_1882();
        }
        if (this.headTextureBox != null) {
            this.headTextureValue = this.headTextureBox.method_1882();
        }
        if (this.headTextureSignatureBox != null) {
            this.headTextureSignatureValue = this.headTextureSignatureBox.method_1882();
        }
        if (this.containerSlotNbtBox != null) {
            this.containerSlotNbtValue = this.containerSlotNbtBox.method_1882();
        }
        if (this.bannerPatternFilterBox != null) {
            this.bannerPatternFilterValue = this.bannerPatternFilterBox.method_1882();
        }
        if (this.potterySherdFilterBox != null) {
            this.potterySherdFilterValue = this.potterySherdFilterBox.method_1882();
        }
        if (this.spawnEggEntityFilterBox != null) {
            this.spawnEggEntityFilterValue = this.spawnEggEntityFilterBox.method_1882();
        }
        if (this.spawnEggCustomNameBox != null) {
            this.spawnEggCustomNameValue = this.spawnEggCustomNameBox.method_1882();
        }
        if (this.spawnEggOwnerBox != null) {
            this.spawnEggOwnerValue = this.spawnEggOwnerBox.method_1882();
        }
        if (this.tradeItemNbtBox != null) {
            this.tradeItemNbtValue = this.tradeItemNbtBox.method_1882();
        }
        if (this.tradeUsesBox != null) {
            this.tradeUsesValue = this.tradeUsesBox.method_1882();
        }
        if (this.tradeMaxUsesBox != null) {
            this.tradeMaxUsesValue = this.tradeMaxUsesBox.method_1882();
        }
        if (this.tradeXpBox != null) {
            this.tradeXpValue = this.tradeXpBox.method_1882();
        }
        if (this.tradePriceMultiplierBox != null) {
            this.tradePriceMultiplierValue = this.tradePriceMultiplierBox.method_1882();
        }
        if (this.tradeSpecialPriceBox != null) {
            this.tradeSpecialPriceValue = this.tradeSpecialPriceBox.method_1882();
        }
        if (this.tradeDemandBox != null) {
            this.tradeDemandValue = this.tradeDemandBox.method_1882();
        }
    }

    protected class_2487 parseNbt(String nbt) throws CommandSyntaxException {
        String value = nbt == null ? "" : nbt.trim();
        if (value.isEmpty() || "{}".equals(value)) {
            return null;
        }
        return class_2522.method_67315(value);
    }

    protected void cleanupEmptyDisplayTag() {
        // Intentionally empty: the old implementation rewrote every mapped component from the
        // legacy NBT view when the view looked empty, which could erase name, lore and enchantments.
    }

    protected void cleanupEmptyTag() {
        // Intentionally empty, see cleanupEmptyDisplayTag().
    }

    protected int loreLineSpaces() {
        int bottom = isSidebarUi() ? sidebarBottomButtonY() - 36 : this.field_22790 - 70;
        return Math.max(1, (bottom / 30) - 1);
    }

    protected boolean isMouseIn(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    protected boolean isTradeSlotEditor() {
        return this.parentTradeScreen != null && this.parentTradeIndex >= 0 && this.parentTradeSlot >= 0;
    }

    protected boolean isNameFollowingDefault(class_1799 stack) {
        String currentName = this.nameBox == null ? this.nameValue : this.nameBox.method_1882();
        return !ItemStackCompat.hasCustomHoverName(stack) && Objects.equals(currentName, getDefaultHoverName(stack));
    }

    protected String getDefaultHoverName(class_1799 stack) {
        class_1799 withoutName = stack.method_7972();
        ItemStackCompat.resetHoverName(withoutName);
        return withoutName.method_7964().getString();
    }

    protected static int getDamageMaxForField(class_1799 stack) {
        return stack.method_7963() ? Math.max(0, stack.method_7936()) : 99999;
    }

    protected static int parsePositiveOrZero(String value) {
        try {
            return Math.max(0, Integer.parseInt(value));
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    protected static String normalizeItemId(String id) {
        String value = id == null ? "" : id.trim().toLowerCase(Locale.ROOT);
        return value.contains(":") ? value : "minecraft:" + value;
    }

    protected static String stripMinecraftNamespace(class_2960 id) {
        return "minecraft".equals(id.method_12836()) ? id.method_12832() : id.toString();
    }

    protected static String getInitialNbt(class_1799 stack) {
        class_2487 tag = ItemStackNbt.get(stack);
        return tag == null || tag.method_33133() ? "{}" : tag.toString();
    }

    protected static String getInitialComponentsNbt(class_1799 stack) {
        class_2487 components = ItemStackNbt.save(stack).method_68568("components");
        return components.method_33133() ? "{}" : components.toString();
    }

    protected void syncNbtEditorValuesFromStack() {
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.componentNbtValue = getInitialComponentsNbt(this.previewStack);
    }

    protected static boolean isColorApplicable(class_1799 stack) {
        return stack.method_31573(class_3489.field_48803) || isPotionItem(stack) || isMapItem(stack);
    }

    protected static boolean canShowEnchantingButton(class_1799 stack) {
        return !stack.method_7960();
    }

    protected static boolean isPotionItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_8574) || stack.method_31574(class_1802.field_8436) || stack.method_31574(class_1802.field_8150) || stack.method_31574(class_1802.field_8087);
    }

    protected static boolean isMapItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_8895) || stack.method_31574(class_1802.field_8204);
    }

    protected static boolean isSignItem(class_1799 stack) {
        return stack.method_7909() instanceof class_1822;
    }

    protected static boolean isBannerEditableItem(class_1799 stack) {
        return stack.method_7909() instanceof class_1746 || stack.method_31574(class_1802.field_8255);
    }

    protected static boolean isArmorTrimApplicable(class_1799 stack) {
        return getArmorTrimEquipmentSlot(stack) != null;
    }

    protected static class_1304 getArmorTrimEquipmentSlot(class_1799 stack) {
        var equippable = stack.method_58694(class_9334.field_54196);
        if (equippable == null || !isArmorTrimSlot(equippable.comp_3174())) {
            return null;
        }
        return equippable.comp_3174();
    }

    protected static boolean isArmorTrimSlot(class_1304 slot) {
        return slot == class_1304.field_6169
                || slot == class_1304.field_6174
                || slot == class_1304.field_6172
                || slot == class_1304.field_6166;
    }

    protected static boolean isDecoratedPotItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_42699);
    }

    protected static boolean isSpawnEggItem(class_1799 stack) {
        return stack.method_7909() instanceof class_1826;
    }

    protected static boolean isTrialSpawnerItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_47314);
    }

    protected static boolean isSpawnerItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_8849) || isTrialSpawnerItem(stack);
    }

    protected static boolean isSpawnEditorItem(class_1799 stack) {
        return isSpawnEggItem(stack) || isSpawnerItem(stack);
    }

    protected static boolean isCommandBlockEditableItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_8866)
                || stack.method_31574(class_1802.field_8799)
                || stack.method_31574(class_1802.field_8468)
                || stack.method_31574(class_1802.field_8220);
    }

    protected boolean isVillagerTradeEditableItem(class_1799 stack) {
        return isSpawnEggItem(stack) && class_1299.field_6077.equals(getCurrentSpawnEggEntityType(stack));
    }

    protected static boolean isPlayerHeadItem(class_1799 stack) {
        return stack.method_7909() instanceof class_1809;
    }

    protected static boolean isArmorStandItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_8694);
    }

    protected static boolean isFireworkEditableItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_8639) || stack.method_31574(class_1802.field_8450);
    }

    protected static boolean isContainerEditableItem(class_1799 stack) {
        if (!(stack.method_7909() instanceof class_1747 blockItem)) {
            return false;
        }
        class_2248 block = blockItem.method_7711();
        return block instanceof class_2281 || block instanceof class_3708 || block instanceof class_2480;
    }

    protected static boolean isBookEditableItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_8360) || stack.method_31574(class_1802.field_8674);
    }

    protected int getBookGeneration() {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        return tag == null ? 0 : class_3532.method_15340(tag.method_68083(BOOK_GENERATION_TAG, 0), 0, MAX_BOOK_GENERATION);
    }

    protected int getBookPageCount() {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        return tag == null ? 0 : tag.method_68569(BOOK_PAGES_TAG).size();
    }

    protected class_2561 getBookResolvedText() {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        boolean resolved = tag != null && tag.method_68566(BOOK_RESOLVED_TAG, false);
        return class_2561.method_43471(key("book.resolved." + (resolved ? 1 : 0)));
    }

    protected class_2561 getBookSignButtonText() {
        if (this.previewStack.method_31574(class_1802.field_8360)) {
            return class_2561.method_43471(key("book.unsign"));
        }
        return class_2561.method_43471(key(this.rememberedSignedBookData == null ? "book.sign" : "book.resign"));
    }

    protected int getFireworkFlight() {
        class_2487 fireworks = ItemStackNbt.getElement(this.previewStack, FIREWORKS_TAG);
        if (fireworks == null) {
            return 1;
        }
        return class_3532.method_15340(fireworks.method_68562(FIREWORK_FLIGHT_TAG, (byte) 0), 1, MAX_FIREWORK_FLIGHT);
    }

    protected int getFireworkExplosionCount() {
        if (this.previewStack.method_31574(class_1802.field_8450)) {
            class_2487 tag = ItemStackNbt.get(this.previewStack);
            return tag != null && tag.method_10545(FIREWORK_EXPLOSION_TAG) ? 1 : 0;
        }

        class_2487 fireworks = ItemStackNbt.getElement(this.previewStack, FIREWORKS_TAG);
        if (fireworks == null || !fireworks.method_10545(FIREWORK_EXPLOSIONS_TAG)) {
            return 0;
        }
        return fireworks.method_68569(FIREWORK_EXPLOSIONS_TAG).size();
    }

    protected boolean hasFireworkData() {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return false;
        }
        if (this.previewStack.method_31574(class_1802.field_8639)) {
            return tag.method_10545(FIREWORKS_TAG) && !tag.method_68568(FIREWORKS_TAG).method_33133();
        }
        return tag.method_10545(FIREWORK_EXPLOSION_TAG) && !tag.method_68568(FIREWORK_EXPLOSION_TAG).method_33133();
    }

    protected class_2561 getFireworkTypeName(int type) {
        return class_2561.method_43471(key("firework.type." + class_3532.method_15340(type, 0, FIREWORK_EXPLOSION_TYPES - 1)));
    }

    protected class_2561 getFireworkFadeColorText() {
        if (this.fireworkFadeColor < 0) {
            return class_2561.method_43471(key("firework.fade.none"));
        }
        return getDyeColorName(getFireworkDyeColor(this.fireworkFadeColor));
    }

    protected class_1767 getFireworkDyeColor(int colorId) {
        return class_1767.method_7791(class_3532.method_15387(colorId, class_1767.values().length));
    }

    protected static int getFireworkRgb(class_1767 color) {
        return color.method_7790();
    }

    protected static class_9283.class_1782 getFireworkShape(int type) {
        return FIREWORK_SHAPES[class_3532.method_15340(type, 0, FIREWORK_SHAPES.length - 1)];
    }

    protected static int getNearestFireworkDyeColorId(int rgb) {
        int normalized = rgb & 0xFFFFFF;
        class_1767 closest = class_1767.field_7952;
        int closestDistance = Integer.MAX_VALUE;
        for (class_1767 color : class_1767.values()) {
            int dyeRgb = getFireworkRgb(color);
            int red = getRed(normalized) - getRed(dyeRgb);
            int green = getGreen(normalized) - getGreen(dyeRgb);
            int blue = getBlue(normalized) - getBlue(dyeRgb);
            int distance = red * red + green * green + blue * blue;
            if (distance < closestDistance) {
                closest = color;
                closestDistance = distance;
            }
        }
        return closest.method_7789();
    }

    protected static String normalizeHeadText(String value) {
        return value == null ? "" : value.trim();
    }

    protected static UUID parseUuidOrNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return UUID.fromString(value.trim());
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    protected static int getDefaultAttributeSlot(class_1799 stack) {
        var equippable = stack.method_58694(class_9334.field_54196);
        if (equippable != null && equippable.comp_3174().method_46643()) {
            return getAttributeSlotNumber(equippable.comp_3174());
        }
        if (stack.method_31574(class_1802.field_8255) || stack.method_31574(class_1802.field_8288)) {
            return 2;
        }
        return 1;
    }

    protected static int getAttributeSlotNumber(class_1304 slot) {
        return switch (slot) {
            case field_6173 -> 1;
            case field_6171 -> 2;
            case field_6169 -> 3;
            case field_6174 -> 4;
            case field_6172 -> 5;
            case field_6166 -> 6;
            default -> 1;
        };
    }

    protected static String getAttributeSlotName(int slot) {
        return switch (slot) {
            case 1 -> class_1304.field_6173.method_5923();
            case 2 -> class_1304.field_6171.method_5923();
            case 3 -> class_1304.field_6169.method_5923();
            case 4 -> class_1304.field_6174.method_5923();
            case 5 -> class_1304.field_6172.method_5923();
            case 6 -> class_1304.field_6166.method_5923();
            default -> null;
        };
    }

    protected static String formatColorHex(int color) {
        return String.format(Locale.ROOT, "#%06x", color & 0xFFFFFF);
    }

    protected static int getRed(int color) {
        return color >> 16 & 255;
    }

    protected static int getGreen(int color) {
        return color >> 8 & 255;
    }

    protected static int getBlue(int color) {
        return color & 255;
    }

    protected static int argb(int alpha, int rgb) {
        return ((alpha & 255) << 24) | (rgb & 0xFFFFFF);
    }

    protected String formatRingEnchantmentName(class_1887 enchantment) {
        class_6880<class_1887> holder = CompatRegistries.ENCHANTMENTS.getHolder(enchantment);
        return holder == null
                ? enchantment.comp_2686().getString()
                : class_1887.method_8179(holder, getDisplayLevel(enchantment)).getString();
    }

    protected String formatStoredEnchantment(EnchantmentEntry entry) {
        if (entry.enchantment() == null) {
            return "Unknown ID (" + entry.id() + ") " + entry.level();
        }
        class_6880<class_1887> holder = CompatRegistries.ENCHANTMENTS.getHolder(entry.enchantment());
        return holder == null
                ? entry.enchantment().comp_2686().getString() + " " + entry.level()
                : class_1887.method_8179(holder, entry.level()).getString();
    }

    protected static int findEnchantmentIndex(class_2499 enchantments, class_2960 id) {
        for (int i = 0; i < enchantments.size(); i++) {
            class_2960 storedId = class_2960.method_12829(enchantments.method_68582(i).method_68564("id", ""));
            if (id.equals(storedId)) {
                return i;
            }
        }
        return -1;
    }

    protected static String getEnchantmentTagKey(class_1799 stack) {
        return stack.method_31574(class_1802.field_8598) ? BOOK_ENCHANTMENTS_TAG : ITEM_ENCHANTMENTS_TAG;
    }
}
