package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
abstract class ItemEditorScreenEffects extends ItemEditorScreenTrades {
    protected ItemEditorScreenEffects(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

protected void updateRawNbt() {
        String raw = this.rawNbtBox == null ? this.rawNbtValue : this.rawNbtBox.method_1882();
        try {
            class_2487 tag = parseNbt(raw);
            this.previewStack = tag == null ? this.previewStack.method_7972() : ItemStackNbt.parseEditorNbt(this.previewStack, tag);
            if (tag == null) {
                ItemStackNbt.set(this.previewStack, null);
            }
            readMainFieldsFromStack(this.previewStack);
            syncNbtEditorValuesFromStack();
            this.nbtFeedbackGood = true;
            this.nbtFeedback = "Looks good";
        } catch (CommandSyntaxException exception) {
            this.nbtFeedbackGood = false;
            this.nbtFeedback = exception.getMessage();
        }
    }

    protected void updateComponentNbt() {
        String raw = this.componentNbtBox == null ? this.componentNbtValue : this.componentNbtBox.method_1882();
        try {
            class_2487 components = parseNbt(raw);
            this.previewStack = parseStackWithComponents(this.previewStack, components == null ? new class_2487() : components);
            readMainFieldsFromStack(this.previewStack);
            syncNbtEditorValuesFromStack();
            this.nbtFeedbackGood = true;
            this.nbtFeedback = "Looks good";
        } catch (CommandSyntaxException exception) {
            this.nbtFeedbackGood = false;
            this.nbtFeedback = exception.getMessage();
        } catch (RuntimeException exception) {
            this.nbtFeedbackGood = false;
            this.nbtFeedback = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
        }
    }

    protected class_1799 parseStackWithComponents(class_1799 current, class_2487 components) {
        class_2487 stackTag = new class_2487();
        class_2960 id = CompatRegistries.ITEMS.getKey(current.method_7909());
        stackTag.method_10582("id", id == null ? "minecraft:air" : id.toString());
        stackTag.method_10569("count", Math.max(1, current.method_7947()));
        if (components != null && !components.method_33133()) {
            stackTag.method_10566("components", components.method_10553());
        }
        class_1799 parsed = ItemStackNbt.parse(stackTag);
        if (parsed.method_7960() && !current.method_31574(class_1802.field_8162)) {
            throw new IllegalArgumentException("Invalid components");
        }
        return parsed;
    }

    protected void toggleUnbreakable() {
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        boolean current = tag.method_68566("Unbreakable", false);
        if (current) {
            tag.method_10551("Unbreakable");
        } else {
            tag.method_10556("Unbreakable", true);
        }
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
        method_41843();
    }

    protected class_2561 getUnbreakableText() {
        boolean unbreakable = ItemStackNbt.get(this.previewStack) != null && ItemStackNbt.get(this.previewStack).method_68566("Unbreakable", false);
        return class_2561.method_43471(key("tag.unbreakable." + (unbreakable ? 1 : 0)));
    }

    protected void toggleHideFlag(HideFlag flag) {
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        int value = tag.method_68083(HIDE_FLAGS_TAG, 0);
        if ((value & flag.mask()) != 0) {
            value &= ~flag.mask();
        } else {
            value |= flag.mask();
        }
        if (value == 0) {
            tag.method_10551(HIDE_FLAGS_TAG);
        } else {
            tag.method_10569(HIDE_FLAGS_TAG, value);
        }
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected class_2561 getHideFlagText(HideFlag flag) {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        boolean hidden = tag != null && (tag.method_68083(HIDE_FLAGS_TAG, 0) & flag.mask()) != 0;
        return class_2561.method_43471(key(flag.translationKey() + "." + (hidden ? 1 : 0)));
    }

    protected void toggleEnchantmentsScope() {
        this.showAllEnchantments = !this.showAllEnchantments;
        this.selectedEnchantmentNamespace = "";
        method_41843();
    }

    protected void renderActiveEnchantments(class_332 guiGraphics) {
        List<EnchantmentEntry> activeEnchantments = getStoredEnchantments(this.previewStack);
        int startY = this.midY - activeEnchantments.size() * 5;
        for (int i = 0; i < activeEnchantments.size(); i++) {
            EnchantmentEntry entry = activeEnchantments.get(i);
            int color = entry.enchantment() == null ? BAD_RED : MAIN_COLOR;
            guiGraphics.method_25303(this.field_22793, formatStoredEnchantment(entry), editorListTextLeft(), startY + i * 10, color);
        }
    }

    protected boolean tryRemoveActiveEnchantment(double mouseX, double mouseY) {
        List<EnchantmentEntry> activeEnchantments = getStoredEnchantments(this.previewStack);
        if (activeEnchantments.isEmpty()) {
            return false;
        }

        int startY = this.midY - activeEnchantments.size() * 5;
        int listWidth = this.field_22793.method_1727("Unbreaking 32767");
        for (EnchantmentEntry entry : activeEnchantments) {
            listWidth = Math.max(listWidth, this.field_22793.method_1727(formatStoredEnchantment(entry)));
        }

        int listLeft = editorListTextLeft();
        if (mouseX < listLeft || mouseX > listLeft + listWidth || mouseY < startY || mouseY >= startY + activeEnchantments.size() * 10) {
            return false;
        }

        int index = (int) ((mouseY - startY) / 10);
        EnchantmentEntry entry = activeEnchantments.get(index);
        if (removeEnchantmentAtIndex(index)) {
            class_2561 name = entry.enchantment() == null
                    ? class_2561.method_43470(String.valueOf(entry.id()))
                    : entry.enchantment().comp_2686();
            this.status = class_2561.method_43469(messageKey("editor_enchantment_removed"), name);
        }
        return true;
    }

    protected boolean tryAddRingEnchantment(double mouseX, double mouseY) {
        List<class_1887> filteredEnchantments = getVisibleEnchantments(this.previewStack);
        if (filteredEnchantments.isEmpty() || Math.abs(this.mouseDist - getRingRadius()) >= RING_HOVER_WIDTH) {
            return false;
        }

        double angle = (2.0D * Math.PI) / filteredEnchantments.size();
        int lowDist = Integer.MAX_VALUE;
        class_1887 closestEnchantment = null;
        for (int i = 0; i < filteredEnchantments.size(); i++) {
            double enchantmentAngle = this.rotOff / 60.0D + angle * i;
            int x = (int) (contentMidX() + getRingRadius() * Math.cos(enchantmentAngle));
            int y = (int) (this.midY + getRingRadius() * Math.sin(enchantmentAngle));
            int distX = x - (int) mouseX;
            int distY = y - (int) mouseY;
            int dist = (int) Math.sqrt(distX * distX + distY * distY);
            if (dist < RING_ICON_HIT_RADIUS && dist < lowDist) {
                lowDist = dist;
                closestEnchantment = filteredEnchantments.get(i);
            }
        }

        if (closestEnchantment == null) {
            return false;
        }

        addEnchantment(closestEnchantment);
        return true;
    }

    protected void addEnchantment(class_1887 enchantment) {
        int level = getLevelForEnchantment(enchantment);
        if (level < 1) {
            return;
        }
        putEnchantment(enchantment, level);
        this.status = class_2561.method_43469(messageKey("editor_enchantment_added"),
                enchantment.comp_2686(), level);
    }

    protected void addMatchingEnchantments() {
        List<class_1887> enchantments = getVisibleEnchantments(this.previewStack);
        if (!getFoldedEnchantmentGroups(this.previewStack).isEmpty()) {
            this.status = class_2561.method_43471(messageKey("editor_select_enchantment_group"));
            return;
        }
        if (enchantments.isEmpty()) {
            this.status = class_2561.method_43471(messageKey("editor_no_enchantment_match"));
            return;
        }

        for (class_1887 enchantment : enchantments) {
            int level = getLevelForEnchantment(enchantment);
            if (level < 1) {
                return;
            }
            putEnchantment(enchantment, level);
        }
        this.status = class_2561.method_43469(messageKey("editor_enchantments_added"), enchantments.size());
    }

    protected int getLevelForEnchantment(class_1887 enchantment) {
        int level;
        try {
            level = Integer.parseInt(this.enchantLevelBox == null ? this.enchantLevelValue : this.enchantLevelBox.method_1882());
        } catch (NumberFormatException exception) {
            this.status = class_2561.method_43469(messageKey("editor_invalid_enchantment_level"), MAX_ENCHANTMENT_LEVEL);
            return -1;
        }

        if (level < 1 || level > MAX_ENCHANTMENT_LEVEL) {
            this.status = class_2561.method_43469(messageKey("editor_invalid_enchantment_level"), MAX_ENCHANTMENT_LEVEL);
            return -1;
        }
        this.enchantLevelValue = Integer.toString(level);
        return level;
    }

    protected int getDisplayLevel(class_1887 enchantment) {
        try {
            int level = Integer.parseInt(this.enchantLevelValue);
            return Math.max(1, Math.min(MAX_ENCHANTMENT_LEVEL, level));
        } catch (NumberFormatException exception) {
            return 1;
        }
    }

    protected void putEnchantment(class_1887 enchantment, int level) {
        class_2960 id = CompatRegistries.ENCHANTMENTS.getKey(enchantment);
        if (id == null) {
            return;
        }
        class_2499 enchantments = getOrCreateEnchantmentsTag();
        int index = findEnchantmentIndex(enchantments, id);
        class_2487 enchantmentTag = new class_2487();
        enchantmentTag.method_10582("id", id.toString());
        enchantmentTag.method_10569("lvl", level);
        if (index >= 0) {
            enchantments.method_68585(index, enchantmentTag);
        } else {
            enchantments.add(enchantmentTag);
        }
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected boolean removeEnchantmentAtIndex(int index) {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return false;
        }

        String key = getEnchantmentTagKey(this.previewStack);
        class_2499 enchantments = tag.method_68569(key);
        if (index < 0 || index >= enchantments.size()) {
            return false;
        }

        enchantments.method_10536(index);
        if (enchantments.isEmpty()) {
            tag.method_10551(key);
            cleanupEmptyTag();
        }
        this.rawNbtValue = getInitialNbt(this.previewStack);
        return true;
    }

    protected class_2499 getOrCreateEnchantmentsTag() {
        String key = getEnchantmentTagKey(this.previewStack);
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        if (!tag.method_10545(key)) {
            tag.method_10566(key, new class_2499());
        }
        return tag.method_68569(key);
    }

    protected List<class_1887> getFilteredEnchantments(class_1799 stack) {
        List<class_1887> matchingEnchantments = new ArrayList<>();
        List<class_1887> applicableMatchingEnchantments = new ArrayList<>();
        boolean hasApplicableEnchantments = false;
        String filter = this.enchantFilterValue == null ? "" : this.enchantFilterValue.trim().toLowerCase(Locale.ROOT);
        for (class_1887 enchantment : CompatRegistries.ENCHANTMENTS.getValues()) {
            boolean applicable = canApplyEnchantment(stack, enchantment);
            hasApplicableEnchantments |= applicable;
            class_2960 id = CompatRegistries.ENCHANTMENTS.getKey(enchantment);
            String name = enchantment.comp_2686().getString().toLowerCase(Locale.ROOT);
            String idString = id == null ? "" : id.toString().toLowerCase(Locale.ROOT);
            if (filter.isEmpty() || name.contains(filter) || idString.contains(filter)) {
                matchingEnchantments.add(enchantment);
                if (applicable) {
                    applicableMatchingEnchantments.add(enchantment);
                }
            }
        }

        List<class_1887> enchantments = this.showAllEnchantments || !hasApplicableEnchantments
                ? matchingEnchantments
                : applicableMatchingEnchantments;
        enchantments.sort(Comparator.comparing(enchantment -> enchantment.comp_2686().getString(),
                String.CASE_INSENSITIVE_ORDER));
        return enchantments;
    }

    protected List<class_1887> getVisibleEnchantments(class_1799 stack) {
        List<class_1887> enchantments = getFilteredEnchantments(stack);
        if (this.selectedEnchantmentNamespace.isBlank()) {
            return enchantments;
        }

        List<class_1887> visibleEnchantments = new ArrayList<>();
        for (class_1887 enchantment : enchantments) {
            class_2960 id = CompatRegistries.ENCHANTMENTS.getKey(enchantment);
            if (id != null && this.selectedEnchantmentNamespace.equals(id.method_12836())) {
                visibleEnchantments.add(enchantment);
            }
        }

        if (visibleEnchantments.isEmpty()) {
            this.selectedEnchantmentNamespace = "";
            return enchantments;
        }
        return visibleEnchantments;
    }

    protected List<EnchantmentGroupEntry> getFoldedEnchantmentGroups(class_1799 stack) {
        if (!this.selectedEnchantmentNamespace.isBlank()) {
            return List.of();
        }

        List<class_1887> enchantments = getFilteredEnchantments(stack);
        Map<String, List<class_1887>> groupedEnchantments = new HashMap<>();
        for (class_1887 enchantment : enchantments) {
            class_2960 id = CompatRegistries.ENCHANTMENTS.getKey(enchantment);
            if (id != null) {
                groupedEnchantments.computeIfAbsent(id.method_12836(), namespace -> new ArrayList<>()).add(enchantment);
            }
        }

        if (!shouldFoldRegistryEntries(enchantments.size(), groupedEnchantments)) {
            return List.of();
        }

        List<EnchantmentGroupEntry> groups = new ArrayList<>();
        for (Map.Entry<String, List<class_1887>> entry : groupedEnchantments.entrySet()) {
            groups.add(new EnchantmentGroupEntry(entry.getKey(), entry.getValue()));
        }
        groups.sort(Comparator.comparing(EnchantmentGroupEntry::namespace, String.CASE_INSENSITIVE_ORDER));
        return groups;
    }

    protected boolean trySelectRingEnchantmentGroup(double mouseX, double mouseY) {
        List<EnchantmentGroupEntry> groups = getFoldedEnchantmentGroups(this.previewStack);
        if (groups.isEmpty() || Math.abs(this.mouseDist - getRingRadius()) >= RING_HOVER_WIDTH) {
            return false;
        }

        double angle = (2.0D * Math.PI) / groups.size();
        int lowDist = Integer.MAX_VALUE;
        EnchantmentGroupEntry closestGroup = null;
        for (int i = 0; i < groups.size(); i++) {
            double groupAngle = this.rotOff / 60.0D + angle * i;
            int x = (int) (contentMidX() + getRingRadius() * Math.cos(groupAngle));
            int y = (int) (this.midY + getRingRadius() * Math.sin(groupAngle));
            int distX = x - (int) mouseX;
            int distY = y - (int) mouseY;
            int dist = (int) Math.sqrt(distX * distX + distY * distY);
            if (dist < RING_ICON_HIT_RADIUS && dist < lowDist) {
                lowDist = dist;
                closestGroup = groups.get(i);
            }
        }

        if (closestGroup == null) {
            return false;
        }

        this.selectedEnchantmentNamespace = closestGroup.namespace();
        this.status = class_2561.method_43469(messageKey("editor_enchantment_group_selected"), closestGroup.namespace());
        method_41843();
        return true;
    }

    protected boolean shouldFoldRegistryEntries(int entryCount, Map<String, ?> groupedEntries) {
        if (entryCount <= FOLDED_REGISTRY_ENTRY_LIMIT || groupedEntries.isEmpty()) {
            return false;
        }
        return groupedEntries.size() > 1 || !groupedEntries.containsKey("minecraft");
    }

    protected boolean canApplyEnchantment(class_1799 stack, class_1887 enchantment) {
        return enchantment.method_8192(stack)
                || stack.method_31574(class_1802.field_8529)
                || stack.method_31574(class_1802.field_8598);
    }

    protected List<EnchantmentEntry> getStoredEnchantments(class_1799 stack) {
        List<EnchantmentEntry> entries = new ArrayList<>();
        class_2487 tag = ItemStackNbt.get(stack);
        if (tag == null) {
            return entries;
        }

        class_2499 enchantments = tag.method_68569(getEnchantmentTagKey(stack));
        for (int i = 0; i < enchantments.size(); i++) {
            class_2487 enchantmentTag = enchantments.method_68582(i);
            class_2960 id = class_2960.method_12829(enchantmentTag.method_68564("id", ""));
            class_1887 enchantment = id == null ? null : CompatRegistries.ENCHANTMENTS.getValue(id);
            entries.add(new EnchantmentEntry(id, enchantment, enchantmentTag.method_68083("lvl", 0)));
        }
        return entries;
    }

    protected boolean tryRemoveActivePotionEffect(double mouseX, double mouseY) {
        List<class_1293> effects = getCustomPotionEffects();
        if (effects.isEmpty()) {
            return false;
        }

        int startY = this.midY - effects.size() * 5;
        int listWidth = this.field_22793.method_1727("Unbreaking 32767");
        for (class_1293 effect : effects) {
            listWidth = Math.max(listWidth, this.field_22793.method_1727(formatPotionEffect(effect)));
        }

        int listLeft = editorListTextLeft();
        if (mouseX < listLeft || mouseX > listLeft + listWidth || mouseY < startY || mouseY >= startY + effects.size() * 10) {
            return false;
        }

        int index = (int) ((mouseY - startY) / 10);
        removeCustomPotionEffectAt(index);
        return true;
    }

    protected boolean tryAddRingPotionEffect(double mouseX, double mouseY) {
        List<class_1291> filteredEffects = getVisiblePotionEffects();
        if (filteredEffects.isEmpty() || Math.abs(this.mouseDist - getRingRadius()) >= RING_HOVER_WIDTH) {
            return false;
        }

        double angle = (2.0D * Math.PI) / filteredEffects.size();
        int lowDist = Integer.MAX_VALUE;
        class_1291 closestEffect = null;
        for (int i = 0; i < filteredEffects.size(); i++) {
            double effectAngle = this.rotOff / 60.0D + angle * i;
            int x = (int) (contentMidX() + getRingRadius() * Math.cos(effectAngle));
            int y = (int) (this.midY + getRingRadius() * Math.sin(effectAngle));
            int distX = x - (int) mouseX;
            int distY = y - (int) mouseY;
            int dist = (int) Math.sqrt(distX * distX + distY * distY);
            if (dist < RING_ICON_HIT_RADIUS && dist < lowDist) {
                lowDist = dist;
                closestEffect = filteredEffects.get(i);
            }
        }

        if (closestEffect == null) {
            return false;
        }

        addPotionEffect(closestEffect);
        return true;
    }

    protected void addMatchingPotionEffects() {
        List<class_1291> effects = getVisiblePotionEffects();
        if (!getFoldedPotionGroups().isEmpty()) {
            this.status = class_2561.method_43471(messageKey("editor_select_potion_group"));
            return;
        }
        if (effects.isEmpty()) {
            this.status = class_2561.method_43471(messageKey("editor_no_potion_match"));
            return;
        }
        for (class_1291 effect : effects) {
            if (!addPotionEffect(effect)) {
                return;
            }
        }
    }

    protected boolean addPotionEffect(class_1291 effect) {
        int level = parsePotionLevel();
        int seconds = parsePotionSeconds();
        if (level < 1 || seconds < 1) {
            return false;
        }

        class_6880<class_1291> holder = CompatRegistries.MOB_EFFECTS.getHolder(effect);
        if (holder == null) {
            return false;
        }

        class_1293 instance = new class_1293(holder, seconds * 20, level - 1, false, this.showPotionParticles);
        List<class_1293> effects = new ArrayList<>(getCustomPotionEffects());
        effects.removeIf(existing -> existing.method_5579().method_55838(holder));
        effects.add(instance);
        PotionCompat.setCustomEffects(this.previewStack, effects);
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43469(messageKey("editor_potion_added"), effect.method_5560(), level);
        return true;
    }

    protected void removeCustomPotionEffectAt(int index) {
        List<class_1293> effects = new ArrayList<>(getCustomPotionEffects());
        if (index < 0 || index >= effects.size()) {
            return;
        }
        class_1293 removed = effects.remove(index);
        if (effects.isEmpty()) {
            class_2487 tag = ItemStackNbt.get(this.previewStack);
            if (tag != null) {
                tag.method_10551(CUSTOM_POTION_EFFECTS_TAG);
            }
            cleanupEmptyTag();
        } else {
            PotionCompat.setCustomEffects(this.previewStack, effects);
        }
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43469(messageKey("editor_potion_removed"), removed.method_5579().comp_349().method_5560());
    }

    protected List<class_1293> getCustomPotionEffects() {
        return new ArrayList<>(PotionCompat.getCustomEffects(this.previewStack));
    }

    protected List<class_1291> getFilteredPotionEffects() {
        List<class_1291> effects = new ArrayList<>();
        String filter = this.potionFilterValue == null ? "" : this.potionFilterValue.trim().toLowerCase(Locale.ROOT);
        for (class_1291 effect : CompatRegistries.MOB_EFFECTS.getValues()) {
            class_2960 id = CompatRegistries.MOB_EFFECTS.getKey(effect);
            String name = effect.method_5560().getString().toLowerCase(Locale.ROOT);
            String idString = id == null ? "" : id.toString().toLowerCase(Locale.ROOT);
            if (filter.isEmpty() || name.contains(filter) || idString.contains(filter)) {
                effects.add(effect);
            }
        }
        effects.sort(Comparator.comparing(effect -> effect.method_5560().getString(), String.CASE_INSENSITIVE_ORDER));
        return effects;
    }

    protected List<class_1291> getVisiblePotionEffects() {
        List<class_1291> effects = getFilteredPotionEffects();
        if (this.selectedPotionNamespace.isBlank()) {
            return effects;
        }

        List<class_1291> visibleEffects = new ArrayList<>();
        for (class_1291 effect : effects) {
            class_2960 id = CompatRegistries.MOB_EFFECTS.getKey(effect);
            if (id != null && this.selectedPotionNamespace.equals(id.method_12836())) {
                visibleEffects.add(effect);
            }
        }

        if (visibleEffects.isEmpty()) {
            this.selectedPotionNamespace = "";
            return effects;
        }
        return visibleEffects;
    }

    protected List<PotionGroupEntry> getFoldedPotionGroups() {
        if (!this.selectedPotionNamespace.isBlank()) {
            return List.of();
        }

        List<class_1291> effects = getFilteredPotionEffects();
        Map<String, List<class_1291>> groupedEffects = new HashMap<>();
        for (class_1291 effect : effects) {
            class_2960 id = CompatRegistries.MOB_EFFECTS.getKey(effect);
            if (id != null) {
                groupedEffects.computeIfAbsent(id.method_12836(), namespace -> new ArrayList<>()).add(effect);
            }
        }

        if (!shouldFoldRegistryEntries(effects.size(), groupedEffects)) {
            return List.of();
        }

        List<PotionGroupEntry> groups = new ArrayList<>();
        for (Map.Entry<String, List<class_1291>> entry : groupedEffects.entrySet()) {
            groups.add(new PotionGroupEntry(entry.getKey(), entry.getValue()));
        }
        groups.sort(Comparator.comparing(PotionGroupEntry::namespace, String.CASE_INSENSITIVE_ORDER));
        return groups;
    }

    protected boolean trySelectRingPotionGroup(double mouseX, double mouseY) {
        List<PotionGroupEntry> groups = getFoldedPotionGroups();
        if (groups.isEmpty() || Math.abs(this.mouseDist - getRingRadius()) >= RING_HOVER_WIDTH) {
            return false;
        }

        double angle = (2.0D * Math.PI) / groups.size();
        int lowDist = Integer.MAX_VALUE;
        PotionGroupEntry closestGroup = null;
        for (int i = 0; i < groups.size(); i++) {
            double groupAngle = this.rotOff / 60.0D + angle * i;
            int x = (int) (contentMidX() + getRingRadius() * Math.cos(groupAngle));
            int y = (int) (this.midY + getRingRadius() * Math.sin(groupAngle));
            int distX = x - (int) mouseX;
            int distY = y - (int) mouseY;
            int dist = (int) Math.sqrt(distX * distX + distY * distY);
            if (dist < RING_ICON_HIT_RADIUS && dist < lowDist) {
                lowDist = dist;
                closestGroup = groups.get(i);
            }
        }

        if (closestGroup == null) {
            return false;
        }

        this.selectedPotionNamespace = closestGroup.namespace();
        this.status = class_2561.method_43469(messageKey("editor_potion_group_selected"), closestGroup.namespace());
        method_41843();
        return true;
    }

    protected int parsePotionLevel() {
        try {
            int level = Integer.parseInt(this.potionLevelBox == null ? this.potionLevelValue : this.potionLevelBox.method_1882());
            if (level < 1 || level > MAX_POTION_LEVEL) {
                throw new NumberFormatException();
            }
            this.potionLevelValue = Integer.toString(level);
            return level;
        } catch (NumberFormatException exception) {
            this.status = class_2561.method_43469(messageKey("editor_invalid_potion_level"), MAX_POTION_LEVEL);
            return -1;
        }
    }

    protected int parsePotionSeconds() {
        try {
            int seconds = Integer.parseInt(this.potionTimeBox == null ? this.potionTimeValue : this.potionTimeBox.method_1882());
            if (seconds < 1 || seconds > MAX_POTION_SECONDS) {
                throw new NumberFormatException();
            }
            this.potionTimeValue = Integer.toString(seconds);
            return seconds;
        } catch (NumberFormatException exception) {
            this.status = class_2561.method_43469(messageKey("editor_invalid_potion_time"), MAX_POTION_SECONDS);
            return -1;
        }
    }

    protected void togglePotionParticles() {
        this.showPotionParticles = !this.showPotionParticles;
        method_41843();
    }

    protected String formatPotionEffect(class_1293 effect) {
        int amplifier = effect.method_5578();
        String text = effect.method_5579().comp_349().method_5560().getString() + " (" + ((long) amplifier + 1L) + ")";
        if (amplifier > 1) {
            text += " " + class_2561.method_43471("potion.potency." + amplifier).getString().trim();
        }
        text += effect.method_5581() ? " P:S" : " P:H";
        return text;
    }

    protected String formatPotionRingName(class_1291 effect) {
        int level = 1;
        try {
            level = Math.max(1, Integer.parseInt(this.potionLevelValue));
        } catch (NumberFormatException ignored) {
        }
        String text = effect.method_5560().getString();
        if (level > 1) {
            text += " " + class_2561.method_43471("potion.potency." + (level - 1)).getString().trim();
        }
        return text;
    }

    protected void toggleAttributeInfinity() {
        this.attributeInfinity = !this.attributeInfinity;
        method_41843();
    }

    protected void cycleAttributeOperation() {
        this.attributeOperation = (this.attributeOperation + 1) % 3;
        method_41843();
    }

    protected void cycleAttributeSlot() {
        this.attributeSlot = (this.attributeSlot + 1) % 7;
        method_41843();
    }

    protected boolean tryRemoveActiveAttributeModifier(double mouseX, double mouseY) {
        List<AttributeEntry> entries = getAttributeModifierEntries();
        if (entries.isEmpty()) {
            return false;
        }

        int startY = this.midY - entries.size() * 5;
        int listWidth = this.field_22793.method_1727("Unbreaking 32767");
        for (AttributeEntry entry : entries) {
            listWidth = Math.max(listWidth, this.field_22793.method_1727(formatAttributeEntry(entry)));
        }

        int listLeft = editorListTextLeft();
        if (mouseX < listLeft || mouseX > listLeft + listWidth || mouseY < startY || mouseY >= startY + entries.size() * 10) {
            return false;
        }

        int index = (int) ((mouseY - startY) / 10);
        AttributeEntry entry = entries.get(index);
        removeAttributeModifierAt(entry.tagIndex());
        this.status = class_2561.method_43469(messageKey("editor_attribute_removed"), getAttributeDisplayName(entry));
        return true;
    }

    protected boolean tryAddRingAttribute(double mouseX, double mouseY) {
        List<class_1320> attributes = getVisibleAttributes();
        if (attributes.isEmpty() || Math.abs(this.mouseDist - getRingRadius()) >= RING_HOVER_WIDTH) {
            return false;
        }

        double angle = (2.0D * Math.PI) / attributes.size();
        int lowDist = Integer.MAX_VALUE;
        class_1320 closestAttribute = null;
        for (int i = 0; i < attributes.size(); i++) {
            double attributeAngle = this.rotOff / 60.0D + angle * i;
            int x = (int) (contentMidX() + getRingRadius() * Math.cos(attributeAngle));
            int y = (int) (this.midY + getRingRadius() * Math.sin(attributeAngle));
            int distX = x - (int) mouseX;
            int distY = y - (int) mouseY;
            int dist = (int) Math.sqrt(distX * distX + distY * distY);
            if (dist < RING_ICON_HIT_RADIUS && dist < lowDist) {
                lowDist = dist;
                closestAttribute = attributes.get(i);
            }
        }

        if (closestAttribute == null) {
            return false;
        }

        addAttributeModifier(closestAttribute);
        return true;
    }

    protected void addAttributeModifier(class_1320 attribute) {
        Double amount = getAttributeAmount();
        if (amount == null) {
            return;
        }

        class_2960 id = CompatRegistries.ATTRIBUTES.getKey(attribute);
        if (id == null) {
            return;
        }

        class_1322.class_1323 operation = getAttributeOperation();
        class_1322 modifier = new class_1322(id.method_48331("/" + UUID.randomUUID()), amount, operation);
        class_2487 modifierTag = (class_2487) class_1322.field_46247.encodeStart(class_2509.field_11560, modifier).getOrThrow();
        modifierTag.method_10582("AttributeName", id.toString());
        modifierTag.method_10549("Amount", amount);
        modifierTag.method_10569("Operation", operation.method_56082());
        String slotName = getAttributeSlotName(this.attributeSlot);
        if (slotName != null) {
            modifierTag.method_10582("Slot", slotName);
        }

        getOrCreateAttributeModifiersTag().add(modifierTag);
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43469(messageKey("editor_attribute_added"), class_2561.method_43471(attribute.method_26830()));
    }

    protected Double getAttributeAmount() {
        if (this.attributeInfinity) {
            return this.attributeNegative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY;
        }

        try {
            int whole = parseBoundedAttributeNumber(this.attributeAmountBox == null ? this.attributeAmountValue : this.attributeAmountBox.method_1882(), MAX_ATTRIBUTE_INTEGER);
            int decimal = parseBoundedAttributeNumber(this.attributeDecimalBox == null ? this.attributeDecimalValue : this.attributeDecimalBox.method_1882(), 999);
            this.attributeAmountValue = Integer.toString(whole);
            this.attributeDecimalValue = Integer.toString(decimal);
            double amount = whole + decimal / 1000.0D;
            return this.attributeNegative ? -amount : amount;
        } catch (NumberFormatException exception) {
            this.status = class_2561.method_43471(messageKey("editor_invalid_attribute_value"));
            return null;
        }
    }

    protected int parseBoundedAttributeNumber(String value, int max) {
        if (value == null || value.isBlank()) {
            return 0;
        }
        int parsed = Integer.parseInt(value);
        if (parsed < 0 || parsed > max) {
            throw new NumberFormatException();
        }
        return parsed;
    }

    protected class_1322.class_1323 getAttributeOperation() {
        if (this.attributeInfinity) {
            return class_1322.class_1323.field_6328;
        }
        return switch (this.attributeOperation) {
            case 1 -> class_1322.class_1323.field_6330;
            case 2 -> class_1322.class_1323.field_6331;
            default -> class_1322.class_1323.field_6328;
        };
    }

    protected class_2499 getOrCreateAttributeModifiersTag() {
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        if (!tag.method_10545(ATTRIBUTE_MODIFIERS_TAG)) {
            tag.method_10566(ATTRIBUTE_MODIFIERS_TAG, new class_2499());
        }
        return tag.method_68569(ATTRIBUTE_MODIFIERS_TAG);
    }

    protected List<AttributeEntry> getAttributeModifierEntries() {
        List<AttributeEntry> entries = new ArrayList<>();
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null || !tag.method_10545(ATTRIBUTE_MODIFIERS_TAG)) {
            return entries;
        }

        class_2499 modifiers = tag.method_68569(ATTRIBUTE_MODIFIERS_TAG);
        for (int i = 0; i < modifiers.size(); i++) {
            class_2487 modifierTag = modifiers.method_68582(i);
            String attributeName = modifierTag.method_68564("AttributeName", "");
            class_1320 attribute = getAttributeByName(attributeName);
            double amount = modifierTag.method_10545("Amount") ? modifierTag.method_68563("Amount", 0.0D) : 0.0D;
            int operation = class_3532.method_15387(modifierTag.method_68083("Operation", 0), 3);
            String slotName = modifierTag.method_10545("Slot") ? modifierTag.method_68564("Slot", "") : "any";
            entries.add(new AttributeEntry(i, attributeName, attribute, amount, operation, slotName));
        }
        return entries;
    }

    protected void removeAttributeModifierAt(int tagIndex) {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null || !tag.method_10545(ATTRIBUTE_MODIFIERS_TAG)) {
            return;
        }

        class_2499 modifiers = tag.method_68569(ATTRIBUTE_MODIFIERS_TAG);
        if (tagIndex < 0 || tagIndex >= modifiers.size()) {
            return;
        }

        modifiers.method_10536(tagIndex);
        if (modifiers.isEmpty()) {
            tag.method_10551(ATTRIBUTE_MODIFIERS_TAG);
            cleanupEmptyTag();
        }
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected String formatAttributeEntry(AttributeEntry entry) {
        String[] prefixes = {entry.amount() < 0.0D ? "" : "+", "*", "**"};
        return getAttributeDisplayName(entry).getString() + " " + prefixes[entry.operation()] + entry.amount() + " (" + entry.slotName() + ")";
    }

    protected class_2561 getAttributeDisplayName(AttributeEntry entry) {
        if (entry.attribute() != null) {
            return class_2561.method_43471(entry.attribute().method_26830());
        }
        if (!entry.attributeName().isBlank()) {
            return class_2561.method_43470(entry.attributeName());
        }
        return class_2561.method_43470("Unknown Attribute");
    }

    protected class_1320 getAttributeByName(String name) {
        class_2960 id = class_2960.method_12829(name);
        return id == null ? null : CompatRegistries.ATTRIBUTES.getValue(id);
    }

    protected List<class_1320> getSharedAttributes() {
        List<class_1320> attributes = new ArrayList<>();
        String filter = this.attributeFilterValue == null ? "" : this.attributeFilterValue.trim().toLowerCase(Locale.ROOT);
        for (class_1320 attribute : CompatRegistries.ATTRIBUTES.getValues()) {
            if (attribute != null && matchesAttributeFilter(attribute, filter)) {
                attributes.add(attribute);
            }
        }
        attributes.sort(Comparator.comparing(attribute -> class_2561.method_43471(attribute.method_26830()).getString(),
                String.CASE_INSENSITIVE_ORDER));
        return attributes;
    }

    protected List<class_1320> getVisibleAttributes() {
        List<class_1320> attributes = getSharedAttributes();
        if (this.selectedAttributeNamespace.isBlank()) {
            return attributes;
        }

        List<class_1320> visibleAttributes = new ArrayList<>();
        for (class_1320 attribute : attributes) {
            class_2960 id = CompatRegistries.ATTRIBUTES.getKey(attribute);
            if (id != null && this.selectedAttributeNamespace.equals(id.method_12836())) {
                visibleAttributes.add(attribute);
            }
        }

        if (visibleAttributes.isEmpty()) {
            this.selectedAttributeNamespace = "";
            return attributes;
        }
        return visibleAttributes;
    }

    protected List<AttributeGroupEntry> getFoldedAttributeGroups() {
        if (!this.selectedAttributeNamespace.isBlank()) {
            return List.of();
        }

        List<class_1320> attributes = getSharedAttributes();
        Map<String, List<class_1320>> groupedAttributes = new HashMap<>();
        for (class_1320 attribute : attributes) {
            class_2960 id = CompatRegistries.ATTRIBUTES.getKey(attribute);
            if (id != null) {
                groupedAttributes.computeIfAbsent(id.method_12836(), namespace -> new ArrayList<>()).add(attribute);
            }
        }

        if (!shouldFoldRegistryEntries(attributes.size(), groupedAttributes)) {
            return List.of();
        }

        List<AttributeGroupEntry> groups = new ArrayList<>();
        for (Map.Entry<String, List<class_1320>> entry : groupedAttributes.entrySet()) {
            groups.add(new AttributeGroupEntry(entry.getKey(), entry.getValue()));
        }
        groups.sort(Comparator.comparing(AttributeGroupEntry::namespace, String.CASE_INSENSITIVE_ORDER));
        return groups;
    }

    protected boolean trySelectRingAttributeGroup(double mouseX, double mouseY) {
        List<AttributeGroupEntry> groups = getFoldedAttributeGroups();
        if (groups.isEmpty() || Math.abs(this.mouseDist - getRingRadius()) >= RING_HOVER_WIDTH) {
            return false;
        }

        double angle = (2.0D * Math.PI) / groups.size();
        int lowDist = Integer.MAX_VALUE;
        AttributeGroupEntry closestGroup = null;
        for (int i = 0; i < groups.size(); i++) {
            double groupAngle = this.rotOff / 60.0D + angle * i;
            int x = (int) (contentMidX() + getRingRadius() * Math.cos(groupAngle));
            int y = (int) (this.midY + getRingRadius() * Math.sin(groupAngle));
            int distX = x - (int) mouseX;
            int distY = y - (int) mouseY;
            int dist = (int) Math.sqrt(distX * distX + distY * distY);
            if (dist < RING_ICON_HIT_RADIUS && dist < lowDist) {
                lowDist = dist;
                closestGroup = groups.get(i);
            }
        }

        if (closestGroup == null) {
            return false;
        }

        this.selectedAttributeNamespace = closestGroup.namespace();
        this.status = class_2561.method_43469(messageKey("editor_attribute_group_selected"), closestGroup.namespace());
        method_41843();
        return true;
    }

    protected boolean matchesAttributeFilter(class_1320 attribute, String filter) {
        if (filter.isBlank()) {
            return true;
        }

        class_2960 id = CompatRegistries.ATTRIBUTES.getKey(attribute);
        String idString = id == null ? "" : id.toString().toLowerCase(Locale.ROOT);
        String descriptionId = attribute.method_26830().toLowerCase(Locale.ROOT);
        String name = class_2561.method_43471(attribute.method_26830()).getString().toLowerCase(Locale.ROOT);
        return idString.contains(filter)
                || descriptionId.contains(filter)
                || name.contains(filter);
    }
}
