package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ComponentCompat;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.NbtCompat;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2522;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3532;
import net.minecraft.class_5250;
abstract class ItemEditorScreenItemData extends ItemEditorScreenCommon {
    protected ItemEditorScreenItemData(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

protected void applySignToStack() {
        if (!isSignItem(this.previewStack)) {
            return;
        }

        boolean hasContent = hasSignContent();
        class_2487 tag = hasContent ? ItemStackNbt.getOrCreate(this.previewStack) : ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        if (!hasContent) {
            blockEntity.method_10551(SIGN_FRONT_TEXT_TAG);
            removeLegacySignText(blockEntity);
            cleanupBlockEntityTag(tag, blockEntity);
            this.rawNbtValue = getInitialNbt(this.previewStack);
            return;
        }

        class_2487 frontText = blockEntity.method_68568(SIGN_FRONT_TEXT_TAG);
        class_2499 messages = new class_2499();
        for (int i = 0; i < SIGN_LINES; i++) {
            messages.add(class_2519.method_23256(ComponentCompat.toJson(createSignLineComponent(i))));
        }

        frontText.method_10566(SIGN_MESSAGES_TAG, messages);
        frontText.method_10551(SIGN_FILTERED_MESSAGES_TAG);
        if (!frontText.method_10545(SIGN_COLOR_TAG)) {
            frontText.method_10582(SIGN_COLOR_TAG, "black");
        }
        if (!frontText.method_10545(SIGN_GLOWING_TEXT_TAG)) {
            frontText.method_10556(SIGN_GLOWING_TEXT_TAG, false);
        }

        blockEntity.method_10566(SIGN_FRONT_TEXT_TAG, frontText);
        removeLegacySignText(blockEntity);
        cleanupBlockEntityTag(tag, blockEntity);
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected void applyBookMetadataToStack() {
        if (!this.previewStack.method_31574(class_1802.field_8360)) {
            return;
        }

        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        tag.method_10582(BOOK_TITLE_TAG, this.bookTitleValue == null ? "" : this.bookTitleValue);
        tag.method_10582(BOOK_AUTHOR_TAG, this.bookAuthorValue == null ? "" : this.bookAuthorValue);
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected void cycleBookGeneration() {
        if (!this.previewStack.method_31574(class_1802.field_8360)) {
            return;
        }

        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        int current = class_3532.method_15340(tag.method_68083(BOOK_GENERATION_TAG, 0), 0, MAX_BOOK_GENERATION);
        int next = class_3532.method_15387(current + 1, MAX_BOOK_GENERATION + 1);
        if (next == 0) {
            tag.method_10551(BOOK_GENERATION_TAG);
        } else {
            tag.method_10569(BOOK_GENERATION_TAG, next);
        }
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43469(messageKey("editor_book_generation_updated"), next);
        method_41843();
    }

    protected void toggleBookResolved() {
        if (!this.previewStack.method_31574(class_1802.field_8360)) {
            return;
        }

        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        if (tag.method_68566(BOOK_RESOLVED_TAG, false)) {
            tag.method_10551(BOOK_RESOLVED_TAG);
        } else {
            tag.method_10556(BOOK_RESOLVED_TAG, true);
        }
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_book_resolved_updated"));
        method_41843();
    }

    protected void toggleBookSignedState() {
        captureFieldValues();
        if (this.previewStack.method_31574(class_1802.field_8360)) {
            unsignBook();
        } else if (this.previewStack.method_31574(class_1802.field_8674)) {
            signBook();
        }
    }

    protected void unsignBook() {
        class_2487 originalTag = ItemStackNbt.get(this.previewStack);
        this.rememberedSignedBookData = originalTag == null ? new class_2487() : originalTag.method_10553();
        class_1799 writableBook = new class_1799(class_1802.field_8674, Math.max(1, this.previewStack.method_7947()));
        class_2487 writableTag = originalTag == null ? null : originalTag.method_10553();
        if (writableTag != null) {
            convertWrittenPagesToWritable(writableTag);
            writableTag.method_10551(BOOK_TITLE_TAG);
            writableTag.method_10551(BOOK_FILTERED_TITLE_TAG);
            writableTag.method_10551(BOOK_AUTHOR_TAG);
            writableTag.method_10551(BOOK_GENERATION_TAG);
            writableTag.method_10551(BOOK_RESOLVED_TAG);
            writableTag.method_10551(BOOK_FILTERED_PAGES_TAG);
            if (writableTag.method_33133()) {
                writableTag = null;
            }
        }
        ItemStackNbt.set(writableBook, writableTag);
        this.previewStack = writableBook;
        readMainFieldsFromStack(this.previewStack);
        this.bookTitleValue = this.rememberedSignedBookData.method_68564(BOOK_TITLE_TAG, "");
        this.bookAuthorValue = this.rememberedSignedBookData.method_68564(BOOK_AUTHOR_TAG, "");
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_book_unsigned"));
        method_41843();
    }

    protected void signBook() {
        class_1799 writtenBook = new class_1799(class_1802.field_8360, Math.max(1, this.previewStack.method_7947()));
        class_2487 writableTag = ItemStackNbt.get(this.previewStack);
        class_2487 signedTag = writableTag == null ? new class_2487() : writableTag.method_10553();
        convertWritablePagesToWritten(signedTag);

        int generation = 0;
        boolean resolved = false;
        if (this.rememberedSignedBookData != null) {
            generation = class_3532.method_15340(this.rememberedSignedBookData.method_68083(BOOK_GENERATION_TAG, 0), 0, MAX_BOOK_GENERATION);
            resolved = this.rememberedSignedBookData.method_68566(BOOK_RESOLVED_TAG, false);
        }

        signedTag.method_10582(BOOK_TITLE_TAG, this.bookTitleValue == null ? "" : this.bookTitleValue);
        signedTag.method_10551(BOOK_FILTERED_TITLE_TAG);
        signedTag.method_10582(BOOK_AUTHOR_TAG, this.bookAuthorValue == null ? "" : this.bookAuthorValue);
        signedTag.method_10551(BOOK_FILTERED_PAGES_TAG);
        if (generation == 0) {
            signedTag.method_10551(BOOK_GENERATION_TAG);
        } else {
            signedTag.method_10569(BOOK_GENERATION_TAG, generation);
        }
        if (resolved) {
            signedTag.method_10556(BOOK_RESOLVED_TAG, true);
        } else {
            signedTag.method_10551(BOOK_RESOLVED_TAG);
        }

        ItemStackNbt.set(writtenBook, signedTag.method_33133() ? null : signedTag);
        this.previewStack = writtenBook;
        this.rememberedSignedBookData = null;
        readMainFieldsFromStack(this.previewStack);
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_book_signed"));
        method_41843();
    }

    protected void convertWrittenPagesToWritable(class_2487 tag) {
        if (!tag.method_10545(BOOK_PAGES_TAG)) {
            return;
        }

        class_2499 pages = tag.method_68569(BOOK_PAGES_TAG);
        class_2499 converted = new class_2499();
        for (int i = 0; i < pages.size(); i++) {
            converted.add(class_2519.method_23256(readSerializedComponent(pages.method_68577(i, "")).getString()));
        }
        tag.method_10566(BOOK_PAGES_TAG, converted);
    }

    protected void convertWritablePagesToWritten(class_2487 tag) {
        if (!tag.method_10545(BOOK_PAGES_TAG)) {
            return;
        }

        class_2499 pages = tag.method_68569(BOOK_PAGES_TAG);
        class_2499 converted = new class_2499();
        for (int i = 0; i < pages.size(); i++) {
            converted.add(class_2519.method_23256(ComponentCompat.toJson(readBookPageComponent(pages.method_68577(i, "")))));
        }
        tag.method_10566(BOOK_PAGES_TAG, converted);
    }

    protected class_2561 readBookPageComponent(String raw) {
        class_2561 parsed = readSerializedComponent(raw);
        if (!parsed.getString().equals(raw) || isProbablyJsonText(raw)) {
            return parsed;
        }
        return class_2561.method_43470(raw);
    }

    protected boolean isProbablyJsonText(String raw) {
        String value = raw == null ? "" : raw.trim();
        return value.startsWith("{") || value.startsWith("[") || value.startsWith("\"");
    }

    protected void applyHeadToStack() {
        if (!isPlayerHeadItem(this.previewStack)) {
            return;
        }

        String ownerName = normalizeHeadText(this.headOwnerValue);
        String uuidText = normalizeHeadText(this.headUuidValue);
        String textureValue = normalizeHeadText(this.headTextureValue);
        String textureSignature = normalizeHeadText(this.headTextureSignatureValue);
        UUID uuid = parseUuidOrNull(uuidText);

        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        if (ownerName.isEmpty() && uuidText.isEmpty() && textureValue.isEmpty()) {
            tag.method_10551(SKULL_OWNER_TAG);
            cleanupEmptyTag();
            this.rawNbtValue = getInitialNbt(this.previewStack);
            return;
        }

        if (textureValue.isEmpty() && uuid == null && !ownerName.isEmpty()) {
            tag.method_10582(SKULL_OWNER_TAG, ownerName);
            this.rawNbtValue = getInitialNbt(this.previewStack);
            return;
        }

        class_2487 skullOwner = new class_2487();
        if (!ownerName.isEmpty()) {
            skullOwner.method_10582(SKULL_OWNER_NAME_TAG, ownerName);
        }
        if (uuid != null) {
            NbtCompat.putUUID(skullOwner, SKULL_OWNER_ID_TAG, uuid);
        }
        if (!textureValue.isEmpty()) {
            class_2487 properties = new class_2487();
            class_2499 textures = new class_2499();
            class_2487 texture = new class_2487();
            texture.method_10582(SKULL_TEXTURE_VALUE_TAG, textureValue);
            if (!textureSignature.isEmpty()) {
                texture.method_10582(SKULL_TEXTURE_SIGNATURE_TAG, textureSignature);
            }
            textures.add(texture);
            properties.method_10566(SKULL_TEXTURES_TAG, textures);
            skullOwner.method_10566(SKULL_PROPERTIES_TAG, properties);
        }

        tag.method_10566(SKULL_OWNER_TAG, skullOwner);
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected void clearHeadOwner() {
        this.headOwnerValue = "";
        this.headUuidValue = "";
        this.headTextureValue = "";
        this.headTextureSignatureValue = "";
        if (this.headOwnerBox != null) {
            this.headOwnerBox.method_1852("");
        }
        if (this.headUuidBox != null) {
            this.headUuidBox.method_1852("");
        }
        if (this.headTextureBox != null) {
            this.headTextureBox.method_1852("");
        }
        if (this.headTextureSignatureBox != null) {
            this.headTextureSignatureBox.method_1852("");
        }
        applyHeadToStack();
        this.status = class_2561.method_43471(messageKey("editor_head_cleared"));
    }

    protected void randomizeHeadUuid() {
        this.headUuidValue = UUID.randomUUID().toString();
        if (this.headUuidBox != null) {
            this.headUuidBox.method_1852(this.headUuidValue);
        }
        applyHeadToStack();
        this.status = class_2561.method_43471(messageKey("editor_head_uuid_randomized"));
    }

    protected void toggleArmorStandFlag(String tagKey, String translationSuffix) {
        if (!isArmorStandItem(this.previewStack)) {
            return;
        }

        class_2487 entityTag = getOrCreateArmorStandEntityTag();
        if (entityTag.method_68566(tagKey, false)) {
            entityTag.method_10551(tagKey);
        } else {
            entityTag.method_10556(tagKey, true);
        }
        cleanupArmorStandEntityTag(entityTag);
        this.status = class_2561.method_43469(messageKey("editor_armor_stand_updated"),
                class_2561.method_43471(key("armorstand." + translationSuffix + ".label")));
        method_41843();
    }

    protected void clearArmorStandEntityTag() {
        if (!isArmorStandItem(this.previewStack)) {
            return;
        }

        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null || !tag.method_10545(ENTITY_TAG)) {
            return;
        }

        class_2487 currentEntityTag = tag.method_68568(ENTITY_TAG);
        class_2487 clearedEntityTag = new class_2487();
        if (currentEntityTag.method_10545(ENTITY_ID_TAG)) {
            clearedEntityTag.method_10582(ENTITY_ID_TAG, currentEntityTag.method_68564(ENTITY_ID_TAG, ""));
        }
        if (clearedEntityTag.method_33133()) {
            tag.method_10551(ENTITY_TAG);
        } else {
            tag.method_10566(ENTITY_TAG, clearedEntityTag);
        }
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_armor_stand_cleared"));
        method_41843();
    }

    protected class_2487 getOrCreateArmorStandEntityTag() {
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        class_2487 entityTag = tag.method_68568(ENTITY_TAG);
        tag.method_10566(ENTITY_TAG, entityTag);
        return entityTag;
    }

    protected void cleanupArmorStandEntityTag(class_2487 entityTag) {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        if (entityTag.method_33133()) {
            tag.method_10551(ENTITY_TAG);
        } else {
            tag.method_10566(ENTITY_TAG, entityTag);
        }
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected class_2561 getArmorStandToggleText(String translationSuffix, String tagKey) {
        return class_2561.method_43471(key("armorstand." + translationSuffix + "." + (getArmorStandFlag(tagKey) ? 1 : 0)));
    }

    protected boolean getArmorStandFlag(String tagKey) {
        class_2487 entityTag = ItemStackNbt.getElement(this.previewStack, ENTITY_TAG);
        return entityTag != null && entityTag.method_68566(tagKey, false);
    }

    protected void cycleFireworkFlight() {
        if (!this.previewStack.method_31574(class_1802.field_8639)) {
            return;
        }

        class_2487 fireworks = getOrCreateFireworksTag();
        int next = getFireworkFlight() + 1;
        if (next > MAX_FIREWORK_FLIGHT) {
            next = 1;
        }
        fireworks.method_10567(FIREWORK_FLIGHT_TAG, (byte) next);
        cleanupFireworksTag(fireworks);
        this.status = class_2561.method_43469(messageKey("editor_firework_flight_updated"), next);
        method_41843();
    }

    protected void cycleFireworkExplosionType(int direction) {
        if (!isFireworkEditableItem(this.previewStack)) {
            return;
        }

        this.fireworkExplosionType = class_3532.method_15387(this.fireworkExplosionType + direction, FIREWORK_EXPLOSION_TYPES);
        applyFireworkControlsToStack();
        this.status = class_2561.method_43471(messageKey("editor_firework_updated"));
        method_41843();
    }

    protected void toggleFireworkFlicker() {
        if (!isFireworkEditableItem(this.previewStack)) {
            return;
        }

        this.fireworkFlicker = !this.fireworkFlicker;
        applyFireworkControlsToStack();
        this.status = class_2561.method_43471(messageKey("editor_firework_updated"));
        method_41843();
    }

    protected void toggleFireworkTrail() {
        if (!isFireworkEditableItem(this.previewStack)) {
            return;
        }

        this.fireworkTrail = !this.fireworkTrail;
        applyFireworkControlsToStack();
        this.status = class_2561.method_43471(messageKey("editor_firework_updated"));
        method_41843();
    }

    protected void cycleFireworkColor(boolean fade, int direction) {
        if (!isFireworkEditableItem(this.previewStack)) {
            return;
        }

        int colorCount = class_1767.values().length;
        if (fade) {
            int selected = this.fireworkFadeColor < 0 ? 0 : this.fireworkFadeColor + 1;
            selected = class_3532.method_15387(selected + direction, colorCount + 1);
            this.fireworkFadeColor = selected == 0 ? -1 : selected - 1;
        } else {
            this.fireworkColor = class_3532.method_15387(this.fireworkColor + direction, colorCount);
        }
        applyFireworkControlsToStack();
        this.status = class_2561.method_43471(messageKey("editor_firework_updated"));
        method_41843();
    }

    protected void randomizeFireworkColors() {
        if (!isFireworkEditableItem(this.previewStack)) {
            return;
        }

        int colorCount = class_1767.values().length;
        this.fireworkColor = ThreadLocalRandom.current().nextInt(colorCount);
        this.fireworkFadeColor = ThreadLocalRandom.current().nextInt(colorCount + 1) - 1;
        applyFireworkControlsToStack();
        this.status = class_2561.method_43471(messageKey("editor_firework_updated"));
        method_41843();
    }

    protected void addFireworkExplosion() {
        if (!this.previewStack.method_31574(class_1802.field_8639)) {
            return;
        }

        class_2487 fireworks = getOrCreateFireworksTag();
        if (!fireworks.method_10545(FIREWORK_FLIGHT_TAG)) {
            fireworks.method_10567(FIREWORK_FLIGHT_TAG, (byte) getFireworkFlight());
        }
        class_2499 explosions = fireworks.method_10545(FIREWORK_EXPLOSIONS_TAG)
                ? fireworks.method_68569(FIREWORK_EXPLOSIONS_TAG).method_10612()
                : new class_2499();
        explosions.add(createFireworkExplosionTag());
        fireworks.method_10566(FIREWORK_EXPLOSIONS_TAG, explosions);
        cleanupFireworksTag(fireworks);
        this.status = class_2561.method_43469(messageKey("editor_firework_explosion_added"), explosions.size());
        method_41843();
    }

    protected void removeLastFireworkExplosion() {
        if (!this.previewStack.method_31574(class_1802.field_8639)) {
            return;
        }

        class_2487 fireworks = ItemStackNbt.getElement(this.previewStack, FIREWORKS_TAG);
        if (fireworks == null || !fireworks.method_10545(FIREWORK_EXPLOSIONS_TAG)) {
            return;
        }

        class_2499 explosions = fireworks.method_68569(FIREWORK_EXPLOSIONS_TAG);
        if (explosions.isEmpty()) {
            return;
        }

        explosions.method_10536(explosions.size() - 1);
        if (explosions.isEmpty()) {
            fireworks.method_10551(FIREWORK_EXPLOSIONS_TAG);
        } else {
            fireworks.method_10566(FIREWORK_EXPLOSIONS_TAG, explosions);
        }
        cleanupFireworksTag(fireworks);
        readFireworkFieldsFromStack(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_firework_explosion_removed"));
        method_41843();
    }

    protected void clearFireworkData() {
        if (!isFireworkEditableItem(this.previewStack)) {
            return;
        }

        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        if (this.previewStack.method_31574(class_1802.field_8639)) {
            tag.method_10551(FIREWORKS_TAG);
        } else {
            tag.method_10551(FIREWORK_EXPLOSION_TAG);
        }
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
        readFireworkFieldsFromStack(this.previewStack);
        this.status = class_2561.method_43471(messageKey("editor_firework_cleared"));
        method_41843();
    }

    protected void applyFireworkControlsToStack() {
        if (this.previewStack.method_31574(class_1802.field_8450)) {
            ItemStackNbt.getOrCreate(this.previewStack).method_10566(FIREWORK_EXPLOSION_TAG, createFireworkExplosionTag());
            this.rawNbtValue = getInitialNbt(this.previewStack);
            return;
        }

        if (!this.previewStack.method_31574(class_1802.field_8639)) {
            return;
        }

        class_2487 fireworks = ItemStackNbt.getElement(this.previewStack, FIREWORKS_TAG);
        if (fireworks == null || !fireworks.method_10545(FIREWORK_EXPLOSIONS_TAG)) {
            return;
        }

        class_2499 explosions = fireworks.method_68569(FIREWORK_EXPLOSIONS_TAG);
        if (explosions.isEmpty()) {
            return;
        }

        explosions.method_68585(explosions.size() - 1, createFireworkExplosionTag());
        fireworks.method_10566(FIREWORK_EXPLOSIONS_TAG, explosions);
        cleanupFireworksTag(fireworks);
    }

    protected class_2487 createFireworkExplosionTag() {
        class_2487 explosion = new class_2487();
        explosion.method_10567(FIREWORK_TYPE_TAG, (byte) getFireworkShape(this.fireworkExplosionType).method_7816());
        explosion.method_10539(FIREWORK_COLORS_TAG, new int[]{getFireworkRgb(getFireworkDyeColor(this.fireworkColor))});
        if (this.fireworkFadeColor >= 0) {
            explosion.method_10539(FIREWORK_FADE_COLORS_TAG, new int[]{getFireworkRgb(getFireworkDyeColor(this.fireworkFadeColor))});
        }
        if (this.fireworkFlicker) {
            explosion.method_10556(FIREWORK_FLICKER_TAG, true);
        }
        if (this.fireworkTrail) {
            explosion.method_10556(FIREWORK_TRAIL_TAG, true);
        }
        return explosion;
    }

    protected class_2487 getOrCreateFireworksTag() {
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        class_2487 fireworks = tag.method_68568(FIREWORKS_TAG);
        tag.method_10566(FIREWORKS_TAG, fireworks);
        return fireworks;
    }

    protected void cleanupFireworksTag(class_2487 fireworks) {
        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null) {
            return;
        }

        if (fireworks.method_33133()) {
            tag.method_10551(FIREWORKS_TAG);
        } else {
            tag.method_10566(FIREWORKS_TAG, fireworks);
        }
        cleanupEmptyTag();
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected void cycleContainerSlot(int direction) {
        this.selectedContainerSlot = class_3532.method_15387(this.selectedContainerSlot + direction, CONTAINER_SIZE);
        this.containerSlotNbtValue = getContainerSelectedSlotNbt();
        if (this.containerSlotNbtBox != null) {
            this.containerSlotNbtBox.method_1852(this.containerSlotNbtValue);
            this.containerSlotNbtBox.method_1875(0);
        }
    }

    protected void updateContainerSlotFromNbt() {
        if (!isContainerEditableItem(this.previewStack)) {
            return;
        }

        captureFieldValues();
        try {
            class_1799 slotStack = parseContainerSlotItem(this.containerSlotNbtValue);
            setContainerSlotItem(this.selectedContainerSlot, slotStack);
            this.containerSlotNbtValue = getContainerSlotNbt(slotStack);
            this.status = slotStack.method_7960()
                    ? class_2561.method_43469(messageKey("editor_container_slot_cleared"), this.selectedContainerSlot + 1)
                    : class_2561.method_43469(messageKey("editor_container_slot_updated"), this.selectedContainerSlot + 1, slotStack.method_7964());
            method_41843();
        } catch (CommandSyntaxException exception) {
            this.status = class_2561.method_43469(messageKey("editor_invalid_nbt"), exception.getMessage());
        } catch (IllegalArgumentException exception) {
            this.status = class_2561.method_43470(exception.getMessage());
        }
    }

    protected class_1799 parseContainerSlotItem(String value) throws CommandSyntaxException {
        String trimmed = value == null ? "" : value.trim();
        if (trimmed.isEmpty() || "{}".equals(trimmed)) {
            return class_1799.field_8037;
        }

        class_2487 itemTag = class_2522.method_67315(trimmed);
        class_1799 slotStack = ItemStackNbt.parse(itemTag);
        if (slotStack.method_7960()) {
            throw new IllegalArgumentException(class_2561.method_43471(messageKey("editor_container_invalid_item")).getString());
        }
        return slotStack;
    }

    protected void clearContainerSlot() {
        if (!isContainerEditableItem(this.previewStack)) {
            return;
        }

        setContainerSlotItem(this.selectedContainerSlot, class_1799.field_8037);
        this.containerSlotNbtValue = "{}";
        this.status = class_2561.method_43469(messageKey("editor_container_slot_cleared"), this.selectedContainerSlot + 1);
        method_41843();
    }

    protected void clearContainerItems() {
        if (!isContainerEditableItem(this.previewStack)) {
            return;
        }

        class_2487 tag = ItemStackNbt.get(this.previewStack);
        if (tag == null || !tag.method_10545(BLOCK_ENTITY_TAG)) {
            return;
        }

        class_2487 blockEntity = tag.method_68568(BLOCK_ENTITY_TAG);
        blockEntity.method_10551(CONTAINER_ITEMS_TAG);
        cleanupBlockEntityTag(tag, blockEntity);
        this.containerSlotNbtValue = "{}";
        this.status = class_2561.method_43471(messageKey("editor_container_cleared"));
        method_41843();
    }

    protected void setContainerSlotItem(int slot, class_1799 slotStack) {
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        class_2487 blockEntity = tag.method_10545(BLOCK_ENTITY_TAG)
                ? tag.method_68568(BLOCK_ENTITY_TAG)
                : new class_2487();
        class_2499 currentItems = blockEntity.method_10545(CONTAINER_ITEMS_TAG)
                ? blockEntity.method_68569(CONTAINER_ITEMS_TAG)
                : new class_2499();
        List<class_2487> updatedItems = new ArrayList<>();
        for (int i = 0; i < currentItems.size(); i++) {
            class_2487 itemTag = currentItems.method_68582(i);
            if ((itemTag.method_68562(CONTAINER_SLOT_TAG, (byte) 0) & 255) != slot) {
                updatedItems.add(itemTag.method_10553());
            }
        }

        if (!slotStack.method_7960()) {
            class_2487 itemTag = ItemStackNbt.save(slotStack);
            itemTag.method_10567(CONTAINER_SLOT_TAG, (byte) slot);
            updatedItems.add(itemTag);
        }

        updatedItems.sort(Comparator.comparingInt(itemTag -> itemTag.method_68562(CONTAINER_SLOT_TAG, (byte) 0) & 255));
        class_2499 items = new class_2499();
        for (class_2487 itemTag : updatedItems) {
            items.add(itemTag);
        }

        if (items.isEmpty()) {
            blockEntity.method_10551(CONTAINER_ITEMS_TAG);
        } else {
            blockEntity.method_10566(CONTAINER_ITEMS_TAG, items);
        }
        cleanupBlockEntityTag(tag, blockEntity);
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected class_1799 getContainerSlotItem(int slot) {
        if (!isContainerEditableItem(this.previewStack)) {
            return class_1799.field_8037;
        }

        class_2499 items = getContainerItemsList();
        class_1799 found = class_1799.field_8037;
        for (int i = 0; i < items.size(); i++) {
            class_2487 itemTag = items.method_68582(i);
            if ((itemTag.method_68562(CONTAINER_SLOT_TAG, (byte) 0) & 255) == slot) {
                found = ItemStackNbt.parse(itemTag);
            }
        }
        return found;
    }

    protected class_2499 getContainerItemsList() {
        class_2487 blockEntity = ItemStackNbt.getElement(this.previewStack, BLOCK_ENTITY_TAG);
        if (blockEntity == null || !blockEntity.method_10545(CONTAINER_ITEMS_TAG)) {
            return new class_2499();
        }
        return blockEntity.method_68569(CONTAINER_ITEMS_TAG);
    }

    protected int getContainerItemCount() {
        int count = 0;
        for (int slot = 0; slot < CONTAINER_SIZE; slot++) {
            if (!getContainerSlotItem(slot).method_7960()) {
                count++;
            }
        }
        return count;
    }

    protected String getContainerSelectedSlotNbt() {
        return getContainerSlotNbt(getContainerSlotItem(this.selectedContainerSlot));
    }

    protected String getContainerSlotNbt(class_1799 stack) {
        if (stack.method_7960()) {
            return "{}";
        }
        return ItemStackNbt.save(stack).toString();
    }

    protected int getContainerGridX() {
        return this.midX - (CONTAINER_COLUMNS * CONTAINER_SLOT_PIXEL_SIZE) / 2;
    }

    protected int getContainerGridY() {
        return 48;
    }

    protected int getHoveredContainerSlot(int mouseX, int mouseY) {
        int gridX = getContainerGridX();
        int gridY = getContainerGridY();
        if (!isMouseIn(mouseX, mouseY, gridX - 1, gridY - 1,
                CONTAINER_COLUMNS * CONTAINER_SLOT_PIXEL_SIZE + 2,
                CONTAINER_ROWS * CONTAINER_SLOT_PIXEL_SIZE + 2)) {
            return -1;
        }

        int column = (mouseX - gridX) / CONTAINER_SLOT_PIXEL_SIZE;
        int row = (mouseY - gridY) / CONTAINER_SLOT_PIXEL_SIZE;
        int slot = column + row * CONTAINER_COLUMNS;
        return column < 0 || column >= CONTAINER_COLUMNS || row < 0 || row >= CONTAINER_ROWS ? -1 : slot;
    }

    protected class_5250 createSignLineComponent(int line) {
        class_5250 component = class_2561.method_43470(getSignLineValue(line));
        if (line == 0) {
            String command = getNormalizedSignCommand();
            if (!command.isEmpty()) {
                component.method_10862(class_2583.field_24360.method_10958(new class_2558.class_10609(command)));
            }
        }
        return component;
    }

    protected boolean hasSignContent() {
        if (!getNormalizedSignCommand().isEmpty()) {
            return true;
        }
        for (int i = 0; i < SIGN_LINES; i++) {
            if (!getSignLineValue(i).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    protected String getSignLineValue(int line) {
        if (line < 0 || line >= this.signLineValues.length || this.signLineValues[line] == null) {
            return "";
        }
        return this.signLineValues[line];
    }

    protected String getNormalizedSignCommand() {
        return this.signCommandValue == null ? "" : this.signCommandValue.trim();
    }

    protected void cleanupBlockEntityTag(class_2487 tag, class_2487 blockEntity) {
        if (blockEntity.method_33133()) {
            tag.method_10551(BLOCK_ENTITY_TAG);
        } else {
            tag.method_10566(BLOCK_ENTITY_TAG, blockEntity);
        }
        cleanupEmptyTag();
    }

    protected static void removeLegacySignText(class_2487 blockEntity) {
        for (int i = 0; i < SIGN_LINES; i++) {
            blockEntity.method_10551(LEGACY_SIGN_TEXT_TAG_PREFIX + (i + 1));
        }
    }
}
