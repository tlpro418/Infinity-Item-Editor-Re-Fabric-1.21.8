package io.github.seraphina.infinity_item_editor_re.client.screen;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernUi;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import io.github.seraphina.infinity_item_editor_re.util.Tooltips;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1320;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4081;
abstract class ItemEditorScreenRendering extends ItemEditorScreenWidgets {
    protected ItemEditorScreenRendering(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

    protected void renderEditorBackground(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        EditorBackgrounds.render(guiGraphics, this.field_22789, this.field_22790);

        if (!isSidebarUi()) {
            return;
        }

        int sidebarWidth = sidebarWidth();
        ModernUi.fillToolboxBackdrop(guiGraphics, this.field_22789, this.field_22790);
        ModernUi.fillContentGlow(guiGraphics, sidebarWidth, 0, this.field_22789, Math.min(this.field_22790, 72));
        ModernUi.fillToolboxSidebar(guiGraphics, 0, 0, sidebarWidth, this.field_22790);
        guiGraphics.method_25294(sidebarWidth, SIDEBAR_SAFE_MARGIN, sidebarWidth + 1, this.field_22790 - SIDEBAR_SAFE_MARGIN, ModernUi.BORDER_SOFT);
        guiGraphics.method_25294(sidebarWidth + 1, SIDEBAR_SAFE_MARGIN, sidebarWidth + 7, this.field_22790 - SIDEBAR_SAFE_MARGIN, 0x4A000000);

        ModernUi.fillHeaderPanel(guiGraphics, SIDEBAR_SAFE_MARGIN, 10, sidebarWidth - SIDEBAR_SAFE_MARGIN, 82, 8);
        ModernUi.drawWindowControls(guiGraphics, SIDEBAR_SAFE_MARGIN + 8, 18);
        String appName = this.field_22793.method_27523(ModSource.NAME, Math.max(20, sidebarWidth - SIDEBAR_SAFE_MARGIN * 2 - 48));
        guiGraphics.method_51433(this.field_22793, appName, SIDEBAR_SAFE_MARGIN + 44, 17, ModernUi.TEXT_SECONDARY, false);
        renderSidebarHeaderItem(guiGraphics);
        guiGraphics.method_27534(this.field_22793, activePanelTitle(), sidebarWidth / 2, 68, SIDEBAR_MUTED_COLOR);

        int left = safeLeft();
        int top = safeTop();
        int right = safeRight();
        int bottom = safeBottom();
        if (right > left && bottom > top) {
            ModernUi.fillWorkSurface(guiGraphics, left, top, right, bottom);
            int accentRight = Math.min(right - 18, left + 160);
            guiGraphics.method_25294(left + 18, top + 15, accentRight, top + 16, ModernUi.ACCENT_HOVER);
            renderAnimatedContentGlow(guiGraphics, left, top, right, bottom);
        }
    }

    private void renderSidebarHeaderItem(class_332 guiGraphics) {
        if (this.previewStack.method_7960()) {
            return;
        }

        int centerX = itemPreviewCenterX();
        int centerY = itemPreviewCenterY();
        ModernUi.fillItemWell(guiGraphics, centerX, centerY, 34);
        int x = centerX - 8;
        int y = centerY - 8;
        guiGraphics.method_51427(this.previewStack, x, y);
        guiGraphics.method_51431(this.field_22793, this.previewStack, x, y);
    }

    private void renderAnimatedContentGlow(class_332 guiGraphics, int left, int top, int right, int bottom) {
        int range = Math.max(1, bottom - top - 56);
        float phase = (System.currentTimeMillis() % 3600L) / 3600.0F;
        int y = top + 16 + (int) (range * phase);
        guiGraphics.method_25296(left + 2, y, right - 2, Math.min(bottom - 2, y + 24),
                0x00FFB347, ModernUi.alpha(0xFFB347, 18));
    }

    private class_2561 activePanelTitle() {
        return switch (this.activePanel) {
            case ITEM -> class_2561.method_43471(key("item"));
            case NBT -> class_2561.method_43471(key("nbt"));
            case COMPONENTS -> class_2561.method_43471(key("components"));
            case NBT_ADVANCED -> class_2561.method_43471(key("nbtadv"));
            case HIDE_FLAGS -> class_2561.method_43471(key("hideflags"));
            case ENCHANTMENTS -> class_2561.method_43471(key("enchanting"));
            case POTION -> class_2561.method_43471(key("potion"));
            case ATTRIBUTES -> class_2561.method_43471(key("attributes"));
            case COLOR -> class_2561.method_43471(key("color"));
            case SIGN -> class_2561.method_43471(key("sign"));
            case HEAD -> class_2561.method_43471(key("head"));
            case ARMOR_STAND -> class_2561.method_43471(key("armorstand"));
            case FIREWORK -> class_2561.method_43471(key("firework"));
            case CONTAINER -> class_2561.method_43471(key("container"));
            case BANNER -> class_2561.method_43471(key("banner"));
            case DECORATED_POT -> class_2561.method_43471(key("decorated_pot"));
            case SPAWN_EGG -> class_2561.method_43471(key(getSpawnEditorTitleKey()));
            case TRADES -> class_2561.method_43471(key("trades"));
            case TRADE -> class_2561.method_43471(key("trade"));
            case BOOK -> class_2561.method_43471(key("book"));
            case LORE -> class_2561.method_43471(key("lore"));
            case LORE_PAINTER -> class_2561.method_43471(key("lorepainter"));
        };
    }

    private int panelTitleColor() {
        return isSidebarUi() ? ModernUi.TEXT_PRIMARY : MAIN_COLOR;
    }

    private int panelLabelColor() {
        return isSidebarUi() ? ModernUi.TEXT_MUTED : MAIN_COLOR;
    }

    private int panelAccentColor() {
        return isSidebarUi() ? ModernUi.ACCENT_HOVER : CONTRAST_COLOR;
    }

    private int panelSecondaryColor() {
        return isSidebarUi() ? ModernUi.TEXT_SECONDARY : ALT_COLOR;
    }

    private void drawPanelTitle(class_332 guiGraphics, class_2561 title) {
        if (isSidebarUi()) {
            int textWidth = this.field_22793.method_27525(title);
            int plateWidth = class_3532.method_15340(textWidth + 38, Math.min(72, Math.max(1, contentWidth() - 36)),
                    Math.max(72, contentWidth() - 36));
            int left = contentMidX() - plateWidth / 2;
            int top = 13;
            ModernUi.fillToolDrawer(guiGraphics, left, top, left + plateWidth, top + 22, true);
            guiGraphics.method_27534(this.field_22793, title, contentMidX(), top + 7, ModernUi.TEXT_PRIMARY);
            return;
        }

        guiGraphics.method_27534(this.field_22793, title, this.midX, 15, panelTitleColor());
    }

    private void drawCenteredLabel(class_332 guiGraphics, class_2561 label, int centerX, int y) {
        guiGraphics.method_27534(this.field_22793, label, centerX, y, panelLabelColor());
    }

    private void drawModernListRow(class_332 guiGraphics, int x1, int y1, int x2, int y2, boolean selected, boolean hovered) {
        if (isSidebarUi() && (selected || hovered)) {
            ModernUi.fillSelection(guiGraphics, x1, y1, x2, y2, 5, selected || hovered);
        }
    }

    protected void renderItemPanel(class_332 guiGraphics, int mouseX, int mouseY) {
        if (isSidebarUi()) {
            renderSidebarItemPanel(guiGraphics);
            return;
        }

        renderItemTooltipPreview(guiGraphics);
        renderPrettyNbt(guiGraphics);
        renderSmallItem(guiGraphics, this.midX, 40);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("item")));

        drawRightLabel(guiGraphics, class_2561.method_43471(key("item.id")), this.midX - 5, 61);
        drawRightLabel(guiGraphics, class_2561.method_43471(key("item.count")), this.midX - 5, 91);
        drawRightLabel(guiGraphics, class_2561.method_43471(key("item.meta")), this.midX - 5, 121);

        guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("item.name")), this.field_22789 - 110, 35, MAIN_COLOR);
        guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("item.lore")), this.field_22789 - 110, 80, MAIN_COLOR);
    }

    private void renderSidebarItemPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        renderPrettyNbt(guiGraphics);

        renderSidebarItemDrawers(guiGraphics);

        drawPanelTitle(guiGraphics, class_2561.method_43471(key("item")));
        drawFieldLabel(guiGraphics, class_2561.method_43471(key("item.id")), this.itemIdBox);
        drawFieldLabel(guiGraphics, class_2561.method_43471(key("item.count")), this.countBox);
        drawFieldLabel(guiGraphics, class_2561.method_43471(key("item.meta")), this.damageBox);
        drawFieldLabel(guiGraphics, class_2561.method_43471(key("item.name")), this.nameBox);

        if (!this.loreBoxes.isEmpty()) {
            for (int i = 0; i < this.loreBoxes.size(); i++) {
                class_342 loreBox = this.loreBoxes.get(i);
                guiGraphics.method_51439(this.field_22793, class_2561.method_43470("Lore " + (i + 1)),
                        loreBox.method_46426(), loreBox.method_46427() - 9, ModernUi.TEXT_MUTED, false);
            }
        }

        if (canShowSidebarActionGrid()) {
            guiGraphics.method_51439(this.field_22793, class_2561.method_43471(key("ui.actions")),
                    getActionGridX(), getActionGridY() - 12, ModernUi.TEXT_MUTED, false);
        }
    }

    private void renderSidebarItemDrawers(class_332 guiGraphics) {
        if (this.itemIdBox != null && this.countBox != null && this.damageBox != null) {
            int left = safeLeft() + 8;
            int right = Math.min(safeRight() - 8, Math.max(this.itemIdBox.method_46426() + this.itemIdBox.method_25368(),
                    this.damageBox.method_46426() + this.damageBox.method_25368()) + 12);
            int top = Math.max(42, this.itemIdBox.method_46427() - 20);
            int bottom = this.damageBox.method_46427() + this.damageBox.method_25364() + 12;
            if (right > left && bottom > top) {
                ModernUi.fillToolDrawer(guiGraphics, left, top, right, bottom, false);
            }
        }

        if (this.nameBox != null) {
            int left = Math.max(safeLeft(), this.nameBox.method_46426() - SIDEBAR_DRAWER_PADDING);
            int right = Math.min(safeRight(), this.nameBox.method_46426() + this.nameBox.method_25368() + 58);
            int top = Math.max(42, this.nameBox.method_46427() - 20);
            int bottom = Math.min(sidebarBottomButtonY() - 8, sidebarNameCardBottom() + 10);
            if (right > left && bottom > top) {
                ModernUi.fillToolDrawer(guiGraphics, left, top, right, bottom, false);
            }
        }

        if (canShowSidebarActionGrid()) {
            int width = getActionGridButtonWidth();
            int left = Math.max(safeLeft(), getActionGridX() - SIDEBAR_DRAWER_PADDING);
            int right = Math.min(safeRight(), getActionGridX() + width * 2 + SIDEBAR_CONTENT_GAP + SIDEBAR_DRAWER_PADDING);
            int top = getActionGridY() - 18;
            int bottom = sidebarBottomButtonY() - 8;
            if (right > left && bottom > top) {
                ModernUi.fillToolDrawer(guiGraphics, left, top, right, bottom, false);
            }
        }
    }

    private void drawFieldLabel(class_332 guiGraphics, class_2561 text, class_342 box) {
        if (box != null) {
            guiGraphics.method_51439(this.field_22793, text, box.method_46426(), box.method_46427() - 9, ModernUi.TEXT_MUTED, false);
        }
    }

    protected void renderNbtPanel(class_332 guiGraphics, int mouseX, int mouseY) {
        renderItemTooltipPreview(guiGraphics);
        renderPrettyNbt(guiGraphics);
        renderSmallItem(guiGraphics, this.midX, 38);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("nbt")));
        if (!this.nbtFeedback.isEmpty()) {
            guiGraphics.method_25300(this.field_22793, this.nbtFeedback, this.midX, 130, this.nbtFeedbackGood ? GOOD_GREEN : BAD_RED);
        }
    }

    protected void renderComponentsPanel(class_332 guiGraphics, int mouseX, int mouseY) {
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("components")));
        renderComponentEditorPanel(guiGraphics, mouseX, mouseY);
    }

    protected void renderNbtAdvancedPanel(class_332 guiGraphics, int mouseX, int mouseY) {
        if (!isSidebarUi()) {
            int mainColor = 0xFF1EC8FF;
            guiGraphics.method_25296(18, 18, this.field_22789 - 18, 38, 0xFF323232, mainColor);
            guiGraphics.method_25294(20, 40, this.field_22789 - 20, this.field_22790 - 20, 0xDE323232);
            guiGraphics.method_25294(18, 38, this.field_22789 - 18, 40, mainColor);
            guiGraphics.method_25294(18, 40, 20, this.field_22790 - 20, mainColor);
            guiGraphics.method_25294(this.field_22789 - 20, 40, this.field_22789 - 18, this.field_22790 - 20, mainColor);
            guiGraphics.method_25294(18, this.field_22790 - 20, this.field_22789 - 18, this.field_22790 - 18, mainColor);
            guiGraphics.method_25303(this.field_22793, ModSource.MODID + " - " + class_2561.method_43471(key("nbtadv")).getString(), 25, 26, CYAN);

            List<NbtRow> rows = buildNbtRows();
            int visibleRows = getNbtAdvancedVisibleRows();
            this.advancedScroll = class_3532.method_15340(this.advancedScroll, 0, Math.max(0, rows.size() - visibleRows));
            int end = Math.min(rows.size(), this.advancedScroll + visibleRows);
            for (int i = this.advancedScroll; i < end; i++) {
                NbtRow row = rows.get(i);
                int y = 48 + (i - this.advancedScroll) * 12;
                int x = 25 + row.depth() * 12;
                int color = row.isExpandable() ? MAIN_COLOR : 0xFFFFFFFF;
                guiGraphics.method_25303(this.field_22793, row.displayText(), x, y, color);
            }

            String unfinished = class_2561.method_43471(key("nbtadv.unfinished")).getString();
            guiGraphics.method_25303(this.field_22793, unfinished, this.field_22789 - this.field_22793.method_1727(unfinished) - 25, this.field_22790 - 30, 0xFFFFFF32);
            return;
        }

        int left = isSidebarUi() ? safeLeft() + 10 : 18;
        int top = isSidebarUi() ? safeTop() + 10 : 18;
        int right = isSidebarUi() ? safeRight() - 10 : this.field_22789 - 18;
        int bottom = isSidebarUi() ? sidebarBottomButtonY() - 8 : this.field_22790 - 18;
        ModernUi.fillGlassPanel(guiGraphics, left, top, right, bottom, 8);
        guiGraphics.method_25296(left + 1, top + 1, right - 1, top + 22,
                ModernUi.alpha(0xFFB347, 64), ModernUi.alpha(0x62D1C7, 18));
        guiGraphics.method_51433(this.field_22793, ModSource.MODID + " / " + class_2561.method_43471(key("nbtadv")).getString(),
                left + 9, top + 8, ModernUi.TEXT_PRIMARY, false);

        List<NbtRow> rows = buildNbtRows();
        int visibleRows = getNbtAdvancedVisibleRows();
        this.advancedScroll = class_3532.method_15340(this.advancedScroll, 0, Math.max(0, rows.size() - visibleRows));
        int end = Math.min(rows.size(), this.advancedScroll + visibleRows);
        for (int i = this.advancedScroll; i < end; i++) {
            NbtRow row = rows.get(i);
            int y = top + 32 + (i - this.advancedScroll) * 12;
            int x = left + 9 + row.depth() * 12;
            int color = row.isExpandable() ? ModernUi.ACCENT_HOVER : ModernUi.TEXT_PRIMARY;
            if ((i - this.advancedScroll) % 2 == 0) {
                guiGraphics.method_25294(left + 5, y - 2, right - 5, y + 10, 0x171FFFFF);
            }
            guiGraphics.method_51433(this.field_22793, row.displayText(), x, y, color, false);
        }

        String unfinished = class_2561.method_43471(key("nbtadv.unfinished")).getString();
        guiGraphics.method_25303(this.field_22793, unfinished, right - this.field_22793.method_1727(unfinished) - 10, bottom - 13, ModernUi.WARM);
    }

    protected void renderHideFlagsPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        renderSimpleItemPanelTitle(guiGraphics, "hideflags", 40);
    }

    protected void renderBookPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        renderSmallItem(guiGraphics, this.midX, 40);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("book")));
        if (this.bookTitleBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("book.title")), this.bookTitleBox.method_46426() - 5, this.bookTitleBox.method_46427() + 6);
        }
        if (this.bookAuthorBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("book.author")), this.bookAuthorBox.method_46426() - 5, this.bookAuthorBox.method_46427() + 6);
        }
        guiGraphics.method_27534(this.field_22793, class_2561.method_43469(key("book.pages"), getBookPageCount()),
                this.midX, 128, panelAccentColor());
    }

    protected void renderHeadPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        renderPrettyNbt(guiGraphics);
        renderSmallItem(guiGraphics, this.midX, 36);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("head")));
        if (this.headOwnerBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("head.owner")), this.headOwnerBox.method_46426() - 5, this.headOwnerBox.method_46427() + 6);
        }
        if (this.headUuidBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("head.uuid")), this.headUuidBox.method_46426() - 5, this.headUuidBox.method_46427() + 6);
        }
        if (this.headTextureBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("head.texture")), this.headTextureBox.method_46426() - 5, this.headTextureBox.method_46427() + 6);
        }
        if (this.headTextureSignatureBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("head.signature")),
                    this.headTextureSignatureBox.method_46426() - 5, this.headTextureSignatureBox.method_46427() + 6);
        }
    }

    protected void renderArmorStandPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        renderPrettyNbt(guiGraphics);
        renderSmallItem(guiGraphics, this.midX, 36);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("armorstand")));
    }

    protected void renderFireworkPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        renderPrettyNbt(guiGraphics);
        renderSmallItem(guiGraphics, this.midX, 36);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("firework")));
        int infoX = Math.min(this.field_22789 - 155, this.midX + 96);
        guiGraphics.method_27535(this.field_22793, class_2561.method_43469(key("firework.explosions"), getFireworkExplosionCount()),
                infoX, 58, panelAccentColor());
    }

    protected void renderSimpleItemPanelTitle(class_332 guiGraphics, String titleKey, int itemY) {
        renderSmallItem(guiGraphics, this.midX, itemY);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key(titleKey)));
    }

    protected void renderEnchantmentsPanel(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int centerX = contentMidX();
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("enchanting")));
        drawCenteredLabel(guiGraphics, class_2561.method_43471(key("enchanting.search")),
                this.enchantFilterBox.method_46426() + this.enchantFilterBox.method_25368() / 2,
                this.enchantFilterBox.method_46427() - 12);
        renderActiveEnchantments(guiGraphics);
        updateMouseDistance(mouseX, mouseY);
        renderLargePreviewItem(guiGraphics);

        List<class_1887> filteredEnchantments = getVisibleEnchantments(this.previewStack);
        List<EnchantmentGroupEntry> enchantmentGroups = getFoldedEnchantmentGroups(this.previewStack);
        if (!enchantmentGroups.isEmpty()) {
            int radius = getRingRadius();
            double angle = (2.0D * Math.PI) / enchantmentGroups.size();
            double rotation = (this.rotOff + (Math.abs(this.mouseDist - radius) >= RING_HOVER_WIDTH ? partialTick : 0.0D)) / 60.0D;
            for (int i = 0; i < enchantmentGroups.size(); i++) {
                EnchantmentGroupEntry group = enchantmentGroups.get(i);
                double groupAngle = rotation + angle * i;
                int x = (int) (centerX + radius * Math.cos(groupAngle));
                int y = (int) (this.midY + radius * Math.sin(groupAngle));
                String label = class_2561.method_43469(key("registry_group.entry"), group.namespace(), group.enchantments().size()).getString();
                guiGraphics.method_25300(this.field_22793, this.field_22793.method_27523(label, 118), x, y - 17, panelTitleColor());
                guiGraphics.method_51427(this.enchantBook, x - 8, y - 8);
                guiGraphics.method_25294(x - 1, y - 1, x + 1, y + 1, isSidebarUi() ? ModernUi.ACCENT_HOVER : 0xFFFFFFFF);
            }
            return;
        }

        if (filteredEnchantments.isEmpty()) {
            guiGraphics.method_27534(this.field_22793, class_2561.method_43471(key("no_enchantment_matches")),
                    centerX, this.midY + 34, panelAccentColor());
            return;
        }

        int radius = getRingRadius();
        double angle = (2.0D * Math.PI) / filteredEnchantments.size();
        double rotation = (this.rotOff + (Math.abs(this.mouseDist - radius) >= RING_HOVER_WIDTH ? partialTick : 0.0D)) / 60.0D;
        for (int i = 0; i < filteredEnchantments.size(); i++) {
            class_1887 enchantment = filteredEnchantments.get(i);
            double enchantmentAngle = rotation + angle * i;
            int x = (int) (centerX + radius * Math.cos(enchantmentAngle));
            int y = (int) (this.midY + radius * Math.sin(enchantmentAngle));
            guiGraphics.method_25300(this.field_22793, this.field_22793.method_27523(formatRingEnchantmentName(enchantment), 118), x, y - 17, panelTitleColor());
            guiGraphics.method_51427(this.enchantBook, x - 8, y - 8);
            guiGraphics.method_25294(x - 1, y - 1, x + 1, y + 1, isSidebarUi() ? ModernUi.ACCENT_HOVER : 0xFFFFFFFF);
        }

        if (isMouseOverCenter(mouseX, mouseY)) {
            guiGraphics.method_27534(this.field_22793, class_2561.method_43471(key("enchanting.addall")),
                    centerX, this.midY, panelAccentColor());
        }
    }

    protected void renderPotionPanel(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int centerX = contentMidX();
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("potion")));
        List<class_1293> activeEffects = getCustomPotionEffects();
        int start = this.midY - 5 * activeEffects.size();
        for (int i = 0; i < activeEffects.size(); i++) {
            class_1293 effect = activeEffects.get(i);
            int rowY = start + i * 10;
            if (isSidebarUi()) {
                ModernUi.fillSelection(guiGraphics, editorListTextLeft() - 4, rowY - 2,
                        editorListTextLeft() + Math.min(174, this.field_22793.method_1727(formatPotionEffect(effect)) + 12), rowY + 10, 4, false);
            }
            int color = effect.method_5579().comp_349().method_18792() == class_4081.field_18272 ? BAD_RED : panelAccentColor();
            guiGraphics.method_51433(this.field_22793, formatPotionEffect(effect), editorListTextLeft(), rowY, color, false);
        }

        drawCenteredLabel(guiGraphics, class_2561.method_43471(key("enchanting.search")),
                this.potionFilterBox.method_46426() + this.potionFilterBox.method_25368() / 2,
                this.potionFilterBox.method_46427() - 12);
        guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("potion.time")), editorControlLeft() + 47, this.field_22790 - 56, panelLabelColor());
        guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("potion.level")), editorControlLeft() + 47, this.field_22790 - 29, panelLabelColor());

        updateMouseDistance(mouseX, mouseY);
        renderLargePreviewItem(guiGraphics);

        List<class_1291> filteredEffects = getVisiblePotionEffects();
        List<PotionGroupEntry> potionGroups = getFoldedPotionGroups();
        if (!potionGroups.isEmpty()) {
            int radius = getRingRadius();
            double angle = (2.0D * Math.PI) / potionGroups.size();
            double rotation = (this.rotOff + (Math.abs(this.mouseDist - radius) >= RING_HOVER_WIDTH ? partialTick : 0.0D)) / 60.0D;
            for (int i = 0; i < potionGroups.size(); i++) {
                PotionGroupEntry group = potionGroups.get(i);
                double groupAngle = rotation + angle * i;
                int x = (int) (centerX + radius * Math.cos(groupAngle));
                int y = (int) (this.midY + radius * Math.sin(groupAngle));
                String label = class_2561.method_43469(key("registry_group.entry"), group.namespace(), group.effects().size()).getString();
                guiGraphics.method_25300(this.field_22793, this.field_22793.method_27523(label, 118), x, y - 17, panelTitleColor());
                guiGraphics.method_51427(this.potionIcon, x - 8, y - 8);
                guiGraphics.method_25294(x - 1, y - 1, x + 1, y + 1, isSidebarUi() ? ModernUi.ACCENT_HOVER : 0xFFFFFFFF);
            }
            return;
        }

        if (filteredEffects.isEmpty()) {
            guiGraphics.method_27534(this.field_22793, class_2561.method_43471(key("no_potion_matches")),
                    centerX, this.midY + 34, panelAccentColor());
            return;
        }

        int radius = getRingRadius();
        double angle = (2.0D * Math.PI) / filteredEffects.size();
        double rotation = (this.rotOff + (Math.abs(this.mouseDist - radius) >= RING_HOVER_WIDTH ? partialTick : 0.0D)) / 60.0D;
        for (int i = 0; i < filteredEffects.size(); i++) {
            class_1291 effect = filteredEffects.get(i);
            double effectAngle = rotation + angle * i;
            int x = (int) (centerX + radius * Math.cos(effectAngle));
            int y = (int) (this.midY + radius * Math.sin(effectAngle));
            guiGraphics.method_25300(this.field_22793, this.field_22793.method_27523(formatPotionRingName(effect), 118), x, y - 17, panelTitleColor());
            guiGraphics.method_51427(this.potionIcon, x - 8, y - 8);
            guiGraphics.method_25294(x - 1, y - 1, x + 1, y + 1, isSidebarUi() ? ModernUi.ACCENT_HOVER : 0xFFFFFFFF);
        }

        if (isMouseOverCenter(mouseX, mouseY)) {
            guiGraphics.method_27534(this.field_22793, class_2561.method_43471(key("enchanting.addall")),
                    centerX, this.midY, panelAccentColor());
        }
    }

    protected void renderAttributesPanel(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int centerX = contentMidX();
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("attributes")));
        drawCenteredLabel(guiGraphics, class_2561.method_43471(key("enchanting.search")),
                this.attributeFilterBox.method_46426() + this.attributeFilterBox.method_25368() / 2,
                this.attributeFilterBox.method_46427() - 12);
        List<AttributeEntry> entries = getAttributeModifierEntries();
        int start = this.midY - 5 * entries.size();
        for (int i = 0; i < entries.size(); i++) {
            int rowY = start + i * 10;
            if (isSidebarUi()) {
                ModernUi.fillSelection(guiGraphics, editorListTextLeft() - 4, rowY - 2,
                        editorListTextLeft() + Math.min(188, this.field_22793.method_1727(formatAttributeEntry(entries.get(i))) + 12), rowY + 10, 4, false);
            }
            guiGraphics.method_51433(this.field_22793, formatAttributeEntry(entries.get(i)), editorListTextLeft(), rowY, panelTitleColor(), false);
        }

        guiGraphics.method_25303(this.field_22793, ".", editorControlLeft() + 81, this.field_22790 - 26, panelTitleColor());
        updateMouseDistance(mouseX, mouseY);
        renderLargePreviewItem(guiGraphics);

        List<class_1320> attributes = getVisibleAttributes();
        List<AttributeGroupEntry> attributeGroups = getFoldedAttributeGroups();
        if (!attributeGroups.isEmpty()) {
            int radius = getRingRadius();
            double angle = (2.0D * Math.PI) / attributeGroups.size();
            double rotation = (this.rotOff + (Math.abs(this.mouseDist - radius) >= RING_HOVER_WIDTH ? partialTick : 0.0D)) / 60.0D;
            for (int i = 0; i < attributeGroups.size(); i++) {
                AttributeGroupEntry group = attributeGroups.get(i);
                double groupAngle = rotation + angle * i;
                int x = (int) (centerX + radius * Math.cos(groupAngle));
                int y = (int) (this.midY + radius * Math.sin(groupAngle));
                String label = class_2561.method_43469(key("registry_group.entry"), group.namespace(), group.attributes().size()).getString();
                guiGraphics.method_25300(this.field_22793, this.field_22793.method_27523(label, 118), x, y - 17, panelTitleColor());
                guiGraphics.method_51427(this.attributeIcon, x - 8, y - 8);
                guiGraphics.method_25294(x - 1, y - 1, x + 1, y + 1, isSidebarUi() ? ModernUi.ACCENT_HOVER : 0xFFFFFFFF);
            }
            return;
        }

        if (attributes.isEmpty()) {
            guiGraphics.method_27534(this.field_22793, class_2561.method_43471(key("no_attribute_matches")),
                    centerX, this.midY + 34, panelAccentColor());
            return;
        }

        int radius = getRingRadius();
        double angle = (2.0D * Math.PI) / attributes.size();
        double rotation = (this.rotOff + (Math.abs(this.mouseDist - radius) >= RING_HOVER_WIDTH ? partialTick : 0.0D)) / 60.0D;
        for (int i = 0; i < attributes.size(); i++) {
            class_1320 attribute = attributes.get(i);
            double attributeAngle = rotation + angle * i;
            int x = (int) (centerX + radius * Math.cos(attributeAngle));
            int y = (int) (this.midY + radius * Math.sin(attributeAngle));
            guiGraphics.method_25300(this.field_22793, this.field_22793.method_27523(class_2561.method_43471(attribute.method_26830()).getString(), 118),
                    x, y - 17, panelTitleColor());
            guiGraphics.method_51427(this.attributeIcon, x - 8, y - 8);
            guiGraphics.method_25294(x - 1, y - 1, x + 1, y + 1, isSidebarUi() ? ModernUi.ACCENT_HOVER : 0xFFFFFFFF);
        }
    }

    protected void renderColorPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        renderPrettyNbt(guiGraphics);

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().scale(4.0F, 4.0F);
        guiGraphics.method_51427(this.previewStack, isSidebarUi() ? this.midX / 4 - 8 : this.field_22789 / 8 - 8, 5);
        guiGraphics.method_51448().popMatrix();

        drawPanelTitle(guiGraphics, class_2561.method_43471(key("color")));

        int color = getEditorColor();
        if (this.redSlider != null && this.greenSlider != null && this.blueSlider != null) {
            if (isSidebarUi()) {
                ModernUi.fillPanel(guiGraphics, this.redSlider.method_46426() - 9, this.redSlider.method_46427() - 9,
                        this.blueSlider.method_46426() + this.blueSlider.method_25368() + 9,
                        this.blueSlider.method_46427() + this.blueSlider.method_25364() + 9,
                        8, ModernUi.lerpColor(ModernUi.SURFACE_SOFT, argb(110, color), 0.35F), ModernUi.BORDER);
                guiGraphics.method_25294(this.redSlider.method_46426() - 2, this.redSlider.method_46427() - 2,
                        this.redSlider.method_46426() + this.redSlider.method_25368() + 2,
                        this.redSlider.method_46427() + this.redSlider.method_25364() + 2,
                        argb(120, getRed(color) << 16));
                guiGraphics.method_25294(this.greenSlider.method_46426() - 2, this.greenSlider.method_46427() - 2,
                        this.greenSlider.method_46426() + this.greenSlider.method_25368() + 2,
                        this.greenSlider.method_46427() + this.greenSlider.method_25364() + 2,
                        argb(120, getGreen(color) << 8));
                guiGraphics.method_25294(this.blueSlider.method_46426() - 2, this.blueSlider.method_46427() - 2,
                        this.blueSlider.method_46426() + this.blueSlider.method_25368() + 2,
                        this.blueSlider.method_46427() + this.blueSlider.method_25364() + 2,
                        argb(120, getBlue(color)));
            } else {
                guiGraphics.method_25294(this.redSlider.method_46426() - 5, this.redSlider.method_46427() - 5,
                        this.blueSlider.method_46426() + this.blueSlider.method_25368() + 5,
                        this.blueSlider.method_46427() + this.blueSlider.method_25364() + 5,
                        argb(100, color));
                guiGraphics.method_25294(this.redSlider.method_46426() - 2, this.redSlider.method_46427() - 2,
                        this.redSlider.method_46426() + this.redSlider.method_25368() + 2,
                        this.redSlider.method_46427() + this.redSlider.method_25364() + 2,
                        argb(255, getRed(color) << 16));
                guiGraphics.method_25294(this.greenSlider.method_46426() - 2, this.greenSlider.method_46427() - 2,
                        this.greenSlider.method_46426() + this.greenSlider.method_25368() + 2,
                        this.greenSlider.method_46427() + this.greenSlider.method_25364() + 2,
                        argb(255, getGreen(color) << 8));
                guiGraphics.method_25294(this.blueSlider.method_46426() - 2, this.blueSlider.method_46427() - 2,
                        this.blueSlider.method_46426() + this.blueSlider.method_25368() + 2,
                        this.blueSlider.method_46427() + this.blueSlider.method_25364() + 2,
                        argb(255, getBlue(color)));
            }
            renderDyeGrid(guiGraphics);
        }
    }

    protected void renderSignPanel(class_332 guiGraphics) {
        renderSmallItem(guiGraphics, this.midX, 35);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("sign")));

        for (int i = 0; i < SIGN_LINES && i < this.signBoxes.size(); i++) {
            class_342 box = this.signBoxes.get(i);
            drawRightLabel(guiGraphics, class_2561.method_43469(key("sign.line"), i + 1), box.method_46426() - 5, box.method_46427() + 6);
        }
        if (this.signCommandBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("sign.command")),
                    this.signCommandBox.method_46426() - 5, this.signCommandBox.method_46427() + 6);
        }
    }

    protected void renderContainerPanel(class_332 guiGraphics) {
        renderSmallItem(guiGraphics, this.midX, 34);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("container")));

        int gridX = getContainerGridX();
        int gridY = getContainerGridY();
        if (isSidebarUi()) {
            ModernUi.fillPanel(guiGraphics, gridX - 7, gridY - 7,
                    gridX + CONTAINER_COLUMNS * CONTAINER_SLOT_PIXEL_SIZE + 7,
                    gridY + CONTAINER_ROWS * CONTAINER_SLOT_PIXEL_SIZE + 7, 8, 0xA8101821, ModernUi.BORDER);
        }
        for (int slot = 0; slot < CONTAINER_SIZE; slot++) {
            int x = gridX + (slot % CONTAINER_COLUMNS) * CONTAINER_SLOT_PIXEL_SIZE;
            int y = gridY + (slot / CONTAINER_COLUMNS) * CONTAINER_SLOT_PIXEL_SIZE;
            boolean selected = slot == this.selectedContainerSlot;
            if (isSidebarUi()) {
                ModernUi.fillSlot(guiGraphics, x, y, selected);
            } else {
                guiGraphics.method_25294(x - 1, y - 1, x + 17, y + 17, selected ? CONTRAST_COLOR : 0xFF555555);
                guiGraphics.method_25294(x, y, x + ITEM_SIZE, y + ITEM_SIZE, 0xFF1C1C1C);
            }

            class_1799 slotStack = getContainerSlotItem(slot);
            if (!slotStack.method_7960()) {
                guiGraphics.method_51427(slotStack, x, y);
                guiGraphics.method_51431(this.field_22793, slotStack, x, y);
            }
        }

        class_2561 selected = class_2561.method_43469(key("container.slot"), this.selectedContainerSlot + 1);
        class_2561 itemCount = class_2561.method_43469(key("container.items"), getContainerItemCount());
        int infoY = gridY + CONTAINER_ROWS * CONTAINER_SLOT_PIXEL_SIZE + 6;
        guiGraphics.method_27535(this.field_22793, selected, gridX, infoY, isSidebarUi() ? ModernUi.TEXT_PRIMARY : MAIN_COLOR);
        guiGraphics.method_27535(this.field_22793, itemCount,
                gridX + CONTAINER_COLUMNS * CONTAINER_SLOT_PIXEL_SIZE - this.field_22793.method_27525(itemCount), infoY,
                isSidebarUi() ? ModernUi.TEXT_MUTED : ALT_COLOR);
        if (this.containerSlotNbtBox != null) {
            drawCenteredLabel(guiGraphics, class_2561.method_43471(key("container.slot_nbt")),
                    this.containerSlotNbtBox.method_46426() + this.containerSlotNbtBox.method_25368() / 2,
                    this.containerSlotNbtBox.method_46427() - 12);
        }
    }

    protected void renderBannerPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("banner")));

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(this.midX, 78);
        guiGraphics.method_51448().scale(4.0F, 4.0F);
        guiGraphics.method_51427(this.previewStack, -8, -8);
        guiGraphics.method_51448().popMatrix();

        drawCenteredLabel(guiGraphics, class_2561.method_43471(key("banner.search")),
                this.bannerPatternFilterBox.method_46426() + this.bannerPatternFilterBox.method_25368() / 2,
                this.bannerPatternFilterBox.method_46427() - 12);

        List<BannerPatternEntry> patterns = getFilteredBannerPatterns();
        clampBannerPatternSelection(patterns);
        int listX = bannerPatternListX();
        int listWidth = bannerPatternListWidth();
        if (isSidebarUi()) {
            ModernUi.fillPanel(guiGraphics, listX - 5, getBannerPatternRowY(0) - 7, listX + listWidth + 5,
                    getBannerPatternRowY(BANNER_PATTERN_ROWS - 1) + 15, 8, ModernUi.SURFACE, ModernUi.BORDER);
        }
        if (patterns.isEmpty()) {
            guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("banner.no_match")),
                    listX + 2, getBannerPatternRowY(0), BAD_RED);
        } else {
            int end = Math.min(patterns.size(), this.bannerPatternScroll + BANNER_PATTERN_ROWS);
            for (int i = this.bannerPatternScroll; i < end; i++) {
                int y = getBannerPatternRowY(i - this.bannerPatternScroll);
                boolean selectedPattern = i == this.selectedBannerPatternIndex;
                int color = isSidebarUi()
                        ? (selectedPattern ? ModernUi.ACCENT_HOVER : ModernUi.TEXT_PRIMARY)
                        : (selectedPattern ? CONTRAST_COLOR : MAIN_COLOR);
                class_2561 name = getBannerPatternName(patterns.get(i), getBannerPatternColor());
                drawModernListRow(guiGraphics, listX, y - 3, listX + listWidth, y + 10, selectedPattern, false);
                guiGraphics.method_25303(this.field_22793, this.field_22793.method_27523(name.getString(), listWidth - 5),
                        listX + 2, y, color);
            }
        }

        class_2561 selected = patterns.isEmpty()
                ? class_2561.method_43471(key("banner.no_match"))
                : getBannerPatternName(patterns.get(this.selectedBannerPatternIndex), getBannerPatternColor());
        guiGraphics.method_27534(this.field_22793, class_2561.method_43469(key("banner.selected"), selected),
                this.midX, this.field_22790 - 78, panelTitleColor());

        renderBannerPatternLayers(guiGraphics);
    }

    protected void renderDecoratedPotPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("decorated_pot")));

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(this.midX, 78);
        guiGraphics.method_51448().scale(4.0F, 4.0F);
        guiGraphics.method_51427(this.previewStack, -8, -8);
        guiGraphics.method_51448().popMatrix();

        drawCenteredLabel(guiGraphics, class_2561.method_43471(key("decorated_pot.search")),
                this.potterySherdFilterBox.method_46426() + this.potterySherdFilterBox.method_25368() / 2,
                this.potterySherdFilterBox.method_46427() - 12);

        List<PotterySherdEntry> sherds = getFilteredPotterySherds();
        clampPotterySherdSelection(sherds);
        int listX = potterySherdListX();
        int listWidth = potterySherdListWidth();
        if (isSidebarUi()) {
            ModernUi.fillPanel(guiGraphics, listX - 5, getPotterySherdRowY(0) - 7, listX + listWidth + 5,
                    getPotterySherdRowY(POTTERY_SHERD_ROWS - 1) + 15, 8, ModernUi.SURFACE, ModernUi.BORDER);
        }
        if (sherds.isEmpty()) {
            guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("decorated_pot.no_match")),
                    listX + 2, getPotterySherdRowY(0), BAD_RED);
        } else {
            int end = Math.min(sherds.size(), this.potterySherdScroll + POTTERY_SHERD_ROWS);
            for (int i = this.potterySherdScroll; i < end; i++) {
                int y = getPotterySherdRowY(i - this.potterySherdScroll);
                boolean selectedSherd = i == this.selectedPotterySherdIndex;
                int color = isSidebarUi()
                        ? (selectedSherd ? ModernUi.ACCENT_HOVER : ModernUi.TEXT_PRIMARY)
                        : (selectedSherd ? CONTRAST_COLOR : MAIN_COLOR);
                class_2561 name = getPotterySherdName(sherds.get(i));
                drawModernListRow(guiGraphics, listX, y - 3, listX + listWidth, y + 10, selectedSherd, false);
                guiGraphics.method_25303(this.field_22793, this.field_22793.method_27523(name.getString(), listWidth - 5),
                        listX + 2, y, color);
            }
        }

        class_2561 selected = sherds.isEmpty()
                ? class_2561.method_43471(key("decorated_pot.no_match"))
                : getPotterySherdName(sherds.get(this.selectedPotterySherdIndex));
        guiGraphics.method_27534(this.field_22793, class_2561.method_43469(key("decorated_pot.selected"), selected),
                this.midX, this.field_22790 - 78, panelTitleColor());
        guiGraphics.method_27534(this.field_22793, class_2561.method_43469(key("decorated_pot.editing"),
                getDecoratedPotSideName(this.selectedDecoratedPotSide), getDecoratedPotSideItemName(this.selectedDecoratedPotSide)),
                this.midX, 112, panelSecondaryColor());

        renderDecoratedPotSides(guiGraphics);
    }

    protected void renderSpawnEggPanel(class_332 guiGraphics) {
        renderItemTooltipPreview(guiGraphics);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key(getSpawnEditorTitleKey())));

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(this.midX, 78);
        guiGraphics.method_51448().scale(4.0F, 4.0F);
        guiGraphics.method_51427(this.previewStack, -8, -8);
        guiGraphics.method_51448().popMatrix();

        drawCenteredLabel(guiGraphics, class_2561.method_43471(key("spawnegg.search")),
                this.spawnEggEntityFilterBox.method_46426() + this.spawnEggEntityFilterBox.method_25368() / 2,
                this.spawnEggEntityFilterBox.method_46427() - 12);

        List<SpawnEggEntityEntry> entities = getFilteredSpawnEggEntities();
        clampSpawnEggEntitySelection(entities);
        int listX = spawnEggEntityListX();
        int listWidth = spawnEggEntityListWidth();
        if (isSidebarUi()) {
            ModernUi.fillPanel(guiGraphics, listX - 5, getSpawnEggEntityRowY(0) - 7, listX + listWidth + 5,
                    getSpawnEggEntityRowY(SPAWN_EGG_ENTITY_ROWS - 1) + 15, 8, ModernUi.SURFACE, ModernUi.BORDER);
        }
        if (entities.isEmpty()) {
            guiGraphics.method_27535(this.field_22793, class_2561.method_43471(key("spawnegg.no_match")),
                    listX + 2, getSpawnEggEntityRowY(0), BAD_RED);
        } else {
            int end = Math.min(entities.size(), this.spawnEggEntityScroll + SPAWN_EGG_ENTITY_ROWS);
            for (int i = this.spawnEggEntityScroll; i < end; i++) {
                int y = getSpawnEggEntityRowY(i - this.spawnEggEntityScroll);
                boolean selectedEntity = i == this.selectedSpawnEggEntityIndex;
                int color = isSidebarUi()
                        ? (selectedEntity ? ModernUi.ACCENT_HOVER : ModernUi.TEXT_PRIMARY)
                        : (selectedEntity ? CONTRAST_COLOR : MAIN_COLOR);
                drawModernListRow(guiGraphics, listX, y - 3, listX + listWidth, y + 10, selectedEntity, false);
                guiGraphics.method_25303(this.field_22793, this.field_22793.method_27523(formatSpawnEggEntityEntry(entities.get(i)), listWidth - 5),
                        listX + 2, y, color);
            }
        }

        class_2561 selected = entities.isEmpty()
                ? class_2561.method_43471(key("spawnegg.no_match"))
                : getSpawnEggEntityName(entities.get(this.selectedSpawnEggEntityIndex));
        guiGraphics.method_27534(this.field_22793, class_2561.method_43469(key("spawnegg.selected"), selected),
                this.midX, this.field_22790 - 78, panelTitleColor());
        guiGraphics.method_27534(this.field_22793, class_2561.method_43469(key("spawnegg.current"), getCurrentSpawnEggEntityName()),
                this.midX, 120, panelSecondaryColor());

        int controlsX = getSpawnEggControlsX();
        drawCenteredLabel(guiGraphics, class_2561.method_43471(key("spawnegg.tags")),
                controlsX + getSpawnEggControlsWidth() / 2, getSpawnEggTagRowY(0) - 12);

        List<SpawnEggTagRow> rows = getSpawnEggTagRows();
        this.spawnEggTagScroll = class_3532.method_15340(this.spawnEggTagScroll, 0, Math.max(0, rows.size() - SPAWN_EGG_TAG_ROWS));
        int end = Math.min(rows.size(), this.spawnEggTagScroll + SPAWN_EGG_TAG_ROWS);
        for (int i = this.spawnEggTagScroll; i < end; i++) {
            SpawnEggTagRow row = rows.get(i);
            if (row.type() != SpawnEggTagRowType.BOOLEAN
                    && row.type() != SpawnEggTagRowType.PRESENCE
                    && row.type() != SpawnEggTagRowType.CHOICE) {
                drawRightLabel(guiGraphics, class_2561.method_43471(key("spawnegg." + row.translationSuffix())),
                        controlsX + 66, getSpawnEggTagRowY(i - this.spawnEggTagScroll) + 6);
            }
        }
    }

    protected void renderTradesPanel(class_332 guiGraphics, int mouseX, int mouseY) {
        renderSmallItem(guiGraphics, this.midX, 35);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("trades")));

        class_2499 trades = getVillagerTradeRecipes();
        int size = trades.size();
        boolean foundHover = false;
        if (isSidebarUi()) {
            int listWidth = Math.min(getTradeListWidth(), Math.max(1, contentWidth() - 48));
            int top = size == 0 ? getTradeListRowY(0, 0) - 8 : getTradeListRowY(0, size) - 8;
            int bottom = getTradeListRowY(size, size) + 18;
            ModernUi.fillPanel(guiGraphics, this.midX - listWidth / 2 - 8, top,
                    this.midX + listWidth / 2 + 8, bottom, 8, ModernUi.SURFACE, ModernUi.BORDER);
        }
        for (int i = 0; i < size; i++) {
            String tradeText = formatTradeRecipe(trades.method_68582(i));
            boolean hovered = !foundHover && isMouseOverCenteredText(mouseX, mouseY, tradeText, this.midX, getTradeListRowY(i, size));
            foundHover = foundHover || hovered;
            int rowY = getTradeListRowY(i, size);
            if (isSidebarUi() && (hovered || i == this.selectedTradeIndex)) {
                int rowWidth = Math.min(getTradeListWidth(), Math.max(1, contentWidth() - 48));
                ModernUi.fillSelection(guiGraphics, this.midX - rowWidth / 2, rowY - 5, this.midX + rowWidth / 2, rowY + 12,
                        5, true);
            }
            guiGraphics.method_25300(this.field_22793, tradeText, this.midX, getTradeListRowY(i, size),
                    isSidebarUi()
                            ? (hovered ? ModernUi.ACCENT_HOVER : ModernUi.TEXT_PRIMARY)
                            : (hovered ? CONTRAST_COLOR : MAIN_COLOR));
        }

        class_2561 addTrade = class_2561.method_43471(key("trades.addtrade"));
        String addTradeText = addTrade.getString();
        boolean addHovered = !foundHover && isMouseOverCenteredText(mouseX, mouseY, addTradeText,
                this.midX, getTradeListRowY(size, size));
        guiGraphics.method_27534(this.field_22793, addTrade, this.midX, getTradeListRowY(size, size),
                isSidebarUi()
                        ? (addHovered ? ModernUi.ACCENT_HOVER : ModernUi.WARM)
                        : (addHovered ? CONTRAST_COLOR : MAIN_COLOR));
    }

    protected void renderTradePanel(class_332 guiGraphics) {
        renderSmallItem(guiGraphics, this.midX, 35);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("trade")));

        if (this.tradeItemNbtBox != null) {
            drawCenteredLabel(guiGraphics, class_2561.method_43471(key("trades.item_nbt")),
                    this.tradeItemNbtBox.method_46426() + this.tradeItemNbtBox.method_25368() / 2,
                    this.tradeItemNbtBox.method_46427() - this.field_22793.field_2000 - 4);
        }
        drawTradeFieldLabels(guiGraphics);

        if (isSidebarUi()) {
            int tradeTop = this.midY - 26;
            ModernUi.fillPanel(guiGraphics, contentMidX() - Math.min(190, contentWidth() / 2), tradeTop,
                    contentMidX() + Math.min(190, contentWidth() / 2), this.midY + 42, 8, ModernUi.SURFACE, ModernUi.BORDER);
        }
        for (int slot = 0; slot < TRADE_SLOT_COUNT; slot++) {
            guiGraphics.method_27534(this.field_22793, class_2561.method_43471(key("trades.slot." + slot)),
                    getSingleTradeSlotX(slot) + 8, this.midY - 10,
                    slot == TRADE_SLOT_SELL ? panelTitleColor() : panelAccentColor());
        }

        class_2487 recipe = getSelectedTradeRecipe();
        if (recipe == null) {
            guiGraphics.method_27534(this.field_22793, class_2561.method_43471(key("trades.no_trades")),
                    this.midX, this.midY + 26, panelAccentColor());
            return;
        }

        renderTradeSlotItem(guiGraphics, recipe, TRADE_SLOT_FIRST_BUY);
        renderTradeSlotItem(guiGraphics, recipe, TRADE_SLOT_SECOND_BUY);
        renderTradeSlotItem(guiGraphics, recipe, TRADE_SLOT_SELL);
    }

    protected void renderLorePanel(class_332 guiGraphics, int mouseX, int mouseY) {
        renderSmallItem(guiGraphics, this.midX, 35);
        drawPanelTitle(guiGraphics, class_2561.method_43471(key("lore")));
        int spaces = loreLineSpaces();
        int size = this.loreValues.size();
        this.loreScroll = class_3532.method_15340(this.loreScroll, 0, Math.max(0, size - spaces));
        int y = 25;
        for (int i = this.loreScroll; i < this.loreScroll + spaces && i < size; i++) {
            String label = "Line " + (i + 1);
            y = 55 + 30 * (i - this.loreScroll);
            guiGraphics.method_25303(this.field_22793, label, loreLineLabelRightX() - this.field_22793.method_1727(label), y + 6,
                    isSidebarUi() ? ModernUi.TEXT_MUTED : 0xFFFFFFFF);
        }

        int actionY = y + 30;
        for (InfinityEditorButton button : this.loreActionButtons) {
            button.method_46419(actionY);
        }
        if (this.copyLoreButton != null) {
            this.copyLoreButton.field_22763 = size > 0;
        }

        int scrollX = loreScrollBarX();
        int scrollTop = loreScrollTop();
        int scrollHeight = loreScrollHeight();
        if (isSidebarUi()) {
            ModernUi.fillRounded(guiGraphics, scrollX, scrollTop, scrollX + 6, scrollTop + scrollHeight, 3,
                    ModernUi.alpha(0x000000, 90));
        } else {
            guiGraphics.method_51738(this.field_22789 - 15, this.field_22789 - 5, 50, 0xFFAAAAAA);
            guiGraphics.method_51738(this.field_22789 - 15, this.field_22789 - 5, this.field_22790 - 50, 0xFFAAAAAA);
            scrollHeight = this.field_22790 - 103;
            scrollTop = 52;
        }
        float covered = size < spaces || size == 0 ? 1.0F : spaces / (float) size;
        int coveredHeight = (int) Math.max(1, scrollHeight * covered);
        float div = size - spaces;
        float perc = div <= 0.0F ? 0.0F : this.loreScroll / div;
        int scrollY = (int) (scrollTop + (scrollHeight - coveredHeight) * perc);
        if (isSidebarUi()) {
            ModernUi.fillRounded(guiGraphics, scrollX + 1, scrollY, scrollX + 5, scrollY + coveredHeight, 2, ModernUi.ACCENT_HOVER);
        } else {
            guiGraphics.method_25294(this.field_22789 - 14, scrollY, this.field_22789 - 5, scrollY + coveredHeight, 0xFF666666);
        }
    }

    protected void renderLorePainterPanel(class_332 guiGraphics, int mouseX, int mouseY) {
        ensureLorePainterRows();
        if (this.lorePainterDragging) {
            paintLorePainterAt(mouseX, mouseY);
        }

        drawPanelTitle(guiGraphics, class_2561.method_43471(key("lorepainter")));

        int gridX = getLorePainterGridX();
        int gridY = getLorePainterGridY();
        guiGraphics.method_25300(this.field_22793, this.lorePainterWidth + "x" + this.lorePainterHeight,
                this.midX, gridY - 15, panelLabelColor());

        if (isSidebarUi()) {
            ModernUi.fillPanel(guiGraphics, gridX - 8, gridY - 8,
                    gridX + getLorePainterSizeX() + 8, gridY + getLorePainterSizeY() + 8,
                    8, ModernUi.SURFACE, ModernUi.BORDER);
        }

        int yOffset = 0;
        for (List<LorePixel> row : this.lorePainterRows) {
            guiGraphics.method_51433(this.field_22793, buildLorePainterRow(row), gridX, gridY + yOffset, 0xFFFFFFFF, false);
            yOffset += 9;
        }

        int rowButtonY = gridY + getLorePainterSizeY() + 9;
        if (this.lorePainterAddRowButton != null) {
            this.lorePainterAddRowButton.method_46419(rowButtonY);
        }
        if (this.lorePainterRemoveRowButton != null) {
            this.lorePainterRemoveRowButton.method_46419(rowButtonY);
            this.lorePainterRemoveRowButton.field_22763 = this.lorePainterHeight > 1;
        }

        int columnButtonX = gridX + getLorePainterSizeX() + 9;
        if (this.lorePainterAddColumnButton != null) {
            this.lorePainterAddColumnButton.method_46421(columnButtonX);
        }
        if (this.lorePainterRemoveColumnButton != null) {
            this.lorePainterRemoveColumnButton.method_46421(columnButtonX);
            this.lorePainterRemoveColumnButton.field_22763 = this.lorePainterWidth > 1;
        }

        String symbols = buildLorePainterSymbols();
        guiGraphics.method_51433(this.field_22793, symbols, 0, 0, 0xFFFFFFFF, false);
        guiGraphics.method_51433(this.field_22793, this.currentLorePixel.format() + class_2561.method_43471(key("lorepainter.symbol." + this.currentLorePixel.symbol.nameKey())).getString(),
                2, 10, 0xFFFFFFFF, false);

        String colors = buildLorePainterColors();
        int colorX = getLorePainterColorX();
        guiGraphics.method_51433(this.field_22793, colors, colorX, 0, 0xFFFFFFFF, false);
        String colorName = this.currentLorePixel.format() + this.currentLorePixel.color.method_7792();
        guiGraphics.method_51433(this.field_22793, colorName, this.field_22789 - this.field_22793.method_1727(colorName) - 2, 10, 0xFFFFFFFF, false);
    }

    protected void renderItemTooltipPreview(class_332 guiGraphics) {
        if (this.previewStack.method_7960() || this.field_22787 == null || this.field_22787.field_1724 == null) {
            return;
        }
        if (isSidebarUi()) {
            return;
        }

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().scale(0.8F, 0.8F);
        Tooltips.show(guiGraphics, this.field_22793, this.previewStack, 0, 25);
        guiGraphics.method_51448().popMatrix();
    }

    protected void renderPrettyNbt(class_332 guiGraphics) {
        if (isSidebarUi()) {
            return;
        }
        List<class_2561> lines = getPrettyNbtLines();
        if (!lines.isEmpty()) {
            guiGraphics.method_51448().pushMatrix();
            guiGraphics.method_51448().scale(0.8F, 0.8F);
            Tooltips.showComponents(guiGraphics, this.field_22793, lines, 0, this.field_22790);
            guiGraphics.method_51448().popMatrix();
        }
    }

    protected void renderSmallItem(class_332 guiGraphics, int centerX, int centerY) {
        if (this.previewStack.method_7960()) {
            return;
        }
        if (isSidebarUi() && centerY <= 45 && centerX != itemPreviewCenterX()) {
            return;
        }
        if (isSidebarUi()) {
            ModernUi.fillItemWell(guiGraphics, centerX, centerY, centerY > 45 ? 42 : 34);
        }
        int x = centerX - 8;
        int y = centerY - 8;
        guiGraphics.method_51427(this.previewStack, x, y);
        guiGraphics.method_51431(this.field_22793, this.previewStack, x, y);
    }

    protected void renderLargePreviewItem(class_332 guiGraphics) {
        if (this.previewStack.method_7960()) {
            return;
        }

        int centerX = contentMidX();
        if (isSidebarUi()) {
            ModernUi.fillSoftHalo(guiGraphics, centerX, this.midY + 18, 104, 34, ModernUi.alpha(0xFFB347, 22));
            ModernUi.fillSoftHalo(guiGraphics, centerX, this.midY + 21, 76, 18, ModernUi.alpha(0x62D1C7, 18));
        }
        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(centerX, this.midY);
        guiGraphics.method_51448().rotate((float) Math.toRadians(this.rotOff * 3.0F));
        guiGraphics.method_51448().scale(5.0F, 5.0F);
        guiGraphics.method_51427(this.previewStack, -8, -8);
        guiGraphics.method_51448().popMatrix();
    }

    protected void renderPanelTooltips(class_332 guiGraphics, int mouseX, int mouseY) {
        if (this.activePanel == Panel.ITEM) {
            int previewX = itemPreviewCenterX() - ITEM_SIZE / 2;
            int previewY = itemPreviewCenterY() - ITEM_SIZE / 2;
            if (isMouseIn(mouseX, mouseY, previewX, previewY, ITEM_SIZE, ITEM_SIZE)) {
                Tooltips.show(guiGraphics, this.field_22793, this.previewStack, mouseX, mouseY);
            }
            if (this.itemIdBox != null && this.itemIdBox.method_1882().length() > 9
                    && isMouseIn(mouseX, mouseY, this.itemIdBox.method_46426(), this.itemIdBox.method_46427(), this.itemIdBox.method_25368(), this.itemIdBox.method_25364())) {
                Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43470(this.itemIdBox.method_1882()), mouseX, mouseY);
            }
            int dropX = isSidebarUi() ? itemPanelDropButtonX() : this.midX + 30;
            int dropY = isSidebarUi() ? sidebarBottomButtonY() : this.field_22790 - 35;
            int dropWidth = isSidebarUi() ? itemPanelDropButtonWidth() : OLD_BUTTON_WIDTH;
            int dropHeight = isSidebarUi() ? SIDEBAR_BUTTON_HEIGHT : OLD_BUTTON_HEIGHT;
            if (isMouseIn(mouseX, mouseY, dropX, dropY, dropWidth, dropHeight)) {
                Tooltips.showComponents(guiGraphics, this.field_22793, List.of(
                        class_2561.method_43471(key("item.drop.tooltip.1")),
                        class_2561.method_43471(key("item.drop.tooltip.2"))), mouseX, mouseY);
            }
        } else if (this.activePanel == Panel.LORE) {
            for (class_342 box : this.loreBoxes) {
                if (isMouseIn(mouseX, mouseY, box.method_46426(), box.method_46427(), box.method_25368(), box.method_25364())) {
                    String value = box.method_1882().replace(class_124.field_33292, '&');
                    if (!value.isEmpty()) {
                        Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43470(value), mouseX, mouseY);
                    }
                    return;
                }
            }
            int previewX = isSidebarUi() ? itemPreviewCenterX() - ITEM_SIZE / 2 : this.midX - 9;
            int previewY = isSidebarUi() ? itemPreviewCenterY() - ITEM_SIZE / 2 : 27;
            if (isMouseIn(mouseX, mouseY, previewX, previewY, 18, 18)) {
                Tooltips.show(guiGraphics, this.field_22793, this.previewStack, mouseX, mouseY);
            }
        } else if (this.activePanel == Panel.CONTAINER) {
            int slot = getHoveredContainerSlot(mouseX, mouseY);
            if (slot >= 0) {
                class_1799 slotStack = getContainerSlotItem(slot);
                if (!slotStack.method_7960()) {
                    Tooltips.show(guiGraphics, this.field_22793, slotStack, mouseX, mouseY);
                } else {
                    Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43471(key("container.empty_slot")), mouseX, mouseY);
                }
                return;
            }
            if (this.containerSlotNbtBox != null && this.containerSlotNbtBox.method_1882().length() > 20
                    && isMouseIn(mouseX, mouseY, this.containerSlotNbtBox.method_46426(), this.containerSlotNbtBox.method_46427(),
                    this.containerSlotNbtBox.method_25368(), this.containerSlotNbtBox.method_25364())) {
                Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43470(this.containerSlotNbtBox.method_1882()), mouseX, mouseY);
            }
        } else if (this.activePanel == Panel.TRADES) {
            if (getHoveredTradeListIndex(mouseX, mouseY) >= 0) {
                Tooltips.showComponents(guiGraphics, this.field_22793, List.of(
                        class_2561.method_43471(key("trades.leftclick")),
                        class_2561.method_43471(key("trades.rightclick"))), mouseX, mouseY);
                return;
            }
            int resetX = this.midX - 30;
            int resetY = this.field_22790 - 35;
            int resetWidth = OLD_BUTTON_WIDTH;
            int resetHeight = OLD_BUTTON_HEIGHT;
            if (isSidebarUi()) {
                int gap = 6;
                resetWidth = sidebarBottomButtonWidth(3, gap);
                resetX = sidebarBottomStartX(3, resetWidth, gap) + resetWidth + gap;
                resetY = sidebarBottomButtonY();
                resetHeight = SIDEBAR_BUTTON_HEIGHT;
            }
            if (isMouseIn(mouseX, mouseY, resetX, resetY, resetWidth, resetHeight)) {
                Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43471(key("trades.reset")), mouseX, mouseY);
            }
        } else if (this.activePanel == Panel.TRADE) {
            int slot = getHoveredSingleTradeSlot(mouseX, mouseY);
            if (slot >= 0) {
                class_2487 recipe = getSelectedTradeRecipe();
                class_1799 stack = recipe == null ? class_1799.field_8037 : getTradeSlotItem(recipe, slot);
                if (!stack.method_7960()) {
                    Tooltips.show(guiGraphics, this.field_22793, stack, mouseX, mouseY);
                }
                Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43471(key("trade.click_to_edit")), mouseX, mouseY - 16);
            }
        } else if (this.activePanel == Panel.LORE_PAINTER) {
            if (this.lorePainterScaleButton != null && isMouseIn(mouseX, mouseY,
                    this.lorePainterScaleButton.method_46426(), this.lorePainterScaleButton.method_46427(),
                    this.lorePainterScaleButton.method_25368(), this.lorePainterScaleButton.method_25364())
                    && this.field_22787 != null) {
                Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43470(String.valueOf(this.field_22787.field_1690.method_42474().method_41753())), mouseX, mouseY);
                return;
            }
            boolean hoveringPreview = this.lorePainterPreviewButton != null && isMouseIn(mouseX, mouseY,
                    this.lorePainterPreviewButton.method_46426(), this.lorePainterPreviewButton.method_46427(),
                    this.lorePainterPreviewButton.method_25368(), this.lorePainterPreviewButton.method_25364());
            if (this.lorePainterPreview || hoveringPreview) {
                List<class_2561> lines = new ArrayList<>();
                lines.add(class_2561.method_43471(key("lorepainter")));
                for (List<LorePixel> row : this.lorePainterRows) {
                    lines.add(class_2561.method_43470(buildLorePainterRow(row)));
                }
                Tooltips.showComponents(guiGraphics, this.field_22793, lines, mouseX, mouseY);
            }
        }
    }

    private int itemPanelDropButtonX() {
        int gap = 6;
        int count = isTradeSlotEditor() ? 3 : 4;
        int buttonWidth = sidebarBottomButtonWidth(count, gap);
        int dropIndex = isTradeSlotEditor() ? 2 : 3;
        return sidebarBottomStartX(count, buttonWidth, gap) + dropIndex * (buttonWidth + gap);
    }

    private int itemPanelDropButtonWidth() {
        return sidebarBottomButtonWidth(isTradeSlotEditor() ? 3 : 4, 6);
    }

    protected void drawRightLabel(class_332 guiGraphics, class_2561 text, int rightX, int y) {
        guiGraphics.method_27535(this.field_22793, text, rightX - this.field_22793.method_27525(text), y, panelLabelColor());
    }

    protected void drawTradeFieldLabels(class_332 guiGraphics) {
        if (this.tradeUsesBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("trades.uses")),
                    this.tradeUsesBox.method_46426() - 5, this.tradeUsesBox.method_46427() + 6);
        }
        if (this.tradeMaxUsesBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("trades.max_uses")),
                    this.tradeMaxUsesBox.method_46426() - 5, this.tradeMaxUsesBox.method_46427() + 6);
        }
        if (this.tradeXpBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("trades.xp")),
                    this.tradeXpBox.method_46426() - 5, this.tradeXpBox.method_46427() + 6);
        }
        if (this.tradeSpecialPriceBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("trades.special_price")),
                    this.tradeSpecialPriceBox.method_46426() - 5, this.tradeSpecialPriceBox.method_46427() + 6);
        }
        if (this.tradeDemandBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("trades.demand")),
                    this.tradeDemandBox.method_46426() - 5, this.tradeDemandBox.method_46427() + 6);
        }
        if (this.tradePriceMultiplierBox != null) {
            drawRightLabel(guiGraphics, class_2561.method_43471(key("trades.price_multiplier")),
                    this.tradePriceMultiplierBox.method_46426() - 5, this.tradePriceMultiplierBox.method_46427() + 6);
        }
    }

    protected boolean handleEnchantingClick(double mouseX, double mouseY) {
        if (tryRemoveActiveEnchantment(mouseX, mouseY)) {
            return true;
        }
        if (trySelectRingEnchantmentGroup(mouseX, mouseY)) {
            return true;
        }
        if (isMouseOverCenter(mouseX, mouseY)) {
            addMatchingEnchantments();
            return true;
        }
        return tryAddRingEnchantment(mouseX, mouseY);
    }

    protected boolean handlePotionClick(double mouseX, double mouseY) {
        if (tryRemoveActivePotionEffect(mouseX, mouseY)) {
            return true;
        }
        if (trySelectRingPotionGroup(mouseX, mouseY)) {
            return true;
        }
        if (isMouseOverCenter(mouseX, mouseY)) {
            addMatchingPotionEffects();
            return true;
        }
        return tryAddRingPotionEffect(mouseX, mouseY);
    }

    protected boolean handleAttributesClick(double mouseX, double mouseY) {
        if (tryRemoveActiveAttributeModifier(mouseX, mouseY)) {
            return true;
        }
        if (trySelectRingAttributeGroup(mouseX, mouseY)) {
            return true;
        }
        return tryAddRingAttribute(mouseX, mouseY);
    }

    protected boolean handleColorClick(double mouseX, double mouseY) {
        if (!shouldShowDyeGrid() || this.blueSlider == null) {
            return false;
        }

        int columns = dyeGridColumns();
        int cellSize = dyeGridCellSize();
        int gridX = dyeGridX(columns, cellSize);
        int gridY = this.blueSlider.method_46427() + this.blueSlider.method_25364() + 10;
        if (!isMouseIn(mouseX, mouseY, gridX, gridY, columns * cellSize, dyeGridRows(columns) * cellSize)) {
            return false;
        }

        int column = ((int) mouseX - gridX) / cellSize;
        int row = ((int) mouseY - gridY) / cellSize;
        int index = column + row * columns;
        class_1767[] colors = class_1767.values();
        if (index < 0 || index >= colors.length) {
            return false;
        }

        addDyeToColor(colors[index]);
        syncColorControlsFromStack();
        this.status = class_2561.method_43469(messageKey("editor_color_updated"), this.colorHexValue);
        return true;
    }

    protected boolean handleContainerClick(double mouseX, double mouseY) {
        int gridX = getContainerGridX();
        int gridY = getContainerGridY();
        int gridWidth = CONTAINER_COLUMNS * CONTAINER_SLOT_PIXEL_SIZE;
        int gridHeight = CONTAINER_ROWS * CONTAINER_SLOT_PIXEL_SIZE;
        if (!isMouseIn(mouseX, mouseY, gridX - 1, gridY - 1, gridWidth + 2, gridHeight + 2)) {
            return false;
        }

        int column = ((int) mouseX - gridX) / CONTAINER_SLOT_PIXEL_SIZE;
        int row = ((int) mouseY - gridY) / CONTAINER_SLOT_PIXEL_SIZE;
        int slot = column + row * CONTAINER_COLUMNS;
        if (column < 0 || column >= CONTAINER_COLUMNS || row < 0 || row >= CONTAINER_ROWS || slot < 0 || slot >= CONTAINER_SIZE) {
            return false;
        }

        this.selectedContainerSlot = slot;
        this.containerSlotNbtValue = getContainerSelectedSlotNbt();
        if (this.containerSlotNbtBox != null) {
            this.containerSlotNbtBox.method_1852(this.containerSlotNbtValue);
            this.containerSlotNbtBox.method_1875(0);
        }
        return true;
    }

    protected boolean handleBannerClick(double mouseX, double mouseY) {
        if (!isMouseIn(mouseX, mouseY, bannerPatternListX(), getBannerPatternRowY(0) - 1,
                bannerPatternListWidth(), BANNER_PATTERN_ROWS * 10 + 2)) {
            return false;
        }

        List<BannerPatternEntry> patterns = getFilteredBannerPatterns();
        if (patterns.isEmpty()) {
            return false;
        }

        int row = ((int) mouseY - getBannerPatternRowY(0)) / 10;
        int index = this.bannerPatternScroll + row;
        if (row < 0 || row >= BANNER_PATTERN_ROWS || index < 0 || index >= patterns.size()) {
            return false;
        }

        this.selectedBannerPatternIndex = index;
        return true;
    }

    protected boolean handleDecoratedPotClick(double mouseX, double mouseY) {
        if (!isMouseIn(mouseX, mouseY, potterySherdListX(), getPotterySherdRowY(0) - 1,
                potterySherdListWidth(), POTTERY_SHERD_ROWS * 10 + 2)) {
            return false;
        }

        List<PotterySherdEntry> sherds = getFilteredPotterySherds();
        if (sherds.isEmpty()) {
            return false;
        }

        int row = ((int) mouseY - getPotterySherdRowY(0)) / 10;
        int index = this.potterySherdScroll + row;
        if (row < 0 || row >= POTTERY_SHERD_ROWS || index < 0 || index >= sherds.size()) {
            return false;
        }

        this.selectedPotterySherdIndex = index;
        return true;
    }

    protected boolean handleSpawnEggClick(double mouseX, double mouseY) {
        if (!isMouseIn(mouseX, mouseY, spawnEggEntityListX(), getSpawnEggEntityRowY(0) - 1,
                spawnEggEntityListWidth(), SPAWN_EGG_ENTITY_ROWS * 10 + 2)) {
            return false;
        }

        List<SpawnEggEntityEntry> entities = getFilteredSpawnEggEntities();
        if (entities.isEmpty()) {
            return false;
        }

        int row = ((int) mouseY - getSpawnEggEntityRowY(0)) / 10;
        int index = this.spawnEggEntityScroll + row;
        if (row < 0 || row >= SPAWN_EGG_ENTITY_ROWS || index < 0 || index >= entities.size()) {
            return false;
        }

        this.selectedSpawnEggEntityIndex = index;
        this.spawnEggTagScroll = 0;
        method_41843();
        return true;
    }

    protected boolean handleTradesClick(double mouseX, double mouseY, int button) {
        int index = getHoveredTradeListIndex((int) mouseX, (int) mouseY);
        if (index >= 0) {
            if (button == 0) {
                openVillagerTrade(index);
                return true;
            }
            if (button == 1) {
                removeVillagerTrade(index);
                return true;
            }
        }

        if (button == 0 && isMouseOverAddTrade((int) mouseX, (int) mouseY)) {
            addVillagerTrade();
            return true;
        }

        return false;
    }

    protected boolean handleTradeClick(double mouseX, double mouseY) {
        int slot = getHoveredSingleTradeSlot((int) mouseX, (int) mouseY);
        if (slot < 0) {
            return false;
        }

        openTradeSlotItemEditor(slot);
        return true;
    }

    protected boolean handleLoreClick(double mouseX, double mouseY) {
        if (isMouseIn(mouseX, mouseY, loreScrollBarX(), loreScrollTop(),
                isSidebarUi() ? 6 : 11, loreScrollHeight())) {
            this.draggingLoreScroll = true;
            updateLoreScrollFromMouse(mouseY);
            return true;
        }
        return false;
    }

    protected boolean handleLorePainterClick(double mouseX, double mouseY) {
        this.lorePainterDragging = true;
        paintLorePainterAt(mouseX, mouseY);
        return true;
    }

    protected boolean handleNbtAdvancedClick(double mouseX, double mouseY) {
        if (mouseX < 20 || mouseX > this.field_22789 - 20 || mouseY < 40 || mouseY > this.field_22790 - 20) {
            return false;
        }

        int rowIndex = this.advancedScroll + ((int) mouseY - 48) / 12;
        List<NbtRow> rows = buildNbtRows();
        if (rowIndex < 0 || rowIndex >= rows.size()) {
            return false;
        }

        NbtRow row = rows.get(rowIndex);
        if (!row.isExpandable()) {
            return false;
        }

        if (this.expandedNbtPaths.contains(row.path())) {
            this.expandedNbtPaths.remove(row.path());
        } else {
            this.expandedNbtPaths.add(row.path());
        }
        return true;
    }
}

