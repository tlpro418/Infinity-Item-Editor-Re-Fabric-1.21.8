package io.github.seraphina.infinity_item_editor_re.client.screen;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernUi;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_9283;
import net.minecraft.class_9302;
abstract class ItemEditorScreenState extends class_437 {
    protected static final int MAX_COUNT = Integer.MAX_VALUE;
    protected static final int MAX_ENCHANTMENT_LEVEL = Integer.MAX_VALUE;
    protected static final int MAX_POTION_LEVEL = Integer.MAX_VALUE;
    protected static final int MAX_POTION_SECONDS = 99999;
    protected static final int MAX_ATTRIBUTE_INTEGER = 99999999;
    protected static final int FIELD_HEIGHT = 20;
    protected static final int OLD_BUTTON_WIDTH = 60;
    protected static final int OLD_BUTTON_HEIGHT = 20;
    protected static final int ITEM_SIZE = 16;
    protected static final int RING_ICON_HIT_RADIUS = 10;
    protected static final int RING_HOVER_WIDTH = 16;
    protected static final int FOLDED_REGISTRY_ENTRY_LIMIT = 48;
    protected static final int CENTER_HIT_RADIUS = 15;
    protected static final int MAIN_COLOR = InfinityEditorButton.MAIN_COLOR;
    protected static final int ALT_COLOR = InfinityEditorButton.ALT_COLOR;
    protected static final int CONTRAST_COLOR = InfinityEditorButton.CONTRAST_COLOR;
    protected static final int SIDEBAR_WIDTH_MIN = 136;
    protected static final int SIDEBAR_WIDTH_MAX = 168;
    protected static final int SIDEBAR_SAFE_MARGIN = 12;
    protected static final int SIDEBAR_CONTENT_GAP = 14;
    protected static final int SIDEBAR_DRAWER_PADDING = 8;
    protected static final int SIDEBAR_BUTTON_HEIGHT = 22;
    protected static final int SIDEBAR_PANEL_COLOR = ModernUi.SIDEBAR_TOP;
    protected static final int SIDEBAR_CARD_COLOR = ModernUi.SURFACE;
    protected static final int SIDEBAR_CARD_SOFT_COLOR = ModernUi.SURFACE_SOFT;
    protected static final int SIDEBAR_BORDER_COLOR = ModernUi.BORDER;
    protected static final int SIDEBAR_ACCENT_COLOR = ModernUi.ACCENT;
    protected static final int SIDEBAR_MUTED_COLOR = ModernUi.TEXT_MUTED;
    protected static final int BAD_RED = 0xFFF44262;
    protected static final int GOOD_GREEN = 0xFF32CC64;
    protected static final int CYAN = 0xFF00FFFF;
    protected static final String ITEM_ENCHANTMENTS_TAG = "Enchantments";
    protected static final String BOOK_ENCHANTMENTS_TAG = "StoredEnchantments";
    protected static final String DISPLAY_TAG = "display";
    protected static final String LORE_TAG = "Lore";
    protected static final String HIDE_FLAGS_TAG = "HideFlags";
    protected static final String CUSTOM_POTION_EFFECTS_TAG = "CustomPotionEffects";
    protected static final String ATTRIBUTE_MODIFIERS_TAG = "AttributeModifiers";
    protected static final String CUSTOM_POTION_COLOR_TAG = PotionCompat.TAG_CUSTOM_POTION_COLOR;
    protected static final String MAP_COLOR_TAG = "MapColor";
    protected static final int SIGN_LINES = 4;
    protected static final String BLOCK_ENTITY_TAG = "BlockEntityTag";
    protected static final String SPAWNER_BLOCK_ENTITY_ID = "minecraft:mob_spawner";
    protected static final String TRIAL_SPAWNER_BLOCK_ENTITY_ID = "minecraft:trial_spawner";
    protected static final String SPAWNER_SPAWN_DATA_TAG = "SpawnData";
    protected static final String SPAWNER_ENTITY_TAG = "entity";
    protected static final String SPAWNER_SPAWN_POTENTIALS_TAG = "SpawnPotentials";
    protected static final String SPAWNER_POTENTIAL_DATA_TAG = "data";
    protected static final String SPAWNER_POTENTIAL_LEGACY_ENTITY_TAG = "Entity";
    protected static final String SPAWNER_CUSTOM_SPAWN_RULES_TAG = "custom_spawn_rules";
    protected static final String TRIAL_SPAWNER_NORMAL_CONFIG_TAG = "normal_config";
    protected static final String TRIAL_SPAWNER_OMINOUS_CONFIG_TAG = "ominous_config";
    protected static final String TRIAL_SPAWNER_SPAWN_DATA_TAG = "spawn_data";
    protected static final String TRIAL_SPAWNER_SPAWN_POTENTIALS_TAG = "spawn_potentials";
    protected static final String SPAWNER_POTENTIAL_WEIGHT_TAG = "weight";
    protected static final String SIGN_FRONT_TEXT_TAG = "front_text";
    protected static final String SIGN_MESSAGES_TAG = "messages";
    protected static final String SIGN_FILTERED_MESSAGES_TAG = "filtered_messages";
    protected static final String SIGN_COLOR_TAG = "color";
    protected static final String SIGN_GLOWING_TEXT_TAG = "has_glowing_text";
    protected static final String LEGACY_SIGN_TEXT_TAG_PREFIX = "Text";
    protected static final String BANNER_PATTERNS_TAG = "Patterns";
    protected static final String BANNER_PATTERN_TAG = "Pattern";
    protected static final String BANNER_COLOR_TAG = "Color";
    protected static final String BANNER_BASE_TAG = "Base";
    protected static final int BANNER_PATTERN_ROWS = 8;
    protected static final String DECORATED_POT_SHERDS_TAG = "sherds";
    protected static final int DECORATED_POT_SIDE_BACK = 0;
    protected static final int DECORATED_POT_SIDE_LEFT = 1;
    protected static final int DECORATED_POT_SIDE_RIGHT = 2;
    protected static final int DECORATED_POT_SIDE_FRONT = 3;
    protected static final int[] DECORATED_POT_DISPLAY_SIDES = {
            DECORATED_POT_SIDE_FRONT,
            DECORATED_POT_SIDE_LEFT,
            DECORATED_POT_SIDE_RIGHT,
            DECORATED_POT_SIDE_BACK
    };
    protected static final int POTTERY_SHERD_ROWS = 8;
    protected static final String BOOK_TITLE_TAG = "title";
    protected static final String BOOK_FILTERED_TITLE_TAG = "filtered_title";
    protected static final String BOOK_AUTHOR_TAG = "author";
    protected static final String BOOK_GENERATION_TAG = "generation";
    protected static final String BOOK_RESOLVED_TAG = "resolved";
    protected static final String BOOK_PAGES_TAG = "pages";
    protected static final String BOOK_FILTERED_PAGES_TAG = "filtered_pages";
    protected static final int MAX_BOOK_GENERATION = class_9302.field_49379;
    protected static final String SKULL_OWNER_TAG = "SkullOwner";
    protected static final String SKULL_OWNER_ID_TAG = "Id";
    protected static final String SKULL_OWNER_NAME_TAG = "Name";
    protected static final String SKULL_PROPERTIES_TAG = "Properties";
    protected static final String SKULL_TEXTURES_TAG = "textures";
    protected static final String SKULL_TEXTURE_VALUE_TAG = "Value";
    protected static final String SKULL_TEXTURE_SIGNATURE_TAG = "Signature";
    protected static final String ENTITY_TAG = "EntityTag";
    protected static final String ENTITY_ID_TAG = "id";
    protected static final String ENTITY_CUSTOM_NAME_TAG = "CustomName";
    protected static final String ENTITY_OWNER_TAG = "Owner";
    protected static final String VILLAGER_DATA_TAG = "VillagerData";
    protected static final String VILLAGER_TYPE_TAG = "type";
    protected static final String VILLAGER_PROFESSION_TAG = "profession";
    protected static final String VILLAGER_LEVEL_TAG = "level";
    protected static final String DEFAULT_VILLAGER_TYPE = "minecraft:plains";
    protected static final String DEFAULT_VILLAGER_PROFESSION = "minecraft:farmer";
    protected static final int DEFAULT_VILLAGER_LEVEL = 1;
    protected static final String ARMOR_STAND_SHOW_ARMS_TAG = "ShowArms";
    protected static final String ARMOR_STAND_SMALL_TAG = "Small";
    protected static final String ARMOR_STAND_INVISIBLE_TAG = "Invisible";
    protected static final String ARMOR_STAND_NO_BASE_PLATE_TAG = "NoBasePlate";
    protected static final String ARMOR_STAND_MARKER_TAG = "Marker";
    protected static final String ARMOR_STAND_NO_GRAVITY_TAG = "NoGravity";
    protected static final String ARMOR_STAND_INVULNERABLE_TAG = "Invulnerable";
    protected static final String FIREWORKS_TAG = "Fireworks";
    protected static final String FIREWORK_FLIGHT_TAG = "Flight";
    protected static final String FIREWORK_EXPLOSIONS_TAG = "Explosions";
    protected static final String FIREWORK_EXPLOSION_TAG = "Explosion";
    protected static final String FIREWORK_TYPE_TAG = "Type";
    protected static final String FIREWORK_COLORS_TAG = "Colors";
    protected static final String FIREWORK_FADE_COLORS_TAG = "FadeColors";
    protected static final String FIREWORK_FLICKER_TAG = "Flicker";
    protected static final String FIREWORK_TRAIL_TAG = "Trail";
    protected static final int MAX_FIREWORK_FLIGHT = 4;
    protected static final int FIREWORK_EXPLOSION_TYPES = 5;
    protected static final class_9283.class_1782[] FIREWORK_SHAPES = {
            class_9283.class_1782.field_7976,
            class_9283.class_1782.field_7977,
            class_9283.class_1782.field_7973,
            class_9283.class_1782.field_7974,
            class_9283.class_1782.field_7970
    };
    protected static final String CONTAINER_ITEMS_TAG = "Items";
    protected static final String CONTAINER_SLOT_TAG = "Slot";
    protected static final int CONTAINER_ROWS = 3;
    protected static final int CONTAINER_COLUMNS = 9;
    protected static final int CONTAINER_SIZE = CONTAINER_ROWS * CONTAINER_COLUMNS;
    protected static final int CONTAINER_SLOT_PIXEL_SIZE = 18;
    protected static final int SPAWN_EGG_ENTITY_ROWS = 8;
    protected static final int SPAWN_EGG_TAG_ROWS = 8;
    protected static final int SPAWN_EGG_TAG_ROW_HEIGHT = 24;
    protected static final int SPAWN_EGG_OWNER_MAX_LENGTH = 128;
    protected static final String OFFERS_TAG = "Offers";
    protected static final String RECIPES_TAG = "Recipes";
    protected static final String TRADE_BUY_TAG = "buy";
    protected static final String TRADE_BUY_B_TAG = "buyB";
    protected static final String TRADE_SELL_TAG = "sell";
    protected static final String TRADE_USES_TAG = "uses";
    protected static final String TRADE_MAX_USES_TAG = "maxUses";
    protected static final String TRADE_REWARD_EXP_TAG = "rewardExp";
    protected static final String TRADE_XP_TAG = "xp";
    protected static final String TRADE_PRICE_MULTIPLIER_TAG = "priceMultiplier";
    protected static final String TRADE_SPECIAL_PRICE_TAG = "specialPrice";
    protected static final String TRADE_DEMAND_TAG = "demand";
    protected static final int TRADE_ROWS = 8;
    protected static final int TRADE_ROW_HEIGHT = 12;
    protected static final int TRADE_LIST_ROW_HEIGHT = 20;
    protected static final int TRADE_LIST_ROW_TEXT_HEIGHT = 8;
    protected static final int TRADE_SLOT_FIRST_BUY = 0;
    protected static final int TRADE_SLOT_SECOND_BUY = 1;
    protected static final int TRADE_SLOT_SELL = 2;
    protected static final int TRADE_SLOT_COUNT = 3;
    protected static final int TRADE_MAX_USES_DIGITS = 4;
    protected static final int TRADE_MAX_USES_LIMIT = 9999;
    protected static final int TRADE_DEFAULT_MAX_USES = 7;
    protected static final float TRADE_DEFAULT_PRICE_MULTIPLIER = 0.05F;

    protected final class_1799 originalStack;
    protected final int targetContainerSlot;
    protected final ItemEditorScreen parentTradeScreen;
    protected final int parentTradeIndex;
    protected final int parentTradeSlot;
    protected class_1799 previewStack;
    protected String pendingSaveNbt;
    protected int pendingSaveSlot = -1;
    protected int pendingSaveTicks;
    protected Panel activePanel = Panel.ITEM;
    protected class_2561 status = class_2561.method_43473();

    protected String itemIdValue;
    protected String countValue;
    protected String damageValue;
    protected String nameValue;
    protected String rawNbtValue;
    protected String componentNbtValue = "";
    protected String componentFilterValue = "";
    protected String componentValueFilterValue = "";
    protected String selectedComponentKey = "";
    protected String enchantFilterValue = "";
    protected String selectedEnchantmentNamespace = "";
    protected String enchantLevelValue = "1";
    protected String potionFilterValue = "";
    protected String selectedPotionNamespace = "";
    protected String potionLevelValue = "1";
    protected String potionTimeValue = "1";
    protected String attributeFilterValue = "";
    protected String selectedAttributeNamespace = "";
    protected String attributeAmountValue = "0";
    protected String attributeDecimalValue = "0";
    protected String colorHexValue;
    protected final String[] signLineValues = new String[SIGN_LINES];
    protected String signCommandValue = "";
    protected String bookTitleValue = "";
    protected String bookAuthorValue = "";
    protected String headOwnerValue = "";
    protected String headUuidValue = "";
    protected String headTextureValue = "";
    protected String headTextureSignatureValue = "";
    protected String containerSlotNbtValue = "{}";
    protected String bannerPatternFilterValue = "";
    protected String potterySherdFilterValue = "";
    protected String spawnEggEntityFilterValue = "";
    protected String spawnEggCustomNameValue = "";
    protected String spawnEggOwnerValue = "";
    protected String tradeItemNbtValue = "{}";
    protected String tradeUsesValue = "0";
    protected String tradeMaxUsesValue = Integer.toString(TRADE_DEFAULT_MAX_USES);
    protected String tradeXpValue = "0";
    protected String tradePriceMultiplierValue = Float.toString(TRADE_DEFAULT_PRICE_MULTIPLIER);
    protected String tradeSpecialPriceValue = "0";
    protected String tradeDemandValue = "0";
    protected String nbtFeedback = "";
    protected boolean nbtFeedbackGood;
    protected boolean showAllEnchantments;
    protected boolean showPotionParticles = true;
    protected boolean attributeInfinity;
    protected boolean attributeNegative;
    protected boolean syncingColorControls;
    protected boolean syncingComponentValue;
    protected boolean syncingComponentControls;
    protected boolean lorePainterDragging;
    protected boolean lorePainterPreview;
    protected boolean tradeRewardExp = true;
    protected class_2487 rememberedSignedBookData;
    protected int rotOff;
    protected int mouseDist;
    protected int midX;
    protected int midY;
    protected int advancedScroll;
    protected int loreScroll;
    protected int attributeSlot = 1;
    protected int attributeOperation;
    protected int bannerBaseColor;
    protected int bannerPatternColor = class_1767.field_7963.method_7789();
    protected int bannerPatternScroll;
    protected int selectedBannerPatternIndex;
    protected int potterySherdScroll;
    protected int selectedPotterySherdIndex;
    protected int selectedDecoratedPotSide = DECORATED_POT_SIDE_FRONT;
    protected int fireworkExplosionType;
    protected int fireworkColor = class_1767.field_7964.method_7789();
    protected int fireworkFadeColor = -1;
    protected int selectedContainerSlot;
    protected int spawnEggEntityScroll;
    protected int spawnEggTagScroll;
    protected int selectedSpawnEggEntityIndex;
    protected int selectedTradeIndex;
    protected int selectedTradeSlot;
    protected int tradeScroll;
    protected int componentListScroll;
    protected int lorePainterWidth = 3;
    protected int lorePainterHeight = 3;
    protected boolean draggingLoreScroll;
    protected boolean fireworkFlicker;
    protected boolean fireworkTrail;

    protected final List<String> loreValues = new ArrayList<>();
    protected final List<List<LorePixel>> lorePainterRows = new ArrayList<>();
    protected final List<class_342> tickingBoxes = new ArrayList<>();
    protected final List<class_342> mainTextBoxes = new ArrayList<>();
    protected final List<class_342> loreBoxes = new ArrayList<>();
    protected final List<class_342> signBoxes = new ArrayList<>();
    protected final List<InfinityEditorButton> loreActionButtons = new ArrayList<>();
    protected final Map<String, String> spawnEggNumberValueOverrides = new HashMap<>();
    protected final Set<String> expandedComponentGroups = new HashSet<>();
    protected final Set<String> expandedNbtPaths = new HashSet<>();
    protected final class_1799 enchantBook = new class_1799(class_1802.field_8598);
    protected final class_1799 potionIcon = new class_1799(class_1802.field_8574);
    protected final class_1799 attributeIcon = new class_1799(class_1802.field_8407);
    protected final LorePixel currentLorePixel = new LorePixel();
    protected boolean draggingComponentListScroll;
    protected String lastComponentGroupClick = "";
    protected long lastComponentGroupClickMs;

    protected class_342 itemIdBox;
    protected class_342 countBox;
    protected class_342 damageBox;
    protected class_342 nameBox;
    protected class_342 rawNbtBox;
    protected class_342 componentFilterBox;
    protected class_342 componentValueSearchBox;
    protected class_342 componentNumberBox;
    protected class_342 componentNbtBox;
    protected class_342 enchantFilterBox;
    protected class_342 enchantLevelBox;
    protected class_342 potionFilterBox;
    protected class_342 potionLevelBox;
    protected class_342 potionTimeBox;
    protected class_342 attributeFilterBox;
    protected class_342 attributeAmountBox;
    protected class_342 attributeDecimalBox;
    protected class_342 colorHexBox;
    protected class_342 signCommandBox;
    protected class_342 bookTitleBox;
    protected class_342 bookAuthorBox;
    protected class_342 headOwnerBox;
    protected class_342 headUuidBox;
    protected class_342 headTextureBox;
    protected class_342 headTextureSignatureBox;
    protected class_342 containerSlotNbtBox;
    protected class_342 bannerPatternFilterBox;
    protected class_342 potterySherdFilterBox;
    protected class_342 spawnEggEntityFilterBox;
    protected class_342 spawnEggCustomNameBox;
    protected class_342 spawnEggOwnerBox;
    protected class_342 tradeItemNbtBox;
    protected class_342 tradeUsesBox;
    protected class_342 tradeMaxUsesBox;
    protected class_342 tradeXpBox;
    protected class_342 tradePriceMultiplierBox;
    protected class_342 tradeSpecialPriceBox;
    protected class_342 tradeDemandBox;
    protected InfinityEditorButton attributeInfinityButton;
    protected InfinityEditorButton attributeOperationButton;
    protected InfinityEditorButton attributeSlotButton;
    protected InfinityEditorButton lorePainterScaleButton;
    protected InfinityEditorButton lorePainterAddRowButton;
    protected InfinityEditorButton lorePainterRemoveRowButton;
    protected InfinityEditorButton lorePainterAddColumnButton;
    protected InfinityEditorButton lorePainterRemoveColumnButton;
    protected InfinityEditorButton lorePainterPreviewButton;
    protected InfinityEditorButton copyLoreButton;
    protected ColorSlider redSlider;
    protected ColorSlider greenSlider;
    protected ColorSlider blueSlider;
    protected ColorSlider componentRedSlider;
    protected ColorSlider componentGreenSlider;
    protected ColorSlider componentBlueSlider;

    protected ItemEditorScreenState(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(class_2561.method_43471(key("item")));
        this.originalStack = stack.method_7972();
        this.targetContainerSlot = targetContainerSlot;
        this.parentTradeScreen = parentTradeScreen;
        this.parentTradeIndex = parentTradeIndex;
        this.parentTradeSlot = parentTradeSlot;
        this.previewStack = stack.method_7972();
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
    }











    protected abstract void addItemPanel();

    protected abstract void addNameAndLoreWidgets();

    protected abstract void addLoreTextField(int line, boolean realLine);

    protected abstract void addSpecialButtons();

    protected abstract void addFormatButtons();

    protected abstract void addNbtPanel();

    protected abstract void addComponentsPanel();

    protected abstract void addNbtAdvancedPanel();

    protected abstract void addHideFlagsPanel();

    protected abstract void addEnchantmentsPanel();

    protected abstract void addPotionPanel();

    protected abstract void addSignPanel();

    protected abstract void addBookPanel();

    protected abstract void addHeadPanel();

    protected abstract void addArmorStandPanel();

    protected abstract void addArmorStandToggleButton(int x, int y, int width, String translationSuffix, String tagKey);

    protected abstract void addFireworkPanel();

    protected abstract void addContainerPanel();

    protected abstract void addBannerPanel();

    protected abstract void addSpawnEggPanel();

    protected abstract void addSpawnEggTagControl(SpawnEggTagRow row, int y, int controlsX, int width);

    protected abstract void addTradesPanel();

    protected abstract void addTradePanel();

    protected abstract class_342 addTradeFieldBox(int x, int y, int width, String value, java.util.function.Predicate<String> filter,
                                     java.util.function.Consumer<String> responder);

    protected abstract void addAttributesPanel();

    protected abstract void addColorPanel();

    protected abstract void addLorePainterPanel();

    protected abstract void addLorePanel();

    protected abstract InfinityEditorButton addTopButton(int x, String keySuffix, InfinityEditorButton.PressAction action);

    protected abstract void addBottomButtons();

    protected abstract class_342 addTrackedBox(class_342 box);

    protected abstract class_342 legacyTextBox(int x, int y, int width, int height, class_2561 message);

    protected abstract class_342 numberBox(int x, int y, int width, int height, int digits, String value, int minValue, int maxValue);

    protected abstract void renderItemPanel(class_332 guiGraphics, int mouseX, int mouseY);

    protected abstract void renderNbtPanel(class_332 guiGraphics, int mouseX, int mouseY);

    protected abstract void renderComponentsPanel(class_332 guiGraphics, int mouseX, int mouseY);

    protected abstract void renderNbtAdvancedPanel(class_332 guiGraphics, int mouseX, int mouseY);

    protected abstract void renderHideFlagsPanel(class_332 guiGraphics);

    protected abstract void renderBookPanel(class_332 guiGraphics);

    protected abstract void renderHeadPanel(class_332 guiGraphics);

    protected abstract void renderArmorStandPanel(class_332 guiGraphics);

    protected abstract void renderFireworkPanel(class_332 guiGraphics);

    protected abstract void renderSimpleItemPanelTitle(class_332 guiGraphics, String titleKey, int itemY);

    protected abstract void renderEnchantmentsPanel(class_332 guiGraphics, int mouseX, int mouseY, float partialTick);

    protected abstract void renderPotionPanel(class_332 guiGraphics, int mouseX, int mouseY, float partialTick);

    protected abstract void renderAttributesPanel(class_332 guiGraphics, int mouseX, int mouseY, float partialTick);

    protected abstract void renderColorPanel(class_332 guiGraphics);

    protected abstract void renderSignPanel(class_332 guiGraphics);

    protected abstract void renderContainerPanel(class_332 guiGraphics);

    protected abstract void renderBannerPanel(class_332 guiGraphics);

    protected abstract void renderSpawnEggPanel(class_332 guiGraphics);

    protected abstract void renderTradesPanel(class_332 guiGraphics, int mouseX, int mouseY);

    protected abstract void renderTradePanel(class_332 guiGraphics);

    protected abstract void renderLorePanel(class_332 guiGraphics, int mouseX, int mouseY);

    protected abstract void renderLorePainterPanel(class_332 guiGraphics, int mouseX, int mouseY);

    protected abstract void renderItemTooltipPreview(class_332 guiGraphics);

    protected abstract void renderPrettyNbt(class_332 guiGraphics);

    protected abstract void renderSmallItem(class_332 guiGraphics, int centerX, int centerY);

    protected abstract void renderLargePreviewItem(class_332 guiGraphics);

    protected abstract void renderPanelTooltips(class_332 guiGraphics, int mouseX, int mouseY);

    protected abstract void drawRightLabel(class_332 guiGraphics, class_2561 text, int rightX, int y);

    protected abstract void drawTradeFieldLabels(class_332 guiGraphics);

    protected abstract boolean handleEnchantingClick(double mouseX, double mouseY);

    protected abstract boolean handlePotionClick(double mouseX, double mouseY);

    protected abstract boolean handleAttributesClick(double mouseX, double mouseY);

    protected abstract boolean handleComponentListClick(double mouseX, double mouseY);

    protected abstract boolean scrollComponentList(double scrollY);

    protected abstract boolean handleColorClick(double mouseX, double mouseY);

    protected abstract boolean handleContainerClick(double mouseX, double mouseY);

    protected abstract boolean handleBannerClick(double mouseX, double mouseY);

    protected abstract boolean handleDecoratedPotClick(double mouseX, double mouseY);

    protected abstract boolean handleSpawnEggClick(double mouseX, double mouseY);

    protected abstract boolean handleTradesClick(double mouseX, double mouseY, int button);

    protected abstract boolean handleTradeClick(double mouseX, double mouseY);

    protected abstract boolean handleLoreClick(double mouseX, double mouseY);

    protected abstract boolean handleLorePainterClick(double mouseX, double mouseY);

    protected abstract boolean handleNbtAdvancedClick(double mouseX, double mouseY);

    protected abstract void switchPanel(Panel panel);

    protected abstract void openContainerItemEditor();

    protected abstract void openBookItemEditor();

    protected abstract void openArmorTrimEditor();

    abstract void refreshAfterContainerEdit();

    abstract void refreshAfterBookEdit();

    abstract void applyArmorTrimEditedStack(class_1799 stack);

    protected abstract void goBack();

    public abstract void method_25419();

    protected abstract void applyToSelectedSlot();

    protected abstract void dropEditedStack();

    protected abstract void copyGiveCommand();

    protected abstract void resetStack();

    protected abstract void saveRealm();

    protected abstract boolean applyMainFieldsToStack(boolean updateStatus);

    protected abstract boolean tryApplyItemId(boolean throwOnError);

    protected abstract void tryApplyCount(boolean throwOnError);

    protected abstract void tryApplyDamage(boolean throwOnError);

    protected abstract void applyNameToStack();

    protected abstract void clearCustomName();

    protected abstract void applyLoreToStack();

    protected abstract void setLoreLine(int line, String value);

    protected abstract void removeLoreLine(int line);

    protected abstract void moveLoreLine(int line, int direction);

    protected abstract void copyLoreOnly();

    protected abstract void copyFullTooltip();

    protected abstract void pasteLore();

    protected abstract void applySignToStack();

    protected abstract void applyBookMetadataToStack();

    protected abstract void cycleBookGeneration();

    protected abstract void toggleBookResolved();

    protected abstract void toggleBookSignedState();

    protected abstract void unsignBook();

    protected abstract void signBook();

    protected abstract void convertWrittenPagesToWritable(class_2487 tag);

    protected abstract void convertWritablePagesToWritten(class_2487 tag);

    protected abstract class_2561 readBookPageComponent(String raw);

    protected abstract boolean isProbablyJsonText(String raw);

    protected abstract void applyHeadToStack();

    protected abstract void clearHeadOwner();

    protected abstract void randomizeHeadUuid();

    protected abstract void toggleArmorStandFlag(String tagKey, String translationSuffix);

    protected abstract void clearArmorStandEntityTag();

    protected abstract class_2487 getOrCreateArmorStandEntityTag();

    protected abstract void cleanupArmorStandEntityTag(class_2487 entityTag);

    protected abstract class_2561 getArmorStandToggleText(String translationSuffix, String tagKey);

    protected abstract boolean getArmorStandFlag(String tagKey);

    protected abstract void cycleFireworkFlight();

    protected abstract void cycleFireworkExplosionType(int direction);

    protected abstract void toggleFireworkFlicker();

    protected abstract void toggleFireworkTrail();

    protected abstract void cycleFireworkColor(boolean fade, int direction);

    protected abstract void randomizeFireworkColors();

    protected abstract void addFireworkExplosion();

    protected abstract void removeLastFireworkExplosion();

    protected abstract void clearFireworkData();

    protected abstract void applyFireworkControlsToStack();

    protected abstract class_2487 createFireworkExplosionTag();

    protected abstract class_2487 getOrCreateFireworksTag();

    protected abstract void cleanupFireworksTag(class_2487 fireworks);

    protected abstract void cycleContainerSlot(int direction);

    protected abstract void updateContainerSlotFromNbt();

    protected abstract class_1799 parseContainerSlotItem(String value) throws CommandSyntaxException;

    protected abstract void clearContainerSlot();

    protected abstract void clearContainerItems();

    protected abstract void setContainerSlotItem(int slot, class_1799 slotStack);

    protected abstract class_1799 getContainerSlotItem(int slot);

    protected abstract class_2499 getContainerItemsList();

    protected abstract int getContainerItemCount();

    protected abstract String getContainerSelectedSlotNbt();

    protected abstract String getContainerSlotNbt(class_1799 stack);

    protected abstract int getContainerGridX();

    protected abstract int getContainerGridY();

    protected abstract int getHoveredContainerSlot(int mouseX, int mouseY);

    protected abstract class_5250 createSignLineComponent(int line);

    protected abstract boolean hasSignContent();

    protected abstract String getSignLineValue(int line);

    protected abstract String getNormalizedSignCommand();

    protected abstract void cleanupBlockEntityTag(class_2487 tag, class_2487 blockEntity);

    protected abstract void addSelectedBannerPattern();

    protected abstract void removeLastBannerPattern();

    protected abstract void clearBannerPatterns();

    protected abstract void cycleBannerBaseColor(int direction);

    protected abstract void cycleBannerPatternColor(int direction);

    protected abstract void cycleSelectedBannerPattern(int direction);

    protected abstract void setBannerPatternScroll(int value);

    protected abstract void scrollBannerPatternSelectionIntoView(List<BannerPatternEntry> patterns);

    protected abstract void clampBannerPatternSelection(List<BannerPatternEntry> patterns);

    protected abstract int getBannerPatternRowY(int row);

    protected abstract List<BannerPatternEntry> getFilteredBannerPatterns();

    protected abstract class_2561 getBannerPatternName(BannerPatternEntry entry, class_1767 color);

    protected abstract void renderBannerPatternLayers(class_332 guiGraphics);

    protected abstract void swapBannerAndShield();

    protected abstract void setBannerBaseColor(class_1767 color);

    protected abstract void replacePreviewItem(class_1792 item);

    protected abstract void removeBannerBaseColorTag();

    protected abstract class_1767 getBannerBaseColor();

    protected abstract class_1767 getBannerPatternColor();

    protected abstract class_2561 getDyeColorName(class_1767 color);

    protected abstract int getBannerPatternCount();

    protected abstract class_2499 getBannerPatterns();

    protected abstract class_2487 getOrCreateBannerBlockEntityTag();

    protected abstract BannerPatternEntry getBannerPatternEntry(String hash);

    protected abstract void applySelectedPotterySherd();

    protected abstract void clearDecoratedPotSide();

    protected abstract void clearDecoratedPotDecorations();

    protected abstract void selectDecoratedPotSide(int side);

    protected abstract void cycleSelectedPotterySherd(int direction);

    protected abstract void setPotterySherdScroll(int value);

    protected abstract void clampPotterySherdSelection(List<PotterySherdEntry> sherds);

    protected abstract int getPotterySherdRowY(int row);

    protected abstract List<PotterySherdEntry> getFilteredPotterySherds();

    protected abstract class_2561 getPotterySherdName(PotterySherdEntry entry);

    protected abstract class_2561 getDecoratedPotSideName(int side);

    protected abstract class_2561 getDecoratedPotSideItemName(int side);

    protected abstract int getDecoratedPotDecorationCount();

    protected abstract void renderDecoratedPotSides(class_332 guiGraphics);

    protected abstract void applySelectedSpawnEggEntity();

    protected abstract void syncSpawnEggToSelectedEntityItem();

    protected abstract void writeSpawnEggEntityId(SpawnEggEntityEntry entry);

    protected abstract void clearSpawnEggEntityTag();

    protected abstract void toggleSpawnEggBoolean(SpawnEggTagRow row);

    protected abstract void toggleSpawnEggPresence(SpawnEggTagRow row);

    protected abstract void applySpawnEggCustomName(String value);

    protected abstract void applySpawnEggOwner(String value);

    protected abstract void applySpawnEggNumber(SpawnEggTagRow row, String value);

    protected abstract void cycleSpawnEggChoice(SpawnEggTagRow row);

    protected abstract class_2487 getOrCreateSpawnEditorEntityTag();

    protected abstract void cleanupSpawnEggEntityTag(class_2487 entityTag);

    protected abstract class_2487 getOrCreateSpawnerEntityTag();

    protected abstract class_2487 getOrCreateSpawnerBlockEntityTag();

    protected abstract void cleanupSpawnerEntityTag(class_2487 entityTag);

    protected abstract void clearSpawnerSpawnData();

    protected abstract void clearSpawnerSpawnPotentials();

    protected abstract void cleanupSpawnerBlockEntityTag(class_2487 blockEntity);

    protected abstract boolean isOnlySpawnerBlockEntityId(class_2487 blockEntity);

    protected abstract class_2561 getSpawnEggBooleanText(SpawnEggTagRow row);

    protected abstract class_2561 getSpawnEggPresenceText(SpawnEggTagRow row);

    protected abstract class_2561 getSpawnEggChoiceText(SpawnEggTagRow row);

    protected abstract class_2561 getSpawnEggChoiceOptionText(SpawnEggTagRow row);

    protected abstract String getSpawnEggChoiceValue(SpawnEggTagRow row);

    protected abstract int getSpawnEggChoiceIndex(SpawnEggTagRow row, String value);

    protected abstract boolean getSpawnEggBooleanValue(SpawnEggTagRow row);

    protected abstract String getSpawnEggNumberValue(SpawnEggTagRow row);

    protected abstract int getSpawnEggTagTextMaxLength(SpawnEggTagRow row);

    protected abstract String getSpawnEggTagTextValue(SpawnEggTagRow row);

    protected abstract class_2487 getSpawnEggTagParent(class_2487 entityTag, String tagPath, boolean create);

    protected abstract String getSpawnEggLeafTagKey(String tagPath);

    protected abstract void putSpawnEggBooleanValue(class_2487 entityTag, String tagPath, boolean value);

    protected abstract void putSpawnEggStringValue(class_2487 entityTag, String tagPath, String value);

    protected abstract void putSpawnEggIntValue(class_2487 entityTag, String tagPath, int value);

    protected abstract void putSpawnEggNumberValue(class_2487 entityTag, SpawnEggTagRow row, double storedValue);

    protected abstract void removeSpawnEggTagValue(class_2487 entityTag, String tagPath);

    protected abstract boolean removeSpawnEggTagValue(class_2487 current, String[] parts, int index);

    protected abstract boolean isAllowedSpawnEggNumber(String value, SpawnEggNumberType type);

    protected abstract boolean isPartialSpawnEggNumber(String value);

    protected abstract String formatSpawnEggNumber(double value);

    protected abstract void setSpawnEggEntityScroll(int value);

    protected abstract void setSpawnEggTagScroll(int value);

    protected abstract void cycleSelectedSpawnEggEntity(int direction);

    protected abstract void scrollSpawnEggSelectionIntoView(List<SpawnEggEntityEntry> entities);

    protected abstract void clampSpawnEggEntitySelection(List<SpawnEggEntityEntry> entities);

    protected abstract int getSpawnEggEntityRowY(int row);

    protected abstract int getSpawnEggTagRowY(int row);

    protected abstract int getSpawnEggControlsX();

    protected abstract int getSpawnEggControlsWidth();

    protected abstract SpawnEggEntityEntry getSelectedSpawnEggEntityEntry();

    protected abstract List<SpawnEggEntityEntry> getFilteredSpawnEggEntities();

    protected abstract String formatSpawnEggEntityEntry(SpawnEggEntityEntry entry);

    protected abstract class_2561 getSpawnEggEntityName(SpawnEggEntityEntry entry);

    protected abstract class_2561 getCurrentSpawnEggEntityName();

    protected abstract class_1299<?> getCurrentSpawnEggEntityType(class_1799 stack);

    protected abstract String getSpawnEggEntityIdOverride(class_1799 stack);

    protected abstract class_2487 getSpawnEditorEntityTag(class_1799 stack);

    protected abstract class_2487 getSpawnerEntityTag(class_1799 stack);

    protected abstract class_2487 getFirstSpawnerPotentialEntity(class_2487 blockEntity);

    protected abstract class_2487 getSpawnerEntityFromPotential(class_2487 potential);

    protected abstract class_2487 getSpawnerEntityFromSpawnData(class_2487 spawnData);

    protected abstract void putSpawnerSpawnData(class_2487 blockEntity, class_2487 originalSpawnData, class_2487 entityTag);

    protected abstract boolean hasSpawnEditorEntityData(class_1799 stack);

    protected abstract String getSpawnEditorTitleKey();

    protected abstract String getSpawnEditorClearKey();

    protected abstract String getSpawnEditorDefaultEntityKey();

    protected abstract List<SpawnEggTagRow> getSpawnEggTagRows();

    protected abstract void ensureVillagerTradeOffers();

    protected abstract void ensureVillagerData(class_2487 entityTag);

    protected abstract void addVillagerTrade();

    protected abstract void removeSelectedVillagerTrade();

    protected abstract void removeVillagerTrade(int index);

    protected abstract void clearVillagerTrades();

    protected abstract void updateSelectedTradeFromFields();

    protected abstract void toggleSelectedTradeRewardExp();

    protected abstract void updateSelectedTradeMaxUses();

    protected abstract void openVillagerTrade(int index);

    protected abstract void selectVillagerTrade(int index);

    protected abstract void selectTradeSlot(int slot);

    protected abstract void openTradeSlotItemEditor(int slot);

    protected abstract void applyTradeSlotEditorAndReturn();

    protected abstract void setTradeSlotItem(int tradeIndex, int slot, class_1799 stack);

    protected abstract void readTradeFieldsFromStack(class_1799 stack);

    protected abstract void resetTradeFieldValues();

    protected abstract class_2499 getVillagerTradeRecipes();

    protected abstract class_2499 getVillagerTradeRecipes(class_1799 stack);

    protected abstract int getVillagerTradeCount();

    protected abstract class_2487 getSelectedTradeRecipe();

    protected abstract class_2499 copyTradeRecipes(class_2499 recipes);

    protected abstract void putVillagerTradeRecipes(class_2499 recipes);

    protected abstract class_2487 createDefaultTradeTag();

    protected abstract void putTradeSlotItem(class_2487 recipe, int slot, class_1799 stack);

    protected abstract class_1799 getTradeSlotItem(class_2487 recipe, int slot);

    protected abstract String getTradeSlotTagName(int slot);

    protected abstract class_1799 parseTradeSlotItem(String value) throws CommandSyntaxException;

    protected abstract String getTradeSlotItemNbt(class_1799 stack);

    protected abstract int parseTradeIntField(String value, String fieldSuffix, int defaultValue, int minValue, int maxValue);

    protected abstract float parseTradeFloatField(String value, String fieldSuffix, float defaultValue);

    protected abstract int getTradeInt(class_2487 recipe, String tagName, int defaultValue);

    protected abstract float getTradeFloat(class_2487 recipe, String tagName, float defaultValue);

    protected abstract String formatTradeRecipe(class_2487 recipe);

    protected abstract String formatTradeStack(class_1799 stack);

    protected abstract void renderTradeSlotItem(class_332 guiGraphics, class_2487 recipe, int slot);

    protected abstract int getTradeListRowY(int index, int size);

    protected abstract int getHoveredTradeListIndex(int mouseX, int mouseY);

    protected abstract boolean isMouseOverAddTrade(int mouseX, int mouseY);

    protected abstract boolean isMouseOverCenteredText(int mouseX, int mouseY, String text, int centerX, int y);

    protected abstract int getSingleTradeSlotX(int slot);

    protected abstract int getSingleTradeSlotY();

    protected abstract int getHoveredSingleTradeSlot(int mouseX, int mouseY);

    protected abstract void clampTradeSelection(class_2499 trades);

    protected abstract void setTradeScroll(int value);

    protected abstract void scrollTradeSelectionIntoView(class_2499 trades);

    protected abstract int getTradeRowY(int row);

    protected abstract int getTradeListWidth();

    protected abstract int getTradeControlsX();

    protected abstract int getTradeControlsWidth();

    protected abstract int getTradeSlotButtonX(int slot);

    protected abstract int getTradeSlotIconX(int slot);

    protected abstract int getTradeSlotIconY();

    protected abstract int getHoveredTradeSlot(int mouseX, int mouseY);

    protected abstract void updateRawNbt();

    protected abstract void updateComponentNbt();

    protected abstract void toggleUnbreakable();

    protected abstract class_2561 getUnbreakableText();

    protected abstract void toggleHideFlag(HideFlag flag);

    protected abstract class_2561 getHideFlagText(HideFlag flag);

    protected abstract void toggleEnchantmentsScope();

    protected abstract void renderActiveEnchantments(class_332 guiGraphics);

    protected abstract boolean tryRemoveActiveEnchantment(double mouseX, double mouseY);

    protected abstract boolean tryAddRingEnchantment(double mouseX, double mouseY);

    protected abstract void addEnchantment(class_1887 enchantment);

    protected abstract void addMatchingEnchantments();

    protected abstract int getLevelForEnchantment(class_1887 enchantment);

    protected abstract int getDisplayLevel(class_1887 enchantment);

    protected abstract void putEnchantment(class_1887 enchantment, int level);

    protected abstract boolean removeEnchantmentAtIndex(int index);

    protected abstract class_2499 getOrCreateEnchantmentsTag();

    protected abstract List<class_1887> getFilteredEnchantments(class_1799 stack);

    protected abstract boolean canApplyEnchantment(class_1799 stack, class_1887 enchantment);

    protected abstract List<EnchantmentEntry> getStoredEnchantments(class_1799 stack);

    protected abstract boolean tryRemoveActivePotionEffect(double mouseX, double mouseY);

    protected abstract boolean tryAddRingPotionEffect(double mouseX, double mouseY);

    protected abstract void addMatchingPotionEffects();

    protected abstract boolean addPotionEffect(class_1291 effect);

    protected abstract void removeCustomPotionEffectAt(int index);

    protected abstract List<class_1293> getCustomPotionEffects();

    protected abstract List<class_1291> getFilteredPotionEffects();

    protected abstract int parsePotionLevel();

    protected abstract int parsePotionSeconds();

    protected abstract void togglePotionParticles();

    protected abstract String formatPotionEffect(class_1293 effect);

    protected abstract String formatPotionRingName(class_1291 effect);

    protected abstract void toggleAttributeInfinity();

    protected abstract void cycleAttributeOperation();

    protected abstract void cycleAttributeSlot();

    protected abstract boolean tryRemoveActiveAttributeModifier(double mouseX, double mouseY);

    protected abstract boolean tryAddRingAttribute(double mouseX, double mouseY);

    protected abstract void addAttributeModifier(class_1320 attribute);

    protected abstract Double getAttributeAmount();

    protected abstract int parseBoundedAttributeNumber(String value, int max);

    protected abstract class_1322.class_1323 getAttributeOperation();

    protected abstract class_2499 getOrCreateAttributeModifiersTag();

    protected abstract List<AttributeEntry> getAttributeModifierEntries();

    protected abstract void removeAttributeModifierAt(int tagIndex);

    protected abstract String formatAttributeEntry(AttributeEntry entry);

    protected abstract class_2561 getAttributeDisplayName(AttributeEntry entry);

    protected abstract class_1320 getAttributeByName(String name);

    protected abstract List<class_1320> getSharedAttributes();

    protected abstract void applyColorFromHex(boolean updateStatus);

    protected abstract void setColorComponent(int shift, int value);

    protected abstract void syncColorControlsFromStack();

    protected abstract int getEditorColor();

    protected abstract void setEditorColor(int color);

    protected abstract void addDyeToColor(class_1767 dyeColor);

    protected abstract void renderDyeGrid(class_332 guiGraphics);

    protected abstract boolean shouldShowDyeGrid();

    protected abstract void ensureLorePainterRows();

    protected abstract void addLorePainterRow();

    protected abstract void removeLorePainterRow();

    protected abstract void addLorePainterColumn();

    protected abstract void removeLorePainterColumn();

    protected abstract void insertLorePainterRows();

    protected abstract void cycleGuiScale();

    protected abstract void paintLorePainterAt(double mouseX, double mouseY);

    protected abstract String buildLorePainterRow(List<LorePixel> row);

    protected abstract String buildLorePainterSymbols();

    protected abstract String buildLorePainterColors();

    protected abstract int getLorePainterColorX();

    protected abstract int getLorePainterGridX();

    protected abstract int getLorePainterGridY();

    protected abstract int getLorePainterSizeX();

    protected abstract int getLorePainterSizeY();

    protected abstract void updateMouseDistance(int mouseX, int mouseY);

    protected abstract int getRingRadius();

    protected abstract boolean isMouseOverCenter(double mouseX, double mouseY);

    protected abstract void insertFormattingPrefix();

    protected abstract void stripFocusedFormatting();

    protected abstract void insertFocusedText(String text);

    protected abstract class_342 getFocusedTextBox();

    protected abstract List<class_2561> getPrettyNbtLines();

    protected abstract List<NbtRow> buildNbtRows();

    protected abstract int getNbtAdvancedVisibleRows();

    protected abstract void readMainFieldsFromStack(class_1799 stack);

    protected abstract String readLoreLine(String raw);

    protected abstract void readSignFieldsFromStack(class_1799 stack);

    protected abstract void readSignLine(int line, String raw);

    protected abstract void readBookFieldsFromStack(class_1799 stack);

    protected abstract void readHeadFieldsFromStack(class_1799 stack);

    protected abstract void readFireworkFieldsFromStack(class_1799 stack);

    protected abstract void readContainerFieldsFromStack(class_1799 stack);

    protected abstract class_2487 getFireworkExplosionForFields(class_1799 stack);

    protected abstract void readBannerFieldsFromStack(class_1799 stack);

    protected abstract void readDecoratedPotFieldsFromStack(class_1799 stack);

    protected abstract void readSpawnEggFieldsFromStack(class_1799 stack);

    protected abstract class_2561 readSerializedComponent(String raw);

    protected abstract void updateLoreScrollFromMouse(double mouseY);

    protected abstract void setLoreScroll(int value);

    protected abstract void captureFieldValues();

    protected abstract class_2487 parseNbt(String nbt) throws CommandSyntaxException;

    protected abstract void cleanupEmptyDisplayTag();

    protected abstract void cleanupEmptyTag();

    protected abstract int loreLineSpaces();

    protected abstract boolean isMouseIn(double mouseX, double mouseY, int x, int y, int width, int height);

    protected abstract boolean isTradeSlotEditor();

    protected abstract boolean isNameFollowingDefault(class_1799 stack);

    protected abstract String getDefaultHoverName(class_1799 stack);

    protected abstract boolean isVillagerTradeEditableItem(class_1799 stack);

    protected abstract int getBookGeneration();

    protected abstract int getBookPageCount();

    protected abstract class_2561 getBookResolvedText();

    protected abstract class_2561 getBookSignButtonText();

    protected abstract int getFireworkFlight();

    protected abstract int getFireworkExplosionCount();

    protected abstract boolean hasFireworkData();

    protected abstract class_2561 getFireworkTypeName(int type);

    protected abstract class_2561 getFireworkFadeColorText();

    protected abstract class_1767 getFireworkDyeColor(int colorId);

    protected abstract String formatRingEnchantmentName(class_1887 enchantment);

    protected abstract String formatStoredEnchantment(EnchantmentEntry entry);

    protected static String key(String suffix) {
        return "screen." + ModSource.MODID + "." + suffix;
    }

    protected static String messageKey(String suffix) {
        return "message." + ModSource.MODID + "." + suffix;
    }
}
