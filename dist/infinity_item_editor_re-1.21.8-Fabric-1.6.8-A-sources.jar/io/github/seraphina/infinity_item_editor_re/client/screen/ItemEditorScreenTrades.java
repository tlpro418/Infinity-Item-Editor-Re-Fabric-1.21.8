package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernUi;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2522;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
abstract class ItemEditorScreenTrades extends ItemEditorScreenBannerSpawn {
    protected ItemEditorScreenTrades(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

    protected void ensureVillagerTradeOffers() {
        if (!isVillagerTradeEditableItem(this.previewStack)) {
            return;
        }

        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        class_2487 entityTag = tag.method_68568(ENTITY_TAG);
        if (!entityTag.method_10545(ENTITY_ID_TAG)) {
            entityTag.method_10582(ENTITY_ID_TAG, "minecraft:villager");
        }
        ensureVillagerData(entityTag);
        if (!entityTag.method_10545(OFFERS_TAG)) {
            entityTag.method_10566(OFFERS_TAG, new class_2487());
        }
        class_2487 offers = entityTag.method_68568(OFFERS_TAG);
        if (!offers.method_10545(RECIPES_TAG)) {
            offers.method_10566(RECIPES_TAG, new class_2499());
        }
        entityTag.method_10566(OFFERS_TAG, offers);
        tag.method_10566(ENTITY_TAG, entityTag);
        this.rawNbtValue = getInitialNbt(this.previewStack);
        readTradeFieldsFromStack(this.previewStack);
    }

    protected void ensureVillagerData(class_2487 entityTag) {
        class_2487 villagerData = entityTag.method_10545(VILLAGER_DATA_TAG)
                ? entityTag.method_68568(VILLAGER_DATA_TAG)
                : new class_2487();
        if (!villagerData.method_10545(VILLAGER_TYPE_TAG)) {
            villagerData.method_10582(VILLAGER_TYPE_TAG, DEFAULT_VILLAGER_TYPE);
        }
        if (!villagerData.method_10545(VILLAGER_PROFESSION_TAG)) {
            villagerData.method_10582(VILLAGER_PROFESSION_TAG, DEFAULT_VILLAGER_PROFESSION);
        }
        if (!villagerData.method_10545(VILLAGER_LEVEL_TAG)) {
            villagerData.method_10569(VILLAGER_LEVEL_TAG, DEFAULT_VILLAGER_LEVEL);
        } else {
            villagerData.method_10569(VILLAGER_LEVEL_TAG, class_3532.method_15340(villagerData.method_68083(VILLAGER_LEVEL_TAG, 0), 1, 5));
        }
        entityTag.method_10566(VILLAGER_DATA_TAG, villagerData);
    }

    protected void addVillagerTrade() {
        if (!isVillagerTradeEditableItem(this.previewStack)) {
            return;
        }

        class_2499 recipes = copyTradeRecipes(getVillagerTradeRecipes());
        recipes.add(createDefaultTradeTag());
        putVillagerTradeRecipes(recipes);
        this.selectedTradeIndex = recipes.size() - 1;
        scrollTradeSelectionIntoView(recipes);
        readTradeFieldsFromStack(this.previewStack);
        this.status = class_2561.method_43469(messageKey("editor_trade_added"), recipes.size());
        method_41843();
    }

    protected void removeSelectedVillagerTrade() {
        removeVillagerTrade(this.selectedTradeIndex);
    }

    protected void removeVillagerTrade(int index) {
        if (!isVillagerTradeEditableItem(this.previewStack)) {
            return;
        }

        class_2499 recipes = copyTradeRecipes(getVillagerTradeRecipes());
        if (recipes.isEmpty()) {
            return;
        }

        int removedIndex = class_3532.method_15340(index, 0, recipes.size() - 1);
        recipes.method_10536(removedIndex);
        this.selectedTradeIndex = class_3532.method_15340(removedIndex, 0, Math.max(0, recipes.size() - 1));
        putVillagerTradeRecipes(recipes);
        readTradeFieldsFromStack(this.previewStack);
        this.status = class_2561.method_43469(messageKey("editor_trade_removed"), removedIndex + 1);
        method_41843();
    }

    protected void clearVillagerTrades() {
        if (!isVillagerTradeEditableItem(this.previewStack)) {
            return;
        }

        putVillagerTradeRecipes(new class_2499());
        this.selectedTradeIndex = 0;
        this.tradeScroll = 0;
        resetTradeFieldValues();
        this.status = class_2561.method_43471(messageKey("editor_trades_cleared"));
        method_41843();
    }

    protected void updateSelectedTradeFromFields() {
        if (!isVillagerTradeEditableItem(this.previewStack)) {
            return;
        }

        captureFieldValues();
        class_2499 recipes = copyTradeRecipes(getVillagerTradeRecipes());
        if (recipes.isEmpty()) {
            return;
        }

        clampTradeSelection(recipes);
        class_2487 recipe = recipes.method_68582(this.selectedTradeIndex).method_10553();
        try {
            class_1799 slotStack = parseTradeSlotItem(this.tradeItemNbtValue);
            if (slotStack.method_7960() && this.selectedTradeSlot != TRADE_SLOT_SECOND_BUY) {
                throw new IllegalArgumentException(class_2561.method_43471(messageKey("editor_trade_invalid_item")).getString());
            }
            putTradeSlotItem(recipe, this.selectedTradeSlot, slotStack);
            recipe.method_10569(TRADE_USES_TAG, parseTradeIntField(this.tradeUsesValue, "uses", 0, 0, Integer.MAX_VALUE));
            recipe.method_10569(TRADE_MAX_USES_TAG, parseTradeIntField(this.tradeMaxUsesValue, "max_uses",
                    TRADE_DEFAULT_MAX_USES, 0, Integer.MAX_VALUE));
            recipe.method_10569(TRADE_XP_TAG, parseTradeIntField(this.tradeXpValue, "xp", 0, 0, Integer.MAX_VALUE));
            recipe.method_10548(TRADE_PRICE_MULTIPLIER_TAG, parseTradeFloatField(this.tradePriceMultiplierValue,
                    "price_multiplier", TRADE_DEFAULT_PRICE_MULTIPLIER));
            recipe.method_10569(TRADE_SPECIAL_PRICE_TAG, parseTradeIntField(this.tradeSpecialPriceValue, "special_price",
                    0, Integer.MIN_VALUE, Integer.MAX_VALUE));
            recipe.method_10569(TRADE_DEMAND_TAG, parseTradeIntField(this.tradeDemandValue, "demand",
                    0, Integer.MIN_VALUE, Integer.MAX_VALUE));
            recipe.method_10556(TRADE_REWARD_EXP_TAG, this.tradeRewardExp);
            recipes.method_68585(this.selectedTradeIndex, recipe);
            putVillagerTradeRecipes(recipes);
            this.tradeItemNbtValue = getTradeSlotItemNbt(slotStack);
            this.status = class_2561.method_43469(messageKey("editor_trade_updated"), this.selectedTradeIndex + 1);
            readTradeFieldsFromStack(this.previewStack);
            method_41843();
        } catch (CommandSyntaxException exception) {
            this.status = class_2561.method_43469(messageKey("editor_invalid_nbt"), exception.getMessage());
        } catch (IllegalArgumentException exception) {
            this.status = class_2561.method_43470(exception.getMessage());
        }
    }

    protected void toggleSelectedTradeRewardExp() {
        class_2499 recipes = copyTradeRecipes(getVillagerTradeRecipes());
        if (recipes.isEmpty()) {
            return;
        }

        clampTradeSelection(recipes);
        class_2487 recipe = recipes.method_68582(this.selectedTradeIndex).method_10553();
        this.tradeRewardExp = !this.tradeRewardExp;
        recipe.method_10556(TRADE_REWARD_EXP_TAG, this.tradeRewardExp);
        recipes.method_68585(this.selectedTradeIndex, recipe);
        putVillagerTradeRecipes(recipes);
        this.status = class_2561.method_43469(messageKey("editor_trade_updated"), this.selectedTradeIndex + 1);
        method_41843();
    }

    protected void updateSelectedTradeMaxUses() {
        class_2499 recipes = copyTradeRecipes(getVillagerTradeRecipes());
        if (recipes.isEmpty()) {
            return;
        }

        clampTradeSelection(recipes);
        class_2487 recipe = recipes.method_68582(this.selectedTradeIndex).method_10553();
        int maxUses = parseTradeIntField(this.tradeMaxUsesValue, "max_uses",
                TRADE_DEFAULT_MAX_USES, -TRADE_MAX_USES_LIMIT, TRADE_MAX_USES_LIMIT);
        recipe.method_10569(TRADE_MAX_USES_TAG, maxUses);
        recipes.method_68585(this.selectedTradeIndex, recipe);
        putVillagerTradeRecipes(recipes);
    }

    protected void openVillagerTrade(int index) {
        class_2499 trades = getVillagerTradeRecipes();
        if (trades.isEmpty()) {
            return;
        }

        this.selectedTradeIndex = class_3532.method_15340(index, 0, trades.size() - 1);
        this.selectedTradeSlot = TRADE_SLOT_FIRST_BUY;
        this.activePanel = Panel.TRADE;
        this.status = class_2561.method_43473();
        readTradeFieldsFromStack(this.previewStack);
        method_41843();
    }

    protected void selectVillagerTrade(int index) {
        class_2499 trades = getVillagerTradeRecipes();
        if (trades.isEmpty()) {
            return;
        }

        this.selectedTradeIndex = class_3532.method_15340(index, 0, trades.size() - 1);
        scrollTradeSelectionIntoView(trades);
        readTradeFieldsFromStack(this.previewStack);
        method_41843();
    }

    protected void selectTradeSlot(int slot) {
        this.selectedTradeSlot = class_3532.method_15340(slot, 0, TRADE_SLOT_COUNT - 1);
        readTradeFieldsFromStack(this.previewStack);
        method_41843();
    }

    protected void openTradeSlotItemEditor(int slot) {
        if (this.field_22787 == null) {
            return;
        }

        class_2499 trades = getVillagerTradeRecipes();
        if (trades.isEmpty()) {
            return;
        }

        clampTradeSelection(trades);
        int clampedSlot = class_3532.method_15340(slot, 0, TRADE_SLOT_COUNT - 1);
        this.selectedTradeSlot = clampedSlot;
        class_1799 slotStack = getTradeSlotItem(trades.method_68582(this.selectedTradeIndex), clampedSlot);
        this.field_22787.method_1507(new ItemEditorScreen(slotStack, (ItemEditorScreen) this, this.selectedTradeIndex, clampedSlot));
    }

    protected void applyTradeSlotEditorAndReturn() {
        if (this.parentTradeScreen == null || this.field_22787 == null) {
            method_25419();
            return;
        }

        if (!applyMainFieldsToStack(true)) {
            return;
        }

        this.parentTradeScreen.setTradeSlotItem(this.parentTradeIndex, this.parentTradeSlot, this.previewStack.method_7972());
        this.parentTradeScreen.activePanel = Panel.TRADE;
        this.parentTradeScreen.status = class_2561.method_43473();
        this.parentTradeScreen.method_41843();
        this.field_22787.method_1507(this.parentTradeScreen);
    }

    protected void setTradeSlotItem(int tradeIndex, int slot, class_1799 stack) {
        if (!isVillagerTradeEditableItem(this.previewStack)) {
            return;
        }

        class_2499 recipes = copyTradeRecipes(getVillagerTradeRecipes());
        if (recipes.isEmpty()) {
            return;
        }

        int clampedIndex = class_3532.method_15340(tradeIndex, 0, recipes.size() - 1);
        int clampedSlot = class_3532.method_15340(slot, 0, TRADE_SLOT_COUNT - 1);
        class_2487 recipe = recipes.method_68582(clampedIndex).method_10553();
        putTradeSlotItem(recipe, clampedSlot, stack);
        recipes.method_68585(clampedIndex, recipe);
        this.selectedTradeIndex = clampedIndex;
        this.selectedTradeSlot = clampedSlot;
        putVillagerTradeRecipes(recipes);
        readTradeFieldsFromStack(this.previewStack);
    }

    protected void readTradeFieldsFromStack(class_1799 stack) {
        class_2499 trades = getVillagerTradeRecipes(stack);
        clampTradeSelection(trades);
        if (!isVillagerTradeEditableItem(stack) || trades.isEmpty()) {
            resetTradeFieldValues();
            return;
        }

        class_2487 recipe = trades.method_68582(this.selectedTradeIndex);
        class_1799 slotStack = getTradeSlotItem(recipe, this.selectedTradeSlot);
        this.tradeItemNbtValue = getTradeSlotItemNbt(slotStack);
        this.tradeUsesValue = Integer.toString(getTradeInt(recipe, TRADE_USES_TAG, 0));
        this.tradeMaxUsesValue = Integer.toString(getTradeInt(recipe, TRADE_MAX_USES_TAG, TRADE_DEFAULT_MAX_USES));
        this.tradeXpValue = Integer.toString(getTradeInt(recipe, TRADE_XP_TAG, 0));
        this.tradePriceMultiplierValue = Float.toString(getTradeFloat(recipe, TRADE_PRICE_MULTIPLIER_TAG,
                TRADE_DEFAULT_PRICE_MULTIPLIER));
        this.tradeSpecialPriceValue = Integer.toString(getTradeInt(recipe, TRADE_SPECIAL_PRICE_TAG, 0));
        this.tradeDemandValue = Integer.toString(getTradeInt(recipe, TRADE_DEMAND_TAG, 0));
        this.tradeRewardExp = !recipe.method_10545(TRADE_REWARD_EXP_TAG) || recipe.method_68566(TRADE_REWARD_EXP_TAG, false);
    }

    protected void resetTradeFieldValues() {
        this.tradeItemNbtValue = "{}";
        this.tradeUsesValue = "0";
        this.tradeMaxUsesValue = Integer.toString(TRADE_DEFAULT_MAX_USES);
        this.tradeXpValue = "0";
        this.tradePriceMultiplierValue = Float.toString(TRADE_DEFAULT_PRICE_MULTIPLIER);
        this.tradeSpecialPriceValue = "0";
        this.tradeDemandValue = "0";
        this.tradeRewardExp = true;
    }

    protected class_2499 getVillagerTradeRecipes() {
        return getVillagerTradeRecipes(this.previewStack);
    }

    protected class_2499 getVillagerTradeRecipes(class_1799 stack) {
        class_2487 entityTag = ItemStackNbt.getElement(stack, ENTITY_TAG);
        if (entityTag == null || !entityTag.method_10545(OFFERS_TAG)) {
            return new class_2499();
        }

        class_2487 offers = entityTag.method_68568(OFFERS_TAG);
        if (!offers.method_10545(RECIPES_TAG)) {
            return new class_2499();
        }
        return offers.method_68569(RECIPES_TAG);
    }

    protected int getVillagerTradeCount() {
        return getVillagerTradeRecipes().size();
    }

    protected class_2487 getSelectedTradeRecipe() {
        class_2499 trades = getVillagerTradeRecipes();
        if (trades.isEmpty()) {
            return null;
        }
        clampTradeSelection(trades);
        return trades.method_68582(this.selectedTradeIndex);
    }

    protected class_2499 copyTradeRecipes(class_2499 recipes) {
        class_2499 copy = new class_2499();
        for (int i = 0; i < recipes.size(); i++) {
            copy.add(recipes.method_68582(i).method_10553());
        }
        return copy;
    }

    protected void putVillagerTradeRecipes(class_2499 recipes) {
        class_2487 tag = ItemStackNbt.getOrCreate(this.previewStack);
        class_2487 entityTag = tag.method_68568(ENTITY_TAG);
        if (!recipes.isEmpty() && !entityTag.method_10545(ENTITY_ID_TAG)) {
            entityTag.method_10582(ENTITY_ID_TAG, "minecraft:villager");
        }
        if (!recipes.isEmpty()) {
            ensureVillagerData(entityTag);
        }

        class_2487 offers = entityTag.method_10545(OFFERS_TAG)
                ? entityTag.method_68568(OFFERS_TAG)
                : new class_2487();
        offers.method_10566(RECIPES_TAG, recipes);
        entityTag.method_10566(OFFERS_TAG, offers);
        tag.method_10566(ENTITY_TAG, entityTag);
        this.rawNbtValue = getInitialNbt(this.previewStack);
    }

    protected class_2487 createDefaultTradeTag() {
        class_2487 recipe = new class_2487();
        putTradeSlotItem(recipe, TRADE_SLOT_FIRST_BUY, new class_1799(class_1802.field_8687));
        putTradeSlotItem(recipe, TRADE_SLOT_SELL, new class_1799(class_1802.field_8687));
        recipe.method_10569(TRADE_USES_TAG, 0);
        recipe.method_10569(TRADE_MAX_USES_TAG, TRADE_DEFAULT_MAX_USES);
        recipe.method_10556(TRADE_REWARD_EXP_TAG, true);
        recipe.method_10569(TRADE_XP_TAG, 0);
        recipe.method_10548(TRADE_PRICE_MULTIPLIER_TAG, TRADE_DEFAULT_PRICE_MULTIPLIER);
        recipe.method_10569(TRADE_SPECIAL_PRICE_TAG, 0);
        recipe.method_10569(TRADE_DEMAND_TAG, 0);
        return recipe;
    }

    protected void putTradeSlotItem(class_2487 recipe, int slot, class_1799 stack) {
        String tagName = getTradeSlotTagName(slot);
        if (stack.method_7960()) {
            recipe.method_10551(tagName);
        } else {
            recipe.method_10566(tagName, ItemStackNbt.save(stack));
        }
    }

    protected class_1799 getTradeSlotItem(class_2487 recipe, int slot) {
        String tagName = getTradeSlotTagName(slot);
        if (!recipe.method_10545(tagName)) {
            return class_1799.field_8037;
        }
        return ItemStackNbt.parse(recipe.method_68568(tagName));
    }

    protected String getTradeSlotTagName(int slot) {
        return switch (slot) {
            case TRADE_SLOT_SECOND_BUY -> TRADE_BUY_B_TAG;
            case TRADE_SLOT_SELL -> TRADE_SELL_TAG;
            default -> TRADE_BUY_TAG;
        };
    }

    protected class_1799 parseTradeSlotItem(String value) throws CommandSyntaxException {
        String trimmed = value == null ? "" : value.trim();
        if (trimmed.isEmpty() || "{}".equals(trimmed)) {
            return class_1799.field_8037;
        }

        class_2487 itemTag = class_2522.method_67315(trimmed);
        class_1799 stack = ItemStackNbt.parse(itemTag);
        if (stack.method_7960()) {
            throw new IllegalArgumentException(class_2561.method_43471(messageKey("editor_trade_invalid_item")).getString());
        }
        return stack;
    }

    protected String getTradeSlotItemNbt(class_1799 stack) {
        if (stack.method_7960()) {
            return "{}";
        }
        return ItemStackNbt.save(stack).toString();
    }

    protected int parseTradeIntField(String value, String fieldSuffix, int defaultValue, int minValue, int maxValue) {
        String normalized = value == null ? "" : value.trim();
        if (normalized.isEmpty()) {
            return defaultValue;
        }

        try {
            long parsed = Long.parseLong(normalized);
            if (parsed < minValue || parsed > maxValue) {
                throw new NumberFormatException();
            }
            return (int) parsed;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(class_2561.method_43469(messageKey("editor_trade_invalid_number"),
                    class_2561.method_43471(key("trades." + fieldSuffix)), minValue, maxValue).getString());
        }
    }

    protected float parseTradeFloatField(String value, String fieldSuffix, float defaultValue) {
        String normalized = value == null ? "" : value.trim();
        if (normalized.isEmpty()) {
            return defaultValue;
        }

        try {
            float parsed = Float.parseFloat(normalized);
            if (!Float.isFinite(parsed) || parsed < 0.0F) {
                throw new NumberFormatException();
            }
            return parsed;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(class_2561.method_43469(messageKey("editor_trade_invalid_decimal"),
                    class_2561.method_43471(key("trades." + fieldSuffix))).getString());
        }
    }

    protected int getTradeInt(class_2487 recipe, String tagName, int defaultValue) {
        return recipe.method_10545(tagName) ? recipe.method_68083(tagName, 0) : defaultValue;
    }

    protected float getTradeFloat(class_2487 recipe, String tagName, float defaultValue) {
        return recipe.method_10545(tagName) ? recipe.method_66563(tagName, 0.0F) : defaultValue;
    }

    protected String formatTradeRecipe(class_2487 recipe) {
        class_1799 firstBuy = getTradeSlotItem(recipe, TRADE_SLOT_FIRST_BUY);
        class_1799 secondBuy = getTradeSlotItem(recipe, TRADE_SLOT_SECOND_BUY);
        class_1799 sell = getTradeSlotItem(recipe, TRADE_SLOT_SELL);
        String cost = formatTradeStack(firstBuy);
        if (!secondBuy.method_7960()) {
            cost += " + " + formatTradeStack(secondBuy);
        }
        return cost + " -> " + formatTradeStack(sell);
    }

    protected String formatTradeStack(class_1799 stack) {
        if (stack.method_7960()) {
            return class_2561.method_43471(key("trades.empty_slot")).getString();
        }
        return stack.method_7964().getString();
    }

    protected void renderTradeSlotItem(class_332 guiGraphics, class_2487 recipe, int slot) {
        class_1799 stack = getTradeSlotItem(recipe, slot);
        int x = getSingleTradeSlotX(slot);
        int y = getSingleTradeSlotY();
        if (isSidebarUi()) {
            ModernUi.fillItemWell(guiGraphics, x + 8, y + 8, 30);
        } else if (stack.method_7960()) {
            guiGraphics.method_25294(x - 1, y - 1, x + 17, y + 17, 0xFF555555);
            guiGraphics.method_25294(x, y, x + ITEM_SIZE, y + ITEM_SIZE, 0xFF1C1C1C);
        }
        if (stack.method_7960()) {
            return;
        }
        guiGraphics.method_51427(stack, x, y);
        guiGraphics.method_51431(this.field_22793, stack, x, y);
    }

    protected int getTradeListRowY(int index, int size) {
        return this.midY - TRADE_LIST_ROW_HEIGHT * (size + 1) / 2 + TRADE_LIST_ROW_HEIGHT * index;
    }

    protected int getHoveredTradeListIndex(int mouseX, int mouseY) {
        class_2499 trades = getVillagerTradeRecipes();
        int size = trades.size();
        for (int i = 0; i < size; i++) {
            if (isMouseOverCenteredText(mouseX, mouseY, formatTradeRecipe(trades.method_68582(i)),
                    this.midX, getTradeListRowY(i, size))) {
                return i;
            }
        }
        return -1;
    }

    protected boolean isMouseOverAddTrade(int mouseX, int mouseY) {
        int size = getVillagerTradeCount();
        return isMouseOverCenteredText(mouseX, mouseY, class_2561.method_43471(key("trades.addtrade")).getString(),
                this.midX, getTradeListRowY(size, size));
    }

    protected boolean isMouseOverCenteredText(int mouseX, int mouseY, String text, int centerX, int y) {
        int width = this.field_22793.method_1727(text);
        return isMouseIn(mouseX, mouseY, centerX - width / 2, y, width, TRADE_LIST_ROW_TEXT_HEIGHT);
    }

    protected int getSingleTradeSlotX(int slot) {
        if (isSidebarUi()) {
            int spacing = class_3532.method_15340(contentWidth() / 4, 58, 92);
            int center = contentMidX();
            return switch (slot) {
                case TRADE_SLOT_SECOND_BUY -> center - 8;
                case TRADE_SLOT_SELL -> center + spacing - 8;
                default -> center - spacing - 8;
            };
        }

        int part = this.midX / 2;
        return switch (slot) {
            case TRADE_SLOT_SECOND_BUY -> 2 * part;
            case TRADE_SLOT_SELL -> 3 * part;
            default -> part;
        };
    }

    protected int getSingleTradeSlotY() {
        return this.midY;
    }

    protected int getHoveredSingleTradeSlot(int mouseX, int mouseY) {
        for (int slot = 0; slot < TRADE_SLOT_COUNT; slot++) {
            if (isMouseIn(mouseX, mouseY, getSingleTradeSlotX(slot), getSingleTradeSlotY(), ITEM_SIZE, ITEM_SIZE)) {
                return slot;
            }
        }
        return -1;
    }

    protected void clampTradeSelection(class_2499 trades) {
        this.selectedTradeSlot = class_3532.method_15340(this.selectedTradeSlot, 0, TRADE_SLOT_COUNT - 1);
        if (trades.isEmpty()) {
            this.selectedTradeIndex = 0;
            this.tradeScroll = 0;
            return;
        }

        this.selectedTradeIndex = class_3532.method_15340(this.selectedTradeIndex, 0, trades.size() - 1);
        this.tradeScroll = class_3532.method_15340(this.tradeScroll, 0, Math.max(0, trades.size() - TRADE_ROWS));
        scrollTradeSelectionIntoView(trades);
    }

    protected void setTradeScroll(int value) {
        class_2499 trades = getVillagerTradeRecipes();
        this.tradeScroll = class_3532.method_15340(value, 0, Math.max(0, trades.size() - TRADE_ROWS));
    }

    protected void scrollTradeSelectionIntoView(class_2499 trades) {
        if (trades.isEmpty()) {
            this.tradeScroll = 0;
            return;
        }

        if (this.selectedTradeIndex < this.tradeScroll) {
            this.tradeScroll = this.selectedTradeIndex;
        } else if (this.selectedTradeIndex >= this.tradeScroll + TRADE_ROWS) {
            this.tradeScroll = this.selectedTradeIndex - TRADE_ROWS + 1;
        }
        this.tradeScroll = class_3532.method_15340(this.tradeScroll, 0, Math.max(0, trades.size() - TRADE_ROWS));
    }

    protected int getTradeRowY(int row) {
        return 58 + row * TRADE_ROW_HEIGHT;
    }

    protected int getTradeListWidth() {
        return Math.min(210, Math.max(130, this.midX - 20));
    }

    protected int getTradeControlsX() {
        int width = getTradeControlsWidth();
        int rightAligned = this.field_22789 - width - 10;
        return Math.min(Math.max(this.midX + 100, rightAligned), rightAligned);
    }

    protected int getTradeControlsWidth() {
        return 132;
    }

    protected int getTradeSlotButtonX(int slot) {
        return this.midX - 117 + slot * 80;
    }

    protected int getTradeSlotIconX(int slot) {
        return getTradeSlotButtonX(slot) + 29;
    }

    protected int getTradeSlotIconY() {
        return 68;
    }

    protected int getHoveredTradeSlot(int mouseX, int mouseY) {
        for (int slot = 0; slot < TRADE_SLOT_COUNT; slot++) {
            if (isMouseIn(mouseX, mouseY, getTradeSlotIconX(slot) - 2, getTradeSlotIconY() - 2, 20, 20)) {
                return slot;
            }
        }
        return -1;
    }
}
