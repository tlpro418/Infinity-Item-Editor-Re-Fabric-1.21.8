package io.github.seraphina.infinity_item_editor_re.client.screen;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.client.screen.legacy.LegacyTextEditBox;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernTextEditBox;
import io.github.seraphina.infinity_item_editor_re.client.screen.modern.ModernUi;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_437;
abstract class ItemEditorScreenWidgets extends ItemEditorScreenComponents {
    protected ItemEditorScreenWidgets(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

protected void addItemPanel() {
        if (isSidebarUi()) {
            addSidebarItemPanel();
            return;
        }

        this.itemIdBox = addTrackedBox(plainTextBox(this.midX, 55, 75, FIELD_HEIGHT,
                class_2561.method_43471(key("item.id"))));
        this.itemIdBox.method_1880(100);
        this.itemIdBox.method_1868(MAIN_COLOR);
        this.itemIdBox.method_1852(this.itemIdValue);
        this.itemIdBox.method_1863(value -> {
            this.itemIdValue = value;
            if (tryApplyItemId(false)) {
                method_41843();
            }
        });
        this.mainTextBoxes.add(this.itemIdBox);

        int countDigits = Integer.toString(MAX_COUNT).length();
        this.countBox = addTrackedBox(numberBox(this.midX, 85, Math.max(10 * countDigits, 20), FIELD_HEIGHT,
                countDigits, this.countValue, 1, MAX_COUNT));
        this.countBox.method_1863(value -> {
            this.countValue = value;
            tryApplyCount(false);
        });

        int maxDamage = getDamageMaxForField(this.previewStack);
        int damageDigits = Math.max(1, Integer.toString(maxDamage).length());
        this.damageBox = addTrackedBox(numberBox(this.midX, 115, Math.max(10 * damageDigits, 15), FIELD_HEIGHT,
                damageDigits, this.damageValue, 0, maxDamage));
        this.damageBox.method_1863(value -> {
            this.damageValue = value;
            tryApplyDamage(false);
        });

        int editorButtonWidth = 72;
        int editorButtonGap = 4;
        int editorButtonLeft = this.midX - (editorButtonWidth * 4 + editorButtonGap * 3) / 2;
        method_37063(new InfinityEditorButton(editorButtonLeft, 145, editorButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("nbt")), button -> switchPanel(Panel.NBT)));
        method_37063(new InfinityEditorButton(editorButtonLeft + editorButtonWidth + editorButtonGap, 145, editorButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("components")), button -> switchPanel(Panel.COMPONENTS)));
        method_37063(new InfinityEditorButton(editorButtonLeft + (editorButtonWidth + editorButtonGap) * 2, 145, editorButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("nbtadv")), button -> switchPanel(Panel.NBT_ADVANCED)));
        method_37063(new InfinityEditorButton(editorButtonLeft + (editorButtonWidth + editorButtonGap) * 3, 145, editorButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("json")), button -> openJsonEditor()));
        method_37063(new InfinityEditorButton(this.field_22789 - 75, 74, 70, FIELD_HEIGHT,
                class_2561.method_43471(key("hideflags")), button -> switchPanel(Panel.HIDE_FLAGS)));
        method_37063(new InfinityEditorButton(this.field_22789 / 8 - 40, this.midY - 45, 80, FIELD_HEIGHT,
                class_2561.method_43471(key("pick")), button -> openItemPicker()));

        addSpecialButtons();
        addNameAndLoreWidgets();
        addFormatButtons();
    }

    protected void addSidebarItemPanel() {
        int detailsWidth = sidebarDetailsWidth();
        int detailsX = sidebarItemDetailsX(detailsWidth);
        int fieldX = sidebarItemFieldX();
        int fieldWidth = sidebarItemFieldWidth(detailsX);

        this.itemIdBox = addTrackedBox(plainTextBox(fieldX, sidebarItemIdY(), fieldWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("item.id"))));
        this.itemIdBox.method_1880(100);
        this.itemIdBox.method_1868(MAIN_COLOR);
        this.itemIdBox.method_1852(this.itemIdValue);
        this.itemIdBox.method_1863(value -> {
            this.itemIdValue = value;
            if (tryApplyItemId(false)) {
                method_41843();
            }
        });
        this.mainTextBoxes.add(this.itemIdBox);

        int countDigits = Integer.toString(MAX_COUNT).length();
        this.countBox = addTrackedBox(numberBox(fieldX, sidebarItemCountY(), Math.min(fieldWidth, Math.max(10 * countDigits, 48)), FIELD_HEIGHT,
                countDigits, this.countValue, 1, MAX_COUNT));
        this.countBox.method_1863(value -> {
            this.countValue = value;
            tryApplyCount(false);
        });

        int maxDamage = getDamageMaxForField(this.previewStack);
        int damageDigits = Math.max(1, Integer.toString(maxDamage).length());
        this.damageBox = addTrackedBox(numberBox(fieldX, sidebarItemDamageY(), Math.max(10 * damageDigits, 48), FIELD_HEIGHT,
                damageDigits, this.damageValue, 0, maxDamage));
        this.damageBox.method_1863(value -> {
            this.damageValue = value;
            tryApplyDamage(false);
        });

        int sidebarX = SIDEBAR_SAFE_MARGIN;
        int sidebarButtonWidth = sidebarWidth() - SIDEBAR_SAFE_MARGIN * 2;
        int y = 100;
        method_37063(new InfinityEditorButton(sidebarX, y, sidebarButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("pick")), button -> openItemPicker()));
        y += 24;
        method_37063(new InfinityEditorButton(sidebarX, y, sidebarButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("nbt")), button -> switchPanel(Panel.NBT)));
        y += 24;
        method_37063(new InfinityEditorButton(sidebarX, y, sidebarButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("components")), button -> switchPanel(Panel.COMPONENTS)));
        y += 24;
        method_37063(new InfinityEditorButton(sidebarX, y, sidebarButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("nbtadv")), button -> switchPanel(Panel.NBT_ADVANCED)));
        y += 24;
        method_37063(new InfinityEditorButton(sidebarX, y, sidebarButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("json")), button -> openJsonEditor()));
        y += 24;
        if (isCommandBlockEditableItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(sidebarX, y, sidebarButtonWidth, FIELD_HEIGHT,
                    class_2561.method_43471(key("commandblock")), button -> openCommandBlockEditor()));
            y += 24;
        }
        method_37063(new InfinityEditorButton(sidebarX, y, sidebarButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("hideflags")), button -> switchPanel(Panel.HIDE_FLAGS)));
        y += 24;
        if (canShowEnchantingButton(this.previewStack)) {
            method_37063(new InfinityEditorButton(sidebarX, y, sidebarButtonWidth, FIELD_HEIGHT,
                    class_2561.method_43471(key("enchanting")), button -> switchPanel(Panel.ENCHANTMENTS)));
        }

        addSidebarNameAndLoreWidgets(detailsX, sidebarItemNameY(), detailsWidth);
        if (canShowSidebarActionGrid()) {
            addSidebarSpecialButtons(getActionGridX(), getActionGridY(), getActionGridButtonWidth());
        }
        addFormatButtons();
    }

    protected int sidebarDetailsWidth() {
        if (isCompactSidebarItemPanel()) {
            return contentWidth();
        }

        return class_3532.method_15340(contentWidth() / 3, 176, 236);
    }

    protected int sidebarDetailsX(int detailsWidth) {
        int x = safeRight() - detailsWidth;
        if (x < safeLeft() + 268) {
            return safeLeft();
        }

        return x;
    }

    protected void addSidebarNameAndLoreWidgets(int x, int y, int width) {
        int controlX = x + SIDEBAR_DRAWER_PADDING;
        int controlWidth = Math.max(1, width - SIDEBAR_DRAWER_PADDING * 2);
        int buttonGap = 4;
        int clearButtonWidth = Math.min(42, Math.max(20, controlWidth / 3));
        int nameFieldWidth = Math.max(1, controlWidth - clearButtonWidth - buttonGap);
        this.nameBox = addTrackedBox(legacyTextBox(controlX, y, nameFieldWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("item.name"))));
        this.nameBox.method_1880(100);
        this.nameBox.method_1868(MAIN_COLOR);
        this.nameBox.method_1852(this.nameValue);
        this.nameBox.method_1863(value -> {
            this.nameValue = value;
            applyNameToStack();
        });
        this.mainTextBoxes.add(this.nameBox);

        method_37063(new InfinityEditorButton(controlX + nameFieldWidth + buttonGap, y, clearButtonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("clear")), button -> clearCustomName()));

        int visibleLoreLines = sidebarVisibleLoreLines();
        for (int i = 0; i < visibleLoreLines; i++) {
            boolean realLine = i < this.loreValues.size();
            addSidebarLoreTextField(controlX, y + 50 + 26 * i, controlWidth, i, realLine);
        }

        if (canShowSidebarLoreButton()) {
            int loreButtonY = visibleLoreLines == 0 ? y + 28 : y + 50 + 26 * visibleLoreLines + 6;
            method_37063(new InfinityEditorButton(controlX, loreButtonY, controlWidth, FIELD_HEIGHT,
                    class_2561.method_43471(key("lore")), button -> switchPanel(Panel.LORE)));
        }
    }

    protected void addSidebarLoreTextField(int x, int y, int width, int line, boolean realLine) {
        int fieldX = realLine ? x + 18 : x;
        int fieldWidth = realLine ? width - 18 : width;
        class_342 loreBox = addTrackedBox(legacyTextBox(fieldX, y, fieldWidth, FIELD_HEIGHT,
                class_2561.method_43470("Lore " + (line + 1))));
        loreBox.method_1880(100);
        loreBox.method_1868(MAIN_COLOR);
        loreBox.method_1852(realLine ? this.loreValues.get(line) : "");
        loreBox.method_1863(value -> {
            if (!realLine && value.isEmpty()) {
                return;
            }
            setLoreLine(line, value);
            applyLoreToStack();
            if (!realLine && line < 5) {
                method_41843();
            }
        });
        this.loreBoxes.add(loreBox);

        if (realLine) {
            method_37063(new InfinityEditorButton(x, y, 16, FIELD_HEIGHT,
                    class_2561.method_43470(class_124.field_1079 + "X"), button -> {
                removeLoreLine(line);
                method_41843();
            }));
        }
    }

    protected int getActionGridX() {
        return safeLeft() + SIDEBAR_DRAWER_PADDING;
    }

    protected int getActionGridButtonWidth() {
        int available;
        int preferredMin;
        if (isCompactSidebarItemPanel()) {
            available = contentWidth();
            preferredMin = 64;
        } else {
            int detailsX = sidebarItemDetailsX(sidebarDetailsWidth());
            available = detailsX - safeLeft() - SIDEBAR_CONTENT_GAP;
            preferredMin = 74;
        }

        available = Math.max(1, available - SIDEBAR_DRAWER_PADDING * 2);
        int maxColumnWidth = Math.max(1, (available - SIDEBAR_CONTENT_GAP) / 2);
        int minColumnWidth = Math.min(preferredMin, maxColumnWidth);
        return class_3532.method_15340(maxColumnWidth, minColumnWidth, 126);
    }

    protected void addSidebarSpecialButtons(int x, int y, int width) {
        int index = 0;
        index = addSidebarActionButton(x, y, width, index, getUnbreakableText(), button -> toggleUnbreakable(), !this.previewStack.method_7960());

        if (!this.previewStack.method_7960()) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("attributes")), button -> switchPanel(Panel.ATTRIBUTES));
        }

        if (isColorApplicable(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("color")), button -> switchPanel(Panel.COLOR));
        }

        if (isSignItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("sign")), button -> switchPanel(Panel.SIGN));
        }

        if (isPlayerHeadItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("head")), button -> switchPanel(Panel.HEAD));
        }

        if (isArmorStandItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("armorstand")), button -> switchPanel(Panel.ARMOR_STAND));
        }

        if (isArmorTrimApplicable(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("armortrim")), button -> openArmorTrimEditor());
        }

        if (isFireworkEditableItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("firework")), button -> switchPanel(Panel.FIREWORK));
        }

        if (isContainerEditableItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("container")), button -> openContainerItemEditor());
        }

        if (isBannerEditableItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("banner")), button -> switchPanel(Panel.BANNER));
        }

        if (isDecoratedPotItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("decorated_pot")), button -> switchPanel(Panel.DECORATED_POT));
        }

        if (isSpawnEditorItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key(getSpawnEditorTitleKey())), button -> switchPanel(Panel.SPAWN_EGG));
        }

        if (isVillagerTradeEditableItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("trades")), button -> switchPanel(Panel.TRADES));
        }

        if (isPotionItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("potion")), button -> switchPanel(Panel.POTION));
        }

        if (isBookEditableItem(this.previewStack)) {
            index = addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("book")), button -> switchPanel(Panel.BOOK));
            addSidebarActionButton(x, y, width, index,
                    class_2561.method_43471(key("book.edit_pages")), button -> openBookItemEditor());
        }
    }

    protected int addSidebarActionButton(int startX, int startY, int width, int index,
                                         class_2561 text, InfinityEditorButton.PressAction action) {
        return addSidebarActionButton(startX, startY, width, index, text, action, true);
    }

    protected int addSidebarActionButton(int startX, int startY, int width, int index,
                                         class_2561 text, InfinityEditorButton.PressAction action, boolean active) {
        int column = index % 2;
        int row = index / 2;
        int buttonX = startX + column * (width + SIDEBAR_CONTENT_GAP);
        int buttonY = startY + row * (SIDEBAR_BUTTON_HEIGHT + 6);
        if (buttonY + SIDEBAR_BUTTON_HEIGHT > sidebarBottomButtonY() - 8) {
            return index;
        }

        InfinityEditorButton button = method_37063(new InfinityEditorButton(buttonX, buttonY, width, SIDEBAR_BUTTON_HEIGHT, text, action));
        button.field_22763 = active;

        return index + 1;
    }

    protected void addNameAndLoreWidgets() {
        this.nameBox = addTrackedBox(legacyTextBox(this.field_22789 - 180, 50, 130, FIELD_HEIGHT,
                class_2561.method_43471(key("item.name"))));
        this.nameBox.method_1880(100);
        this.nameBox.method_1868(MAIN_COLOR);
        this.nameBox.method_1852(this.nameValue);
        this.nameBox.method_1863(value -> {
            this.nameValue = value;
            applyNameToStack();
        });
        this.mainTextBoxes.add(this.nameBox);

        method_37063(new InfinityEditorButton(this.field_22789 - 45, 50, 40, FIELD_HEIGHT,
                class_2561.method_43471(key("clear")), button -> clearCustomName()));

        int visibleLoreLines = Math.min(5, this.loreValues.size() + 1);
        for (int i = 0; i < visibleLoreLines; i++) {
            boolean realLine = i < this.loreValues.size();
            addLoreTextField(i, realLine);
        }

        method_37063(new InfinityEditorButton(this.field_22789 - 180, 100 + 30 * visibleLoreLines, 170, FIELD_HEIGHT,
                class_2561.method_43471(key("lore")), button -> switchPanel(Panel.LORE)));
    }

    protected void addLoreTextField(int line, boolean realLine) {
        class_342 loreBox = addTrackedBox(legacyTextBox(this.field_22789 - 180, 100 + 30 * line, 170, FIELD_HEIGHT,
                class_2561.method_43470("Lore " + (line + 1))));
        loreBox.method_1880(100);
        loreBox.method_1868(MAIN_COLOR);
        loreBox.method_1852(realLine ? this.loreValues.get(line) : "");
        loreBox.method_1863(value -> {
            if (!realLine && value.isEmpty()) {
                return;
            }
            setLoreLine(line, value);
            applyLoreToStack();
            if (!realLine && line < 4) {
                method_41843();
            }
        });
        this.loreBoxes.add(loreBox);

        if (realLine) {
            method_37063(new InfinityEditorButton(this.field_22789 - 195, 100 + 30 * line, 14, FIELD_HEIGHT,
                    class_2561.method_43470(class_124.field_1079 + "X"), button -> {
                removeLoreLine(line);
                method_41843();
            }));
        }
    }

    protected void addSpecialButtons() {
        int y = 175;
        if (!this.previewStack.method_7960()) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    getUnbreakableText(), button -> toggleUnbreakable()));
            y += 30;
        }

        if (!this.previewStack.method_7960()) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("attributes")), button -> switchPanel(Panel.ATTRIBUTES)));
            y += 30;
        }

        if (isColorApplicable(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("color")), button -> switchPanel(Panel.COLOR)));
            y += 30;
        }

        if (isSignItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("sign")), button -> switchPanel(Panel.SIGN)));
            y += 30;
        }

        if (isPlayerHeadItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("head")), button -> switchPanel(Panel.HEAD)));
            y += 30;
        }

        if (isArmorStandItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("armorstand")), button -> switchPanel(Panel.ARMOR_STAND)));
            y += 30;
        }

        if (isArmorTrimApplicable(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("armortrim")), button -> openArmorTrimEditor()));
            y += 30;
        }

        if (isFireworkEditableItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("firework")), button -> switchPanel(Panel.FIREWORK)));
            y += 30;
        }

        if (isContainerEditableItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("container")), button -> openContainerItemEditor()));
            y += 30;
        }

        if (isCommandBlockEditableItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("commandblock")), button -> openCommandBlockEditor()));
            y += 30;
        }

        if (isBannerEditableItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("banner")), button -> switchPanel(Panel.BANNER)));
            y += 30;
        }

        if (isDecoratedPotItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("decorated_pot")), button -> switchPanel(Panel.DECORATED_POT)));
            y += 30;
        }

        if (isSpawnEditorItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key(getSpawnEditorTitleKey())), button -> switchPanel(Panel.SPAWN_EGG)));
            y += 30;
        }

        if (isVillagerTradeEditableItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("trades")), button -> switchPanel(Panel.TRADES)));
            y += 30;
        }

        if (canShowEnchantingButton(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("enchanting")), button -> switchPanel(Panel.ENCHANTMENTS)));
            y += 30;
        }

        if (isPotionItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("potion")), button -> switchPanel(Panel.POTION)));
            y += 30;
        }

        if (isBookEditableItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("book")), button -> switchPanel(Panel.BOOK)));
            y += 30;
            method_37063(new InfinityEditorButton(this.midX - 50, y, 100, FIELD_HEIGHT,
                    class_2561.method_43471(key("book.edit_pages")), button -> openBookItemEditor()));
        }
    }

    protected void addFormatButtons() {
        if (isSidebarUi()) {
            addSidebarFormatButtons();
            return;
        }

        class_124[] formats = class_124.values();
        int colorAmount = 2 + formats.length;
        int columns = colorAmount / 2;
        int startX = this.field_22789 - 1 - 13 * ((colorAmount + 2) / 2);

        method_37063(new InfinityEditorButton(startX + 13, this.field_22790 - 30, 13, 15,
                class_2561.method_43470(String.valueOf(class_124.field_33292)), button -> insertFormattingPrefix()));
        method_37063(new InfinityEditorButton(startX + 26, this.field_22790 - 30, 13, 15,
                class_2561.method_43470(class_124.field_1079 + "%"), button -> stripFocusedFormatting()));

        for (int i = 2; i < colorAmount; i++) {
            class_124 format = formats[i - 2];
            int x = startX + 13 * ((i % columns) + 1);
            int y = this.field_22790 - 30 + 15 * (i / columns);
            method_37063(new InfinityEditorButton(x, y, 13, 15,
                    class_2561.method_43470(format.toString() + format.method_36145()), button -> insertFocusedText(format.toString())));
        }
    }

    protected void addSidebarFormatButtons() {
        class_124[] formats = class_124.values();
        int columns = 8;
        int buttonWidth = 13;
        int buttonHeight = 15;
        int colorAmount = 2 + formats.length;
        int rows = (colorAmount + columns - 1) / columns;
        int paletteWidth = columns * buttonWidth;
        int paletteHeight = rows * buttonHeight;
        int startY = Math.max(82, this.field_22790 - 38 - paletteHeight);
        int startX = Math.max(4, (sidebarWidth() - paletteWidth) / 2);
        addSidebarFormatButton(startX, startY, columns, 0,
                class_2561.method_43470(String.valueOf(class_124.field_33292)), button -> insertFormattingPrefix());
        addSidebarFormatButton(startX, startY, columns, 1,
                class_2561.method_43470(class_124.field_1079 + "%"), button -> stripFocusedFormatting());

        for (int i = 2; i < colorAmount; i++) {
            class_124 format = formats[i - 2];
            addSidebarFormatButton(startX, startY, columns, i,
                    class_2561.method_43470(format.toString() + format.method_36145()), button -> insertFocusedText(format.toString()));
        }
    }

    protected void addSidebarFormatButton(int startX, int startY, int columns, int index,
                                          class_2561 text, InfinityEditorButton.PressAction action) {
        int x = startX + 13 * (index % columns);
        int y = startY + 15 * (index / columns);
        method_37063(new InfinityEditorButton(x, y, 13, 15, text, action));
    }

    protected void addNbtPanel() {
        int boxWidth = nbtEditorWidth();
        this.rawNbtBox = addTrackedBox(legacyTextBox(nbtEditorX(), nbtEditorBoxY(), boxWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("nbt"))));
        this.rawNbtBox.method_1880(20000);
        this.rawNbtBox.method_1868(MAIN_COLOR);
        this.rawNbtBox.method_1852(this.rawNbtValue == null ? getInitialNbt(this.previewStack) : this.rawNbtValue);
        this.rawNbtBox.method_1863(value -> this.rawNbtValue = value);

        int buttonWidth = nbtEditorButtonWidth();
        method_37063(new InfinityEditorButton(nbtEditorButtonX(buttonWidth), nbtEditorButtonY(), buttonWidth, SIDEBAR_BUTTON_HEIGHT,
                class_2561.method_43471(key("nbt.update")), button -> updateRawNbt()));
        addFormatButtons();
    }

    protected void addComponentsPanel() {
        addComponentEditorPanel();
    }

    protected void addNbtAdvancedPanel() {
        this.advancedScroll = class_3532.method_15340(this.advancedScroll, 0, Math.max(0, buildNbtRows().size() - getNbtAdvancedVisibleRows()));
    }

    protected void addHideFlagsPanel() {
        for (int i = 0; i < HideFlag.values().length; i++) {
            HideFlag flag = HideFlag.values()[i];
            method_37063(new InfinityEditorButton(this.midX - 60, 60 + 26 * i, 120, FIELD_HEIGHT,
                    getHideFlagText(flag), button -> {
                toggleHideFlag(flag);
                method_41843();
            }));
        }
    }

    protected void addEnchantmentsPanel() {
        this.enchantFilterBox = addTrackedBox(plainTextBox(searchFilterX(), searchFilterY(), searchFilterWidth(), 18,
                class_2561.method_43471(key("enchantment_filter"))));
        this.enchantFilterBox.method_1880(48);
        this.enchantFilterBox.method_1890(value -> value.matches("[a-z0-9_:.\\-]*"));
        this.enchantFilterBox.method_1868(MAIN_COLOR);
        this.enchantFilterBox.method_1852(this.enchantFilterValue);
        this.enchantFilterBox.method_1863(value -> {
            String normalized = value.toLowerCase(Locale.ROOT);
            if (!Objects.equals(this.enchantFilterValue, normalized)) {
                this.selectedEnchantmentNamespace = "";
            }
            this.enchantFilterValue = normalized;
        });

        int controlLeft = editorControlLeft();
        if (!this.selectedEnchantmentNamespace.isBlank()) {
            method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 93, 90, OLD_BUTTON_HEIGHT,
                    class_2561.method_43471(key("registry_group.all")), button -> {
                this.selectedEnchantmentNamespace = "";
                method_41843();
            }));
        }

        int enchantLevelDigits = Integer.toString(MAX_ENCHANTMENT_LEVEL).length();
        this.enchantLevelBox = addTrackedBox(numberBox(controlLeft, this.field_22790 - 33, Math.max(10 * enchantLevelDigits, 40), 18,
                enchantLevelDigits, this.enchantLevelValue, 1, MAX_ENCHANTMENT_LEVEL));
        this.enchantLevelBox.method_1863(value -> this.enchantLevelValue = value);

        method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 63, 90, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("enchanting.enchanttoggle." + (this.showAllEnchantments ? 0 : 1))),
                button -> toggleEnchantmentsScope()));
    }

    protected void addPotionPanel() {
        this.potionFilterBox = addTrackedBox(plainTextBox(searchFilterX(), searchFilterY(), searchFilterWidth(), 18,
                class_2561.method_43471(key("potion_filter"))));
        this.potionFilterBox.method_1880(48);
        this.potionFilterBox.method_1890(value -> value.matches("[a-z0-9_:.\\-]*"));
        this.potionFilterBox.method_1868(MAIN_COLOR);
        this.potionFilterBox.method_1852(this.potionFilterValue);
        this.potionFilterBox.method_1863(value -> {
            this.potionFilterValue = value.toLowerCase(Locale.ROOT);
            if (!this.selectedPotionNamespace.isBlank()) {
                this.selectedPotionNamespace = "";
                method_41843();
            }
        });

        int controlLeft = editorControlLeft();
        if (!this.selectedPotionNamespace.isBlank()) {
            method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 150, 90, OLD_BUTTON_HEIGHT,
                    class_2561.method_43471(key("registry_group.all_mods")), button -> {
                this.selectedPotionNamespace = "";
                method_41843();
            }));
        }

        int potionLevelDigits = Integer.toString(MAX_POTION_LEVEL).length();
        this.potionLevelBox = addTrackedBox(numberBox(controlLeft, this.field_22790 - 33, Math.max(10 * potionLevelDigits, 40), 18,
                potionLevelDigits, this.potionLevelValue, 1, MAX_POTION_LEVEL));
        this.potionLevelBox.method_1863(value -> this.potionLevelValue = value);

        this.potionTimeBox = addTrackedBox(numberBox(controlLeft, this.field_22790 - 60, 40, 18, 5,
                this.potionTimeValue, 1, MAX_POTION_SECONDS));
        this.potionTimeBox.method_1863(value -> this.potionTimeValue = value);

        method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 120, 80, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("color")), button -> switchPanel(Panel.COLOR)));
        method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 90, 80, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("potion.showparticles." + (this.showPotionParticles ? 1 : 0))),
                button -> togglePotionParticles()));
    }

    protected void addSignPanel() {
        int fieldWidth = contentLimitedWidth(220, 120, 80);
        int x = centeredContentX(fieldWidth);

        for (int i = 0; i < SIGN_LINES; i++) {
            int line = i;
            class_342 lineBox = addTrackedBox(legacyTextBox(x, 60 + 30 * i, fieldWidth, FIELD_HEIGHT,
                    class_2561.method_43469(key("sign.line"), line + 1)));
            lineBox.method_1880(384);
            lineBox.method_1852(getSignLineValue(line));
            lineBox.method_1863(value -> {
                this.signLineValues[line] = value;
                applySignToStack();
            });
            this.signBoxes.add(lineBox);
        }

        int commandWidth = contentLimitedWidth(260, 120, 60);
        this.signCommandBox = addTrackedBox(legacyTextBox(centeredContentX(commandWidth), 190, commandWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("sign.command"))));
        this.signCommandBox.method_1880(512);
        this.signCommandBox.method_1852(this.signCommandValue == null ? "" : this.signCommandValue);
        this.signCommandBox.method_1863(value -> {
            this.signCommandValue = value;
            applySignToStack();
        });
        this.signBoxes.add(this.signCommandBox);

        addFormatButtons();
    }

    protected void addBookPanel() {
        boolean written = this.previewStack.method_31574(class_1802.field_8360);
        int fieldWidth = contentLimitedWidth(220, 120, 80);
        int x = centeredContentX(fieldWidth);

        this.bookTitleBox = addTrackedBox(legacyTextBox(x, 70, fieldWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("book.title"))));
        this.bookTitleBox.method_1880(100);
        this.bookTitleBox.method_1852(this.bookTitleValue == null ? "" : this.bookTitleValue);
        this.bookTitleBox.method_1863(value -> {
            this.bookTitleValue = value;
            applyBookMetadataToStack();
        });
        this.mainTextBoxes.add(this.bookTitleBox);

        this.bookAuthorBox = addTrackedBox(legacyTextBox(x, 100, fieldWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("book.author"))));
        this.bookAuthorBox.method_1880(100);
        this.bookAuthorBox.method_1852(this.bookAuthorValue == null ? "" : this.bookAuthorValue);
        this.bookAuthorBox.method_1863(value -> {
            this.bookAuthorValue = value;
            applyBookMetadataToStack();
        });
        this.mainTextBoxes.add(this.bookAuthorBox);

        int buttonWidth = contentLimitedWidth(150, 100, 32);
        int buttonX = centeredContentX(buttonWidth);
        InfinityEditorButton generation = method_37063(new InfinityEditorButton(buttonX, 140, buttonWidth, FIELD_HEIGHT,
                class_2561.method_43469(key("book.generation"), getBookGeneration()), button -> cycleBookGeneration()));
        generation.field_22763 = written;

        InfinityEditorButton resolved = method_37063(new InfinityEditorButton(buttonX, 170, buttonWidth, FIELD_HEIGHT,
                getBookResolvedText(), button -> toggleBookResolved()));
        resolved.field_22763 = written;

        method_37063(new InfinityEditorButton(buttonX, 200, buttonWidth, FIELD_HEIGHT,
                getBookSignButtonText(), button -> toggleBookSignedState()));

        method_37063(new InfinityEditorButton(buttonX, 230, buttonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("book.edit_pages")), button -> openBookItemEditor()));

        addFormatButtons();
    }

    protected void addHeadPanel() {
        int fieldWidth = contentLimitedWidth(320, 180, 80);
        int x = centeredContentX(fieldWidth);

        this.headOwnerBox = addTrackedBox(legacyTextBox(x, 64, fieldWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("head.owner"))));
        this.headOwnerBox.method_1880(64);
        this.headOwnerBox.method_1852(this.headOwnerValue == null ? "" : this.headOwnerValue);
        this.headOwnerBox.method_1863(value -> {
            this.headOwnerValue = value;
            applyHeadToStack();
        });
        this.mainTextBoxes.add(this.headOwnerBox);

        this.headUuidBox = addTrackedBox(legacyTextBox(x, 94, fieldWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("head.uuid"))));
        this.headUuidBox.method_1880(36);
        this.headUuidBox.method_1852(this.headUuidValue == null ? "" : this.headUuidValue);
        this.headUuidBox.method_1863(value -> {
            this.headUuidValue = value;
            applyHeadToStack();
        });
        this.mainTextBoxes.add(this.headUuidBox);

        this.headTextureBox = addTrackedBox(legacyTextBox(x, 124, fieldWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("head.texture"))));
        this.headTextureBox.method_1880(4096);
        this.headTextureBox.method_1852(this.headTextureValue == null ? "" : this.headTextureValue);
        this.headTextureBox.method_1863(value -> {
            this.headTextureValue = value;
            applyHeadToStack();
        });
        this.mainTextBoxes.add(this.headTextureBox);

        this.headTextureSignatureBox = addTrackedBox(legacyTextBox(x, 154, fieldWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("head.signature"))));
        this.headTextureSignatureBox.method_1880(4096);
        this.headTextureSignatureBox.method_1852(this.headTextureSignatureValue == null ? "" : this.headTextureSignatureValue);
        this.headTextureSignatureBox.method_1863(value -> {
            this.headTextureSignatureValue = value;
            applyHeadToStack();
        });
        this.mainTextBoxes.add(this.headTextureSignatureBox);

        int buttonGap = 8;
        int buttonAreaWidth = contentLimitedWidth(208, 120, 20);
        int buttonWidth = Math.max(1, (buttonAreaWidth - buttonGap) / 2);
        int buttonX = centeredContentX(buttonAreaWidth);
        method_37063(new InfinityEditorButton(buttonX, 190, buttonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("head.random_uuid")), button -> randomizeHeadUuid()));
        method_37063(new InfinityEditorButton(buttonX + buttonWidth + buttonGap, 190, buttonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("head.clear_owner")), button -> clearHeadOwner()));
    }

    protected void addArmorStandPanel() {
        int width = contentLimitedWidth(150, 100, 32);
        int x = centeredContentX(width);
        int y = 54;
        addArmorStandToggleButton(x, y, width, "show_arms", ARMOR_STAND_SHOW_ARMS_TAG);
        addArmorStandToggleButton(x, y + 26, width, "small", ARMOR_STAND_SMALL_TAG);
        addArmorStandToggleButton(x, y + 52, width, "invisible", ARMOR_STAND_INVISIBLE_TAG);
        addArmorStandToggleButton(x, y + 78, width, "no_base_plate", ARMOR_STAND_NO_BASE_PLATE_TAG);
        addArmorStandToggleButton(x, y + 104, width, "marker", ARMOR_STAND_MARKER_TAG);
        addArmorStandToggleButton(x, y + 130, width, "no_gravity", ARMOR_STAND_NO_GRAVITY_TAG);
        addArmorStandToggleButton(x, y + 156, width, "invulnerable", ARMOR_STAND_INVULNERABLE_TAG);
        method_37063(new InfinityEditorButton(x, y + 190, width, FIELD_HEIGHT,
                class_2561.method_43471(key("armorstand.clear_entity_tag")), button -> clearArmorStandEntityTag()));
    }

    protected void addArmorStandToggleButton(int x, int y, int width, String translationSuffix, String tagKey) {
        method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                getArmorStandToggleText(translationSuffix, tagKey), button -> toggleArmorStandFlag(tagKey, translationSuffix)));
    }

    protected void addFireworkPanel() {
        int width = contentLimitedWidth(156, 104, 32);
        int x = centeredContentX(width);
        int y = 52;

        if (this.previewStack.method_31574(class_1802.field_8639)) {
            method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                    class_2561.method_43469(key("firework.flight"), getFireworkFlight()), button -> cycleFireworkFlight()));
            y += 26;
        }

        method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                class_2561.method_43469(key("firework.type"), getFireworkTypeName(this.fireworkExplosionType)),
                button -> cycleFireworkExplosionType(class_437.method_25442() ? -1 : 1)));
        y += 26;
        method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                class_2561.method_43471(key("firework.flicker." + (this.fireworkFlicker ? 1 : 0))),
                button -> toggleFireworkFlicker()));
        y += 26;
        method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                class_2561.method_43471(key("firework.trail." + (this.fireworkTrail ? 1 : 0))),
                button -> toggleFireworkTrail()));
        y += 26;
        method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                class_2561.method_43469(key("firework.color"), getDyeColorName(getFireworkDyeColor(this.fireworkColor))),
                button -> cycleFireworkColor(false, class_437.method_25442() ? -1 : 1)));
        y += 26;
        method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                class_2561.method_43469(key("firework.fade_color"), getFireworkFadeColorText()),
                button -> cycleFireworkColor(true, class_437.method_25442() ? -1 : 1)));
        y += 26;
        method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                class_2561.method_43471(key("firework.random_colors")), button -> randomizeFireworkColors()));
        y += 26;

        if (this.previewStack.method_31574(class_1802.field_8639)) {
            method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                    class_2561.method_43471(key("firework.add_explosion")), button -> addFireworkExplosion()));
            y += 26;
            InfinityEditorButton remove = method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                    class_2561.method_43471(key("firework.remove_explosion")), button -> removeLastFireworkExplosion()));
            remove.field_22763 = getFireworkExplosionCount() > 0;
            y += 26;
            InfinityEditorButton clear = method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                    class_2561.method_43471(key("firework.clear_fireworks")), button -> clearFireworkData()));
            clear.field_22763 = hasFireworkData();
        } else {
            InfinityEditorButton clear = method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT,
                    class_2561.method_43471(key("firework.clear_explosion")), button -> clearFireworkData()));
            clear.field_22763 = hasFireworkData();
        }
    }

    protected void addContainerPanel() {
        this.selectedContainerSlot = class_3532.method_15340(this.selectedContainerSlot, 0, CONTAINER_SIZE - 1);
        int boxWidth = contentLimitedWidth(300, 180, 20);
        this.containerSlotNbtBox = addTrackedBox(legacyTextBox(centeredContentX(boxWidth), 132, boxWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("container.slot_nbt"))));
        this.containerSlotNbtBox.method_1880(20000);
        this.containerSlotNbtBox.method_1852(this.containerSlotNbtValue == null ? getContainerSelectedSlotNbt() : this.containerSlotNbtValue);
        this.containerSlotNbtBox.method_1863(value -> this.containerSlotNbtValue = value);

        int controlsWidth = contentLimitedWidth(270, 160, 20);
        int x = centeredContentX(controlsWidth);
        int gap = isSidebarUi() ? 4 : 4;
        int smallWidth = isSidebarUi() ? 20 : 24;
        int remainingWidth = Math.max(1, controlsWidth - smallWidth * 2 - gap * 4);
        int updateWidth = isSidebarUi() ? Math.max(1, remainingWidth * 84 / 204) : 84;
        int clearWidth = isSidebarUi() ? Math.max(1, remainingWidth * 58 / 204) : 58;
        int clearAllWidth = isSidebarUi() ? Math.max(1, remainingWidth - updateWidth - clearWidth) : 62;

        method_37063(new InfinityEditorButton(x, 158, smallWidth, FIELD_HEIGHT,
                class_2561.method_43470("<"), button -> cycleContainerSlot(-1)));
        method_37063(new InfinityEditorButton(x + smallWidth + gap, 158, smallWidth, FIELD_HEIGHT,
                class_2561.method_43470(">"), button -> cycleContainerSlot(1)));
        int updateX = x + smallWidth * 2 + gap * 2;
        method_37063(new InfinityEditorButton(updateX, 158, updateWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("container.update_slot")), button -> updateContainerSlotFromNbt()));
        int clearX = updateX + updateWidth + gap;
        method_37063(new InfinityEditorButton(clearX, 158, clearWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("container.clear_slot")), button -> clearContainerSlot()));
        InfinityEditorButton clearAll = method_37063(new InfinityEditorButton(clearX + clearWidth + gap, 158, clearAllWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("container.clear_all")), button -> clearContainerItems()));
        clearAll.field_22763 = getContainerItemCount() > 0;
    }

    protected void addBannerPanel() {
        int listX = bannerPatternListX();
        int listWidth = bannerPatternListWidth();
        this.bannerPatternFilterBox = addTrackedBox(legacyTextBox(listX, sideListSearchY(), Math.min(160, listWidth), FIELD_HEIGHT,
                class_2561.method_43471(key("banner.search"))));
        this.bannerPatternFilterBox.method_1880(32);
        this.bannerPatternFilterBox.method_1852(this.bannerPatternFilterValue);
        this.bannerPatternFilterBox.method_1863(value -> {
            this.bannerPatternFilterValue = value.toLowerCase(Locale.ROOT);
            this.bannerPatternScroll = 0;
            this.selectedBannerPatternIndex = 0;
        });

        int width = isSidebarUi() ? contentLimitedWidth(132, 88, 20) : 132;
        int controlsX = rightControlsX(width, listX, listWidth);
        method_37063(new InfinityEditorButton(controlsX, 52, width, FIELD_HEIGHT,
                class_2561.method_43469(key("banner.base"), getDyeColorName(getBannerBaseColor())),
                button -> cycleBannerBaseColor(class_437.method_25442() ? -1 : 1)));
        method_37063(new InfinityEditorButton(controlsX, 78, width, FIELD_HEIGHT,
                class_2561.method_43469(key("banner.pattern_color"), getDyeColorName(getBannerPatternColor())),
                button -> cycleBannerPatternColor(class_437.method_25442() ? -1 : 1)));
        method_37063(new InfinityEditorButton(controlsX, 104, width, FIELD_HEIGHT,
                class_2561.method_43471(key("banner.swap")), button -> swapBannerAndShield()));
        method_37063(new InfinityEditorButton(controlsX, 130, width, FIELD_HEIGHT,
                class_2561.method_43471(key("banner.add")), button -> addSelectedBannerPattern()));

        InfinityEditorButton remove = method_37063(new InfinityEditorButton(controlsX, 156, width, FIELD_HEIGHT,
                class_2561.method_43471(key("banner.remove")), button -> removeLastBannerPattern()));
        remove.field_22763 = getBannerPatternCount() > 0;

        InfinityEditorButton clear = method_37063(new InfinityEditorButton(controlsX, 182, width, FIELD_HEIGHT,
                class_2561.method_43471(key("banner.clear")), button -> clearBannerPatterns()));
        clear.field_22763 = getBannerPatternCount() > 0;

        if (!isSidebarUi()) {
            method_37063(new InfinityEditorButton(this.midX - 58, this.field_22790 - 64, 28, FIELD_HEIGHT,
                    class_2561.method_43470("<"), button -> cycleSelectedBannerPattern(-1)));
            method_37063(new InfinityEditorButton(this.midX - 28, this.field_22790 - 64, 56, FIELD_HEIGHT,
                    class_2561.method_43471(key("banner.add")), button -> addSelectedBannerPattern()));
            method_37063(new InfinityEditorButton(this.midX + 30, this.field_22790 - 64, 28, FIELD_HEIGHT,
                    class_2561.method_43470(">"), button -> cycleSelectedBannerPattern(1)));
        }
    }

    protected void addDecoratedPotPanel() {
        int listX = potterySherdListX();
        int listWidth = potterySherdListWidth();
        this.potterySherdFilterBox = addTrackedBox(legacyTextBox(listX, sideListSearchY(), Math.min(180, listWidth), FIELD_HEIGHT,
                class_2561.method_43471(key("decorated_pot.search"))));
        this.potterySherdFilterBox.method_1880(48);
        this.potterySherdFilterBox.method_1852(this.potterySherdFilterValue);
        this.potterySherdFilterBox.method_1863(value -> {
            this.potterySherdFilterValue = value.toLowerCase(Locale.ROOT);
            this.potterySherdScroll = 0;
            this.selectedPotterySherdIndex = 0;
        });

        int width = isSidebarUi() ? contentLimitedWidth(132, 88, 20) : 132;
        int controlsX = rightControlsX(width, listX, listWidth);
        int sideButtonWidth = (width - 4) / 2;
        for (int i = 0; i < DECORATED_POT_DISPLAY_SIDES.length; i++) {
            int side = DECORATED_POT_DISPLAY_SIDES[i];
            int x = controlsX + (i % 2) * (sideButtonWidth + 4);
            int y = 52 + (i / 2) * 26;
            addDecoratedPotSideButton(x, y, sideButtonWidth, side);
        }

        method_37063(new InfinityEditorButton(controlsX, 104, width, FIELD_HEIGHT,
                class_2561.method_43471(key("decorated_pot.apply")), button -> applySelectedPotterySherd()));
        method_37063(new InfinityEditorButton(controlsX, 130, width, FIELD_HEIGHT,
                class_2561.method_43471(key("decorated_pot.clear_side")), button -> clearDecoratedPotSide()));
        InfinityEditorButton clearAll = method_37063(new InfinityEditorButton(controlsX, 156, width, FIELD_HEIGHT,
                class_2561.method_43471(key("decorated_pot.clear_all")), button -> clearDecoratedPotDecorations()));
        clearAll.field_22763 = getDecoratedPotDecorationCount() > 0;

        if (!isSidebarUi()) {
            method_37063(new InfinityEditorButton(this.midX - 58, this.field_22790 - 64, 28, FIELD_HEIGHT,
                    class_2561.method_43470("<"), button -> cycleSelectedPotterySherd(-1)));
            method_37063(new InfinityEditorButton(this.midX - 28, this.field_22790 - 64, 56, FIELD_HEIGHT,
                    class_2561.method_43471(key("decorated_pot.apply")), button -> applySelectedPotterySherd()));
            method_37063(new InfinityEditorButton(this.midX + 30, this.field_22790 - 64, 28, FIELD_HEIGHT,
                    class_2561.method_43470(">"), button -> cycleSelectedPotterySherd(1)));
        }
    }

    protected void addDecoratedPotSideButton(int x, int y, int width, int side) {
        class_2561 text = side == this.selectedDecoratedPotSide
                ? class_2561.method_43470("> ").method_10852(getDecoratedPotSideName(side))
                : getDecoratedPotSideName(side);
        method_37063(new InfinityEditorButton(x, y, width, FIELD_HEIGHT, text,
                button -> selectDecoratedPotSide(side)));
    }

    protected void addSpawnEggPanel() {
        int listX = spawnEggEntityListX();
        int listWidth = spawnEggEntityListWidth();
        this.spawnEggEntityFilterBox = addTrackedBox(legacyTextBox(listX, sideListSearchY(), Math.min(180, listWidth), FIELD_HEIGHT,
                class_2561.method_43471(key("spawnegg.search"))));
        this.spawnEggEntityFilterBox.method_1880(48);
        this.spawnEggEntityFilterBox.method_1852(this.spawnEggEntityFilterValue);
        this.spawnEggEntityFilterBox.method_1863(value -> {
            this.spawnEggEntityFilterValue = value.toLowerCase(Locale.ROOT);
            this.spawnEggEntityScroll = 0;
            this.selectedSpawnEggEntityIndex = 0;
            this.spawnEggTagScroll = 0;
            method_41843();
            if (this.spawnEggEntityFilterBox != null) {
                this.method_25395(this.spawnEggEntityFilterBox);
                this.spawnEggEntityFilterBox.method_25365(true);
                this.spawnEggEntityFilterBox.method_1875(this.spawnEggEntityFilterBox.method_1882().length());
            }
        });

        int controlsX = getSpawnEggControlsX();
        int width = getSpawnEggControlsWidth();
        int buttonY = 52;
        method_37063(new InfinityEditorButton(controlsX, 52, width, FIELD_HEIGHT,
                class_2561.method_43471(key("spawnegg.apply_entity")), button -> applySelectedSpawnEggEntity()));
        buttonY += 26;
        if (isSpawnEggItem(this.previewStack)) {
            method_37063(new InfinityEditorButton(controlsX, buttonY, width, FIELD_HEIGHT,
                    class_2561.method_43471(key("spawnegg.sync_egg")), button -> syncSpawnEggToSelectedEntityItem()));
            buttonY += 26;
        }

        InfinityEditorButton clear = method_37063(new InfinityEditorButton(controlsX, buttonY, width, FIELD_HEIGHT,
                class_2561.method_43471(key(getSpawnEditorClearKey())), button -> clearSpawnEggEntityTag()));
        clear.field_22763 = hasSpawnEditorEntityData(this.previewStack);

        List<SpawnEggTagRow> rows = getSpawnEggTagRows();
        setSpawnEggTagScroll(this.spawnEggTagScroll);
        int end = Math.min(rows.size(), this.spawnEggTagScroll + SPAWN_EGG_TAG_ROWS);
        for (int i = this.spawnEggTagScroll; i < end; i++) {
            addSpawnEggTagControl(rows.get(i), getSpawnEggTagRowY(i - this.spawnEggTagScroll), controlsX, width);
        }

        if (!isSidebarUi()) {
            method_37063(new InfinityEditorButton(this.midX - 58, this.field_22790 - 64, 28, FIELD_HEIGHT,
                    class_2561.method_43470("<"), button -> cycleSelectedSpawnEggEntity(-1)));
            method_37063(new InfinityEditorButton(this.midX - 28, this.field_22790 - 64, 56, FIELD_HEIGHT,
                    class_2561.method_43471(key("spawnegg.apply_entity")), button -> applySelectedSpawnEggEntity()));
            method_37063(new InfinityEditorButton(this.midX + 30, this.field_22790 - 64, 28, FIELD_HEIGHT,
                    class_2561.method_43470(">"), button -> cycleSelectedSpawnEggEntity(1)));
        }
    }

    protected void addSpawnEggTagControl(SpawnEggTagRow row, int y, int controlsX, int width) {
        if (row.type() == SpawnEggTagRowType.CHOICE) {
            method_37063(new InfinityEditorButton(controlsX, y, width, FIELD_HEIGHT,
                    getSpawnEggChoiceText(row), button -> cycleSpawnEggChoice(row)));
            return;
        }

        if (row.type() == SpawnEggTagRowType.BOOLEAN) {
            method_37063(new InfinityEditorButton(controlsX, y, width, FIELD_HEIGHT,
                    getSpawnEggBooleanText(row), button -> toggleSpawnEggBoolean(row)));
            return;
        }

        if (row.type() == SpawnEggTagRowType.PRESENCE) {
            method_37063(new InfinityEditorButton(controlsX, y, width, FIELD_HEIGHT,
                    getSpawnEggPresenceText(row), button -> toggleSpawnEggPresence(row)));
            return;
        }

        class_342 box = addTrackedBox(legacyTextBox(controlsX + 70, y, width - 70, FIELD_HEIGHT,
                class_2561.method_43471(key("spawnegg." + row.translationSuffix()))));
        box.method_1880(getSpawnEggTagTextMaxLength(row));
        box.method_1852(getSpawnEggTagTextValue(row));
        if (row.type() == SpawnEggTagRowType.CUSTOM_NAME) {
            this.spawnEggCustomNameBox = box;
            box.method_1863(value -> {
                this.spawnEggCustomNameValue = value;
                applySpawnEggCustomName(value);
            });
        } else if (row.type() == SpawnEggTagRowType.OWNER) {
            this.spawnEggOwnerBox = box;
            box.method_1863(value -> {
                this.spawnEggOwnerValue = value;
                applySpawnEggOwner(value);
            });
        } else {
            box.method_1890(value -> isAllowedSpawnEggNumber(value, row.numberType()));
            box.method_1863(value -> applySpawnEggNumber(row, value));
        }
    }

    protected void addTradesPanel() {
        ensureVillagerTradeOffers();
    }

    protected void addTradePanel() {
        readTradeFieldsFromStack(this.previewStack);
        int nbtWidth = contentLimitedWidth(420, 180, 48);
        int nbtY = Math.max(66, Math.min(getSingleTradeSlotY() + 52, sidebarBottomButtonY() - 132));
        this.tradeItemNbtBox = addTrackedBox(legacyTextBox(centeredContentX(nbtWidth), nbtY, nbtWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("trades.item_nbt"))));
        this.tradeItemNbtBox.method_1880(20000);
        this.tradeItemNbtBox.method_1852(this.tradeItemNbtValue);
        this.tradeItemNbtBox.method_1863(value -> this.tradeItemNbtValue = value);
        this.tradeItemNbtBox.field_22763 = getVillagerTradeCount() > 0;

        int labelWidth = isSidebarUi() ? 78 : 86;
        int fieldWidth = 58;
        int columnGap = 24;
        int columnWidth = labelWidth + fieldWidth;
        int fieldsLeft = centeredContentX(columnWidth * 2 + columnGap);
        int leftFieldX = fieldsLeft + labelWidth;
        int rightFieldX = fieldsLeft + columnWidth + columnGap + labelWidth;
        int fieldsY = nbtY + 34;

        this.tradeUsesBox = addTradeFieldBox(leftFieldX, fieldsY, fieldWidth, this.tradeUsesValue,
                value -> value.matches("\\d{0,10}"), value -> this.tradeUsesValue = value);
        this.tradeMaxUsesBox = addTradeFieldBox(rightFieldX, fieldsY, fieldWidth, this.tradeMaxUsesValue,
                value -> value.matches("-?\\d{0,10}"), value -> this.tradeMaxUsesValue = value);
        this.tradeXpBox = addTradeFieldBox(leftFieldX, fieldsY + 24, fieldWidth, this.tradeXpValue,
                value -> value.matches("\\d{0,10}"), value -> this.tradeXpValue = value);
        this.tradeSpecialPriceBox = addTradeFieldBox(rightFieldX, fieldsY + 24, fieldWidth, this.tradeSpecialPriceValue,
                value -> value.matches("-?\\d{0,10}"), value -> this.tradeSpecialPriceValue = value);
        this.tradeDemandBox = addTradeFieldBox(leftFieldX, fieldsY + 48, fieldWidth, this.tradeDemandValue,
                value -> value.matches("-?\\d{0,10}"), value -> this.tradeDemandValue = value);
        this.tradePriceMultiplierBox = addTradeFieldBox(rightFieldX, fieldsY + 48, fieldWidth, this.tradePriceMultiplierValue,
                value -> value.matches("\\d{0,8}(\\.\\d{0,6})?"), value -> this.tradePriceMultiplierValue = value);

        int buttonY = fieldsY + 76;
        int buttonGap = 8;
        int buttonAreaWidth = contentLimitedWidth(196, 130, 32);
        int buttonWidth = Math.max(1, (buttonAreaWidth - buttonGap) / 2);
        int buttonX = centeredContentX(buttonAreaWidth);
        InfinityEditorButton update = method_37063(new InfinityEditorButton(buttonX, buttonY,
                buttonWidth, FIELD_HEIGHT, class_2561.method_43471(key("trades.update")), button -> updateSelectedTradeFromFields()));
        update.field_22763 = getVillagerTradeCount() > 0;
        InfinityEditorButton reward = method_37063(new InfinityEditorButton(buttonX + buttonWidth + buttonGap,
                buttonY, buttonWidth, FIELD_HEIGHT,
                class_2561.method_43471(key("trades.reward_exp." + (this.tradeRewardExp ? 1 : 0))),
                button -> toggleSelectedTradeRewardExp()));
        reward.field_22763 = getVillagerTradeCount() > 0;
    }

    protected class_342 addTradeFieldBox(int x, int y, int width, String value, java.util.function.Predicate<String> filter,
                                     java.util.function.Consumer<String> responder) {
        class_342 box = addTrackedBox(legacyTextBox(x, y, width, FIELD_HEIGHT, class_2561.method_43473()));
        box.method_1880(16);
        box.method_1890(filter);
        box.method_1852(value);
        box.method_1863(responder);
        box.field_22763 = getVillagerTradeCount() > 0;
        return box;
    }

    protected void addAttributesPanel() {
        int controlLeft = editorControlLeft();
        this.attributeFilterBox = addTrackedBox(plainTextBox(searchFilterX(), searchFilterY(), searchFilterWidth(), 18,
                class_2561.method_43471(key("attribute_filter"))));
        this.attributeFilterBox.method_1880(48);
        this.attributeFilterBox.method_1868(MAIN_COLOR);
        this.attributeFilterBox.method_1852(this.attributeFilterValue);
        this.attributeFilterBox.method_1863(value -> {
            String normalized = value.toLowerCase(Locale.ROOT);
            if (!Objects.equals(this.attributeFilterValue, normalized)) {
                this.selectedAttributeNamespace = "";
            }
            this.attributeFilterValue = normalized;
        });

        if (!this.selectedAttributeNamespace.isBlank()) {
            method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 153, 80, OLD_BUTTON_HEIGHT,
                    class_2561.method_43471(key("registry_group.all")), button -> {
                this.selectedAttributeNamespace = "";
                method_41843();
            }));
        }

        this.attributeInfinityButton = method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 123, 80, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("attributes.infinity." + (this.attributeInfinity ? 1 : 0))),
                button -> toggleAttributeInfinity()));

        this.attributeOperationButton = method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 93, 80, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("attributes.operation." + this.attributeOperation)),
                button -> cycleAttributeOperation()));
        this.attributeOperationButton.field_22763 = !this.attributeInfinity;

        this.attributeSlotButton = method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 63, 80, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("attributes.slot." + this.attributeSlot)),
                button -> cycleAttributeSlot()));

        method_37063(new InfinityEditorButton(controlLeft, this.field_22790 - 33, 20, OLD_BUTTON_HEIGHT,
                class_2561.method_43470(this.attributeNegative ? "-" : "+"), button -> {
            this.attributeNegative = !this.attributeNegative;
            method_41843();
        }));

        this.attributeAmountBox = addTrackedBox(numberBox(controlLeft + 23, this.field_22790 - 32, 55, 18, 8,
                this.attributeAmountValue, 0, MAX_ATTRIBUTE_INTEGER));
        this.attributeAmountBox.method_1863(value -> this.attributeAmountValue = value);
        this.attributeAmountBox.field_22763 = !this.attributeInfinity;

        this.attributeDecimalBox = addTrackedBox(numberBox(controlLeft + 85, this.field_22790 - 32, 25, 18, 3,
                this.attributeDecimalValue, 0, 999));
        this.attributeDecimalBox.method_1863(value -> this.attributeDecimalValue = value);
        this.attributeDecimalBox.field_22763 = !this.attributeInfinity;
    }

    protected void addColorPanel() {
        int color = getEditorColor();
        this.colorHexValue = formatColorHex(color);

        this.colorHexBox = addTrackedBox(plainTextBox(centeredContentX(50), this.midY - 85, 50, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("color.hex"))));
        this.colorHexBox.method_1880(7);
        this.colorHexBox.method_1890(value -> value.matches("#?[0-9a-fA-F]{0,6}"));
        this.colorHexBox.method_1868(MAIN_COLOR);
        this.colorHexBox.method_1852(this.colorHexValue);
        this.colorHexBox.method_1863(value -> {
            this.colorHexValue = value;
            if (!this.syncingColorControls) {
                applyColorFromHex(false);
            }
        });

        int sliderWidth = contentLimitedWidth(160, 100, 32);
        int sliderX = centeredContentX(sliderWidth);
        this.redSlider = method_37063(new ColorSlider(sliderX, this.midY - 50, sliderWidth, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("color.red")), getRed(color), value -> setColorComponent(16, value)));
        this.greenSlider = method_37063(new ColorSlider(sliderX, this.midY - 10, sliderWidth, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("color.green")), getGreen(color), value -> setColorComponent(8, value)));
        this.blueSlider = method_37063(new ColorSlider(sliderX, this.midY + 30, sliderWidth, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("color.blue")), getBlue(color), value -> setColorComponent(0, value)));

        method_37063(new InfinityEditorButton(centeredContentX(60), this.midY + 65, 60, OLD_BUTTON_HEIGHT,
                class_2561.method_43471(key("color.random")), button -> {
            setEditorColor(ThreadLocalRandom.current().nextInt(0x1000000));
            syncColorControlsFromStack();
            this.status = class_2561.method_43469(messageKey("editor_color_updated"), this.colorHexValue);
        }));
    }

    protected void addLorePainterPanel() {
        ensureLorePainterRows();

        class_2561 insertText = class_2561.method_43471(key("lorepainter.insert"));
        int insertWidth = this.field_22793.method_27525(insertText) + 5;
        method_37063(new InfinityEditorButton(this.midX - insertWidth / 2, this.field_22790 - 55, insertWidth, OLD_BUTTON_HEIGHT,
                insertText, button -> insertLorePainterRows()));

        class_2561 scaleText = class_2561.method_43471(key("lorepainter.scale"));
        int scaleWidth = this.field_22793.method_27525(scaleText) + 5;
        this.lorePainterScaleButton = method_37063(new InfinityEditorButton(this.field_22789 - scaleWidth, this.field_22790 - 20, scaleWidth, OLD_BUTTON_HEIGHT,
                scaleText, button -> cycleGuiScale()));

        this.lorePainterAddRowButton = method_37063(new InfinityEditorButton(this.midX - 20, this.field_22790 - 50, 20, OLD_BUTTON_HEIGHT,
                class_2561.method_43470("+"), button -> addLorePainterRow()));
        this.lorePainterRemoveRowButton = method_37063(new InfinityEditorButton(this.midX, this.field_22790 - 50, 20, OLD_BUTTON_HEIGHT,
                class_2561.method_43470("-"), button -> removeLorePainterRow()));
        this.lorePainterAddColumnButton = method_37063(new InfinityEditorButton(this.field_22789 - 50, this.midY - 20, 20, OLD_BUTTON_HEIGHT,
                class_2561.method_43470("+"), button -> addLorePainterColumn()));
        this.lorePainterRemoveColumnButton = method_37063(new InfinityEditorButton(this.field_22789 - 50, this.midY, 20, OLD_BUTTON_HEIGHT,
                class_2561.method_43470("-"), button -> removeLorePainterColumn()));

        class_2561 previewText = class_2561.method_43471(key("lorepainter.preview"));
        this.lorePainterPreviewButton = method_37063(new InfinityEditorButton(0, this.field_22790 - 20, this.field_22793.method_27525(previewText) + 5, OLD_BUTTON_HEIGHT,
                previewText, button -> this.lorePainterPreview = !this.lorePainterPreview));
    }

    protected void addLorePanel() {
        this.loreScroll = class_3532.method_15340(this.loreScroll, 0, Math.max(0, this.loreValues.size() - loreLineSpaces()));
        int x = lorePanelLeft();
        int padding = 2;
        InfinityEditorButton button = addTopButton(x, "lore.addline", pressed -> {
            this.loreValues.add("");
            this.loreScroll = Math.max(0, this.loreValues.size() - loreLineSpaces());
            applyLoreToStack();
            method_41843();
        });
        x += button.method_25368() + padding;
        this.copyLoreButton = addTopButton(x, "lore.copylore", pressed -> copyLoreOnly());
        x += this.copyLoreButton.method_25368() + padding;
        button = addTopButton(x, "lore.copyall", pressed -> copyFullTooltip());
        x += button.method_25368() + padding;
        button = addTopButton(x, "lore.paste", pressed -> pasteLore());
        x += button.method_25368() + padding;
        button = addTopButton(x, "hideflags", pressed -> switchPanel(Panel.HIDE_FLAGS));
        x += button.method_25368() + padding;
        addTopButton(x, "lorepainter", pressed -> switchPanel(Panel.LORE_PAINTER));

        int spaces = loreLineSpaces();
        int end = Math.min(this.loreValues.size(), this.loreScroll + spaces);
        for (int i = this.loreScroll; i < end; i++) {
            int line = i;
            int row = i - this.loreScroll;
            int y = 55 + 30 * row;
            class_342 field = addTrackedBox(legacyTextBox(lorePanelLeft(), y, loreFieldWidth(), FIELD_HEIGHT,
                    class_2561.method_43470("Line " + (line + 1))));
            field.method_1880(500);
            field.method_1868(MAIN_COLOR);
            field.method_1852(this.loreValues.get(line));
            field.method_1863(value -> {
                setLoreLine(line, value);
                applyLoreToStack();
            });
            this.loreBoxes.add(field);

            InfinityEditorButton up = method_37063(new InfinityEditorButton(field.method_46426() + field.method_25368() + 3, y, 20, FIELD_HEIGHT,
                    class_2561.method_43470("\u2B06"), pressed -> moveLoreLine(line, -1)));
            up.field_22763 = line > 0;
            InfinityEditorButton down = method_37063(new InfinityEditorButton(field.method_46426() + field.method_25368() + 24, y, 20, FIELD_HEIGHT,
                    class_2561.method_43470("\u2B07"), pressed -> moveLoreLine(line, 1)));
            down.field_22763 = line < this.loreValues.size() - 1;
            method_37063(new InfinityEditorButton(field.method_46426() + field.method_25368() + 45, y, 20, FIELD_HEIGHT,
                    class_2561.method_43470("\u2715"), pressed -> {
                removeLoreLine(line);
                method_41843();
            }));
        }
        addFormatButtons();
    }

    protected InfinityEditorButton addTopButton(int x, String keySuffix, InfinityEditorButton.PressAction action) {
        class_2561 text = class_2561.method_43471(key(keySuffix));
        int width = this.field_22793.method_27525(text) + 6;
        if (isSidebarUi()) {
            width = Math.min(width, Math.max(24, safeRight() - lorePanelLeft()));
        }
        int clampedX = isSidebarUi() ? Math.min(x, Math.max(lorePanelLeft(), safeRight() - width)) : x;
        InfinityEditorButton button = method_37063(new InfinityEditorButton(clampedX, 10, width, FIELD_HEIGHT, text, action));
        this.loreActionButtons.add(button);
        return button;
    }

    protected void addBottomButtons() {
        if (isSidebarUi()) {
            addSidebarBottomButtons();
            return;
        }

        switch (this.activePanel) {
            case ITEM -> {
                method_37063(new InfinityEditorButton(5, legacyUiModeButtonY(), 80, OLD_BUTTON_HEIGHT,
                        getUiModeButtonText(), button -> toggleUiMode()));
                if (isTradeSlotEditor()) {
                    method_37063(new InfinityEditorButton(this.midX - 90, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                            class_2561.method_43471(key("back")), button -> goBack()));
                    method_37063(new InfinityEditorButton(this.midX - 30, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                            class_2561.method_43471(key("reset")), button -> resetStack()));
                } else {
                    method_37063(new InfinityEditorButton(this.midX - 90, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                            class_2561.method_43471(key("close")), button -> method_25419()));
                    method_37063(new InfinityEditorButton(this.midX - 30, this.field_22790 - 25, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                            class_2561.method_43471(key("save")), button -> applyToSelectedSlot()));
                    method_37063(new InfinityEditorButton(this.midX - 30, this.field_22790 - 45, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                            class_2561.method_43471(key("reset")), button -> resetStack()));
                }
                method_37063(new InfinityEditorButton(this.midX + 30, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                        class_2561.method_43471(key("drop")), button -> dropEditedStack()));
            }
            case NBT -> {
                method_37063(new InfinityEditorButton(this.midX - 60, this.field_22790 - 25, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                        class_2561.method_43471(key("back")), button -> goBack()));
                method_37063(new InfinityEditorButton(this.midX, this.field_22790 - 25, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                        class_2561.method_43471(key("reset")), button -> resetStack()));
            }
            case NBT_ADVANCED -> method_37063(new InfinityEditorButton(this.midX - 60, this.field_22790 - 25, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                    class_2561.method_43471(key("back")), button -> goBack()));
            case TRADE -> {
                method_37063(new InfinityEditorButton(this.midX - 90, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                        class_2561.method_43471(key("back")), button -> goBack()));
                InfinityEditorButton reset = method_37063(new InfinityEditorButton(this.midX - 30, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                        class_2561.method_43471(key("reset")), button -> {
                }));
                reset.field_22763 = false;
                method_37063(new InfinityEditorButton(this.midX + 30, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                        class_2561.method_43471(key("drop")), button -> dropEditedStack()));
            }
            default -> {
                method_37063(new InfinityEditorButton(this.midX - 90, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                        class_2561.method_43471(key("back")), button -> goBack()));
                method_37063(new InfinityEditorButton(this.midX - 30, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                        class_2561.method_43471(key("reset")), button -> resetStack()));
                method_37063(new InfinityEditorButton(this.midX + 30, this.field_22790 - 35, OLD_BUTTON_WIDTH, OLD_BUTTON_HEIGHT,
                        class_2561.method_43471(key("drop")), button -> dropEditedStack()));
            }
        }
    }

    protected void addSidebarBottomButtons() {
        int buttonHeight = SIDEBAR_BUTTON_HEIGHT;
        int gap = 6;
        int y = sidebarBottomButtonY();

        method_37063(new InfinityEditorButton(10, sidebarUiModeButtonY(), sidebarWidth() - 20, buttonHeight,
                getUiModeButtonText(), button -> toggleUiMode()));

        if (this.activePanel == Panel.ITEM) {
            int count = isTradeSlotEditor() ? 3 : 4;
            int buttonWidth = sidebarBottomButtonWidth(count, gap);
            int x = sidebarBottomStartX(count, buttonWidth, gap);
            method_37063(new InfinityEditorButton(x, y, buttonWidth, buttonHeight,
                    class_2561.method_43471(key(isTradeSlotEditor() ? "back" : "close")), button -> {
                if (isTradeSlotEditor()) {
                    goBack();
                } else {
                    method_25419();
                }
            }));
            method_37063(new InfinityEditorButton(x + buttonWidth + gap, y, buttonWidth, buttonHeight,
                    class_2561.method_43471(key("reset")), button -> resetStack()));
            if (!isTradeSlotEditor()) {
                method_37063(new InfinityEditorButton(x + 2 * (buttonWidth + gap), y, buttonWidth, buttonHeight,
                        class_2561.method_43471(key("save")), button -> applyToSelectedSlot()));
                method_37063(new InfinityEditorButton(x + 3 * (buttonWidth + gap), y, buttonWidth, buttonHeight,
                        class_2561.method_43471(key("drop")), button -> dropEditedStack()));
            } else {
                method_37063(new InfinityEditorButton(x + 2 * (buttonWidth + gap), y, buttonWidth, buttonHeight,
                        class_2561.method_43471(key("drop")), button -> dropEditedStack()));
            }
            return;
        }

        if (this.activePanel == Panel.NBT_ADVANCED) {
            int buttonWidth = sidebarBottomButtonWidth(1, gap);
            method_37063(new InfinityEditorButton(contentLeft() + 16, y, buttonWidth, buttonHeight,
                    class_2561.method_43471(key("back")), button -> goBack()));
            return;
        }

        if (this.activePanel == Panel.TRADE) {
            int buttonWidth = sidebarBottomButtonWidth(3, gap);
            int x = sidebarBottomStartX(3, buttonWidth, gap);
            method_37063(new InfinityEditorButton(x, y, buttonWidth, buttonHeight,
                    class_2561.method_43471(key("back")), button -> goBack()));
            InfinityEditorButton reset = method_37063(new InfinityEditorButton(x + buttonWidth + gap, y, buttonWidth, buttonHeight,
                    class_2561.method_43471(key("reset")), button -> {
            }));
            reset.field_22763 = false;
            method_37063(new InfinityEditorButton(x + 2 * (buttonWidth + gap), y, buttonWidth, buttonHeight,
                    class_2561.method_43471(key("drop")), button -> dropEditedStack()));
            return;
        }

        int buttonWidth = sidebarBottomButtonWidth(3, gap);
        int x = sidebarBottomStartX(3, buttonWidth, gap);
        method_37063(new InfinityEditorButton(x, y, buttonWidth, buttonHeight,
                class_2561.method_43471(key("back")), button -> goBack()));
        method_37063(new InfinityEditorButton(x + buttonWidth + gap, y, buttonWidth, buttonHeight,
                class_2561.method_43471(key("reset")), button -> resetStack()));
        method_37063(new InfinityEditorButton(x + 2 * (buttonWidth + gap), y, buttonWidth, buttonHeight,
                class_2561.method_43471(key("drop")), button -> dropEditedStack()));
    }

    protected class_342 addTrackedBox(class_342 box) {
        this.tickingBoxes.add(box);
        return method_37063(box);
    }

    protected class_342 legacyTextBox(int x, int y, int width, int height, class_2561 message) {
        class_342 box = isSidebarUi()
                ? new ModernTextEditBox(this.field_22793, x, y, width, height, message)
                : new LegacyTextEditBox(this.field_22793, x, y, width, height, message);
        box.method_1868(isSidebarUi() ? ModernUi.TEXT_PRIMARY : MAIN_COLOR);
        return box;
    }

    protected class_342 plainTextBox(int x, int y, int width, int height, class_2561 message) {
        class_342 box = isSidebarUi()
                ? new ModernTextEditBox(this.field_22793, x, y, width, height, message)
                : new class_342(this.field_22793, x, y, width, height, message);
        box.method_1868(isSidebarUi() ? ModernUi.TEXT_PRIMARY : MAIN_COLOR);
        return box;
    }

    protected class_342 numberBox(int x, int y, int width, int height, int digits, String value, int minValue, int maxValue) {
        if (isSidebarUi()) {
            class_342 box = plainTextBox(x, y, width, height, class_2561.method_43473());
            int normalizedDigits = Math.max(1, digits);
            box.method_1880(normalizedDigits + (minValue < 0 ? 1 : 0));
            box.method_1890(text -> isAllowedSidebarNumber(text, normalizedDigits, minValue < 0));
            box.method_1852(value == null ? "" : value);
            return box;
        }

        class_342 box = new FixedDigitEditBox(this.field_22793, x, y, width, height, digits, minValue, maxValue);
        box.method_1852(value);
        return box;
    }

    private boolean isAllowedSidebarNumber(String value, int digits, boolean allowNegative) {
        if (value == null || value.isEmpty()) {
            return true;
        }

        int start = 0;
        if (value.charAt(0) == '-') {
            if (!allowNegative || value.length() == 1) {
                return allowNegative;
            }
            start = 1;
        }
        if (value.length() - start > digits) {
            return false;
        }
        for (int i = start; i < value.length(); i++) {
            char character = value.charAt(i);
            if (character < '0' || character > '9') {
                return false;
            }
        }
        return true;
    }
}
