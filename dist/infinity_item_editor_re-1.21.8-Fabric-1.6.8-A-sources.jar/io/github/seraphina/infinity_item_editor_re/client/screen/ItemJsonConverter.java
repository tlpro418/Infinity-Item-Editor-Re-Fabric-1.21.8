package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_2479;
import net.minecraft.class_2481;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2494;
import net.minecraft.class_2495;
import net.minecraft.class_2497;
import net.minecraft.class_2499;
import net.minecraft.class_2501;
import net.minecraft.class_2503;
import net.minecraft.class_2514;
import net.minecraft.class_2516;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

final class ItemJsonConverter {
    private static final Gson PRETTY_GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Set<String> STACK_ROOT_KEYS = Set.of("id", "item", "Item", "Count", "count", "components", "tag", "nbt");

    private ItemJsonConverter() {
    }

    static String toJson(class_1799 stack) {
        class_2487 saved = ItemStackNbt.save(stack);
        return PRETTY_GSON.toJson(toJsonElement(saved));
    }

    static String format(String value) throws JsonParseException {
        JsonElement parsed = JsonParser.parseString(value);
        return PRETTY_GSON.toJson(parsed);
    }

    static class_1799 fromJson(String value) throws JsonParseException {
        JsonElement parsed = JsonParser.parseString(value);
        if (!parsed.isJsonObject()) {
            throw new JsonParseException("Root must be a JSON object.");
        }

        class_2487 saved = jsonObjectToCompound(parsed.getAsJsonObject());
        normalizeStackKeys(saved);
        class_1799 stack = ItemStackNbt.parse(saved);
        if (stack.method_7960() && !"minecraft:air".equals(saved.method_68564("id", ""))) {
            throw new JsonParseException("JSON does not describe a valid item stack.");
        }
        return stack;
    }

    private static void normalizeStackKeys(class_2487 saved) {
        if (!saved.method_10545("id")) {
            if (saved.method_10545("item")) {
                saved.method_10582("id", saved.method_68564("item", ""));
            } else if (saved.method_10545("Item")) {
                saved.method_10582("id", saved.method_68564("Item", ""));
            }
        }
        if (!saved.method_10545("Count") && saved.method_10545("count")) {
            saved.method_10567("Count", saved.method_68562("count", (byte) 0));
        }
        if (!saved.method_10545("Count")) {
            saved.method_10567("Count", (byte) 1);
        }
        if (!saved.method_10545("tag") && saved.method_10580("nbt") instanceof class_2487 nbt) {
            saved.method_10566("tag", nbt.method_10553());
        }
        moveLooseRootTags(saved);
    }

    private static void moveLooseRootTags(class_2487 saved) {
        class_2487 itemTag = saved.method_10580("tag") instanceof class_2487 existing ? existing.method_10553() : new class_2487();
        for (String key : new ArrayList<>(saved.method_10541())) {
            if (STACK_ROOT_KEYS.contains(key) || itemTag.method_10545(key)) {
                continue;
            }
            class_2520 value = saved.method_10580(key);
            if (value != null) {
                itemTag.method_10566(key, value.method_10707());
            }
        }
        if (!itemTag.method_33133()) {
            saved.method_10566("tag", itemTag);
        }
    }

    private static class_2487 jsonObjectToCompound(JsonObject object) {
        class_2487 compound = new class_2487();
        for (String key : object.keySet()) {
            class_2520 tag = toTag(key, object.get(key));
            if (tag != null) {
                compound.method_10566(key, tag);
            }
        }
        return compound;
    }

    private static class_2520 toTag(String key, JsonElement element) {
        if (element == null || element instanceof JsonNull || element.isJsonNull()) {
            return null;
        }
        if (element.isJsonObject()) {
            return jsonObjectToCompound(element.getAsJsonObject());
        }
        if (element.isJsonArray()) {
            return toArrayTag(key, element.getAsJsonArray());
        }
        if (!element.isJsonPrimitive()) {
            return class_2519.method_23256(element.toString());
        }

        JsonPrimitive primitive = element.getAsJsonPrimitive();
        if (primitive.isBoolean()) {
            return class_2481.method_23234(primitive.getAsBoolean());
        }
        if (primitive.isString()) {
            return class_2519.method_23256(primitive.getAsString());
        }
        if (primitive.isNumber()) {
            return toNumberTag(key, primitive);
        }
        return class_2519.method_23256(primitive.getAsString());
    }

    private static class_2520 toArrayTag(String key, JsonArray array) {
        if (array.isEmpty()) {
            return new class_2499();
        }
        if (isByteArrayKey(key) && allIntegralNumbers(array)) {
            byte[] values = new byte[array.size()];
            for (int i = 0; i < array.size(); i++) {
                values[i] = array.get(i).getAsByte();
            }
            return new class_2479(values);
        }
        if (isIntArrayKey(key) && allIntegralNumbers(array)) {
            List<Integer> values = new ArrayList<>(array.size());
            for (JsonElement element : array) {
                values.add(element.getAsInt());
            }
            return new class_2495(values.stream().mapToInt(Integer::intValue).toArray());
        }
        if (isLongArrayKey(key) && allIntegralNumbers(array)) {
            long[] values = new long[array.size()];
            for (int i = 0; i < array.size(); i++) {
                values[i] = array.get(i).getAsLong();
            }
            return new class_2501(values);
        }

        class_2499 list = new class_2499();
        for (JsonElement element : array) {
            class_2520 tag = toTag(key, element);
            if (tag != null) {
                list.add(tag);
            }
        }
        return list;
    }

    private static class_2520 toNumberTag(String key, JsonPrimitive primitive) {
        String raw = primitive.getAsString();
        String normalizedKey = key.toLowerCase(Locale.ROOT);
        if (raw.indexOf('.') >= 0 || raw.indexOf('e') >= 0 || raw.indexOf('E') >= 0) {
            if (normalizedKey.contains("multiplier") || normalizedKey.equals("amount")) {
                return class_2494.method_23244(primitive.getAsFloat());
            }
            return class_2489.method_23241(primitive.getAsDouble());
        }

        long value = primitive.getAsLong();
        if (normalizedKey.equals("count") || normalizedKey.equals("slot") || normalizedKey.equals("type")
                || normalizedKey.equals("flight") || normalizedKey.equals("operation")) {
            return class_2481.method_23233((byte) value);
        }
        if (value >= Short.MIN_VALUE && value <= Short.MAX_VALUE && normalizedKey.endsWith("short")) {
            return class_2516.method_23254((short) value);
        }
        if (value >= Integer.MIN_VALUE && value <= Integer.MAX_VALUE) {
            return class_2497.method_23247((int) value);
        }
        return class_2503.method_23251(value);
    }

    private static boolean allIntegralNumbers(JsonArray array) {
        for (JsonElement element : array) {
            if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isNumber()) {
                return false;
            }
            String raw = element.getAsString();
            if (raw.indexOf('.') >= 0 || raw.indexOf('e') >= 0 || raw.indexOf('E') >= 0) {
                return false;
            }
        }
        return true;
    }

    private static boolean isByteArrayKey(String key) {
        String normalized = key.toLowerCase(Locale.ROOT);
        return normalized.endsWith("bytes") || normalized.endsWith("bytearray");
    }

    private static boolean isIntArrayKey(String key) {
        String normalized = key.toLowerCase(Locale.ROOT);
        return normalized.equals("id") || normalized.equals("uuid") || normalized.endsWith("uuid")
                || normalized.equals("colors") || normalized.equals("fadecolors");
    }

    private static boolean isLongArrayKey(String key) {
        String normalized = key.toLowerCase(Locale.ROOT);
        return normalized.endsWith("longs") || normalized.endsWith("longarray");
    }

    private static JsonElement toJsonElement(class_2520 tag) {
        if (tag == null) {
            return JsonNull.INSTANCE;
        }
        if (tag instanceof class_2487 compoundTag) {
            JsonObject object = new JsonObject();
            for (String key : compoundTag.method_10541()) {
                object.add(key, toJsonElement(compoundTag.method_10580(key)));
            }
            return object;
        }
        if (tag instanceof class_2499 listTag) {
            JsonArray array = new JsonArray();
            for (int i = 0; i < listTag.size(); i++) {
                array.add(toJsonElement(listTag.method_10534(i)));
            }
            return array;
        }
        if (tag instanceof class_2479 byteArrayTag) {
            JsonArray array = new JsonArray();
            for (byte value : byteArrayTag.method_10521()) {
                array.add(value);
            }
            return array;
        }
        if (tag instanceof class_2495 intArrayTag) {
            JsonArray array = new JsonArray();
            for (int value : intArrayTag.method_10588()) {
                array.add(value);
            }
            return array;
        }
        if (tag instanceof class_2501 longArrayTag) {
            JsonArray array = new JsonArray();
            for (long value : longArrayTag.method_10615()) {
                array.add(value);
            }
            return array;
        }
        if (tag instanceof class_2519 stringTag) {
            return new JsonPrimitive(stringTag.comp_3831());
        }
        if (tag instanceof class_2514 numericTag) {
            return new JsonPrimitive(numericTag.method_10702());
        }
        return new JsonPrimitive(tag.toString());
    }
}
