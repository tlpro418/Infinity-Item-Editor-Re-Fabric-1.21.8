package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.data.voids.VoidController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3544;
import net.minecraft.class_437;
import io.github.seraphina.infinity_item_editor_re.util.Tooltips;
final class ItemPickScreen extends class_437 {
    private static final int MAX_IN_ROW = 8;
    private static final int ROWS = 10;
    private static final int ITEM_SIZE = 16;
    private static final int TOP_BAR = 20;
    private static final int BLAND_COLOR = 0xFF96C8FF;
    private static final int HOVER_COLOR = 0x96969696;
    private static final PickList REALM_LIST = new PickList() {
        @Override
        List<class_1799> getStackList() {
            class_310 minecraft = class_310.method_1551();
            RealmController controller = ModSource.getOrCreateRealmController(minecraft.field_1697);
            class_2371<class_1799> stacks = class_2371.method_10211();
            if (controller != null) {
                for (class_1799 stack : controller.getStackList()) {
                    stacks.add(stack.method_7972());
                }
            }
            return stacks;
        }

        @Override
        class_2561 getName() {
            return class_2561.method_43471(itemGroupKey("realm"));
        }
    };
    private static final PickList VOID_LIST = new PickList() {
        @Override
        List<class_1799> getStackList() {
            class_2371<class_1799> stacks = class_2371.method_10211();
            VoidController.loadVoidToList(stacks);
            return stacks;
        }

        @Override
        class_2561 getName() {
            return class_2561.method_43471(itemGroupKey("void"));
        }
    };
    private static final PickList INVENTORY_LIST = new PickList() {
        @Override
        List<class_1799> getStackList() {
            class_310 minecraft = class_310.method_1551();
            class_2371<class_1799> stacks = class_2371.method_10211();
            if (minecraft.field_1724 == null) {
                return stacks;
            }

            class_1661 inventory = minecraft.field_1724.method_31548();
            for (int slot = 0; slot < inventory.method_5439(); slot++) {
                class_1799 stack = inventory.method_5438(slot);
                if (!stack.method_7960()) {
                    stacks.add(stack.method_7972());
                }
            }
            return stacks;
        }

        @Override
        class_2561 getName() {
            class_310 minecraft = class_310.method_1551();
            if (minecraft.field_1724 == null) {
                return class_2561.method_43471("container.inventory");
            }
            return minecraft.field_1724.method_31548().method_5476();
        }
    };

    private final class_437 lastScreen;
    private final Consumer<class_1799> stackSetter;
    private final Supplier<class_1799> stackGetter;
    private final List<class_1799> filteredList = new ArrayList<>();
    private PickList pickList;
    private int currentElement;
    private String filteredString;
    private String searchString = "";
    private int midX;
    private int midY;

    ItemPickScreen(class_437 lastScreen, Consumer<class_1799> stackSetter, Supplier<class_1799> stackGetter) {
        this(lastScreen, stackSetter, stackGetter, REALM_LIST);
    }

    private ItemPickScreen(class_437 lastScreen, Consumer<class_1799> stackSetter, Supplier<class_1799> stackGetter, PickList pickList) {
        super(class_2561.method_43471(key("pick")));
        this.lastScreen = lastScreen;
        this.stackSetter = stackSetter;
        this.stackGetter = stackGetter;
        this.pickList = pickList;
    }

    @Override
    protected void method_25426() {
        this.midX = this.field_22789 / 2;
        this.midY = this.field_22790 / 2;

        method_37063(new InfinityEditorButton(this.midX - 90, this.field_22790 - 35, 60, 20,
                class_2561.method_43471(key("back")), button -> returnToLastScreen()));
        InfinityEditorButton reset = method_37063(new InfinityEditorButton(this.midX - 30, this.field_22790 - 35, 60, 20,
                class_2561.method_43471(key("reset")), button -> {
        }));
        reset.field_22763 = false;
        method_37063(new InfinityEditorButton(this.midX + 30, this.field_22790 - 35, 60, 20,
                class_2561.method_43471(key("drop")), button -> dropSelectedStack()));

        applySearchIfNeeded();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            returnToLastScreen();
            return true;
        }
        if (keyCode == 259) {
            this.searchString = this.searchString.substring(0, Math.max(this.searchString.length() - 1, 0));
            if (this.searchString.isEmpty() && !this.searchString.equals(this.filteredString)) {
                applySearch();
            }
            return true;
        }
        if (keyCode == 257 || keyCode == 335) {
            if (!this.searchString.equals(this.filteredString)) {
                applySearch();
            }
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        if (class_3544.method_57175(codePoint) && this.searchString.length() < 20) {
            this.searchString += codePoint;
            return true;
        }
        return super.method_25400(codePoint, modifiers);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (super.method_25402(mouseX, mouseY, button)) {
            return true;
        }
        if (button != 0) {
            return false;
        }

        int space = getClickSpace();
        int nextPageWidth = this.field_22793.method_1727("-->");
        int currentPage = getCurrentPage();
        int amountPages = getAmountPages();
        int searchWidth = this.field_22793.method_1727(this.searchString);
        if (!this.searchString.isEmpty() && !this.searchString.equals(this.filteredString)
                && isMouseIn(mouseX, mouseY, this.midX - searchWidth / 2, 56, searchWidth, 8)) {
            applySearch();
            return true;
        }

        if (currentPage + 1 < amountPages
                && isMouseIn(mouseX, mouseY, this.midX + 10, 70 + TOP_BAR + 168, nextPageWidth, 8)) {
            this.currentElement = Math.min(this.filteredList.size() - 1, (currentPage + 1) * getAmountInPage());
            return true;
        }
        if (currentPage > 0
                && isMouseIn(mouseX, mouseY, this.midX - 10 - nextPageWidth, 70 + TOP_BAR + 168, nextPageWidth, 8)) {
            this.currentElement = Math.max(0, (currentPage - 1) * getAmountInPage());
            return true;
        }
        if (mouseX < space) {
            if (trySwitchPickList(mouseX, mouseY, space, REALM_LIST, 100)) {
                return true;
            }
            if (trySwitchPickList(mouseX, mouseY, space, VOID_LIST, 120)) {
                return true;
            }
            return trySwitchPickList(mouseX, mouseY, space, INVENTORY_LIST, 140);
        }

        if (!this.filteredList.isEmpty()) {
            int start = Math.min(this.filteredList.size() - 1, currentPage * getAmountInPage());
            int end = Math.min(this.filteredList.size(), (currentPage + 1) * getAmountInPage());
            for (int i = start; i < end; i++) {
                int x = space + ITEM_SIZE * (i % MAX_IN_ROW);
                int y = 70 + TOP_BAR + ITEM_SIZE * ((i % getAmountInPage()) / MAX_IN_ROW);
                if (mouseX > x && mouseX < x + ITEM_SIZE && mouseY > y && mouseY < y + ITEM_SIZE) {
                    this.stackSetter.accept(this.filteredList.get(i).method_7972());
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        EditorBackgrounds.render(guiGraphics, this.field_22789, this.field_22790);
        renderSelectedStack(guiGraphics);
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.midX, 15, InfinityEditorButton.MAIN_COLOR);
        renderPickContents(guiGraphics, mouseX, mouseY);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void method_25419() {
        returnToLastScreen();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void renderPickContents(class_332 guiGraphics, int mouseX, int mouseY) {
        int space = getRenderSpace();
        int currentPage = getCurrentPage();
        int amountPages = getAmountPages();

        guiGraphics.method_27534(this.field_22793, this.pickList.getName(), this.midX, 60, InfinityEditorButton.CONTRAST_COLOR);
        class_2561 searchText = this.searchString.isEmpty()
                ? class_2561.method_43471(key("pick.type_search"))
                : class_2561.method_43470(this.searchString);
        guiGraphics.method_27534(this.field_22793, searchText, this.midX, 73, BLAND_COLOR);

        renderPickListName(guiGraphics, REALM_LIST, space, 100);
        renderPickListName(guiGraphics, VOID_LIST, space, 120);
        renderPickListName(guiGraphics, INVENTORY_LIST, space, 140);

        String nextPage = "-->";
        int nextPageWidth = this.field_22793.method_1727(nextPage);
        if (currentPage + 1 < amountPages) {
            boolean selected = isMouseIn(mouseX, mouseY, this.midX + 10, 70 + TOP_BAR + 168, nextPageWidth, 8);
            guiGraphics.method_25303(this.field_22793, nextPage, this.midX + 10, 70 + TOP_BAR + 168,
                    selected ? InfinityEditorButton.CONTRAST_COLOR : BLAND_COLOR);
        }

        guiGraphics.method_25300(this.field_22793, Integer.toString(currentPage + 1), this.midX, 70 + TOP_BAR + 168, BLAND_COLOR);

        if (currentPage > 0) {
            String previousPage = "<--";
            boolean selected = isMouseIn(mouseX, mouseY, this.midX - nextPageWidth - 10, 70 + TOP_BAR + 168, nextPageWidth, 8);
            guiGraphics.method_25303(this.field_22793, previousPage, this.midX - nextPageWidth - 10, 70 + TOP_BAR + 168,
                    selected ? InfinityEditorButton.CONTRAST_COLOR : BLAND_COLOR);
        }

        class_1799 hovered = renderPickItems(guiGraphics, mouseX, mouseY, space, currentPage);
        int searchWidth = this.field_22793.method_1727(this.searchString);
        if (!hovered.method_7960()) {
            Tooltips.show(guiGraphics, this.field_22793, hovered, mouseX, mouseY);
        } else if (!this.searchString.equals(this.filteredString)
                && isMouseIn(mouseX, mouseY, this.midX - searchWidth / 2, 56, searchWidth, 8)) {
            Tooltips.show(guiGraphics, this.field_22793, class_2561.method_43471(key("pick.click_search")), mouseX, mouseY);
        } else if (isMouseIn(mouseX, mouseY, this.midX - 8, 27, ITEM_SIZE, ITEM_SIZE)) {
            class_1799 stack = getSelectedStack();
            if (!stack.method_7960()) {
                Tooltips.show(guiGraphics, this.field_22793, stack, mouseX, mouseY);
            }
        }
    }

    private class_1799 renderPickItems(class_332 guiGraphics, int mouseX, int mouseY, int space, int currentPage) {
        if (this.filteredList.isEmpty()) {
            return class_1799.field_8037;
        }

        class_1799 hovered = class_1799.field_8037;
        int start = Math.min(this.filteredList.size() - 1, currentPage * getAmountInPage());
        int end = Math.min(this.filteredList.size(), (currentPage + 1) * getAmountInPage());
        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(0.0F, 0.0F);
        for (int i = start; i < end; i++) {
            int x = space + ITEM_SIZE * (i % MAX_IN_ROW);
            int y = 70 + TOP_BAR + ITEM_SIZE * ((i % getAmountInPage()) / MAX_IN_ROW);
            class_1799 stack = this.filteredList.get(i);
            guiGraphics.method_51427(stack, x, y);
            guiGraphics.method_51431(this.field_22793, stack, x, y);
            if (mouseX > x && mouseX < x + ITEM_SIZE && mouseY > y && mouseY < y + ITEM_SIZE) {
                guiGraphics.method_25294(x, y, x + ITEM_SIZE, y + ITEM_SIZE, HOVER_COLOR);
                hovered = stack;
            }
        }
        guiGraphics.method_51448().popMatrix();
        return hovered;
    }

    private void renderSelectedStack(class_332 guiGraphics) {
        class_1799 stack = getSelectedStack();
        if (stack.method_7960()) {
            return;
        }
        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(0.0F, 0.0F);
        guiGraphics.method_51427(stack, this.midX - 8, 27);
        guiGraphics.method_51431(this.field_22793, stack, this.midX - 8, 27);
        guiGraphics.method_51448().popMatrix();
    }

    private void renderPickListName(class_332 guiGraphics, PickList list, int space, int y) {
        class_2561 name = list.getName();
        int x = space - this.field_22793.method_27525(name) - 10;
        int color = this.pickList == list ? InfinityEditorButton.CONTRAST_COLOR : InfinityEditorButton.MAIN_COLOR;
        guiGraphics.method_27535(this.field_22793, name, x, y, color);
    }

    private boolean trySwitchPickList(double mouseX, double mouseY, int space, PickList list, int y) {
        class_2561 name = list.getName();
        if (this.pickList != list && isMouseIn(mouseX, mouseY, space - this.field_22793.method_27525(name) - 10, y, this.field_22793.method_27525(name), 8)) {
            this.pickList = list;
            this.filteredString = null;
            applySearch();
            return true;
        }
        return false;
    }

    private void applySearchIfNeeded() {
        if (!this.searchString.equals(this.filteredString)) {
            applySearch();
        }
    }

    private void applySearch() {
        this.filteredList.clear();
        String loweredSearch = this.searchString.toLowerCase(Locale.ROOT);
        for (class_1799 stack : this.pickList.getStackList()) {
            if (stack.method_7964().getString().toLowerCase(Locale.ROOT).contains(loweredSearch)) {
                this.filteredList.add(stack);
            }
        }
        this.currentElement = 0;
        this.filteredString = this.searchString;
    }

    private void returnToLastScreen() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.lastScreen);
        }
    }

    private void dropSelectedStack() {
        class_1799 stack = getSelectedStack();
        if (stack.method_7960() || this.field_22787 == null) {
            return;
        }

        if (class_437.method_25442()) {
            this.field_22787.field_1774.method_1455(GiveHelper.getStringFromItemStack(stack));
            return;
        }

        if (this.field_22787.field_1761 != null && this.field_22787.field_1724 != null && this.field_22787.field_1724.method_31549().field_7477) {
            this.field_22787.field_1761.method_2915(stack.method_7972());
        }
    }

    private class_1799 getSelectedStack() {
        class_1799 stack = this.stackGetter.get();
        return stack == null ? class_1799.field_8037 : stack;
    }

    private int getAmountInPage() {
        return MAX_IN_ROW * ROWS;
    }

    private int getCurrentPage() {
        return this.currentElement / getAmountInPage();
    }

    private int getAmountPages() {
        return this.filteredList.size() / getAmountInPage() + 1;
    }

    private int getClickSpace() {
        return (this.field_22789 - MAX_IN_ROW * ITEM_SIZE) / 2;
    }

    private int getRenderSpace() {
        return (this.field_22789 - (MAX_IN_ROW * ITEM_SIZE + 3)) / 2;
    }

    private static boolean isMouseIn(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    private static String key(String suffix) {
        return "screen." + ModSource.MODID + "." + suffix;
    }

    private static String itemGroupKey(String suffix) {
        return "itemGroup." + ModSource.MODID + "." + suffix;
    }

    private abstract static class PickList {
        abstract List<class_1799> getStackList();

        abstract class_2561 getName();
    }
}
