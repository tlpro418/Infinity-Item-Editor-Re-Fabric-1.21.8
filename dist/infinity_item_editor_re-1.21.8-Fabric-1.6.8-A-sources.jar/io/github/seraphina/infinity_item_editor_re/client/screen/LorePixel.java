package io.github.seraphina.infinity_item_editor_re.client.screen;

import net.minecraft.class_124;
import net.minecraft.class_1767;

class LorePixel {
    class_1767 color;
    LoreSymbol symbol;

    LorePixel() {
        this(class_1767.field_7952, LoreSymbol.FULL_BLOCK);
    }

    LorePixel(class_1767 color, LoreSymbol symbol) {
        this.color = color;
        this.symbol = symbol;
    }

    LorePixel copy() {
        return new LorePixel(this.color, this.symbol);
    }

    String format() {
        class_124 formatting = class_124.method_534(15 - this.color.method_7789());
        return (formatting == null ? class_124.field_1068 : formatting).toString();
    }

    @Override
    public String toString() {
        if (this.symbol.whitespace()) {
            return this.symbol.symbol();
        }
        return format() + this.symbol.symbol();
    }
}

enum LoreSymbol {
    FULL_BLOCK("fullblock", "\u2588", false),
    MEDIUM_SHADE("mediumshade", "\u2592", false),
    DARK_SHADE("darkshade", "\u2593", false),
    FULL_SPACE("fullspace", class_124.field_1067 + " " + class_124.field_1070 + " ", true);

    private final String nameKey;
    private final String symbol;
    private final boolean whitespace;

    LoreSymbol(String nameKey, String symbol, boolean whitespace) {
        this.nameKey = nameKey;
        this.symbol = symbol;
        this.whitespace = whitespace;
    }

    String nameKey() {
        return this.nameKey;
    }

    String symbol() {
        return this.symbol;
    }

    boolean whitespace() {
        return this.whitespace;
    }
}
