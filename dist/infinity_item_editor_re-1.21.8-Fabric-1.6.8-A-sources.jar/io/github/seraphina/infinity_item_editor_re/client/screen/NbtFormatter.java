package io.github.seraphina.infinity_item_editor_re.client.screen;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_2479;
import net.minecraft.class_2487;
import net.minecraft.class_2495;
import net.minecraft.class_2499;
import net.minecraft.class_2501;
import net.minecraft.class_2514;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2561;

final class NbtFormatter {
    private static final Gson PRETTY_GSON = new GsonBuilder().setPrettyPrinting().create();

    private NbtFormatter() {
    }

    static List<class_2561> prettyLines(class_2520 tag) {
        List<class_2561> lines = new ArrayList<>();
        for (String line : prettyJson(tag).split("\\n")) {
            lines.add(class_2561.method_43470(class_124.field_1064 + line));
        }
        return lines;
    }

    static List<NbtRow> rows(class_2487 tag, Set<String> expandedPaths) {
        List<NbtRow> rows = new ArrayList<>();
        if (tag == null || tag.method_33133()) {
            rows.add(new NbtRow("tag", "tag: {}", false, 0));
            return rows;
        }

        addRows(rows, expandedPaths, "tag", "tag", tag, 0);
        return rows;
    }

    private static void addRows(List<NbtRow> rows, Set<String> expandedPaths, String path, String name, class_2520 tag, int depth) {
        boolean expandable = tag instanceof class_2487 || tag instanceof class_2499;
        String prefix = expandable ? (expandedPaths.contains(path) ? "- " : "+ ") : "  ";
        rows.add(new NbtRow(path, prefix + name + ": " + summarizeTag(tag), expandable, depth));
        if (!expandable || !expandedPaths.contains(path)) {
            return;
        }

        if (tag instanceof class_2487 compoundTag) {
            for (String key : compoundTag.method_10541()) {
                addRows(rows, expandedPaths, path + "." + key, key, compoundTag.method_10580(key), depth + 1);
            }
        } else if (tag instanceof class_2499 listTag) {
            for (int i = 0; i < listTag.size(); i++) {
                addRows(rows, expandedPaths, path + "[" + i + "]", "[" + i + "]", listTag.method_10534(i), depth + 1);
            }
        }
    }

    private static String summarizeTag(class_2520 tag) {
        if (tag instanceof class_2487 compoundTag) {
            return "{" + compoundTag.method_10541().size() + "}";
        }
        if (tag instanceof class_2499 listTag) {
            return "[" + listTag.size() + "]";
        }
        String value = tag.toString();
        return value.length() > 120 ? value.substring(0, 117) + "..." : value;
    }

    private static String prettyJson(class_2520 tag) {
        if (tag == null || tag instanceof class_2487 compoundTag && compoundTag.method_33133()) {
            return "{}";
        }

        String raw = tag.toString();
        try {
            return PRETTY_GSON.toJson(JsonParser.parseString(raw));
        } catch (JsonParseException ignored) {
            return PRETTY_GSON.toJson(toJsonElement(tag));
        }
    }

    private static JsonElement toJsonElement(class_2520 tag) {
        if (tag == null) {
            return JsonNull.INSTANCE;
        }
        if (tag instanceof class_2487 compoundTag) {
            JsonObject object = new JsonObject();
            for (String key : compoundTag.method_10541()) {
                object.add(key, toJsonElement(compoundTag.method_10580(key)));
            }
            return object;
        }
        if (tag instanceof class_2499 listTag) {
            JsonArray array = new JsonArray();
            for (int i = 0; i < listTag.size(); i++) {
                array.add(toJsonElement(listTag.method_10534(i)));
            }
            return array;
        }
        if (tag instanceof class_2479 byteArrayTag) {
            JsonArray array = new JsonArray();
            for (byte value : byteArrayTag.method_10521()) {
                array.add(value);
            }
            return array;
        }
        if (tag instanceof class_2495 intArrayTag) {
            JsonArray array = new JsonArray();
            for (int value : intArrayTag.method_10588()) {
                array.add(value);
            }
            return array;
        }
        if (tag instanceof class_2501 longArrayTag) {
            JsonArray array = new JsonArray();
            for (long value : longArrayTag.method_10615()) {
                array.add(value);
            }
            return array;
        }
        if (tag instanceof class_2519 stringTag) {
            return new JsonPrimitive(stringTag.comp_3831());
        }
        if (tag instanceof class_2514 numericTag) {
            return new JsonPrimitive(numericTag.method_10702());
        }
        return new JsonPrimitive(tag.toString());
    }
}
