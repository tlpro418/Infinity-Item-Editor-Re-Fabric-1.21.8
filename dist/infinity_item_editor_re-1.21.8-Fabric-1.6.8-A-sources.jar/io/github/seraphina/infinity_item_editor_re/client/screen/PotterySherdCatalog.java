package io.github.seraphina.infinity_item_editor_re.client.screen;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public final class PotterySherdCatalog {
    static final List<PotterySherdEntry> SHERDS = List.of(
            new PotterySherdEntry("brick", class_1802.field_8621),
            new PotterySherdEntry("angler", class_1802.field_43201),
            new PotterySherdEntry("archer", class_1802.field_43202),
            new PotterySherdEntry("arms_up", class_1802.field_43203),
            new PotterySherdEntry("blade", class_1802.field_43204),
            new PotterySherdEntry("brewer", class_1802.field_43205),
            new PotterySherdEntry("burn", class_1802.field_43206),
            new PotterySherdEntry("danger", class_1802.field_43207),
            new PotterySherdEntry("explorer", class_1802.field_43208),
            new PotterySherdEntry("flow", class_1802.field_49819),
            new PotterySherdEntry("friend", class_1802.field_43209),
            new PotterySherdEntry("guster", class_1802.field_49820),
            new PotterySherdEntry("heart", class_1802.field_43210),
            new PotterySherdEntry("heartbreak", class_1802.field_43211),
            new PotterySherdEntry("howl", class_1802.field_43212),
            new PotterySherdEntry("miner", class_1802.field_43213),
            new PotterySherdEntry("mourner", class_1802.field_43214),
            new PotterySherdEntry("plenty", class_1802.field_43215),
            new PotterySherdEntry("prize", class_1802.field_43216),
            new PotterySherdEntry("scrape", class_1802.field_49822),
            new PotterySherdEntry("sheaf", class_1802.field_43217),
            new PotterySherdEntry("shelter", class_1802.field_43218),
            new PotterySherdEntry("skull", class_1802.field_43219),
            new PotterySherdEntry("snort", class_1802.field_43220)
    );

    private PotterySherdCatalog() {
    }

    static PotterySherdEntry getByItem(class_1792 item) {
        for (PotterySherdEntry entry : SHERDS) {
            if (entry.item() == item) {
                return entry;
            }
        }
        return SHERDS.getFirst();
    }
}
