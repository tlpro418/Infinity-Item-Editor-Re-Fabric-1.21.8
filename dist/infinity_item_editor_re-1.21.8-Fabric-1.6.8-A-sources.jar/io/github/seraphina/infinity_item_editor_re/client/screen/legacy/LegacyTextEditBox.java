package io.github.seraphina.infinity_item_editor_re.client.screen.legacy;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_342;
import net.minecraft.class_3544;

public class LegacyTextEditBox extends class_342 {
    private int legacyMaxLength = 32;

    public LegacyTextEditBox(class_327 font, int x, int y, int width, int height, class_2561 message) {
        super(font, x, y, width, height, message);
    }

    @Override
    public void method_1880(int maxLength) {
        this.legacyMaxLength = maxLength;
        super.method_1880(maxLength);
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        if (!this.field_22763 || !method_20315()) {
            return false;
        }
        if (isLegacyAllowedCharacter(codePoint)) {
            method_1867(Character.toString(codePoint));
            return true;
        }
        return false;
    }

    @Override
    public void method_1867(String text) {
        if (!this.field_22763) {
            return;
        }

        String filtered = filterLegacyText(text);
        String value = method_1882();
        int[] range = getSelectionRange();
        int room = this.legacyMaxLength - value.length() + (range[1] - range[0]);
        if (room < filtered.length()) {
            filtered = filtered.substring(0, Math.max(0, room));
        }

        String next = value.substring(0, range[0]) + filtered + value.substring(range[1]);
        super.method_1852(next);
        int cursor = range[0] + filtered.length();
        method_1875(cursor);
        method_1884(cursor);
    }

    private int[] getSelectionRange() {
        String highlighted = method_1866();
        int cursor = method_1881();
        if (highlighted.isEmpty()) {
            return new int[]{cursor, cursor};
        }

        String value = method_1882();
        int length = highlighted.length();
        int start;
        int end;
        if (cursor >= length && value.substring(cursor - length, cursor).equals(highlighted)) {
            start = cursor - length;
            end = cursor;
        } else {
            start = cursor;
            end = Math.min(value.length(), cursor + length);
        }
        return new int[]{Math.min(start, end), Math.max(start, end)};
    }

    private static String filterLegacyText(String input) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char character = input.charAt(i);
            if (isLegacyAllowedCharacter(character)) {
                builder.append(character);
            }
        }
        return builder.toString();
    }

    private static boolean isLegacyAllowedCharacter(char character) {
        return class_3544.method_57175(character) || character == class_124.field_33292;
    }
}
