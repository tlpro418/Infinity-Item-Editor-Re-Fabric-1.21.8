package io.github.seraphina.infinity_item_editor_re.client.screen.modern;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3544;

public class ModernTextEditBox extends class_342 {
    private int modernMaxLength = 32;
    private float focusAmount;

    public ModernTextEditBox(class_327 font, int x, int y, int width, int height, class_2561 message) {
        super(font, x, y, width, height, message);
        method_1858(false);
        method_1868(ModernUi.TEXT_PRIMARY);
        method_1860(ModernUi.TEXT_MUTED);
    }

    @Override
    public void method_1880(int maxLength) {
        this.modernMaxLength = maxLength;
        super.method_1880(maxLength);
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        if (!this.field_22763 || !method_20315()) {
            return false;
        }
        if (isModernAllowedCharacter(codePoint)) {
            method_1867(Character.toString(codePoint));
            return true;
        }
        return false;
    }

    @Override
    public void method_1867(String text) {
        if (!this.field_22763) {
            return;
        }

        String filtered = filterModernText(text);
        String value = method_1882();
        int[] range = getSelectionRange();
        int room = this.modernMaxLength - value.length() + (range[1] - range[0]);
        if (room < filtered.length()) {
            filtered = filtered.substring(0, Math.max(0, room));
        }

        String next = value.substring(0, range[0]) + filtered + value.substring(range[1]);
        super.method_1852(next);
        int cursor = range[0] + filtered.length();
        method_1875(cursor);
        method_1884(cursor);
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!method_1885()) {
            return;
        }

        boolean highlighted = this.field_22763 && (method_25370() || method_25405(mouseX, mouseY));
        updateFocusAmount(partialTick, highlighted);
        ModernUi.fillToolInput(guiGraphics, method_46426() - 2, method_46427() + 1, method_46426() + method_25368() + 2,
                method_46427() + method_25364() - 1, highlighted, this.field_22763);
        if (this.focusAmount > 0.0F && this.field_22763) {
            int glow = ModernUi.alpha(0xFFB347, Math.round(32.0F * this.focusAmount));
            guiGraphics.method_25294(method_46426() + 2, method_46427() + method_25364() - 2, method_46426() + method_25368() - 2, method_46427() + method_25364() - 1, glow);
        }
        renderVanillaTextInsideFrame(guiGraphics, mouseX, mouseY, partialTick);
    }

    private void renderVanillaTextInsideFrame(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int originalX = method_46426();
        int originalY = method_46427();
        int originalWidth = method_25368();
        method_46421(originalX + 4);
        method_46419(originalY + (method_25364() - 8) / 2);
        method_25358(Math.max(1, originalWidth - 8));
        try {
            super.method_48579(guiGraphics, mouseX, mouseY, partialTick);
        } finally {
            method_46421(originalX);
            method_46419(originalY);
            method_25358(originalWidth);
        }
    }

    private void updateFocusAmount(float partialTick, boolean highlighted) {
        float target = highlighted ? 1.0F : 0.0F;
        float speed = 0.18F + Math.min(partialTick, 1.0F) * 0.12F;
        this.focusAmount += (target - this.focusAmount) * speed;
        if (Math.abs(this.focusAmount - target) < 0.01F) {
            this.focusAmount = target;
        }
    }

    private int[] getSelectionRange() {
        String highlighted = method_1866();
        int cursor = method_1881();
        if (highlighted.isEmpty()) {
            return new int[]{cursor, cursor};
        }

        String value = method_1882();
        int length = highlighted.length();
        int start;
        int end;
        if (cursor >= length && value.substring(cursor - length, cursor).equals(highlighted)) {
            start = cursor - length;
            end = cursor;
        } else {
            start = cursor;
            end = Math.min(value.length(), cursor + length);
        }
        return new int[]{Math.min(start, end), Math.max(start, end)};
    }

    private static String filterModernText(String input) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char character = input.charAt(i);
            if (isModernAllowedCharacter(character)) {
                builder.append(character);
            }
        }
        return builder.toString();
    }

    private static boolean isModernAllowedCharacter(char character) {
        return class_3544.method_57175(character) || character == class_124.field_33292;
    }
}
