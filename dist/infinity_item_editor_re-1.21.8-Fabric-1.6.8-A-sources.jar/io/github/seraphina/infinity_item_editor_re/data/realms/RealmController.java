package io.github.seraphina.infinity_item_editor_re.data.realms;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2520;
import net.minecraft.class_2561;

public class RealmController {
    public static final String VERSION = "0.2";

    private final File dataFile;
    private final class_2371<class_1799> stackList = class_2371.method_10211();

    public RealmController(File dataDir) {
        this.dataFile = new File(dataDir, "realm.nbt");
        read();
    }

    public void read() {
        stackList.clear();

        if (!dataFile.exists()) {
            return;
        }

        try {
            class_2487 root = readRootTag();
            if (root == null || !root.method_10545("realm")) {
                return;
            }

            class_2499 realm = root.method_68569("realm");
            for (class_2520 tag : realm) {
                if (tag instanceof class_2487 stackTag) {
                    class_1799 stack = ItemStackNbt.parse(stackTag);
                    if (!stack.method_7960()) {
                        stackList.add(stack);
                    }
                }
            }
        } catch (Exception exception) {
            ModSource.LOGGER.error("Failed to load infinity realm from {}", dataFile.getAbsolutePath(), exception);
        }
    }

    public void write() {
        try {
            File parent = dataFile.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                ModSource.LOGGER.warn("Failed to create realm data directory {}", parent.getAbsolutePath());
            }

            class_2487 root = new class_2487();
            class_2499 realm = new class_2499();
            root.method_10566("realm", realm);
            root.method_10582("realm_version", VERSION);

            for (class_1799 itemStack : stackList) {
                realm.add(ItemStackNbt.save(itemStack));
            }

            class_2507.method_30614(root, dataFile.toPath());
        } catch (Exception exception) {
            ModSource.LOGGER.error("Failed to save infinity realm to {}", dataFile.getAbsolutePath(), exception);
        }
    }

    private class_2487 readRootTag() throws IOException {
        try {
            return class_2507.method_30613(dataFile.toPath(), class_2505.method_53898());
        } catch (IOException compressedException) {
            try {
                return class_2507.method_10633(dataFile.toPath());
            } catch (IOException uncompressedException) {
                compressedException.addSuppressed(uncompressedException);
                throw compressedException;
            }
        }
    }

    public boolean addItemStack(class_1657 player, class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }

        class_1799 savedStack = stack.method_7972();
        for (class_1799 existingStack : stackList) {
            if (class_1799.method_7973(existingStack, savedStack)) {
                player.method_7353(class_2561.method_43470("Didn't add ")
                        .method_10852(savedStack.method_7964())
                        .method_10852(class_2561.method_43470(", as it seems to already exist in the Infinity Realm.")), false);
                return false;
            }
        }

        stackList.add(savedStack);
        write();
        player.method_7353(class_2561.method_43470("Added ")
                .method_10852(savedStack.method_7964())
                .method_10852(class_2561.method_43470(" to Infinity Realm.")), false);
        return true;
    }

    public boolean removeItemStack(class_1657 player, class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }

        for (class_1799 existingStack : stackList) {
            if (class_1799.method_7973(existingStack, stack)) {
                stackList.remove(existingStack);
                write();
                player.method_7353(class_2561.method_43470("Banished ")
                        .method_10852(stack.method_7964())
                        .method_10852(class_2561.method_43470(" from the Infinity Realm.")), false);
                return true;
            }
        }
        return false;
    }

    public List<class_1799> getStackList() {
        return Collections.unmodifiableList(stackList);
    }
}
