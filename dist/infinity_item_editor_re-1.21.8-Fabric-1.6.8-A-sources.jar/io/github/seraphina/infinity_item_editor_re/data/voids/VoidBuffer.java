package io.github.seraphina.infinity_item_editor_re.data.voids;

import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import net.minecraft.class_2744;

public class VoidBuffer {
    private static final int MAX_SIZE = 300;

    private final BlockingDeque<class_2744> queue = new LinkedBlockingDeque<>(MAX_SIZE);

    public class_2744 get() {
        try {
            return queue.take();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            return null;
        }
    }

    public void put(class_2744 packet) {
        queue.offer(packet);
    }
}
