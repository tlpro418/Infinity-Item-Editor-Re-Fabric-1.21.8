package io.github.seraphina.infinity_item_editor_re.data.voids;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import io.github.seraphina.infinity_item_editor_re.Config;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1826;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class VoidController {
    public static final String VERSION = "0.2";

    private final File dataFile;
    private final class_2371<VoidElement> elementList = class_2371.method_10211();

    public VoidController(class_1799 stack) {
        this(fileForStack(stack));
    }

    private VoidController(File dataFile) {
        this.dataFile = dataFile;
        read();
    }

    public void read() {
        elementList.clear();

        if (dataFile == null || !dataFile.exists()) {
            return;
        }

        try {
            class_2487 root = readRootTag();
            if (root == null) {
                return;
            }

            class_2499 elements;
            if (root.method_10545("elements")) {
                elements = root.method_68569("elements");
            } else if (root.method_10545("stacks")) {
                elements = root.method_68569("stacks");
            } else {
                return;
            }

            for (class_2520 tag : elements) {
                if (tag instanceof class_2487 compoundTag) {
                    VoidElement element = VoidElement.readFromTag(compoundTag);
                    if (!element.getStack().method_7960()) {
                        elementList.add(element);
                    }
                }
            }
        } catch (Exception exception) {
            ModSource.LOGGER.error("Failed to load void for {}", dataFile.getName(), exception);
        }
    }

    public void write() {
        if (dataFile == null) {
            return;
        }

        try {
            File parent = dataFile.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                ModSource.LOGGER.warn("Failed to create void data directory {}", parent.getAbsolutePath());
            }

            class_2487 root = new class_2487();
            class_2499 elements = new class_2499();
            root.method_10566("elements", elements);
            root.method_10582("void_version", VERSION);

            for (VoidElement voidElement : elementList) {
                elements.add(voidElement.writeToTag(new class_2487()));
            }

            class_2507.method_30614(root, dataFile.toPath());
        } catch (Exception exception) {
            ModSource.LOGGER.error("Failed to save void for {}", dataFile.getName(), exception);
        }
    }

    private class_2487 readRootTag() throws IOException {
        try {
            return class_2507.method_30613(dataFile.toPath(), class_2505.method_53898());
        } catch (IOException compressedException) {
            try {
                return class_2507.method_10633(dataFile.toPath());
            } catch (IOException uncompressedException) {
                compressedException.addSuppressed(uncompressedException);
                throw compressedException;
            }
        }
    }
    public void addItemStack(class_1657 player, class_1799 stack, String from) {
        if (stack == null || stack.method_7960() || !hasMeaningfulTag(stack)) {
            return;
        }

        class_1799 savedStack = stack.method_7972();
        savedStack.method_7939(1);
        if (savedStack.method_7963()) {
            savedStack.method_7974(0);
        }

        for (VoidElement element : elementList) {
            if (isSameStack(element.getStack(), savedStack)) {
                if (element.addUuid(from, true)) {
                    write();
                }
                return;
            }
        }

        if (Config.voidAddNotification && player != null) {
            player.method_7353(class_2561.method_43470("Added ")
                    .method_10852(savedStack.method_7964())
                    .method_10852(class_2561.method_43470(" to Infinity Void.")), false);
        }

        VoidElement element = new VoidElement(savedStack);
        element.addUuid(from, false);
        elementList.add(element);
        write();
    }

    public class_2371<VoidElement> getElementList() {
        return elementList;
    }

    public static synchronized void loadVoidToList(List<class_1799> list) {
        File voidDirectory = getVoidDirectory();
        if (voidDirectory == null || !voidDirectory.isDirectory()) {
            return;
        }

        File[] files = voidDirectory.listFiles((directory, name) -> name.endsWith(".nbt"));
        if (files == null || files.length == 0) {
            return;
        }

        Arrays.sort(files, Comparator.comparing(File::getName));
        for (File file : files) {
            VoidController controller = new VoidController(file);
            class_2371<VoidElement> elements = controller.getElementList();
            if (elements.isEmpty()) {
                continue;
            }

            if (Config.voidTabHideHeads && elements.get(0).getStack().method_31574(class_1802.field_8575)) {
                continue;
            }

            for (VoidElement element : elements) {
                class_1799 stack = element.getStack().method_7972();
                stack.method_7939(1);
                list.add(stack);
            }
        }
    }

    private static boolean hasMeaningfulTag(class_1799 stack) {
        class_2487 tag = ItemStackNbt.get(stack);
        if (tag == null || tag.method_33133()) {
            return false;
        }

        return !(stack.method_7909() instanceof class_1826 && tag.method_10546() == 1 && tag.method_10545("EntityTag"));
    }

    private static boolean isSameStack(class_1799 first, class_1799 second) {
        if (first == second) {
            return true;
        }

        if (first.method_7960()) {
            return second.method_7960();
        }

        if (second.method_7960() || !first.method_31574(second.method_7909())) {
            return false;
        }

        if ((first.method_7963() || second.method_7963()) && first.method_7919() != second.method_7919()) {
            return false;
        }

        class_2487 firstTag = ItemStackNbt.get(first);
        class_2487 secondTag = ItemStackNbt.get(second);
        boolean firstTagEmpty = firstTag == null || firstTag.method_33133();
        boolean secondTagEmpty = secondTag == null || secondTag.method_33133();

        if (firstTagEmpty || secondTagEmpty) {
            return firstTagEmpty == secondTagEmpty;
        }

        return firstTag.equals(secondTag);
    }

    private static File fileForStack(class_1799 stack) {
        File voidDirectory = getVoidDirectory();
        if (voidDirectory == null) {
            return null;
        }

        class_2960 itemName = CompatRegistries.ITEMS.getKey(stack.method_7909());
        String fileName = (itemName == null ? "unknown" : itemName.toString().replace(':', '.')) + ".nbt";
        return new File(voidDirectory, fileName);
    }

    private static File getVoidDirectory() {
        if (ModSource.dataDir == null) {
            return null;
        }

        File voidDirectory = new File(ModSource.dataDir, "void");
        if (!voidDirectory.exists() && !voidDirectory.mkdirs()) {
            ModSource.LOGGER.warn("Failed to create void data directory {}", voidDirectory.getAbsolutePath());
        }
        return voidDirectory;
    }
}
