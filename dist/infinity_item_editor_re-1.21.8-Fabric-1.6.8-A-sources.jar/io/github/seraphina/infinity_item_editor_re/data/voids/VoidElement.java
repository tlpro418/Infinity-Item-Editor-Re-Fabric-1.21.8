package io.github.seraphina.infinity_item_editor_re.data.voids;

import io.github.seraphina.infinity_item_editor_re.util.NbtCompat;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

public class VoidElement {
    private final class_1799 stack;
    private class_2499 uuids;

    public VoidElement(class_1799 stack) {
        this.stack = stack;
    }

    public class_1799 getStack() {
        return stack;
    }

    public static VoidElement readFromTag(class_2487 tag) {
        class_1799 readStack = ItemStackNbt.parse(tag);
        class_2499 ids = tag.method_68569("uuids");

        if (readStack.method_7960() && tag.method_10545("stack")) {
            readStack = ItemStackNbt.parse(tag.method_68568("stack"));
        }

        VoidElement element = new VoidElement(readStack);
        if (!ids.isEmpty()) {
            element.uuids = ids;
        }
        return element;
    }

    public class_2487 writeToTag(class_2487 tag) {
        tag.method_10566("stack", ItemStackNbt.save(stack));

        if (uuids != null && !uuids.isEmpty()) {
            tag.method_10566("uuids", uuids.method_10612());
        }

        return tag;
    }

    public boolean hasUuid(String id) {
        if (uuids == null) {
            return false;
        }

        for (class_2520 tag : uuids) {
            if (id.equals(NbtCompat.asString(tag))) {
                return true;
            }
        }

        return false;
    }

    public boolean addUuid(String id, boolean check) {
        if (id == null || id.isEmpty() || (check && hasUuid(id))) {
            return false;
        }

        if (uuids == null) {
            uuids = new class_2499();
        }

        uuids.add(class_2519.method_23256(id));
        return true;
    }
}
