package io.github.seraphina.infinity_item_editor_re.eventhandlers;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public final class ClientKeyMappings {
    private static final String CATEGORY = "key.categories." + ModSource.MODID;

    public static final class_304 OPEN_EDITOR = new class_304(
            "key." + ModSource.MODID + ".open_editor",
            GLFW.GLFW_KEY_U,
            CATEGORY
    );
    public static final class_304 COPY_TARGET = new class_304(
            "key." + ModSource.MODID + ".copy_target",
            GLFW.GLFW_KEY_V,
            CATEGORY
    );
    public static final class_304 SAVE_REALM = new class_304(
            "key." + ModSource.MODID + ".save_realm",
            GLFW.GLFW_KEY_G,
            CATEGORY
    );

    private ClientKeyMappings() {
    }

    public static void register() {
        KeyBindingHelper.registerKeyBinding(OPEN_EDITOR);
        KeyBindingHelper.registerKeyBinding(COPY_TARGET);
        KeyBindingHelper.registerKeyBinding(SAVE_REALM);
    }
}
