package io.github.seraphina.infinity_item_editor_re.init;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackCompat;

import io.github.seraphina.infinity_item_editor_re.util.ComponentCompat;

import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;

import io.github.seraphina.infinity_item_editor_re.Config;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.data.voids.VoidController;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1826;
import net.minecraft.class_1842;
import net.minecraft.class_1887;
import net.minecraft.class_1889;
import net.minecraft.class_1890;
import net.minecraft.class_2246;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_9283;

public final class CreativeTabRegistry {
    private static final class_9283.class_1782[] FIREWORK_SHAPES = {
            class_9283.class_1782.field_7976,
            class_9283.class_1782.field_7977,
            class_9283.class_1782.field_7973,
            class_9283.class_1782.field_7974,
            class_9283.class_1782.field_7970
    };

    public static class_1761 REALM;
    public static class_1761 UNAVAILABLE;
    public static class_1761 BANNERS;
    public static class_1761 SKULLS;
    public static class_1761 THIEF;
    public static class_1761 FIREWORKS;
    public static class_1761 VOID;

    private CreativeTabRegistry() {
    }

    public static void register() {
        REALM = registerTab("realm", new class_1799(class_2246.field_10443), CreativeTabRegistry::fillRealm);
        UNAVAILABLE = registerTab("unavailable", new class_1799(class_2246.field_10499), CreativeTabRegistry::fillUnavailable);
        BANNERS = registerTab("banners", new class_1799(class_1802.field_8586), CreativeTabRegistry::fillBanners);
        SKULLS = registerTab("skulls", new class_1799(class_1802.field_8575), CreativeTabRegistry::fillSkulls);
        THIEF = registerTab("thief", new class_1799(class_1802.field_8153), CreativeTabRegistry::fillThief);
        FIREWORKS = registerTab("fireworks", new class_1799(class_1802.field_8639), CreativeTabRegistry::fillFireworks);
        VOID = registerTab("void", new class_1799(class_2246.field_9997), CreativeTabRegistry::fillVoid);
    }

    private static class_1761 registerTab(String name, class_1799 icon, class_1761.class_7914 generator) {
        return class_2378.method_10230(class_7923.field_44687, class_2960.method_60655(ModSource.MODID, name),
                searchTab(name, () -> icon, generator));
    }

    private static final String[] MHF_HEADS = {
            "MHF_Alex", "MHF_Blaze", "MHF_CaveSpider", "MHF_Chicken", "MHF_Cow", "MHF_Creeper",
            "MHF_Enderman", "MHF_Ghast", "MHF_Golem", "MHF_Herobrine", "MHF_LavaSlime", "MHF_MushroomCow",
            "MHF_Ocelot", "MHF_Pig", "MHF_PigZombie", "MHF_Sheep", "MHF_Skeleton", "MHF_Slime",
            "MHF_Spider", "MHF_Squid", "MHF_Steve", "MHF_Villager", "MHF_Wolf", "MHF_WSkeleton",
            "MHF_Zombie", "MHF_Cactus", "MHF_Cake", "MHF_Chest", "MHF_CoconutB", "MHF_CoconutG",
            "MHF_Melon", "MHF_OakLog", "MHF_Present1", "MHF_Present2", "MHF_Pumpkin", "MHF_TNT",
            "MHF_TNT2", "MHF_ArrowUp", "MHF_ArrowDown", "MHF_ArrowLeft", "MHF_ArrowRight", "MHF_Exclamation",
            "MHF_Question"
    };


    private static class_1761 searchTab(String name, Supplier<class_1799> icon, class_1761.class_7914 generator) {
        return class_1761.method_47307(class_1761.class_7915.field_41049, 0)
                .method_47321(class_2561.method_43471("itemGroup." + ModSource.MODID + "." + name))
                .method_47320(icon)
                .method_47317(generator)
                .method_47324();
    }

    private static void fillRealm(class_1761.class_8128 parameters, class_1761.class_7704 output) {
        RealmController realmController = ModSource.getRealmController();
        List<class_1799> stacks = new ArrayList<>();

        if (realmController != null) {
            for (class_1799 stack : realmController.getStackList()) {
                addUnique(stacks, normalizedTabStack(stack));
            }
        }

        if (stacks.isEmpty()) {
            output.method_45421(class_2246.field_10443);
            return;
        }

        output.method_45423(stacks);
    }

    private static void fillUnavailable(class_1761.class_8128 parameters, class_1761.class_7704 output) {
        if (!Config.getIsUnavailableTabEnabled()) {
            return;
        }

        List<class_1799> stacks = new ArrayList<>();
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8077)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8866)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8799)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8468)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8220)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8238)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8615)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_16538)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8688)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8361)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_30904)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8849)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_47314)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8493)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8574)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8436)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8150)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8087)));
        addUnique(stacks, normalizedTabStack(new class_1799(class_1802.field_8598)));
        addUnavailableVariants(parameters, stacks);
        addUncategorizedRegistryItems(parameters, stacks);
        output.method_45423(stacks);
    }

    private static void fillBanners(class_1761.class_8128 parameters, class_1761.class_7704 output) {
        if (!Config.getIsBannerTabEnabled()) {
            return;
        }

        List<class_1799> banners = new ArrayList<>();
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8539)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8824)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8671)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8379)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8049)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8778)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8329)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8617)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8855)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8629)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8405)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8128)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8124)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8295)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8586)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8572)));
        addUnique(banners, normalizedTabStack(new class_1799(class_1802.field_8255)));
        for (class_1767 color : class_1767.values()) {
            addUnique(banners, normalizedTabStack(shield(color)));
        }
            io.github.seraphina.infinity_item_editor_re.client.ClientCreativeTabData.addBannerVariants(banners);
        output.method_45423(banners);
    }

    private static void fillSkulls(class_1761.class_8128 parameters, class_1761.class_7704 output) {
        if (!Config.getIsHeadTabEnabled()) {
            return;
        }

        List<class_1799> heads = new ArrayList<>();
            io.github.seraphina.infinity_item_editor_re.client.ClientCreativeTabData.addPlayerHeads(heads);
        for (String owner : MHF_HEADS) {
            addUnique(heads, createPlayerHead(owner));
        }
        output.method_45423(heads);
    }

    private static void fillThief(class_1761.class_8128 parameters, class_1761.class_7704 output) {
        if (!Config.getIsThiefTabEnabled()) {
            return;
        }

        List<class_1799> stacks = new ArrayList<>();
            io.github.seraphina.infinity_item_editor_re.client.ClientCreativeTabData.addThiefItems(stacks);
        if (stacks.isEmpty()) {
            output.method_45421(class_1802.field_8153);
            return;
        }

        output.method_45423(stacks);
    }

    private static void fillFireworks(class_1761.class_8128 parameters, class_1761.class_7704 output) {
        if (!Config.getIsFireworkTabEnabled()) {
            return;
        }

        List<class_1799> fireworks = new ArrayList<>();
        addUnique(fireworks, normalizedTabStack(new class_1799(class_1802.field_8639)));
        addUnique(fireworks, normalizedTabStack(new class_1799(class_1802.field_8450)));
        addUnique(fireworks, normalizedTabStack(new class_1799(class_1802.field_8054)));
        addUnique(fireworks, normalizedTabStack(fireworkStar(0, 0xE14141)));
        addUnique(fireworks, normalizedTabStack(fireworkStar(1, 0xF0F06B)));
        addUnique(fireworks, normalizedTabStack(fireworkStar(2, 0x4A80FF)));
        addUnique(fireworks, normalizedTabStack(fireworkRocket((byte) 1)));
        addUnique(fireworks, normalizedTabStack(fireworkRocket((byte) 2)));
        addUnique(fireworks, normalizedTabStack(fireworkRocket((byte) 3)));
            io.github.seraphina.infinity_item_editor_re.client.ClientCreativeTabData.addFireworkVariants(fireworks);
        output.method_45423(fireworks);
    }

    private static void fillVoid(class_1761.class_8128 parameters, class_1761.class_7704 output) {
        if (!Config.getIsVoidEnabled()) {
            return;
        }

        List<class_1799> loadedStacks = new ArrayList<>();
        VoidController.loadVoidToList(loadedStacks);
        List<class_1799> stacks = new ArrayList<>(loadedStacks.size());
        for (class_1799 stack : loadedStacks) {
            addUnique(stacks, normalizedTabStack(stack));
        }

        if (stacks.isEmpty()) {
            output.method_45421(class_1802.field_8410);
            return;
        }

        output.method_45423(stacks);
    }

    private static class_1799 createPlayerHead(String owner) {
        class_1799 stack = new class_1799(class_1802.field_8575);
        ItemStackNbt.getOrCreate(stack).method_10582("SkullOwner", owner);

        class_2487 display = ItemStackNbt.getOrCreateElement(stack, "display");
        class_2499 lore = new class_2499();
        lore.add(class_2519.method_23256(ComponentCompat.toJson(class_2561.method_43470("Marc's Head Format"))));
        display.method_10566("Lore", lore);
        return stack;
    }

    private static class_1799 fireworkStar(int type, int color) {
        class_1799 stack = new class_1799(class_1802.field_8450);
        class_2487 explosion = ItemStackNbt.getOrCreateElement(stack, "Explosion");
        explosion.method_10567("Type", (byte) getFireworkShape(type).method_7816());
        explosion.method_10539("Colors", new int[]{color});
        return stack;
    }

    private static class_9283.class_1782 getFireworkShape(int type) {
        if (type < 0 || type >= FIREWORK_SHAPES.length) {
            return class_9283.class_1782.field_7976;
        }
        return FIREWORK_SHAPES[type];
    }

    private static class_1799 fireworkRocket(byte flight) {
        class_1799 stack = new class_1799(class_1802.field_8639);
        ItemStackNbt.getOrCreateElement(stack, "Fireworks").method_10567("Flight", flight);
        return stack;
    }

    private static class_1799 shield(class_1767 color) {
        class_1799 stack = new class_1799(class_1802.field_8255);
        ItemStackNbt.getOrCreateElement(stack, "BlockEntityTag").method_10569("Base", color.method_7789());
        return stack;
    }

    private static void addUnavailableVariants(class_1761.class_8128 parameters, List<class_1799> stacks) {
        addPotionVariants(parameters, stacks, class_1802.field_8574);
        addPotionVariants(parameters, stacks, class_1802.field_8436);
        addPotionVariants(parameters, stacks, class_1802.field_8150);
        addPotionVariants(parameters, stacks, class_1802.field_8087);
        addSpawnEggVariants(parameters, stacks);
        addEnchantedBookVariants(stacks);
    }

    private static void addPotionVariants(class_1761.class_8128 parameters, List<class_1799> stacks, class_1792 item) {
        if (!item.method_45382(parameters.comp_1251())) {
            return;
        }

        class_7923.field_41179.method_10220()
                .forEach(potion -> addUnique(stacks, potionStack(item, potion)));
    }

    private static class_1799 potionStack(class_1792 item, class_1842 potion) {
        class_1799 stack = new class_1799(item);
        PotionCompat.setPotion(stack, potion);
        return normalizedTabStack(stack);
    }

    private static void addSpawnEggVariants(class_1761.class_8128 parameters, List<class_1799> stacks) {
        class_7923.field_41178.method_10220()
                .filter(item -> item instanceof class_1826)
                .filter(item -> item.method_45382(parameters.comp_1251()))
                .forEach(item -> addUnique(stacks, normalizedTabStack(new class_1799(item))));
    }

    private static void addEnchantedBookVariants(List<class_1799> stacks) {
        CompatRegistries.ENCHANTMENTS.getHolders()
                .forEach(enchantmentHolder -> {
                    class_1887 enchantment = enchantmentHolder.comp_349();
                    for (int level = enchantment.method_8187(); level <= enchantment.method_8183(); level++) {
                        addUnique(stacks, normalizedTabStack(class_1890.method_61711(new class_1889(enchantmentHolder, level))));
                    }
                });
    }

    private static void addUncategorizedRegistryItems(class_1761.class_8128 parameters, List<class_1799> stacks) {
        Set<class_1792> categorizedItems = new HashSet<>();
        for (class_1761 tab : class_7706.method_47341()) {
            var tabKey = class_7923.field_44687.method_29113(tab);
            if (tabKey.isPresent() && ModSource.MODID.equals(tabKey.get().method_29177().method_12836())) {
                continue;
            }

            for (class_1799 stack : tab.method_47313()) {
                categorizedItems.add(stack.method_7909());
            }
            for (class_1799 stack : tab.method_45414()) {
                categorizedItems.add(stack.method_7909());
            }
        }

        class_7923.field_41178.method_10220()
                .filter(item -> item != class_1802.field_8162)
                .filter(item -> item.method_45382(parameters.comp_1251()))
                .filter(item -> !categorizedItems.contains(item))
                .forEach(item -> addUnique(stacks, normalizedTabStack(new class_1799(item))));
    }

    private static void acceptStack(class_1761.class_7704 output, class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return;
        }
        output.method_45420(normalizedTabStack(stack));
    }

    private static class_1799 normalizedTabStack(class_1799 stack) {
        class_1799 copy = stack.method_7972();
        copy.method_7939(1);
        return copy;
    }

    private static void addUnique(List<class_1799> stacks, class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return;
        }

        for (class_1799 existingStack : stacks) {
            if (ItemStackCompat.isSameItemSameTags(existingStack, stack)) {
                return;
            }
        }

        stacks.add(stack);
    }
}