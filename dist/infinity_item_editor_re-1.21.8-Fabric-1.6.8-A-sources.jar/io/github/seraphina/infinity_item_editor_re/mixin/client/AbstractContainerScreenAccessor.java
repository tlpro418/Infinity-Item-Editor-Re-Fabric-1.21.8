package io.github.seraphina.infinity_item_editor_re.mixin.client;

import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_465.class)
public interface AbstractContainerScreenAccessor {
    @Accessor("hoveredSlot")
    class_1735 infinityItemEditorRe$getHoveredSlot();
}
