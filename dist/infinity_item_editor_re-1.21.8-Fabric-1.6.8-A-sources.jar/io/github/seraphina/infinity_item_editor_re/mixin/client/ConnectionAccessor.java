package io.github.seraphina.infinity_item_editor_re.mixin.client;

import io.netty.channel.Channel;
import net.minecraft.class_2535;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2535.class)
public interface ConnectionAccessor {
    @Accessor("channel")
    Channel infinityItemEditorRe$getChannel();
}
