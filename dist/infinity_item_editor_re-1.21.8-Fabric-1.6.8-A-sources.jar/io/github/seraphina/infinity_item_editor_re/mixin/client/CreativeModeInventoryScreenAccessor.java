package io.github.seraphina.infinity_item_editor_re.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.Collection;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_481;

@Mixin(class_481.class)
public interface CreativeModeInventoryScreenAccessor {
    @Accessor("selectedTab")
    static class_1761 infinityItemEditorRe$getSelectedTab() {
        throw new AssertionError();
    }

    @Invoker("refreshCurrentTabContents")
    void infinityItemEditorRe$refreshCurrentTabContents(Collection<class_1799> stacks);

    @Invoker("selectTab")
    void infinityItemEditorRe$selectTab(class_1761 tab);
}
