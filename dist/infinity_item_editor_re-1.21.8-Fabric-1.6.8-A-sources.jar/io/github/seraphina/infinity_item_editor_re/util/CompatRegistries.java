package io.github.seraphina.infinity_item_editor_re.util;

import java.util.Collection;
import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8054;
import net.minecraft.class_8056;

public final class CompatRegistries {
    public static final RegistryAdapter<class_1792> ITEMS = new RegistryAdapter<>(class_7923.field_41178);
    public static final RegistryAdapter<class_2248> BLOCKS = new RegistryAdapter<>(class_7923.field_41175);
    public static final RegistryAdapter<class_1299<?>> ENTITY_TYPES = new RegistryAdapter<>(class_7923.field_41177);
    public static final RegistryAdapter<class_1291> MOB_EFFECTS = new RegistryAdapter<>(class_7923.field_41174);
    public static final RegistryAdapter<class_1320> ATTRIBUTES = new RegistryAdapter<>(class_7923.field_41190);
    public static final DynamicRegistryAdapter<class_1887> ENCHANTMENTS = new DynamicRegistryAdapter<>(class_7924.field_41265);
    public static final DynamicRegistryAdapter<class_8054> TRIM_MATERIALS = new DynamicRegistryAdapter<>(class_7924.field_42083);
    public static final DynamicRegistryAdapter<class_8056> TRIM_PATTERNS = new DynamicRegistryAdapter<>(class_7924.field_42082);

    private CompatRegistries() {
    }

    public static class RegistryAdapter<T> {
        private final class_2378<T> registry;

        private RegistryAdapter(class_2378<T> registry) {
            this.registry = registry;
        }

        public class_2960 getKey(T value) {
            return this.registry.method_10221(value);
        }

        public T getValue(class_2960 id) {
            return this.registry.method_63535(id);
        }

        public class_6880<T> getHolder(T value) {
            return value == null ? null : this.registry.method_47983(value);
        }

        public class_6880<T> getHolder(class_2960 id) {
            return this.registry.method_10223(id).orElse(null);
        }

        public Collection<class_6880.class_6883<T>> getHolders() {
            return this.registry.method_42017().toList();
        }

        public Collection<T> getValues() {
            return this.registry.method_10220().toList();
        }
    }

    public static final class DynamicRegistryAdapter<T> {
        private final class_5321<class_2378<T>> key;

        private DynamicRegistryAdapter(class_5321<class_2378<T>> key) {
            this.key = key;
        }

        public class_2960 getKey(T value) {
            class_2378<T> registry = registry();
            return registry == null ? null : registry.method_10221(value);
        }

        public T getValue(class_2960 id) {
            class_2378<T> registry = registry();
            return registry == null ? null : registry.method_63535(id);
        }

        public class_6880<T> getHolder(T value) {
            class_2378<T> registry = registry();
            return registry == null || value == null ? null : registry.method_47983(value);
        }

        public class_6880<T> getHolder(class_2960 id) {
            class_2378<T> registry = registry();
            return registry == null ? null : registry.method_10223(id).orElse(null);
        }

        public Collection<class_6880.class_6883<T>> getHolders() {
            class_2378<T> registry = registry();
            return registry == null ? List.of() : registry.method_42017().toList();
        }

        public Collection<T> getValues() {
            class_2378<T> registry = registry();
            return registry == null ? List.of() : registry.method_10220().toList();
        }

        private class_2378<T> registry() {
            class_5455 access = ItemStackNbt.registryAccess();
            return access.method_46759(this.key).orElse(null);
        }
    }
}
