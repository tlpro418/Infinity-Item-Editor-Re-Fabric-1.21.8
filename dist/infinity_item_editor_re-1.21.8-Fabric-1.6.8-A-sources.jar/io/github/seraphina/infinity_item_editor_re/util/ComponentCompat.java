package io.github.seraphina.infinity_item_editor_re.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_2561;
import net.minecraft.class_8824;

public final class ComponentCompat {
    private ComponentCompat() {
    }

    public static String toJson(class_2561 component) {
        return class_8824.field_46597
                .encodeStart(JsonOps.INSTANCE, component)
                .getOrThrow()
                .toString();
    }

    public static class_2561 fromJson(String json) {
        return fromJson(JsonParser.parseString(json));
    }

    public static class_2561 fromJson(JsonElement json) {
        return class_8824.field_46597
                .parse(JsonOps.INSTANCE, json)
                .result()
                .orElse(class_2561.method_43473());
    }

    public static class_2561 fromJsonLenient(String json) {
        return fromJson(json);
    }
}
