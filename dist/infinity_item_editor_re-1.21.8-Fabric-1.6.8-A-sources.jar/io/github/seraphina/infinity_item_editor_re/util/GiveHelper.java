package io.github.seraphina.infinity_item_editor_re.util;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;
import net.minecraft.class_1799;
import net.minecraft.class_2290;
import net.minecraft.class_2291;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_7225;

public final class GiveHelper {
    private GiveHelper() {
    }

    public static String getStringFromItemStack(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return "";
        }

        class_2960 itemName = CompatRegistries.ITEMS.getKey(stack.method_7909());
        StringBuilder command = new StringBuilder("/give @p ");
        command.append(itemName == null ? "minecraft:air" : itemName);

        class_2487 tag = ItemStackNbt.get(stack);
        if (tag != null && !tag.method_33133()) {
            command.append(tag);
        }

        if (stack.method_7947() != 1) {
            command.append(' ').append(stack.method_7947());
        }

        return command.toString();
    }

    public static class_1799 getItemStackFromString(String command, class_7225.class_7874 lookupProvider) {
        if (command == null || command.isBlank() || lookupProvider == null) {
            return class_1799.field_8037;
        }

        try {
            String itemArgument = stripGiveCommand(command.trim());
            if (itemArgument.isBlank()) {
                return class_1799.field_8037;
            }

            StringReader reader = new StringReader(itemArgument);
            class_2291.class_7215 itemResult = new class_2291(lookupProvider).method_9789(reader);
            int count = 1;
            reader.skipWhitespace();
            if (reader.canRead()) {
                count = reader.readInt();
            }
            if (count <= 0) {
                return class_1799.field_8037;
            }

            return new class_2290(itemResult.comp_628(), itemResult.comp_2439()).method_9781(count, false);
        } catch (CommandSyntaxException exception) {
            return class_1799.field_8037;
        }
    }

    private static String stripGiveCommand(String command) throws CommandSyntaxException {
        StringReader reader = new StringReader(command);
        reader.skipWhitespace();
        String literal = reader.readUnquotedString();
        if (!"give".equals(literal) && !"/give".equals(literal)) {
            return command;
        }

        reader.skipWhitespace();
        if (!reader.canRead()) {
            return "";
        }
        reader.readUnquotedString();
        reader.skipWhitespace();
        return reader.canRead() ? command.substring(reader.getCursor()) : "";
    }
}
