package io.github.seraphina.infinity_item_editor_re.util;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_9334;

public final class ItemStackCompat {
    private ItemStackCompat() {
    }

    public static boolean isSameItemSameTags(class_1799 first, class_1799 second) {
        return class_1799.method_31577(first, second);
    }

    public static boolean hasCustomHoverName(class_1799 stack) {
        return stack.method_57826(class_9334.field_49631);
    }

    public static void setHoverName(class_1799 stack, class_2561 name) {
        stack.method_57379(class_9334.field_49631, name);
    }

    public static void resetHoverName(class_1799 stack) {
        stack.method_57381(class_9334.field_49631);
    }

    public static List<class_2561> getTooltipLines(class_1799 stack, class_1657 player, class_1836 flag) {
        class_1792.class_9635 context = player == null || player.method_37908() == null
                ? class_1792.class_9635.method_59530(ItemStackNbt.provider())
                : class_1792.class_9635.method_59528(player.method_37908());
        return stack.method_7950(context, player, flag);
    }
}
