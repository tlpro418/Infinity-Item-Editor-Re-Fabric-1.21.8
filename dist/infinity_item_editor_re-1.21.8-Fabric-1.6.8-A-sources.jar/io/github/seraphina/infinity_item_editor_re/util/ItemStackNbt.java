package io.github.seraphina.infinity_item_editor_re.util;
import io.github.seraphina.infinity_item_editor_re.util.NbtCompat;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1291;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2494;
import net.minecraft.class_2497;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2514;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8824;
import net.minecraft.class_9279;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

public final class ItemStackNbt {
    private static final Set<String> FULL_STACK_KEYS = Set.of("id", "item", "Item", "count", "Count", "components", "tag", "nbt");
    private static final Map<String, String> BANNER_HASH_TO_PATTERN = Map.ofEntries(
            Map.entry("bl", "square_bottom_left"),
            Map.entry("br", "square_bottom_right"),
            Map.entry("tl", "square_top_left"),
            Map.entry("tr", "square_top_right"),
            Map.entry("bs", "stripe_bottom"),
            Map.entry("ts", "stripe_top"),
            Map.entry("ls", "stripe_left"),
            Map.entry("rs", "stripe_right"),
            Map.entry("cs", "stripe_center"),
            Map.entry("ms", "stripe_middle"),
            Map.entry("drs", "stripe_downright"),
            Map.entry("dls", "stripe_downleft"),
            Map.entry("ss", "small_stripes"),
            Map.entry("cr", "cross"),
            Map.entry("sc", "straight_cross"),
            Map.entry("bt", "triangle_bottom"),
            Map.entry("tt", "triangle_top"),
            Map.entry("bts", "triangles_bottom"),
            Map.entry("tts", "triangles_top"),
            Map.entry("ld", "diagonal_left"),
            Map.entry("rd", "diagonal_up_right"),
            Map.entry("lud", "diagonal_up_left"),
            Map.entry("rud", "diagonal_right"),
            Map.entry("mc", "circle"),
            Map.entry("mr", "rhombus"),
            Map.entry("vh", "half_vertical"),
            Map.entry("hh", "half_horizontal"),
            Map.entry("vhr", "half_vertical_right"),
            Map.entry("hhb", "half_horizontal_bottom"),
            Map.entry("bo", "border"),
            Map.entry("cbo", "curly_border"),
            Map.entry("gra", "gradient"),
            Map.entry("gru", "gradient_up"),
            Map.entry("bri", "bricks"),
            Map.entry("glb", "globe"),
            Map.entry("cre", "creeper"),
            Map.entry("sku", "skull"),
            Map.entry("flo", "flower"),
            Map.entry("moj", "mojang"),
            Map.entry("pig", "piglin")
    );
    private static final Map<String, String> BANNER_PATTERN_TO_HASH = invert(BANNER_HASH_TO_PATTERN);
    private static final Map<String, String> BLOCK_ENTITY_BY_ITEM = Map.ofEntries(
            Map.entry("barrel", "barrel"),
            Map.entry("beacon", "beacon"),
            Map.entry("beehive", "beehive"),
            Map.entry("bee_nest", "beehive"),
            Map.entry("blast_furnace", "blast_furnace"),
            Map.entry("brewing_stand", "brewing_stand"),
            Map.entry("campfire", "campfire"),
            Map.entry("soul_campfire", "campfire"),
            Map.entry("chest", "chest"),
            Map.entry("trapped_chest", "chest"),
            Map.entry("command_block", "command_block"),
            Map.entry("chain_command_block", "command_block"),
            Map.entry("repeating_command_block", "command_block"),
            Map.entry("comparator", "comparator"),
            Map.entry("conduit", "conduit"),
            Map.entry("crafter", "crafter"),
            Map.entry("decorated_pot", "decorated_pot"),
            Map.entry("dispenser", "dispenser"),
            Map.entry("dropper", "dropper"),
            Map.entry("furnace", "furnace"),
            Map.entry("hopper", "hopper"),
            Map.entry("jigsaw", "jigsaw"),
            Map.entry("jukebox", "jukebox"),
            Map.entry("lectern", "lectern"),
            Map.entry("smoker", "smoker"),
            Map.entry("spawner", "mob_spawner"),
            Map.entry("structure_block", "structure_block"),
            Map.entry("suspicious_gravel", "brushable_block"),
            Map.entry("suspicious_sand", "brushable_block"),
            Map.entry("trial_spawner", "trial_spawner"),
            Map.entry("vault", "vault")
    );

    private ItemStackNbt() {
    }

    public static class_2487 get(class_1799 stack) {
        class_2487 tag = buildLegacyTag(stack);
        return tag == null || tag.method_33133() ? null : syncedRoot(stack, tag);
    }

    public static class_2487 getOrCreate(class_1799 stack) {
        class_2487 tag = buildLegacyTag(stack);
        return syncedRoot(stack, tag == null ? new class_2487() : tag);
    }

    public static class_2487 getElement(class_1799 stack, String key) {
        class_2487 tag = get(stack);
        if (tag == null || !tag.method_10545(key)) {
            return null;
        }
        return tag.method_68568(key);
    }

    public static class_2487 getOrCreateElement(class_1799 stack, String key) {
        class_2487 tag = getOrCreate(stack);
        if (!tag.method_10545(key)) {
            tag.method_10566(key, new class_2487());
        }
        return tag.method_68568(key);
    }

    public static void set(class_1799 stack, class_2487 tag) {
        applyLegacyTag(stack, tag == null ? new class_2487() : tag);
    }

    public static class_2487 save(class_1799 stack) {
        class_2520 saved = class_1799.field_49266
                .encodeStart(provider().method_57093(class_2509.field_11560), stack)
                .getOrThrow();
        return saved instanceof class_2487 compoundTag ? compoundTag : new class_2487();
    }

    private static class_1799 parseOptionalStack(class_2487 tag) {
        return parse(provider(), tag);
    }

    public static class_1799 parse(class_7225.class_7874 provider, class_2487 tag) {
        var result = class_1799.field_49266.parse(provider.method_57093(class_2509.field_11560), tag);
        if (result.error().isPresent() && Boolean.getBoolean("infinity_item_editor_re.debug")) {
            System.err.println("[infinity_item_editor_re] stack parse failed: " + result.error().get().message() + " input=" + tag);
        }
        return result.result().orElse(class_1799.field_8037);
    }

    public static class_1799 parse(class_2487 tag) {
        class_1799 parsed = parseOptionalStack(normalizeStackTag(tag));
        if (!parsed.method_7960() || !isLegacyStackTag(tag)) {
            return parsed;
        }

        class_2960 id = class_2960.method_12829(tag.method_68564("id", ""));
        class_1792 item = id == null ? class_1802.field_8162 : class_7923.field_41178.method_63535(id);
        if (item == class_1802.field_8162) {
            return class_1799.field_8037;
        }

        int count = tag.method_10545("Count") ? tag.method_68562("Count", (byte) 0) : 1;
        class_1799 stack = new class_1799(item, Math.max(1, count));
        if (tag.method_10545("tag")) {
            set(stack, tag.method_68568("tag").method_10553());
        }
        return stack;
    }

    public static class_1799 parseEditorNbt(class_1799 current, class_2487 tag) {
        if (isFullStackTag(tag)) {
            class_1799 parsed = parse(tag);
            if (!parsed.method_7960() || "minecraft:air".equals(tag.method_68564("id", ""))) {
                return parsed;
            }
        }

        class_1799 edited = current.method_7972();
        set(edited, tag);
        return edited;
    }

    public static class_7225.class_7874 provider() {
        try {
            class_310 minecraft = class_310.method_1551();
            if (minecraft.field_1687 != null) {
                return minecraft.field_1687.method_30349();
            }
        } catch (RuntimeException | LinkageError ignored) {
        }

        return class_5455.method_40302(class_7923.field_41167);
    }

    public static class_5455 registryAccess() {
        class_7225.class_7874 provider = provider();
        return provider instanceof class_5455 registryAccess ? registryAccess : class_5455.field_40585;
    }

    private static class_2487 syncedRoot(class_1799 stack, class_2487 tag) {
        final class_2487[] holder = new class_2487[1];
        holder[0] = syncedCompound(tag, () -> applyLegacyTag(stack, holder[0]));
        return holder[0];
    }

    private static class_2487 buildLegacyTag(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return null;
        }

        class_2487 saved = save(stack);
        class_2487 components = saved.method_68568("components");
        class_2487 tag = new class_2487();
        int hideFlags = 0;

        if (components.method_10545("minecraft:custom_data")) {
            tag.method_10543(components.method_68568("minecraft:custom_data").method_10553());
        }

        copyComponent(components, "minecraft:damage", tag, "Damage");
        copyComponent(components, "minecraft:repair_cost", tag, "RepairCost");
        copyComponent(components, "minecraft:custom_model_data", tag, "CustomModelData");
        copyComponent(components, "minecraft:block_state", tag, "BlockStateTag");
        copyComponent(components, "minecraft:entity_data", tag, "EntityTag");
        copyComponent(components, "minecraft:trim", tag, "Trim");

        hideFlags = readComponentDisplay(components, tag, hideFlags);
        hideFlags = readComponentEnchantments(components, tag, hideFlags);
        hideFlags = readComponentUnbreakable(components, tag, hideFlags);
        hideFlags = readComponentAttributes(components, tag, hideFlags);
        hideFlags = readComponentAdventure(components, tag, hideFlags);
        readComponentPotion(components, tag);
        readComponentBooks(components, tag);
        readComponentFireworks(components, tag);
        readComponentProfile(components, tag);
        readComponentBlockEntity(stack, components, tag);

        if (isTooltipComponentHidden(components, "minecraft:trim")) {
            hideFlags |= 128;
        }
        if (isTooltipComponentHidden(components, "minecraft:potion_contents")) {
            hideFlags |= 32;
        }
        if (hideFlags != 0) {
            tag.method_10569("HideFlags", hideFlags);
        }

        return tag;
    }

    private static void applyLegacyTag(class_1799 stack, class_2487 tag) {
        if (stack == null || stack.method_7960()) {
            return;
        }

        if (tag == null || tag.method_33133()) {
            applyLegacyComponentsFrom(stack, new class_1799(stack.method_7909(), stack.method_7947()));
            return;
        }

        class_2487 stackTag = stackTagFromLegacy(stack, tag);
        class_1799 parsed = parseOptionalStack(stackTag);
        if (parsed.method_7960() && !stack.method_31574(class_1802.field_8162)) {
            applyParseableComponents(stack, stackTag);
            class_9279 existing = stack.method_58694(class_9334.field_49628);
            class_2487 merged = existing == null ? new class_2487() : existing.method_57461();
            merged.method_10543(tag.method_10553());
            if (!merged.method_33133()) {
                stack.method_57379(class_9334.field_49628, class_9279.method_57456(merged));
            }
            return;
        }

        applyLegacyComponentsFrom(stack, parsed);
    }

    private static void applyParseableComponents(class_1799 stack, class_2487 stackTag) {
        class_2520 componentsTag = stackTag.method_10580("components");
        if (!(componentsTag instanceof class_2487 components) || components.method_33133()) {
            return;
        }

        class_2487 good = new class_2487();
        for (String key : components.method_10541()) {
            class_2487 single = new class_2487();
            single.method_10582("id", stackTag.method_68564("id", "minecraft:air"));
            single.method_10569("count", Math.max(1, stackTag.method_68083("count", 1)));
            class_2487 singleComponents = new class_2487();
            singleComponents.method_10566(key, components.method_10580(key));
            single.method_10566("components", singleComponents);
            if (!parseOptionalStack(single).method_7960()) {
                good.method_10566(key, components.method_10580(key));
            }
        }
        if (good.method_33133()) {
            return;
        }

        class_2487 goodStack = new class_2487();
        goodStack.method_10582("id", stackTag.method_68564("id", "minecraft:air"));
        goodStack.method_10569("count", Math.max(1, stackTag.method_68083("count", 1)));
        goodStack.method_10566("components", good);
        class_1799 parsed = parseOptionalStack(goodStack);
        if (!parsed.method_7960()) {
            applyLegacyComponentsFrom(stack, parsed);
        }
    }

    private static void applyLegacyComponentsFrom(class_1799 stack, class_1799 source) {
        copyDataComponent(source, stack, class_9334.field_49628);
        copyDataComponent(source, stack, class_9334.field_49629);
        copyDataComponent(source, stack, class_9334.field_49639);
        copyDataComponent(source, stack, class_9334.field_49637);
        copyDataComponent(source, stack, class_9334.field_49609);
        copyDataComponent(source, stack, class_9334.field_49611);
        copyDataComponent(source, stack, class_9334.field_49630);
        copyDataComponent(source, stack, class_9334.field_49633);
        copyDataComponent(source, stack, class_9334.field_49643);
        copyDataComponent(source, stack, class_9334.field_49641);
        copyDataComponent(source, stack, class_9334.field_49631);
        copyDataComponent(source, stack, class_9334.field_50239);
        copyDataComponent(source, stack, class_9334.field_49632);
        copyDataComponent(source, stack, class_9334.field_49644);
        copyDataComponent(source, stack, class_9334.field_49645);
        copyDataComponent(source, stack, class_9334.field_49635);
        copyDataComponent(source, stack, class_9334.field_49634);
        copyDataComponent(source, stack, class_9334.field_49636);
        copyDataComponent(source, stack, class_9334.field_49607);
        copyDataComponent(source, stack, class_9334.field_56400);
        copyDataComponent(source, stack, class_9334.field_49649);
        copyDataComponent(source, stack, class_9334.field_49650);
        copyDataComponent(source, stack, class_9334.field_49646);
        copyDataComponent(source, stack, class_9334.field_49647);
        copyDataComponent(source, stack, class_9334.field_49651);
        copyDataComponent(source, stack, class_9334.field_49653);
        copyDataComponent(source, stack, class_9334.field_49606);
        copyDataComponent(source, stack, class_9334.field_49652);
        copyDataComponent(source, stack, class_9334.field_49608);
        copyDataComponent(source, stack, class_9334.field_49610);
        copyDataComponent(source, stack, class_9334.field_49612);
        copyDataComponent(source, stack, class_9334.field_49613);
        copyDataComponent(source, stack, class_9334.field_49614);
        copyDataComponent(source, stack, class_9334.field_49616);
        copyDataComponent(source, stack, class_9334.field_49615);
        copyDataComponent(source, stack, class_9334.field_49617);
        copyDataComponent(source, stack, class_9334.field_49618);
        copyDataComponent(source, stack, class_9334.field_49619);
        copyDataComponent(source, stack, class_9334.field_49620);
        copyDataComponent(source, stack, class_9334.field_49622);
        copyDataComponent(source, stack, class_9334.field_49624);
        copyDataComponent(source, stack, class_9334.field_49625);
        copyDataComponent(source, stack, class_9334.field_49626);
        copyDataComponent(source, stack, class_9334.field_49621);
    }

    private static <T> void copyDataComponent(class_1799 source, class_1799 target, class_9331<T> component) {
        target.method_57379(component, source.method_58694(component));
    }

    private static class_2487 stackTagFromLegacy(class_1799 stack, class_2487 legacyTag) {
        class_2960 itemId = class_7923.field_41178.method_10221(stack.method_7909());
        return stackTagFromLegacy(itemId == null ? "minecraft:air" : itemId.toString(), Math.max(1, stack.method_7947()), legacyTag);
    }

    private static class_2487 stackTagFromLegacy(String itemId, int count, class_2487 legacyTag) {
        class_2487 stackTag = new class_2487();
        stackTag.method_10582("id", itemId);
        stackTag.method_10569("count", Math.max(1, count));

        class_2487 customData = legacyTag.method_10553();
        class_2487 components = new class_2487();
        int hideFlags = removeInt(customData, "HideFlags");

        moveComponent(customData, "Damage", components, "minecraft:damage");
        moveComponent(customData, "RepairCost", components, "minecraft:repair_cost");
        writeCustomModelData(customData, components);
        moveComponent(customData, "BlockStateTag", components, "minecraft:block_state");
        writeEntityDataComponent(itemId, customData, components);
        writeTrimComponent(customData, components, hideFlags);

        writeDisplayComponents(customData, components, hideFlags);
        writeEnchantmentsComponent(customData, components, "Enchantments", "minecraft:enchantments", (hideFlags & 1) != 0);
        writeEnchantmentsComponent(customData, components, "StoredEnchantments", "minecraft:stored_enchantments", (hideFlags & 32) != 0);
        writeUnbreakableComponent(customData, components, hideFlags);
        writeAttributeComponents(customData, components, hideFlags);
        writeAdventureComponents(customData, components, hideFlags);
        writePotionComponents(customData, components);
        writeBookComponents(customData, components);
        writeFireworkComponents(customData, components);
        writeProfileComponent(customData, components);
        writeBlockEntityComponents(itemId, customData, components);

        if ((hideFlags & 32) != 0) {
            hideTooltipComponent(components, "minecraft:potion_contents");
        }
        if (!customData.method_33133()) {
            components.method_10566("minecraft:custom_data", customData);
        }
        if (!components.method_33133()) {
            stackTag.method_10566("components", components);
        }
        return stackTag;
    }

    private static class_2487 normalizeStackTag(class_2487 tag) {
        if (!isFullStackTag(tag)) {
            return tag;
        }

        class_2487 normalized = tag.method_10553();
        if (!normalized.method_10545("id")) {
            if (normalized.method_10545("item")) {
                normalized.method_10582("id", normalized.method_68564("item", ""));
            } else if (normalized.method_10545("Item")) {
                normalized.method_10582("id", normalized.method_68564("Item", ""));
            }
        }
        if (!normalized.method_10545("count") && normalized.method_10545("Count")) {
            normalized.method_10569("count", normalized.method_68562("Count", (byte) 0) & 255);
        }
        if (!normalized.method_10545("count")) {
            normalized.method_10569("count", 1);
        }
        if (!normalized.method_10545("components")) {
            class_2487 legacy = normalized.method_10545("tag")
                    ? normalized.method_68568("tag")
                    : normalized.method_10545("nbt") ? normalized.method_68568("nbt") : new class_2487();
            normalized = stackTagFromLegacy(normalized.method_68564("id", ""), normalized.method_68083("count", 0), legacy);
        }
        return normalized;
    }

    private static boolean isFullStackTag(class_2487 tag) {
        for (String key : tag.method_10541()) {
            if (FULL_STACK_KEYS.contains(key)) {
                return tag.method_10545("id") || tag.method_10545("item") || tag.method_10545("Item");
            }
        }
        return false;
    }

    private static boolean isLegacyStackTag(class_2487 tag) {
        return tag.method_10545("id") && (tag.method_10545("Count") || tag.method_10545("tag"));
    }


    private static void hideTooltipComponent(class_2487 components, String hiddenComponent) {
        class_2487 tooltipDisplay = components.method_10545("minecraft:tooltip_display")
                ? components.method_68568("minecraft:tooltip_display").method_10553()
                : new class_2487();
        class_2499 hiddenComponents = tooltipDisplay.method_10545("hidden_components")
                ? tooltipDisplay.method_68569("hidden_components").method_10612()
                : new class_2499();
        if (!listContainsString(hiddenComponents, hiddenComponent)) {
            hiddenComponents.add(class_2519.method_23256(hiddenComponent));
        }
        tooltipDisplay.method_10566("hidden_components", hiddenComponents);
        components.method_10566("minecraft:tooltip_display", tooltipDisplay);
    }

    private static boolean isTooltipComponentHidden(class_2487 components, String componentKey) {
        if (!components.method_10545("minecraft:tooltip_display")) {
            return false;
        }
        class_2487 tooltipDisplay = components.method_68568("minecraft:tooltip_display");
        return tooltipDisplay.method_68566("hide_tooltip", false)
                || listContainsString(tooltipDisplay.method_68569("hidden_components"), componentKey);
    }

    private static boolean listContainsString(class_2499 list, String value) {
        for (int i = 0; i < list.size(); i++) {
            if (value.equals(list.method_68577(i, ""))) {
                return true;
            }
        }
        return false;
    }

    private static void writeDisplayComponents(class_2487 customData, class_2487 components, int hideFlags) {
        if (!customData.method_10545("display")) {
            return;
        }

        class_2487 display = customData.method_68568("display").method_10553();
        writeTextComponent(display, "Name", components, "minecraft:custom_name");
        writeLoreComponent(display, components);
        if (display.method_10545("LocName")) {
            class_2487 itemName = new class_2487();
            itemName.method_10582("translate", display.method_68564("LocName", ""));
            components.method_10566("minecraft:item_name", itemName);
            display.method_10551("LocName");
        }
        if (display.method_10545("color")) {
            components.method_10569("minecraft:dyed_color", display.method_68083("color", 0));
            if ((hideFlags & 64) != 0) {
                hideTooltipComponent(components, "minecraft:dyed_color");
            }
            display.method_10551("color");
        } else if ((hideFlags & 64) != 0) {
            components.method_10569("minecraft:dyed_color", 10511680);
            hideTooltipComponent(components, "minecraft:dyed_color");
        }
        moveComponent(display, "MapColor", components, "minecraft:map_color");

        if (display.method_33133()) {
            customData.method_10551("display");
        } else {
            customData.method_10566("display", display);
        }
    }

    private static void writeCustomModelData(class_2487 customData, class_2487 components) {
        class_2520 value = customData.method_10580("CustomModelData");
        if (value == null) {
            return;
        }
        if (value instanceof class_2514 numericTag) {
            class_2487 modern = new class_2487();
            class_2499 floats = new class_2499();
            floats.add(class_2494.method_23244(numericTag.method_10700()));
            modern.method_10566("floats", floats);
            components.method_10566("minecraft:custom_model_data", modern);
        } else if (value instanceof class_2487 compoundTag) {
            components.method_10566("minecraft:custom_model_data", compoundTag.method_10553());
        }
        customData.method_10551("CustomModelData");
    }

    private static void writeTextComponent(class_2487 display, String key, class_2487 components, String componentKey) {
        class_2520 value = display.method_10580(key);
        if (value == null) {
            return;
        }
        class_2520 component = legacyTextToComponentTag(value);
        if (component != null) {
            components.method_10566(componentKey, component);
        }
        display.method_10551(key);
    }

    private static void writeLoreComponent(class_2487 display, class_2487 components) {
        class_2520 value = display.method_10580("Lore");
        if (value == null) {
            return;
        }

        class_2499 lines = new class_2499();
        if (value instanceof class_2499 list) {
            for (int i = 0; i < list.size(); i++) {
                class_2520 component = legacyTextToComponentTag(list.method_10534(i));
                if (component != null) {
                    lines.add(component);
                }
            }
        }
        if (!lines.isEmpty()) {
            components.method_10566("minecraft:lore", lines);
        }
        display.method_10551("Lore");
    }

    private static class_2520 legacyTextToComponentTag(class_2520 value) {
        if (value == null) {
            return null;
        }
        if (!(value instanceof class_2519 stringTag)) {
            return value.method_10707();
        }

        String raw = LegacyText.unwrapJsonString(stringTag.comp_3831());
        class_2561 component = null;
        if (raw.startsWith("{") || raw.startsWith("[")) {
            try {
                component = ComponentCompat.fromJson(raw);
            } catch (RuntimeException ignored) {
                component = null;
            }
        }
        if (component == null) {
            component = LegacyText.parse(raw);
        }
        return class_8824.field_46597
                .encodeStart(provider().method_57093(class_2509.field_11560), component)
                .result()
                .orElseGet(() -> class_2519.method_23256(raw));
    }

    private static void copyTextComponent(class_2487 components, String componentKey, class_2487 display, String key) {
        class_2520 value = components.method_10580(componentKey);
        if (value == null) {
            return;
        }
        class_2561 component = parseComponentTag(value);
        String legacy = component == null ? null : LegacyText.toLegacy(component);
        if (legacy != null) {
            display.method_10582(key, legacy);
        } else {
            display.method_10566(key, value.method_10707());
        }
    }

    private static void copyLoreComponent(class_2487 components, class_2487 display) {
        class_2520 value = components.method_10580("minecraft:lore");
        if (!(value instanceof class_2499 list)) {
            return;
        }
        class_2499 lines = new class_2499();
        for (int i = 0; i < list.size(); i++) {
            class_2520 entry = list.method_10534(i);
            class_2561 component = parseComponentTag(entry);
            String legacy = component == null ? null : LegacyText.toLegacy(component);
            lines.add(legacy != null ? class_2519.method_23256(legacy) : entry.method_10707());
        }
        display.method_10566("Lore", lines);
    }

    private static class_2561 parseComponentTag(class_2520 tag) {
        try {
            return class_8824.field_46597
                    .parse(provider().method_57093(class_2509.field_11560), tag)
                    .result()
                    .orElse(null);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    private static void writeEnchantmentsComponent(class_2487 customData, class_2487 components, String oldKey, String componentKey, boolean hidden) {
        if (!customData.method_10545(oldKey) && !hidden) {
            return;
        }

        class_2499 oldEnchantments = customData.method_68569(oldKey);
        class_2487 levels = new class_2487();
        for (int i = 0; i < oldEnchantments.size(); i++) {
            class_2487 enchantment = oldEnchantments.method_68582(i);
            if (enchantment.method_10545("id")) {
                levels.method_10569(enchantment.method_68564("id", ""), Math.max(0, enchantment.method_68083("lvl", 0)));
            }
        }

        if (!levels.method_33133()) {
            components.method_10566(componentKey, levels);
        }
        if (hidden) {
            hideTooltipComponent(components, componentKey);
            if (levels.method_33133()) {
                components.method_10556("minecraft:enchantment_glint_override", true);
            }
        }
        customData.method_10551(oldKey);
    }

    private static void writeUnbreakableComponent(class_2487 customData, class_2487 components, int hideFlags) {
        if (!customData.method_68566("Unbreakable", false)) {
            customData.method_10551("Unbreakable");
            return;
        }

        class_2487 unbreakable = new class_2487();
        if ((hideFlags & 4) != 0) {
            hideTooltipComponent(components, "minecraft:unbreakable");
        }
        components.method_10566("minecraft:unbreakable", unbreakable);
        customData.method_10551("Unbreakable");
    }

    private static void writeAttributeComponents(class_2487 customData, class_2487 components, int hideFlags) {
        if (!customData.method_10545("AttributeModifiers")) {
            return;
        }

        class_2499 oldModifiers = customData.method_68569("AttributeModifiers");
        class_2499 modifiers = new class_2499();
        for (int i = 0; i < oldModifiers.size(); i++) {
            class_2487 oldModifier = oldModifiers.method_68582(i);
            class_2487 modifier = new class_2487();
            String type = oldModifier.method_10545("AttributeName")
                    ? oldModifier.method_68564("AttributeName", "")
                    : oldModifier.method_68564("type", "");
            if (type.isBlank()) {
                continue;
            }
            modifier.method_10582("type", type);
            modifier.method_10582("id", oldModifier.method_10545("id")
                    ? oldModifier.method_68564("id", "")
                    : type + "/" + UUID.randomUUID());
            modifier.method_10549("amount", oldModifier.method_10545("Amount") ? oldModifier.method_68563("Amount", 0.0D) : oldModifier.method_68563("amount", 0.0D));
            modifier.method_10582("operation", operationName(oldModifier.method_10545("Operation") ? oldModifier.method_68083("Operation", 0) : 0));
            if (oldModifier.method_10545("operation")) {
                modifier.method_10582("operation", oldModifier.method_68564("operation", ""));
            }
            if (oldModifier.method_10545("Slot")) {
                modifier.method_10582("slot", oldModifier.method_68564("Slot", ""));
            } else if (oldModifier.method_10545("slot")) {
                modifier.method_10582("slot", oldModifier.method_68564("slot", ""));
            }
            modifiers.add(modifier);
        }
        if (!modifiers.isEmpty()) {
            components.method_10566("minecraft:attribute_modifiers", modifiers);
        }
        if ((hideFlags & 2) != 0) {
            hideTooltipComponent(components, "minecraft:attribute_modifiers");
        }
        customData.method_10551("AttributeModifiers");
    }

    private static void writeAdventureComponents(class_2487 customData, class_2487 components, int hideFlags) {
        writeStringPredicateComponent(customData, components, "CanDestroy", "minecraft:can_break", (hideFlags & 8) != 0);
        writeStringPredicateComponent(customData, components, "CanPlaceOn", "minecraft:can_place_on", (hideFlags & 16) != 0);
    }

    private static void writeStringPredicateComponent(class_2487 customData, class_2487 components, String oldKey, String componentKey, boolean hidden) {
        if (!customData.method_10545(oldKey)) {
            return;
        }

        class_2499 oldList = customData.method_68569(oldKey);
        class_2499 predicates = new class_2499();
        for (int i = 0; i < oldList.size(); i++) {
            class_2487 predicate = new class_2487();
            predicate.method_10582("blocks", oldList.method_68577(i, ""));
            predicates.add(predicate);
        }
        if (predicates.size() == 1) {
            components.method_10566(componentKey, predicates.method_68582(0));
        } else if (!predicates.isEmpty()) {
            components.method_10566(componentKey, predicates);
        }
        if (hidden) {
            hideTooltipComponent(components, componentKey);
        }
        customData.method_10551(oldKey);
    }

    private static void writePotionComponents(class_2487 customData, class_2487 components) {
        class_2487 potion = new class_2487();
        if (customData.method_10545("Potion") && !"minecraft:empty".equals(customData.method_68564("Potion", ""))) {
            potion.method_10582("potion", customData.method_68564("Potion", ""));
        }
        moveInto(customData, potion, "CustomPotionColor", "custom_color");
        if (customData.method_10545("CustomPotionEffects")) {
            potion.method_10566("custom_effects", convertPotionEffects(customData.method_68569("CustomPotionEffects")));
            customData.method_10551("CustomPotionEffects");
        } else {
            moveInto(customData, potion, "custom_potion_effects", "custom_effects");
        }
        customData.method_10551("Potion");
        if (!potion.method_33133()) {
            components.method_10566("minecraft:potion_contents", potion);
        }
    }

    private static void writeBookComponents(class_2487 customData, class_2487 components) {
        if (customData.method_10545("pages") && !customData.method_10545("title")) {
            class_2487 book = new class_2487();
            book.method_10566("pages", filterableStringList(customData.method_68569("pages"), null));
            components.method_10566("minecraft:writable_book_content", book);
            customData.method_10551("pages");
            return;
        }

        if (customData.method_10545("title") || customData.method_10545("author") || customData.method_10545("pages")) {
            class_2487 book = new class_2487();
            book.method_10566("title", filterableText(customData.method_68564("title", ""),
                    customData.method_10545("filtered_title") ? customData.method_68564("filtered_title", "") : null));
            book.method_10582("author", customData.method_68564("author", ""));
            if (customData.method_10545("generation")) {
                book.method_10569("generation", clamp(customData.method_68083("generation", 0), 0, 3));
            }
            if (customData.method_10545("resolved")) {
                book.method_10556("resolved", customData.method_68566("resolved", false));
            }
            if (customData.method_10545("pages")) {
                book.method_10566("pages", filterableStringList(customData.method_68569("pages"),
                        customData.method_10545("filtered_pages") ? customData.method_68568("filtered_pages") : null));
            }
            components.method_10566("minecraft:written_book_content", book);
            customData.method_10551("title");
            customData.method_10551("filtered_title");
            customData.method_10551("author");
            customData.method_10551("generation");
            customData.method_10551("resolved");
            customData.method_10551("pages");
            customData.method_10551("filtered_pages");
        }
    }

    private static void writeFireworkComponents(class_2487 customData, class_2487 components) {
        if (customData.method_10545("Explosion")) {
            components.method_10566("minecraft:firework_explosion", fireworkExplosionToComponent(customData.method_68568("Explosion")));
            customData.method_10551("Explosion");
        }
        if (customData.method_10545("Fireworks")) {
            class_2487 oldFireworks = customData.method_68568("Fireworks");
            class_2487 fireworks = new class_2487();
            fireworks.method_10569("flight_duration", oldFireworks.method_68562("Flight", (byte) 0) & 255);
            if (oldFireworks.method_10545("Explosions")) {
                class_2499 explosions = new class_2499();
                class_2499 oldExplosions = oldFireworks.method_68569("Explosions");
                for (int i = 0; i < oldExplosions.size(); i++) {
                    explosions.add(fireworkExplosionToComponent(oldExplosions.method_68582(i)));
                }
                fireworks.method_10566("explosions", explosions);
            }
            components.method_10566("minecraft:fireworks", fireworks);
            customData.method_10551("Fireworks");
        }
    }

    private static void writeProfileComponent(class_2487 customData, class_2487 components) {
        if (!customData.method_10545("SkullOwner")) {
            return;
        }

        class_2520 skullOwner = customData.method_10580("SkullOwner");
        if (skullOwner instanceof class_2519 stringTag) {
            components.method_10582("minecraft:profile", stringTag.comp_3831());
        } else if (skullOwner instanceof class_2487 skullOwnerTag) {
            class_2487 profile = new class_2487();
            if (skullOwnerTag.method_10545("Name")) {
                profile.method_10582("name", skullOwnerTag.method_68564("Name", ""));
            }
            if (NbtCompat.hasUUID(skullOwnerTag, "Id")) {
                NbtCompat.putUUID(profile, "id", NbtCompat.getUUID(skullOwnerTag, "Id"));
            }
            if (skullOwnerTag.method_10545("Properties")) {
                profile.method_10566("properties", profilePropertiesToComponent(skullOwnerTag.method_68568("Properties")));
            }
            components.method_10566("minecraft:profile", profile);
        }
        customData.method_10551("SkullOwner");
    }

    private static void writeEntityDataComponent(String itemId, class_2487 customData, class_2487 components) {
        if (!customData.method_10545("EntityTag")) {
            return;
        }

        class_2487 entity = customData.method_68568("EntityTag").method_10553();
        ensureId(entity, inferEntityId(itemId));
        components.method_10566("minecraft:entity_data", entity);
        customData.method_10551("EntityTag");
    }

    private static void writeTrimComponent(class_2487 customData, class_2487 components, int hideFlags) {
        class_2520 value = customData.method_10580("Trim");
        if (value == null) {
            return;
        }

        class_2520 trim = value.method_10707();
        if ((hideFlags & 128) != 0) {
            hideTooltipComponent(components, "minecraft:trim");
        }
        components.method_10566("minecraft:trim", trim);
        customData.method_10551("Trim");
    }

    private static void writeBlockEntityComponents(String itemId, class_2487 customData, class_2487 components) {
        if (!customData.method_10545("BlockEntityTag")) {
            return;
        }

        class_2487 blockEntity = customData.method_68568("BlockEntityTag").method_10553();
        ensureId(blockEntity, inferBlockEntityId(itemId));
        if (blockEntity.method_10545("Items")) {
            components.method_10566("minecraft:container", containerItemsToComponent(blockEntity.method_68569("Items")));
            blockEntity.method_10551("Items");
        }
        if (blockEntity.method_10545("Patterns")) {
            components.method_10566("minecraft:banner_patterns", bannerPatternsToComponent(blockEntity.method_68569("Patterns")));
            blockEntity.method_10551("Patterns");
        }
        if (blockEntity.method_10545("Base")) {
            components.method_10582("minecraft:base_color", dyeNameById(blockEntity.method_68083("Base", 0)));
            blockEntity.method_10551("Base");
        }
        if ("minecraft:decorated_pot".equals(itemId) && blockEntity.method_10545("sherds")) {
            components.method_10566("minecraft:pot_decorations", potDecorationsToComponent(blockEntity.method_68569("sherds")));
            blockEntity.method_10551("sherds");
        }
        moveInto(blockEntity, components, "Lock", "minecraft:lock");
        if (blockEntity.method_10545("LootTable")) {
            class_2487 loot = new class_2487();
            loot.method_10582("loot_table", blockEntity.method_68564("LootTable", ""));
            if (blockEntity.method_10545("LootTableSeed")) {
                loot.method_10544("seed", blockEntity.method_68080("LootTableSeed", 0L));
            }
            components.method_10566("minecraft:container_loot", loot);
            blockEntity.method_10551("LootTable");
            blockEntity.method_10551("LootTableSeed");
        }
        if (!blockEntity.method_33133() && !isOnlyId(blockEntity)) {
            components.method_10566("minecraft:block_entity_data", blockEntity);
        }
        customData.method_10551("BlockEntityTag");
    }

    private static int readComponentDisplay(class_2487 components, class_2487 tag, int hideFlags) {
        class_2487 display = tag.method_10545("display") ? tag.method_68568("display").method_10553() : new class_2487();
        copyTextComponent(components, "minecraft:custom_name", display, "Name");
        copyTextComponent(components, "minecraft:item_name", display, "Name");
        copyLoreComponent(components, display);
        if (components.method_10545("minecraft:dyed_color")) {
            class_2520 dyed = components.method_10580("minecraft:dyed_color");
            if (dyed instanceof class_2514 numericTag) {
                display.method_10569("color", numericTag.method_10701());
            } else if (dyed instanceof class_2487 dyedTag) {
                display.method_10569("color", dyedTag.method_68083("rgb", 0));
            }
            if (isTooltipComponentHidden(components, "minecraft:dyed_color")) {
                hideFlags |= 64;
            }
        }
        copyComponent(components, "minecraft:map_color", display, "MapColor");
        if (display.method_33133()) {
            tag.method_10551("display");
        } else {
            tag.method_10566("display", display);
        }
        return hideFlags;
    }

    private static int readComponentEnchantments(class_2487 components, class_2487 tag, int hideFlags) {
        hideFlags = readEnchantmentsComponent(components, tag, "minecraft:enchantments", "Enchantments", hideFlags, 1);
        hideFlags = readEnchantmentsComponent(components, tag, "minecraft:stored_enchantments", "StoredEnchantments", hideFlags, 32);
        return hideFlags;
    }

    private static int readEnchantmentsComponent(class_2487 components, class_2487 tag, String componentKey, String oldKey, int hideFlags, int hideMask) {
        if (!components.method_10545(componentKey)) {
            return hideFlags;
        }

        class_2487 component = components.method_10580(componentKey) instanceof class_2487 compoundTag ? compoundTag : new class_2487();
        class_2487 levels = component.method_10545("levels") ? component.method_68568("levels") : component;
        class_2499 enchantments = new class_2499();
        for (String id : levels.method_10541()) {
            class_2487 enchantment = new class_2487();
            enchantment.method_10582("id", id);
            enchantment.method_10569("lvl", levels.method_68083(id, 0));
            enchantments.add(enchantment);
        }
        if (!enchantments.isEmpty()) {
            tag.method_10566(oldKey, enchantments);
        }
        if (isTooltipComponentHidden(components, componentKey)) {
            hideFlags |= hideMask;
        }
        return hideFlags;
    }

    private static int readComponentUnbreakable(class_2487 components, class_2487 tag, int hideFlags) {
        if (components.method_10545("minecraft:unbreakable")) {
            tag.method_10556("Unbreakable", true);
            if (isTooltipComponentHidden(components, "minecraft:unbreakable")) {
                hideFlags |= 4;
            }
        }
        return hideFlags;
    }

    private static int readComponentAttributes(class_2487 components, class_2487 tag, int hideFlags) {
        if (!components.method_10545("minecraft:attribute_modifiers")) {
            return hideFlags;
        }

        class_2520 attributeComponent = components.method_10580("minecraft:attribute_modifiers");
        class_2499 modifiers;
        if (attributeComponent instanceof class_2499 listTag) {
            modifiers = listTag;
        } else if (attributeComponent instanceof class_2487 compoundTag) {
            modifiers = compoundTag.method_68569("modifiers");
        } else {
            modifiers = new class_2499();
        }
        class_2499 oldModifiers = new class_2499();
        for (int i = 0; i < modifiers.size(); i++) {
            class_2487 modifier = modifiers.method_68582(i);
            class_2487 oldModifier = new class_2487();
            oldModifier.method_10582("AttributeName", modifier.method_68564("type", ""));
            oldModifier.method_10582("id", modifier.method_68564("id", ""));
            oldModifier.method_10549("Amount", modifier.method_68563("amount", 0.0D));
            oldModifier.method_10582("operation", modifier.method_68564("operation", ""));
            oldModifier.method_10569("Operation", operationId(modifier.method_68564("operation", "")));
            if (modifier.method_10545("slot")) {
                oldModifier.method_10582("Slot", modifier.method_68564("slot", ""));
            }
            oldModifiers.add(oldModifier);
        }
        if (!oldModifiers.isEmpty()) {
            tag.method_10566("AttributeModifiers", oldModifiers);
        }
        if (isTooltipComponentHidden(components, "minecraft:attribute_modifiers")) {
            hideFlags |= 2;
        }
        return hideFlags;
    }

    private static int readComponentAdventure(class_2487 components, class_2487 tag, int hideFlags) {
        hideFlags = readStringPredicateComponent(components, tag, "minecraft:can_break", "CanDestroy", hideFlags, 8);
        return readStringPredicateComponent(components, tag, "minecraft:can_place_on", "CanPlaceOn", hideFlags, 16);
    }

    private static int readStringPredicateComponent(class_2487 components, class_2487 tag, String componentKey, String oldKey, int hideFlags, int hideMask) {
        if (!components.method_10545(componentKey)) {
            return hideFlags;
        }

        class_2520 adventureComponent = components.method_10580(componentKey);
        class_2499 predicates = new class_2499();
        if (adventureComponent instanceof class_2487 compoundTag) {
            if (compoundTag.method_10545("predicates")) {
                predicates = compoundTag.method_68569("predicates");
            } else if (compoundTag.method_10545("blocks")) {
                predicates.add(compoundTag.method_10553());
            }
        } else if (adventureComponent instanceof class_2499 listTag) {
            predicates = listTag;
        }
        class_2499 oldList = new class_2499();
        for (int i = 0; i < predicates.size(); i++) {
            class_2487 predicate = predicates.method_68582(i);
            if (predicate.method_10545("blocks")) {
                oldList.add(class_2519.method_23256(predicate.method_68564("blocks", "")));
            }
        }
        if (!oldList.isEmpty()) {
            tag.method_10566(oldKey, oldList);
        }
        if (isTooltipComponentHidden(components, componentKey)) {
            hideFlags |= hideMask;
        }
        return hideFlags;
    }

    private static void readComponentPotion(class_2487 components, class_2487 tag) {
        if (!components.method_10545("minecraft:potion_contents")) {
            return;
        }

        class_2487 potion = components.method_68568("minecraft:potion_contents");
        copyTag(potion, "potion", tag, "Potion");
        copyTag(potion, "custom_color", tag, "CustomPotionColor");
        copyTag(potion, "custom_effects", tag, "CustomPotionEffects");
    }

    private static void readComponentBooks(class_2487 components, class_2487 tag) {
        if (components.method_10545("minecraft:writable_book_content")) {
            class_2487 book = components.method_68568("minecraft:writable_book_content");
            tag.method_10566("pages", readFilterableList(book.method_68569("pages")));
        }
        if (components.method_10545("minecraft:written_book_content")) {
            class_2487 book = components.method_68568("minecraft:written_book_content");
            tag.method_10582("title", readFilterableString(book.method_10580("title")));
            tag.method_10582("author", book.method_68564("author", ""));
            if (book.method_10545("generation")) {
                tag.method_10569("generation", book.method_68083("generation", 0));
            }
            if (book.method_10545("resolved")) {
                tag.method_10556("resolved", book.method_68566("resolved", false));
            }
            tag.method_10566("pages", readFilterableList(book.method_68569("pages")));
        }
    }

    private static void readComponentFireworks(class_2487 components, class_2487 tag) {
        if (components.method_10545("minecraft:firework_explosion")) {
            tag.method_10566("Explosion", fireworkExplosionFromComponent(components.method_68568("minecraft:firework_explosion")));
        }
        if (components.method_10545("minecraft:fireworks")) {
            class_2487 component = components.method_68568("minecraft:fireworks");
            class_2487 fireworks = new class_2487();
            fireworks.method_10567("Flight", (byte) component.method_68083("flight_duration", 0));
            class_2499 oldExplosions = new class_2499();
            class_2499 explosions = component.method_68569("explosions");
            for (int i = 0; i < explosions.size(); i++) {
                oldExplosions.add(fireworkExplosionFromComponent(explosions.method_68582(i)));
            }
            if (!oldExplosions.isEmpty()) {
                fireworks.method_10566("Explosions", oldExplosions);
            }
            tag.method_10566("Fireworks", fireworks);
        }
    }

    private static void readComponentProfile(class_2487 components, class_2487 tag) {
        if (!components.method_10545("minecraft:profile")) {
            return;
        }

        class_2520 profile = components.method_10580("minecraft:profile");
        if (profile instanceof class_2519 stringTag) {
            tag.method_10582("SkullOwner", stringTag.comp_3831());
        } else if (profile instanceof class_2487 profileTag) {
            class_2487 skullOwner = new class_2487();
            copyTag(profileTag, "name", skullOwner, "Name");
            if (NbtCompat.hasUUID(profileTag, "id")) {
                NbtCompat.putUUID(skullOwner, "Id", NbtCompat.getUUID(profileTag, "id"));
            }
            if (profileTag.method_10545("properties")) {
                skullOwner.method_10566("Properties", profilePropertiesFromComponent(profileTag.method_68569("properties")));
            }
            tag.method_10566("SkullOwner", skullOwner);
        }
    }

    private static void readComponentBlockEntity(class_1799 stack, class_2487 components, class_2487 tag) {
        class_2487 blockEntity = tag.method_10545("BlockEntityTag") ? tag.method_68568("BlockEntityTag").method_10553() : new class_2487();
        if (components.method_10545("minecraft:block_entity_data")) {
            blockEntity.method_10543(components.method_68568("minecraft:block_entity_data").method_10553());
        }
        if (components.method_10545("minecraft:container")) {
            blockEntity.method_10566("Items", containerItemsFromComponent(components.method_68569("minecraft:container")));
        }
        if (components.method_10545("minecraft:banner_patterns")) {
            blockEntity.method_10566("Patterns", bannerPatternsFromComponent(components.method_68569("minecraft:banner_patterns")));
        }
        if (components.method_10545("minecraft:base_color")) {
            blockEntity.method_10569("Base", dyeIdByName(components.method_68564("minecraft:base_color", "")));
        }
        if (stack.method_31574(class_1802.field_42699) && components.method_10545("minecraft:pot_decorations")) {
            blockEntity.method_10566("sherds", potDecorationsFromComponent(components.method_68569("minecraft:pot_decorations")));
        }
        copyTag(components, "minecraft:lock", blockEntity, "Lock");
        if (components.method_10545("minecraft:container_loot")) {
            class_2487 loot = components.method_68568("minecraft:container_loot");
            copyTag(loot, "loot_table", blockEntity, "LootTable");
            copyTag(loot, "seed", blockEntity, "LootTableSeed");
        }
        if (!blockEntity.method_33133()) {
            tag.method_10566("BlockEntityTag", blockEntity);
        }
    }

    private static class_2499 containerItemsToComponent(class_2499 oldItems) {
        class_2499 items = new class_2499();
        for (int i = 0; i < oldItems.size(); i++) {
            class_2487 oldItem = oldItems.method_68582(i);
            class_2487 item = new class_2487();
            item.method_10569("slot", oldItem.method_68562("Slot", (byte) 0) & 255);
            class_2487 stackTag = oldItem.method_10553();
            stackTag.method_10551("Slot");
            item.method_10566("item", normalizeStackTag(stackTag));
            items.add(item);
        }
        return items;
    }

    private static class_2499 containerItemsFromComponent(class_2499 componentItems) {
        class_2499 items = new class_2499();
        for (int i = 0; i < componentItems.size(); i++) {
            class_2487 componentItem = componentItems.method_68582(i);
            if (!componentItem.method_10545("item")) {
                continue;
            }
            class_2487 item = componentItem.method_68568("item").method_10553();
            item.method_10567("Slot", (byte) componentItem.method_68083("slot", 0));
            items.add(item);
        }
        return items;
    }

    private static class_2499 bannerPatternsToComponent(class_2499 oldPatterns) {
        class_2499 patterns = new class_2499();
        for (int i = 0; i < oldPatterns.size(); i++) {
            class_2487 oldPattern = oldPatterns.method_68582(i);
            class_2487 pattern = new class_2487();
            pattern.method_10582("pattern", bannerPatternId(oldPattern.method_68564("Pattern", "")));
            pattern.method_10582("color", dyeNameById(oldPattern.method_68083("Color", 0)));
            patterns.add(pattern);
        }
        return patterns;
    }

    private static class_2499 bannerPatternsFromComponent(class_2499 componentPatterns) {
        class_2499 patterns = new class_2499();
        for (int i = 0; i < componentPatterns.size(); i++) {
            class_2487 componentPattern = componentPatterns.method_68582(i);
            class_2487 pattern = new class_2487();
            pattern.method_10582("Pattern", bannerPatternHash(componentPattern.method_68564("pattern", "")));
            pattern.method_10569("Color", dyeIdByName(componentPattern.method_68564("color", "")));
            patterns.add(pattern);
        }
        return patterns;
    }

    private static class_2499 potDecorationsToComponent(class_2499 oldSherds) {
        class_2499 sherds = new class_2499();
        for (int i = 0; i < 4; i++) {
            String itemId = i < oldSherds.size() ? oldSherds.method_68577(i, "") : "minecraft:brick";
            sherds.add(class_2519.method_23256(normalizeItemId(itemId)));
        }
        return sherds;
    }

    private static class_2499 potDecorationsFromComponent(class_2499 componentSherds) {
        class_2499 sherds = new class_2499();
        for (int i = 0; i < Math.min(4, componentSherds.size()); i++) {
            sherds.add(class_2519.method_23256(normalizeItemId(componentSherds.method_68577(i, ""))));
        }
        return sherds;
    }

    private static String normalizeItemId(String value) {
        String normalized = value == null ? "" : value.trim().toLowerCase(java.util.Locale.ROOT);
        if (normalized.isEmpty()) {
            return "minecraft:brick";
        }
        return normalized.contains(":") ? normalized : "minecraft:" + normalized;
    }

    private static class_2487 fireworkExplosionToComponent(class_2487 oldExplosion) {
        class_2487 explosion = new class_2487();
        explosion.method_10582("shape", switch (oldExplosion.method_68562("Type", (byte) 0)) {
            case 1 -> "large_ball";
            case 2 -> "star";
            case 3 -> "creeper";
            case 4 -> "burst";
            default -> "small_ball";
        });
        if (oldExplosion.method_10545("Colors")) {
            explosion.method_10566("colors", intArrayToList(NbtCompat.getIntArray(oldExplosion, "Colors")));
        }
        if (oldExplosion.method_10545("FadeColors")) {
            explosion.method_10566("fade_colors", intArrayToList(NbtCompat.getIntArray(oldExplosion, "FadeColors")));
        }
        if (oldExplosion.method_10545("Trail")) {
            explosion.method_10556("has_trail", oldExplosion.method_68566("Trail", false));
        }
        if (oldExplosion.method_10545("Flicker")) {
            explosion.method_10556("has_twinkle", oldExplosion.method_68566("Flicker", false));
        }
        return explosion;
    }

    private static class_2487 fireworkExplosionFromComponent(class_2487 explosion) {
        class_2487 oldExplosion = new class_2487();
        oldExplosion.method_10567("Type", (byte) switch (explosion.method_68564("shape", "")) {
            case "large_ball" -> 1;
            case "star" -> 2;
            case "creeper" -> 3;
            case "burst" -> 4;
            default -> 0;
        });
        if (explosion.method_10545("colors")) {
            oldExplosion.method_10539("Colors", listToIntArray(explosion.method_68569("colors")));
        }
        if (explosion.method_10545("fade_colors")) {
            oldExplosion.method_10539("FadeColors", listToIntArray(explosion.method_68569("fade_colors")));
        }
        if (explosion.method_10545("has_trail")) {
            oldExplosion.method_10556("Trail", explosion.method_68566("has_trail", false));
        }
        if (explosion.method_10545("has_twinkle")) {
            oldExplosion.method_10556("Flicker", explosion.method_68566("has_twinkle", false));
        }
        return oldExplosion;
    }

    private static class_2499 convertPotionEffects(class_2499 oldEffects) {
        class_2499 effects = new class_2499();
        for (int i = 0; i < oldEffects.size(); i++) {
            class_2487 oldEffect = oldEffects.method_68582(i);
            class_2487 effect = oldEffect.method_10553();
            String id = potionEffectId(oldEffect);
            if (!id.isBlank()) {
                effect.method_10582("id", id);
            }
            if (oldEffect.method_10545("Amplifier")) {
                effect.method_10569("amplifier", oldEffect.method_68562("Amplifier", (byte) 0) & 255);
            }
            if (oldEffect.method_10545("Duration")) {
                effect.method_10569("duration", oldEffect.method_68083("Duration", 0));
            }
            if (oldEffect.method_10545("Ambient")) {
                effect.method_10556("ambient", oldEffect.method_68566("Ambient", false));
            }
            if (oldEffect.method_10545("ShowParticles")) {
                effect.method_10556("show_particles", oldEffect.method_68566("ShowParticles", false));
            }
            if (oldEffect.method_10545("ShowIcon")) {
                effect.method_10556("show_icon", oldEffect.method_68566("ShowIcon", false));
            }
            effect.method_10551("Id");
            effect.method_10551("Amplifier");
            effect.method_10551("Duration");
            effect.method_10551("Ambient");
            effect.method_10551("ShowParticles");
            effect.method_10551("ShowIcon");
            effects.add(effect);
        }
        return effects;
    }

    private static String potionEffectId(class_2487 effect) {
        if (effect.method_10545("Id")) {
            return effect.method_68564("Id", "");
        }
        if (effect.method_10545("Id")) {
            class_1291 mobEffect = class_7923.field_41174.method_10200(effect.method_68083("Id", 0));
            class_2960 id = mobEffect == null ? null : class_7923.field_41174.method_10221(mobEffect);
            return id == null ? "" : id.toString();
        }
        return effect.method_10545("id") ? effect.method_68564("id", "") : "";
    }

    private static class_2487 filterableText(String raw, String filtered) {
        class_2487 tag = new class_2487();
        tag.method_10582("raw", raw == null ? "" : raw);
        if (filtered != null) {
            tag.method_10582("filtered", filtered);
        }
        return tag;
    }

    private static class_2499 filterableStringList(class_2499 strings, class_2487 filteredPages) {
        class_2499 pages = new class_2499();
        for (int i = 0; i < strings.size(); i++) {
            String filtered = filteredPages != null && filteredPages.method_10545(Integer.toString(i))
                    ? filteredPages.method_68564(Integer.toString(i), "")
                    : null;
            pages.add(filterableText(strings.method_68577(i, ""), filtered));
        }
        return pages;
    }

    private static class_2499 readFilterableList(class_2499 pages) {
        class_2499 strings = new class_2499();
        for (int i = 0; i < pages.size(); i++) {
            strings.add(class_2519.method_23256(readFilterableString(pages.method_10534(i))));
        }
        return strings;
    }

    private static String readFilterableString(class_2520 tag) {
        if (tag instanceof class_2519 stringTag) {
            return stringTag.comp_3831();
        }
        if (tag instanceof class_2487 compoundTag) {
            if (compoundTag.method_10545("raw")) {
                return compoundTag.method_68564("raw", "");
            }
            if (compoundTag.method_10545("filtered")) {
                return compoundTag.method_68564("filtered", "");
            }
        }
        return "";
    }

    private static class_2499 profilePropertiesToComponent(class_2487 properties) {
        class_2499 converted = new class_2499();
        for (String name : properties.method_10541()) {
            class_2499 values = properties.method_68569(name);
            for (int i = 0; i < values.size(); i++) {
                class_2487 value = values.method_68582(i);
                class_2487 property = new class_2487();
                property.method_10582("name", name);
                property.method_10582("value", value.method_68564("Value", ""));
                if (value.method_10545("Signature")) {
                    property.method_10582("signature", value.method_68564("Signature", ""));
                }
                converted.add(property);
            }
        }
        return converted;
    }

    private static class_2487 profilePropertiesFromComponent(class_2499 properties) {
        class_2487 converted = new class_2487();
        for (int i = 0; i < properties.size(); i++) {
            class_2487 property = properties.method_68582(i);
            String name = property.method_68564("name", "");
            class_2499 values = converted.method_10545(name) ? converted.method_68569(name) : new class_2499();
            class_2487 value = new class_2487();
            value.method_10582("Value", property.method_68564("value", ""));
            if (property.method_10545("signature")) {
                value.method_10582("Signature", property.method_68564("signature", ""));
            }
            values.add(value);
            converted.method_10566(name, values);
        }
        return converted;
    }

    private static class_2499 intArrayToList(int[] values) {
        class_2499 list = new class_2499();
        for (int value : values) {
            list.add(class_2497.method_23247(value));
        }
        return list;
    }

    private static int[] listToIntArray(class_2499 list) {
        int[] values = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            values[i] = list.method_68576(i, 0);
        }
        return values;
    }

    private static void copyComponent(class_2487 components, String componentKey, class_2487 tag, String oldKey) {
        copyTag(components, componentKey, tag, oldKey);
    }

    private static void copyTag(class_2487 source, String sourceKey, class_2487 target, String targetKey) {
        class_2520 value = source.method_10580(sourceKey);
        if (value != null) {
            target.method_10566(targetKey, value.method_10707());
        }
    }

    private static void moveComponent(class_2487 source, String oldKey, class_2487 components, String componentKey) {
        class_2520 value = source.method_10580(oldKey);
        if (value != null) {
            components.method_10566(componentKey, value.method_10707());
            source.method_10551(oldKey);
        }
    }

    private static void moveInto(class_2487 source, class_2487 target, String sourceKey, String targetKey) {
        class_2520 value = source.method_10580(sourceKey);
        if (value != null) {
            target.method_10566(targetKey, value.method_10707());
            source.method_10551(sourceKey);
        }
    }

    private static int removeInt(class_2487 tag, String key) {
        int value = tag.method_68083(key, 0);
        tag.method_10551(key);
        return value;
    }

    private static String operationName(int id) {
        return switch (id) {
            case 1 -> "add_multiplied_base";
            case 2 -> "add_multiplied_total";
            default -> "add_value";
        };
    }

    private static int operationId(String name) {
        return switch (name) {
            case "add_multiplied_base" -> 1;
            case "add_multiplied_total" -> 2;
            default -> 0;
        };
    }

    private static void ensureId(class_2487 tag, String inferredId) {
        if (!tag.method_10545("id") && inferredId != null && !inferredId.isBlank()) {
            tag.method_10582("id", inferredId);
        }
    }

    private static boolean isOnlyId(class_2487 tag) {
        return tag.method_10546() == 1 && tag.method_10545("id");
    }

    private static String inferEntityId(String itemId) {
        String namespace = namespace(itemId);
        String path = path(itemId);
        if ("armor_stand".equals(path)) {
            return "minecraft:armor_stand";
        }
        if ("item_frame".equals(path)) {
            return "minecraft:item_frame";
        }
        if ("glow_item_frame".equals(path)) {
            return "minecraft:glow_item_frame";
        }
        if ("command_block_minecart".equals(path)) {
            return "minecraft:command_block_minecart";
        }
        if (path.endsWith("_spawn_egg")) {
            return namespace + ":" + path.substring(0, path.length() - "_spawn_egg".length());
        }
        return null;
    }

    private static String inferBlockEntityId(String itemId) {
        String path = path(itemId);
        if (path.endsWith("_shulker_box")) {
            return "minecraft:shulker_box";
        }
        if (path.endsWith("_banner")) {
            return "minecraft:banner";
        }
        if (path.endsWith("_bed")) {
            return "minecraft:bed";
        }
        if (path.endsWith("_hanging_sign")) {
            return "minecraft:hanging_sign";
        }
        if (path.endsWith("_sign")) {
            return "minecraft:sign";
        }
        if (path.endsWith("_head") || path.endsWith("_skull")) {
            return "minecraft:skull";
        }

        String id = BLOCK_ENTITY_BY_ITEM.get(path);
        return id == null ? null : "minecraft:" + id;
    }

    private static String namespace(String id) {
        int separator = id.indexOf(':');
        return separator >= 0 ? id.substring(0, separator) : "minecraft";
    }

    private static String path(String id) {
        int separator = id.indexOf(':');
        return separator >= 0 ? id.substring(separator + 1) : id;
    }

    private static String bannerPatternId(String hash) {
        String id = hash.contains(":") ? hash.substring(hash.indexOf(':') + 1) : hash;
        return "minecraft:" + BANNER_HASH_TO_PATTERN.getOrDefault(id, id);
    }

    private static String bannerPatternHash(String pattern) {
        String id = pattern.contains(":") ? pattern.substring(pattern.indexOf(':') + 1) : pattern;
        return BANNER_PATTERN_TO_HASH.getOrDefault(id, id);
    }

    private static String dyeNameById(int id) {
        return class_1767.method_7791(id).method_7792();
    }

    private static int dyeIdByName(String name) {
        for (class_1767 color : class_1767.values()) {
            if (color.method_7792().equals(name)) {
                return color.method_7789();
            }
        }
        return class_1767.field_7952.method_7789();
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static Map<String, String> invert(Map<String, String> input) {
        Map<String, String> inverted = new HashMap<>();
        for (Map.Entry<String, String> entry : input.entrySet()) {
            inverted.put(entry.getValue(), entry.getKey());
        }
        return inverted;
    }

    private static final Constructor<class_2487> COMPOUND_TAG_CONSTRUCTOR = compoundTagConstructor();
    private static final Constructor<class_2499> LIST_TAG_CONSTRUCTOR = listTagConstructor();

    private static class_2487 syncedCompound(class_2487 source, Runnable onChanged) {
        ListeningMap map = new ListeningMap(onChanged);
        map.muted = true;
        for (String key : source.method_10541()) {
            class_2520 value = source.method_10580(key);
            if (value != null) {
                map.put(key, syncedTag(value, onChanged));
            }
        }
        map.muted = false;
        try {
            return COMPOUND_TAG_CONSTRUCTOR.newInstance(map);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException exception) {
            throw new IllegalStateException("Unable to create synced CompoundTag", exception);
        }
    }

    private static class_2499 syncedList(class_2499 source, Runnable onChanged) {
        ListeningList list = new ListeningList(onChanged);
        list.muted = true;
        for (int i = 0; i < source.size(); i++) {
            list.add(syncedTag(source.method_10534(i), onChanged));
        }
        list.muted = false;
        try {
            return LIST_TAG_CONSTRUCTOR.newInstance(list);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException exception) {
            throw new IllegalStateException("Unable to create synced ListTag", exception);
        }
    }

    private static class_2520 syncedTag(class_2520 tag, Runnable onChanged) {
        if (tag instanceof class_2487 compoundTag) {
            return syncedCompound(compoundTag, onChanged);
        }
        if (tag instanceof class_2499 listTag) {
            return syncedList(listTag, onChanged);
        }
        return tag.method_10707();
    }

    private static Constructor<class_2487> compoundTagConstructor() {
        try {
            Constructor<class_2487> constructor = class_2487.class.getDeclaredConstructor(Map.class);
            constructor.setAccessible(true);
            return constructor;
        } catch (NoSuchMethodException exception) {
            throw new IllegalStateException("CompoundTag map constructor is unavailable", exception);
        }
    }

    private static Constructor<class_2499> listTagConstructor() {
        try {
            Constructor<class_2499> constructor = class_2499.class.getDeclaredConstructor(List.class);
            constructor.setAccessible(true);
            return constructor;
        } catch (NoSuchMethodException exception) {
            throw new IllegalStateException("ListTag list constructor is unavailable", exception);
        }
    }

    private static final class ListeningMap extends HashMap<String, class_2520> {
        private final Runnable onChanged;
        private boolean muted;

        private ListeningMap(Runnable onChanged) {
            this.onChanged = onChanged;
        }

        @Override
        public class_2520 put(String key, class_2520 value) {
            class_2520 old = super.put(key, syncedTag(value, this.onChanged));
            changed();
            return old;
        }

        @Override
        public class_2520 remove(Object key) {
            class_2520 old = super.remove(key);
            changed();
            return old;
        }

        @Override
        public void clear() {
            super.clear();
            changed();
        }

        private void changed() {
            if (!this.muted) {
                this.onChanged.run();
            }
        }
    }

    private static final class ListeningList extends ArrayList<class_2520> {
        private final Runnable onChanged;
        private boolean muted;

        private ListeningList(Runnable onChanged) {
            this.onChanged = onChanged;
        }

        @Override
        public class_2520 set(int index, class_2520 element) {
            class_2520 old = super.set(index, syncedTag(element, this.onChanged));
            changed();
            return old;
        }

        @Override
        public void add(int index, class_2520 element) {
            super.add(index, syncedTag(element, this.onChanged));
            changed();
        }

        @Override
        public boolean add(class_2520 tag) {
            boolean added = super.add(syncedTag(tag, this.onChanged));
            if (added) {
                changed();
            }
            return added;
        }

        @Override
        public class_2520 remove(int index) {
            class_2520 old = super.remove(index);
            changed();
            return old;
        }

        @Override
        public boolean remove(Object value) {
            boolean removed = super.remove(value);
            if (removed) {
                changed();
            }
            return removed;
        }

        @Override
        public void clear() {
            if (isEmpty()) {
                return;
            }
            super.clear();
            changed();
        }

        private void changed() {
            if (!this.muted) {
                this.onChanged.run();
            }
        }
    }
}
