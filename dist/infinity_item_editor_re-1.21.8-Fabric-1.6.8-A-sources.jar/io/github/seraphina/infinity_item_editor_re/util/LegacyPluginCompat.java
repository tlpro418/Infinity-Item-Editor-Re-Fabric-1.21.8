package io.github.seraphina.infinity_item_editor_re.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * Some servers/plugins keep item display data inside {@code custom_data} (the reported item had
 * keys such as {@code WLProtocol_20_3To1_20_5}, {@code WLProtocol_12_2To1_13Name}). Editing only the
 * 1.21 components leaves those fields stale, so the server restores the old name/lore. This mirrors
 * the edited text back into those fields, preserving their original value format (plain vs JSON).
 */
public final class LegacyPluginCompat {
    private LegacyPluginCompat() {
    }

    public static boolean sync(class_1799 stack, String nameValue, List<String> loreValues) {
        class_9279 data = stack.method_58694(class_9334.field_49628);
        if (data == null) {
            return false;
        }
        class_2487 tag = data.method_57461();
        if (tag.method_10541().stream().noneMatch(key -> key.startsWith("WLProtocol"))) {
            return false;
        }

        String name = LegacyText.stripCodes(nameValue == null ? "" : nameValue).trim();
        class_2499 plainLore = new class_2499();
        for (String line : loreValues) {
            if (line != null && !line.isEmpty()) {
                plainLore.add(class_2519.method_23256(line));
            }
        }

        class_2487 display = tag.method_10545("display")
                ? tag.method_68568("display").method_10553()
                : new class_2487();
        if (name.isEmpty()) {
            display.method_10551("Name");
        } else if (isJsonString(display.method_10580("Name"))) {
            display.method_10582("Name", ComponentCompat.toJson(LegacyText.parse(nameValue)));
        } else {
            display.method_10582("Name", name);
        }

        boolean jsonLore = isJsonList(display.method_10580("Lore"));
        if (plainLore.isEmpty()) {
            display.method_10551("Lore");
        } else {
            display.method_10566("Lore", buildLore(loreValues, jsonLore));
        }
        tag.method_10566("display", display);

        for (String key : new ArrayList<>(tag.method_10541())) {
            if (key.endsWith("Name") && tag.method_10580(key) instanceof class_2519 nameTag) {
                tag.method_10582(key, isJsonString(nameTag)
                        ? ComponentCompat.toJson(LegacyText.parse(nameValue))
                        : name);
            } else if (key.endsWith("Lore") && tag.method_10580(key) instanceof class_2499 loreTag) {
                tag.method_10566(key, buildLore(loreValues, isJsonList(loreTag)));
            }
        }

        stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        return true;
    }

    private static class_2499 buildLore(List<String> lines, boolean json) {
        class_2499 list = new class_2499();
        for (String line : lines) {
            if (line == null || line.isEmpty()) {
                continue;
            }
            list.add(class_2519.method_23256(json ? ComponentCompat.toJson(LegacyText.parse(line)) : line));
        }
        return list;
    }

    private static boolean isJsonString(net.minecraft.class_2520 tag) {
        return tag instanceof class_2519 stringTag
                && (stringTag.comp_3831().startsWith("{") || stringTag.comp_3831().startsWith("\""));
    }

    private static boolean isJsonList(net.minecraft.class_2520 tag) {
        return tag instanceof class_2499 listTag && !listTag.isEmpty()
                && isJsonString(listTag.method_10534(0));
    }
}
