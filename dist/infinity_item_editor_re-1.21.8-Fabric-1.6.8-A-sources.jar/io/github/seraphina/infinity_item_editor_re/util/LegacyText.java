package io.github.seraphina.infinity_item_editor_re.util;

import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

/**
 * Converts legacy section-sign formatting codes to real component styles and back.
 * Minecraft 1.21.5+ no longer applies color codes stored in a plain component string.
 */
public final class LegacyText {
    private static final char SECTION = '\u00a7';

    private LegacyText() {
    }

    public static class_2561 parse(String text) {
        if (text == null || text.isEmpty()) {
            return class_2561.method_43473();
        }

        class_5250 root = null;
        class_2583 style = class_2583.field_24360;
        StringBuilder buffer = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char current = text.charAt(i);
            if (current == SECTION && i + 1 < text.length()) {
                class_124 format = class_124.method_544(text.charAt(i + 1));
                if (format != null) {
                    root = append(root, buffer, style);
                    style = style.method_27707(format);
                    i++;
                    continue;
                }
            }
            buffer.append(current);
        }
        root = append(root, buffer, style);
        return root == null ? class_2561.method_43473() : root;
    }

    /** Returns the legacy-code string, or {@code null} when the component is too complex to round-trip. */
    public static String toLegacy(class_2561 component) {
        if (component == null) {
            return null;
        }

        StringBuilder out = new StringBuilder();
        boolean[] complex = {false};
        component.method_27658((style, text) -> {
            if (complex[0]) {
                return Optional.empty();
            }
            if (style.method_10970() != null || style.method_10969() != null
                    || style.method_10955() != null || (style.method_27708() != null && !class_2583.field_24359.equals(style.method_27708()))) {
                complex[0] = true;
                return Optional.empty();
            }
            if (!appendStyleCodes(out, style)) {
                complex[0] = true;
                return Optional.empty();
            }
            out.append(text);
            return Optional.empty();
        }, class_2583.field_24360);
        return complex[0] ? null : out.toString();
    }

    public static String toLegacyOrPlain(class_2561 component) {
        String legacy = toLegacy(component);
        return legacy == null ? component.getString() : legacy;
    }

    /** Unwraps a quoted JSON string such as {@code "\"\u00a76text\""} produced by older serializers. */
    public static String unwrapJsonString(String text) {
        if (text == null || text.length() < 2 || !text.startsWith("\"") || !text.endsWith("\"")) {
            return text;
        }
        try {
            return com.google.gson.JsonParser.parseString(text).getAsString();
        } catch (RuntimeException exception) {
            return text;
        }
    }

    public static String stripCodes(String text) {
        if (text == null || text.indexOf(SECTION) < 0) {
            return text == null ? "" : text;
        }

        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char current = text.charAt(i);
            if (current == SECTION && i + 1 < text.length() && class_124.method_544(text.charAt(i + 1)) != null) {
                i++;
                continue;
            }
            out.append(current);
        }
        return out.toString();
    }

    private static class_5250 append(class_5250 root, StringBuilder buffer, class_2583 style) {
        if (buffer.isEmpty()) {
            return root;
        }
        class_5250 part = class_2561.method_43470(buffer.toString()).method_27696(style);
        buffer.setLength(0);
        return root == null ? part : root.method_10852(part);
    }

    private static boolean appendStyleCodes(StringBuilder out, class_2583 style) {
        if (style.method_10973() != null) {
            class_124 color = legacyColor(style.method_10973());
            if (color == null) {
                return false;
            }
            out.append(SECTION).append(color.method_36145());
        }
        if (style.method_10984()) {
            out.append(SECTION).append(class_124.field_1067.method_36145());
        }
        if (style.method_10966()) {
            out.append(SECTION).append(class_124.field_1056.method_36145());
        }
        if (style.method_10965()) {
            out.append(SECTION).append(class_124.field_1073.method_36145());
        }
        if (style.method_10986()) {
            out.append(SECTION).append(class_124.field_1055.method_36145());
        }
        if (style.method_10987()) {
            out.append(SECTION).append(class_124.field_1051.method_36145());
        }
        return true;
    }

    private static class_124 legacyColor(class_5251 color) {
        for (class_124 format : class_124.values()) {
            if (format.method_543() && class_5251.method_27718(format).equals(color)) {
                return format;
            }
        }
        return null;
    }
}


