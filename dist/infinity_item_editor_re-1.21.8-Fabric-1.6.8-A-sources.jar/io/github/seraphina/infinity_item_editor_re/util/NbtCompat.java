package io.github.seraphina.infinity_item_editor_re.util;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_2479;
import net.minecraft.class_2487;
import net.minecraft.class_2495;
import net.minecraft.class_2499;
import net.minecraft.class_2501;
import net.minecraft.class_2509;
import net.minecraft.class_2514;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2522;

public final class NbtCompat {
    public static final int TAG_ANY_NUMERIC = 99;

    private NbtCompat() {
    }

    public static boolean contains(class_2487 tag, String key, int type) {
        if (tag == null) {
            return false;
        }
        class_2520 value = tag.method_10580(key);
        if (value == null) {
            return false;
        }
        return type == TAG_ANY_NUMERIC ? value instanceof class_2514 : value.method_10711() == type;
    }

    public static boolean contains(class_2487 tag, String key) {
        return tag != null && tag.method_10545(key);
    }

    public static class_2487 getCompound(class_2487 tag, String key) {
        return tag == null ? new class_2487() : tag.method_68568(key);
    }

    public static class_2499 getList(class_2487 tag, String key, int ignoredType) {
        return tag == null ? new class_2499() : tag.method_68569(key);
    }

    public static byte getByte(class_2487 tag, String key) {
        return tag == null ? 0 : tag.method_68562(key, (byte) 0);
    }

    public static short getShort(class_2487 tag, String key) {
        return tag == null ? 0 : tag.method_68565(key, (short) 0);
    }

    public static int getInt(class_2487 tag, String key) {
        return tag == null ? 0 : tag.method_68083(key, 0);
    }

    public static long getLong(class_2487 tag, String key) {
        return tag == null ? 0L : tag.method_68080(key, 0L);
    }

    public static float getFloat(class_2487 tag, String key) {
        return tag == null ? 0.0F : tag.method_66563(key, 0.0F);
    }

    public static double getDouble(class_2487 tag, String key) {
        return tag == null ? 0.0D : tag.method_68563(key, 0.0D);
    }

    public static String getString(class_2487 tag, String key) {
        return tag == null ? "" : tag.method_68564(key, "");
    }

    public static boolean getBoolean(class_2487 tag, String key) {
        return tag != null && tag.method_68566(key, false);
    }

    public static byte[] getByteArray(class_2487 tag, String key) {
        return tag == null ? new byte[0] : tag.method_10547(key).orElseGet(() -> new byte[0]);
    }

    public static int[] getIntArray(class_2487 tag, String key) {
        return tag == null ? new int[0] : tag.method_10561(key).orElseGet(() -> new int[0]);
    }

    public static long[] getLongArray(class_2487 tag, String key) {
        return tag == null ? new long[0] : tag.method_10565(key).orElseGet(() -> new long[0]);
    }

    public static class_2487 getCompound(class_2499 list, int index) {
        return list == null ? new class_2487() : list.method_68582(index);
    }

    public static class_2499 getList(class_2499 list, int index) {
        return list == null ? new class_2499() : list.method_68588(index);
    }

    public static short getShort(class_2499 list, int index) {
        return list == null ? 0 : list.method_68578(index, (short) 0);
    }

    public static int getInt(class_2499 list, int index) {
        return list == null ? 0 : list.method_68576(index, 0);
    }

    public static float getFloat(class_2499 list, int index) {
        return list == null ? 0.0F : list.method_68575(index, 0.0F);
    }

    public static double getDouble(class_2499 list, int index) {
        return list == null ? 0.0D : list.method_68574(index, 0.0D);
    }

    public static String getString(class_2499 list, int index) {
        return list == null ? "" : list.method_68577(index, "");
    }

    public static int[] getIntArray(class_2499 list, int index) {
        return list == null ? new int[0] : list.method_36111(index).orElseGet(() -> new int[0]);
    }

    public static long[] getLongArray(class_2499 list, int index) {
        return list == null ? new long[0] : list.method_36112(index).orElseGet(() -> new long[0]);
    }

    public static boolean hasUUID(class_2487 tag, String key) {
        return tag != null && tag.method_10561(key).map(values -> values.length == 4).orElse(false);
    }

    public static UUID getUUID(class_2487 tag, String key) {
        int[] values = getIntArray(tag, key);
        if (values.length != 4) {
            return new UUID(0L, 0L);
        }
        long most = ((long) values[0] << 32) | (values[1] & 0xFFFFFFFFL);
        long least = ((long) values[2] << 32) | (values[3] & 0xFFFFFFFFL);
        return new UUID(most, least);
    }

    public static void putUUID(class_2487 tag, String key, UUID uuid) {
        long most = uuid.getMostSignificantBits();
        long least = uuid.getLeastSignificantBits();
        tag.method_10539(key, new int[]{
                (int) (most >> 32),
                (int) most,
                (int) (least >> 32),
                (int) least
        });
    }

    public static class_2487 parseTag(String value) throws CommandSyntaxException {
        return class_2522.method_67315(value);
    }

    public static class_2520 parseAnyTag(String value) throws CommandSyntaxException {
        return class_2522.method_68662(class_2509.field_11560).method_67313(value);
    }

    public static String asString(class_2520 tag) {
        return tag instanceof class_2519 stringTag ? stringTag.comp_3831() : "";
    }

    public static Number asNumber(class_2520 tag) {
        return tag instanceof class_2514 numericTag ? numericTag.method_10702() : 0;
    }

    public static int[] asIntArray(class_2520 tag) {
        return tag instanceof class_2495 arrayTag ? arrayTag.method_10588() : new int[0];
    }

    public static long[] asLongArray(class_2520 tag) {
        return tag instanceof class_2501 arrayTag ? arrayTag.method_10615() : new long[0];
    }

    public static byte[] asByteArray(class_2520 tag) {
        return tag instanceof class_2479 arrayTag ? arrayTag.method_10521() : new byte[0];
    }

    public static <T> T or(Optional<T> value, T fallback) {
        return value.orElse(fallback);
    }
}
