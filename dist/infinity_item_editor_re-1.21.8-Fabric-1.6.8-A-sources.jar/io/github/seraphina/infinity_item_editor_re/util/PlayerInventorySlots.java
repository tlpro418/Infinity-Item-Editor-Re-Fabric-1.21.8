package io.github.seraphina.infinity_item_editor_re.util;

import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public final class PlayerInventorySlots {
    public static final int HEAD_CONTAINER_SLOT = 5;
    public static final int CHEST_CONTAINER_SLOT = 6;
    public static final int LEGS_CONTAINER_SLOT = 7;
    public static final int FEET_CONTAINER_SLOT = 8;
    public static final int HOTBAR_CONTAINER_SLOT_START = 36;
    public static final int HOTBAR_CONTAINER_SLOT_END = 44;
    public static final int OFFHAND_CONTAINER_SLOT = 45;

    private PlayerInventorySlots() {
    }

    public static boolean isPlayerInventorySlot(class_1657 player, class_1735 slot) {
        return player != null && slot != null && slot.field_7871 == player.method_31548();
    }

    public static int toContainerSlot(class_1735 slot) {
        return slot == null ? -1 : toContainerSlot(slot.method_34266());
    }

    public static int toContainerSlot(int inventorySlot) {
        if (inventorySlot >= 0 && inventorySlot <= 8) {
            return HOTBAR_CONTAINER_SLOT_START + inventorySlot;
        }
        if (inventorySlot >= 9 && inventorySlot <= 35) {
            return inventorySlot;
        }
        if (inventorySlot >= 36 && inventorySlot <= 39) {
            return 8 - inventorySlot % 4;
        }
        if (inventorySlot == 40) {
            return OFFHAND_CONTAINER_SLOT;
        }
        return -1;
    }

    public static boolean setStack(class_1657 player, int containerSlot, class_1799 stack) {
        if (player == null || containerSlot < 0) {
            return false;
        }

        class_1661 inventory = player.method_31548();
        class_1799 localStack = stack == null || stack.method_7960() ? class_1799.field_8037 : stack.method_7972();
        if (containerSlot >= HOTBAR_CONTAINER_SLOT_START && containerSlot <= HOTBAR_CONTAINER_SLOT_END) {
            inventory.method_5447(containerSlot - HOTBAR_CONTAINER_SLOT_START, localStack);
            return true;
        }
        if (containerSlot >= 9 && containerSlot <= 35) {
            inventory.method_5447(containerSlot, localStack);
            return true;
        }

        switch (containerSlot) {
            case HEAD_CONTAINER_SLOT -> player.method_5673(class_1304.field_6169, localStack);
            case CHEST_CONTAINER_SLOT -> player.method_5673(class_1304.field_6174, localStack);
            case LEGS_CONTAINER_SLOT -> player.method_5673(class_1304.field_6172, localStack);
            case FEET_CONTAINER_SLOT -> player.method_5673(class_1304.field_6166, localStack);
            case OFFHAND_CONTAINER_SLOT -> player.method_5673(class_1304.field_6171, localStack);
            default -> {
                return false;
            }
        }
        return true;
    }
}
