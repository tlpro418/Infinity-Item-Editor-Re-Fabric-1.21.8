package io.github.seraphina.infinity_item_editor_re.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

public final class PotionCompat {
    public static final String TAG_CUSTOM_POTION_COLOR = "CustomPotionColor";

    private PotionCompat() {
    }

    public static int getColor(class_1799 stack) {
        return contents(stack).method_8064();
    }

    public static void setPotion(class_1799 stack, class_1842 potion) {
        stack.method_57379(class_9334.field_49651, contents(stack).method_57403(class_7923.field_41179.method_47983(potion)));
    }

    public static void setCustomColor(class_1799 stack, int color) {
        class_1844 old = contents(stack);
        stack.method_57379(class_9334.field_49651, new class_1844(old.comp_2378(), Optional.of(color), old.comp_2380(), old.comp_3209()));
    }

    public static void setCustomEffects(class_1799 stack, List<class_1293> effects) {
        class_1844 old = contents(stack);
        stack.method_57379(class_9334.field_49651, new class_1844(old.comp_2378(), old.comp_2379(), List.copyOf(effects), old.comp_3209()));
    }

    public static List<class_1293> getCustomEffects(class_1799 stack) {
        return new ArrayList<>(contents(stack).comp_2380());
    }

    private static class_1844 contents(class_1799 stack) {
        return stack.method_58695(class_9334.field_49651, class_1844.field_49274);
    }
}
