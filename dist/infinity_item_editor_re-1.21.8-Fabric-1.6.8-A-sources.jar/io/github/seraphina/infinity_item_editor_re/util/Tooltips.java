package io.github.seraphina.infinity_item_editor_re.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_8001;

/**
 * Draws tooltips immediately.
 * <p>
 * 1.21.6+ defers {@code setTooltipForNextFrame} into a private field of the {@link class_332} instance.
 * The editor renders through a derived {@link class_332} (for UI scaling), whose deferred tooltip would
 * never be flushed by the screen, so tooltips are drawn eagerly like the 1.21.4 code did.
 */
public final class Tooltips {
    private Tooltips() {
    }

    public static void show(class_332 graphics, class_327 font, class_1799 stack, int x, int y) {
        class_310 minecraft = class_310.method_1551();
        List<class_2561> lines = class_437.method_25408(minecraft, stack);
        show(graphics, font, lines, stack.method_32347(), x, y);
    }

    public static void show(class_332 graphics, class_327 font, class_2561 component, int x, int y) {
        show(graphics, font, List.of(component), Optional.empty(), x, y);
    }

    public static void showComponents(class_332 graphics, class_327 font, List<class_2561> lines, int x, int y) {
        show(graphics, font, lines, Optional.empty(), x, y);
    }

    private static void show(class_332 graphics, class_327 font, List<class_2561> lines,
                             Optional<class_5632> image, int x, int y) {
        if (lines.isEmpty()) {
            return;
        }

        List<class_5684> components = new ArrayList<>(lines.size() + 1);
        image.ifPresent(tooltip -> components.add(class_5684.method_32663(tooltip)));
        for (class_2561 line : lines) {
            components.add(class_5684.method_32662(line.method_30937()));
        }
        graphics.method_51435(font, components, x, y, class_8001.field_41687, null);
    }
}
