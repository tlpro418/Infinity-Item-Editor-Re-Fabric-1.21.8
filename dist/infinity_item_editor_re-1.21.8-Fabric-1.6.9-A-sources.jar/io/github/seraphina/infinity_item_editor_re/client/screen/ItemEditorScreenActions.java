package io.github.seraphina.infinity_item_editor_re.client.screen;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackCompat;

import io.github.seraphina.infinity_item_editor_re.util.ComponentCompat;

import io.github.seraphina.infinity_item_editor_re.util.ItemStackNbt;
import io.github.seraphina.infinity_item_editor_re.util.LegacyPluginCompat;
import io.github.seraphina.infinity_item_editor_re.util.LegacyText;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.seraphina.infinity_item_editor_re.Config;
import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.github.seraphina.infinity_item_editor_re.client.CreativeTabRefresher;
import io.github.seraphina.infinity_item_editor_re.data.realms.RealmController;
import io.github.seraphina.infinity_item_editor_re.util.GiveHelper;
import io.github.seraphina.infinity_item_editor_re.util.PlayerInventorySlots;
import io.github.seraphina.infinity_item_editor_re.util.SaveVerifier;
import io.github.seraphina.infinity_item_editor_re.util.ServerTagStripper;
import io.github.seraphina.infinity_item_editor_re.util.PotionCompat;
import io.github.seraphina.infinity_item_editor_re.util.CompatRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1132;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_9290;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
abstract class ItemEditorScreenActions extends ItemEditorScreenColorLore {
    protected ItemEditorScreenActions(class_1799 stack, int targetContainerSlot, ItemEditorScreen parentTradeScreen, int parentTradeIndex, int parentTradeSlot) {
        super(stack, targetContainerSlot, parentTradeScreen, parentTradeIndex, parentTradeSlot);
    }

    protected void switchPanel(Panel panel) {
        if (this.activePanel == panel) {
            return;
        }
        captureFieldValues();
        if (this.activePanel == Panel.ITEM) {
            applyMainFieldsToStack(false);
        }
        this.activePanel = panel;
        this.status = class_2561.method_43473();
        method_41843();
    }

    protected void openContainerItemEditor() {
        if (this.field_22787 == null || this.field_22787.field_1724 == null) {
            return;
        }
        if (!applyMainFieldsToStack(true) || !isContainerEditableItem(this.previewStack)) {
            return;
        }
        this.status = class_2561.method_43473();
        syncNbtEditorValuesFromStack();
        this.field_22787.method_1507(ContainerItemScreen.create((ItemEditorScreen) this, this.field_22787.field_1724, this.previewStack));
    }

    protected void openBookItemEditor() {
        if (this.field_22787 == null) {
            return;
        }
        if (!applyMainFieldsToStack(true) || !isBookEditableItem(this.previewStack)) {
            return;
        }
        this.status = class_2561.method_43473();
        syncNbtEditorValuesFromStack();
        this.field_22787.method_1507(new BookItemScreen((ItemEditorScreen) this, this.previewStack));
    }

    protected void openJsonEditor() {
        if (this.field_22787 == null) {
            return;
        }
        if (!applyMainFieldsToStack(true)) {
            return;
        }
        this.status = class_2561.method_43473();
        syncNbtEditorValuesFromStack();
        this.field_22787.method_1507(new ItemJsonEditorScreen((ItemEditorScreen) this, this.previewStack));
    }

    protected void openCommandBlockEditor() {
        if (this.field_22787 == null) {
            return;
        }
        if (!applyMainFieldsToStack(true) || !isCommandBlockEditableItem(this.previewStack)) {
            return;
        }
        this.status = class_2561.method_43473();
        syncNbtEditorValuesFromStack();
        this.field_22787.method_1507(new ItemCommandBlockEditorScreen((ItemEditorScreen) this, this.previewStack));
    }

    protected void openArmorTrimEditor() {
        if (this.field_22787 == null) {
            return;
        }
        if (!applyMainFieldsToStack(true) || !isArmorTrimApplicable(this.previewStack)) {
            return;
        }
        this.status = class_2561.method_43473();
        syncNbtEditorValuesFromStack();
        this.field_22787.method_1507(new ArmorTrimEditorScreen((ItemEditorScreen) this, this.previewStack));
    }

    protected void openItemPicker() {
        if (this.field_22787 == null) {
            return;
        }
        if (this.activePanel == Panel.ITEM) {
            applyMainFieldsToStack(false);
        }
        this.field_22787.method_1507(new ItemPickScreen((ItemEditorScreen) this, this::replacePickedStack, () -> this.previewStack));
    }

    private void replacePickedStack(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return;
        }

        this.previewStack = stack.method_7972();
        readMainFieldsFromStack(this.previewStack);
        syncNbtEditorValuesFromStack();
        this.nbtFeedback = "";
        syncItemPanelFieldsFromStack();
    }

    private void syncItemPanelFieldsFromStack() {
        if (this.itemIdBox != null) {
            this.itemIdBox.method_1852(this.itemIdValue);
        }
        if (this.countBox != null) {
            this.countBox.method_1852(this.countValue);
        }
        if (this.damageBox != null) {
            this.damageBox.method_1852(this.damageValue);
        }
        if (this.nameBox != null) {
            this.nameBox.method_1852(this.nameValue);
        }
    }

    void refreshAfterContainerEdit() {
        readMainFieldsFromStack(this.previewStack);
        syncNbtEditorValuesFromStack();
        this.containerSlotNbtValue = getContainerSelectedSlotNbt();
        this.nbtFeedback = "";
    }

    void refreshAfterBookEdit() {
        readMainFieldsFromStack(this.previewStack);
        syncNbtEditorValuesFromStack();
        this.nbtFeedback = "";
    }

    void applyJsonEditedStack(class_1799 stack) {
        if (stack == null) {
            return;
        }
        this.previewStack = stack.method_7972();
        readMainFieldsFromStack(this.previewStack);
        syncNbtEditorValuesFromStack();
        this.nbtFeedback = "";
        this.status = class_2561.method_43469(messageKey("editor_json_applied"), this.previewStack.method_7964());
    }

    void applyCommandBlockEditedStack(class_1799 stack) {
        if (stack == null) {
            return;
        }
        this.previewStack = stack.method_7972();
        readMainFieldsFromStack(this.previewStack);
        syncNbtEditorValuesFromStack();
        this.nbtFeedback = "";
        this.status = class_2561.method_43471(messageKey("editor_command_block_applied"));
    }

    void applyArmorTrimEditedStack(class_1799 stack) {
        if (stack == null) {
            return;
        }
        this.previewStack = stack.method_7972();
        readMainFieldsFromStack(this.previewStack);
        syncNbtEditorValuesFromStack();
        this.nbtFeedback = "";
        this.status = class_2561.method_43471(messageKey("editor_armor_trim_applied"));
    }

    protected void goBack() {
        if (this.activePanel == Panel.ITEM) {
            if (isTradeSlotEditor()) {
                applyTradeSlotEditorAndReturn();
                return;
            }
            method_25419();
            return;
        }

        if (this.activePanel == Panel.TRADE) {
            this.activePanel = Panel.TRADES;
            ensureVillagerTradeOffers();
            method_41843();
            return;
        }

        this.activePanel = Panel.ITEM;
        readMainFieldsFromStack(this.previewStack);
        syncNbtEditorValuesFromStack();
        method_41843();
    }

    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(null);
        }
    }

    protected void applyToSelectedSlot() {
        if (!applyMainFieldsToStack(true) || this.previewStack.method_7960() || this.field_22787 == null || this.field_22787.field_1724 == null) {
            return;
        }

        restoreLostComponents();
        if (Config.getStripServerTags()) {
            ServerTagStripper.strip(this.previewStack);
        }

        int selected = this.field_22787.field_1724.method_31548().method_67532();
        int containerSlot = this.targetContainerSlot >= 0
                ? this.targetContainerSlot
                : PlayerInventorySlots.HOTBAR_CONTAINER_SLOT_START + selected;
        class_1799 inventoryStack = this.previewStack.method_7972();
        if (this.field_22787.method_47392()) {
            if (!applySingleplayerInventoryStack(containerSlot, inventoryStack)) {
                this.status = class_2561.method_43471(messageKey("editor_invalid_target_slot"));
                return;
            }

            ModSource.LOGGER.info("Infinity Item Editor save: {}", ItemStackNbt.save(inventoryStack));
            this.status = class_2561.method_43469(messageKey("editor_applied"), inventoryStack.method_7964());
            return;
        }

        if (this.field_22787.field_1761 == null) {
            return;
        }

        if (class_437.method_25442()) {
            String command = GiveHelper.getStringFromItemStack(inventoryStack);
            if (command.startsWith("/")) {
                command = command.substring(1);
            }
            this.field_22787.field_1724.field_3944.method_45730(command);
            this.status = class_2561.method_43469(messageKey("editor_give_sent"), inventoryStack.method_7964());
            return;
        }
        if (this.field_22787.field_1761.method_2920() != net.minecraft.class_1934.field_9220) {
            this.status = class_2561.method_43471(messageKey("editor_server_not_creative"));
            this.field_22787.field_1774.method_1455(GiveHelper.getStringFromItemStack(inventoryStack));
            return;
        }
        if (!this.field_22787.field_1724.method_31549().field_7477) {
            this.status = class_2561.method_43471(messageKey("editor_requires_creative"));
            return;
        }

        if (!PlayerInventorySlots.setStack(this.field_22787.field_1724, containerSlot, inventoryStack)) {
            this.status = class_2561.method_43471(messageKey("editor_invalid_target_slot"));
            return;
        }

        String sentNbt = ItemStackNbt.save(inventoryStack).toString();
        ModSource.LOGGER.info("Infinity Item Editor save: {}", sentNbt);
        int inventorySlot = containerSlot >= 36 && containerSlot <= 44
                ? containerSlot - 36
                : (containerSlot >= 9 && containerSlot <= 35 ? containerSlot : -1);
        SaveVerifier.expect(inventoryStack.method_7972(), sentNbt, inventorySlot);
        this.field_22787.field_1761.method_2909(inventoryStack.method_7972(), containerSlot);
        this.status = class_2561.method_43469(messageKey("editor_save_sent"), inventoryStack.method_7964());
    }

    private static final List<class_9331<?>> PROTECTED_COMPONENTS = List.of(
            class_9334.field_49628,
            class_9334.field_49633,
            class_9334.field_49643,
            class_9334.field_49636,
            class_9334.field_49607,
            class_9334.field_49617,
            class_9334.field_49611,
            class_9334.field_49609,
            class_9334.field_49651,
            class_9334.field_49616,
            class_9334.field_49619,
            class_9334.field_49620,
            class_9334.field_49621,
            class_9334.field_49622,
            class_9334.field_56400,
            class_9334.field_49630,
            class_9334.field_49649,
            class_9334.field_49650,
            class_9334.field_49646,
            class_9334.field_49647,
            class_9334.field_49625,
            class_9334.field_49626,
            class_9334.field_49613,
            class_9334.field_49612
    );

    /**
     * The legacy NBT view only knows a subset of 1.21 components; a failed conversion used to drop
     * the rest when saving. Restore anything the original stack had that the edited stack lost,
     * except name/lore which the user edits directly.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private void restoreLostComponents() {
        if (this.originalStack.method_7960() || this.previewStack.method_7960()) {
            return;
        }

        List<class_9331<?>> missing = new ArrayList<>();
        for (class_9331<?> type : PROTECTED_COMPONENTS) {
            if (this.originalStack.method_57826(type) && !this.previewStack.method_57826(type)) {
                missing.add(type);
            }
        }
        if (missing.isEmpty()) {
            return;
        }

        // A single missing component is usually an intentional edit (e.g. clearing enchantments);
        // two or more means a conversion dropped data, so restore everything that disappeared.
        boolean catastrophic = missing.size() >= 2;
        List<String> restored = new ArrayList<>();
        for (class_9331<?> type : missing) {
            if (catastrophic || type == class_9334.field_49628) {
                setComponent(this.previewStack, type, this.originalStack);
                restored.add(type.toString());
            }
        }
        if (!restored.isEmpty()) {
            ModSource.LOGGER.warn("Infinity Item Editor: restored lost components before saving: {}", restored);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setComponent(class_1799 target, class_9331 type, class_1799 source) {
        target.method_57379(type, source.method_58694(type));
    }

    private boolean applySingleplayerInventoryStack(int containerSlot, class_1799 stack) {
        class_1132 server = this.field_22787.method_1576();
        if (server == null || !PlayerInventorySlots.setStack(this.field_22787.field_1724, containerSlot, stack)) {
            return false;
        }

        UUID playerId = this.field_22787.field_1724.method_5667();
        class_2487 serverStackTag = ItemStackNbt.save(stack);
        server.execute(() -> {
            class_3222 serverPlayer = server.method_3760().method_14602(playerId);
            class_1799 serverStack = ItemStackNbt.parse(server.method_30611(), serverStackTag.method_10553());
            if (serverPlayer == null || !PlayerInventorySlots.setStack(serverPlayer, containerSlot, serverStack)) {
                return;
            }

            serverPlayer.field_7512.method_7623();
            if (serverPlayer.field_7512 != serverPlayer.field_7498) {
                serverPlayer.field_7498.method_7623();
            }
        });
        return true;
    }

    protected void dropEditedStack() {
        if (class_437.method_25442()) {
            copyGiveCommand();
            return;
        }

        if (!applyMainFieldsToStack(true) || this.previewStack.method_7960() || this.field_22787 == null || this.field_22787.field_1761 == null) {
            return;
        }

        if (this.field_22787.field_1724 == null || !this.field_22787.field_1724.method_31549().field_7477) {
            this.status = class_2561.method_43471(messageKey("editor_requires_creative"));
            return;
        }

        class_1799 dropped = this.previewStack.method_7972();
        this.field_22787.field_1761.method_2915(dropped);
        this.status = class_2561.method_43469(messageKey("editor_dropped"), dropped.method_7964());
    }

    protected void copyGiveCommand() {
        if (!applyMainFieldsToStack(true) || this.previewStack.method_7960() || this.field_22787 == null) {
            return;
        }
        this.field_22787.field_1774.method_1455(GiveHelper.getStringFromItemStack(this.previewStack));
        this.status = class_2561.method_43471(messageKey("editor_copied"));
    }

    protected void resetStack() {
        if (this.activePanel == Panel.TRADES) {
            clearVillagerTrades();
            return;
        }

        if (this.activePanel == Panel.TRADE) {
            return;
        }

        if (this.activePanel == Panel.COMPONENTS) {
            this.previewStack = parseStackWithComponents(this.previewStack, new class_2487());
        } else if (this.activePanel == Panel.NBT) {
            ItemStackNbt.set(this.previewStack, new class_2487());
        } else {
            ItemStackNbt.set(this.previewStack, null);
        }
        readMainFieldsFromStack(this.previewStack);
        syncNbtEditorValuesFromStack();
        this.nbtFeedback = "";
        method_41843();
    }

    protected void saveRealm() {
        if (!applyMainFieldsToStack(true) || this.previewStack.method_7960() || this.field_22787 == null || this.field_22787.field_1724 == null) {
            return;
        }

        RealmController realmController = ModSource.getOrCreateRealmController(this.field_22787.field_1697);
        if (realmController != null) {
            if (realmController.addItemStack(this.field_22787.field_1724, this.previewStack.method_7972())) {
                CreativeTabRefresher.refreshRealm(this.field_22787);
                this.status = class_2561.method_43469(messageKey("editor_saved"), this.previewStack.method_7964());
            }
        }
    }

    protected boolean applyMainFieldsToStack(boolean updateStatus) {
        try {
            captureFieldValues();
            tryApplyItemId(true);
            tryApplyCount(true);
            tryApplyDamage(true);
            applyNameToStack();
            applyLoreToStack();
            if (Boolean.getBoolean("infinity_item_editor_re.syncLegacyPluginData")) {
                LegacyPluginCompat.sync(this.previewStack, this.nameValue, this.loreValues);
            }
            if (this.activePanel == Panel.SIGN) {
                applySignToStack();
            }
            if (this.activePanel == Panel.BOOK) {
                applyBookMetadataToStack();
            }
            if (this.activePanel == Panel.HEAD) {
                applyHeadToStack();
            }
            if (this.activePanel == Panel.BANNER) {
                readBannerFieldsFromStack(this.previewStack);
            }
            if (this.activePanel == Panel.DECORATED_POT) {
                readDecoratedPotFieldsFromStack(this.previewStack);
            }
            syncNbtEditorValuesFromStack();
            return true;
        } catch (IllegalArgumentException exception) {
            if (updateStatus) {
                this.status = class_2561.method_43470(exception.getMessage());
            }
            return false;
        }
    }

    protected boolean tryApplyItemId(boolean throwOnError) {
        String idText = normalizeItemId(this.itemIdBox == null ? this.itemIdValue : this.itemIdBox.method_1882());
        class_2960 id = class_2960.method_12829(idText);
        class_1792 item = id == null ? null : CompatRegistries.ITEMS.getValue(id);
        if (item == null || item == class_1802.field_8162 && !"minecraft:air".equals(idText)) {
            if (throwOnError) {
                throw new IllegalArgumentException(class_2561.method_43469(messageKey("editor_invalid_item"), idText).getString());
            }
            return false;
        }

        this.itemIdValue = stripMinecraftNamespace(id);
        if (this.previewStack.method_31574(item)) {
            return false;
        }

        boolean syncDefaultName = isNameFollowingDefault(this.previewStack);
        class_2487 tag = ItemStackNbt.get(this.previewStack) == null ? null : ItemStackNbt.get(this.previewStack).method_10553();
        int count = this.previewStack.method_7947() <= 0 ? 1 : this.previewStack.method_7947();
        this.previewStack = new class_1799(item, count);
        ItemStackNbt.set(this.previewStack, tag);
        if (syncDefaultName) {
            this.nameValue = getDefaultHoverName(this.previewStack);
            if (this.nameBox != null) {
                this.nameBox.method_1852(this.nameValue);
            }
        }
        this.damageValue = Integer.toString(Math.min(getDamageMaxForField(this.previewStack), parsePositiveOrZero(this.damageValue)));
        tryApplyDamage(false);
        this.attributeSlot = getDefaultAttributeSlot(this.previewStack);
        this.colorHexValue = formatColorHex(getEditorColor());
        return true;
    }

    protected void tryApplyCount(boolean throwOnError) {
        String value = this.countBox == null ? this.countValue : this.countBox.method_1882();
        if (value == null || value.isBlank()) {
            if (throwOnError) {
                throw new IllegalArgumentException(class_2561.method_43469(messageKey("editor_invalid_count"), MAX_COUNT).getString());
            }
            return;
        }

        int count;
        try {
            count = Integer.parseInt(value);
        } catch (NumberFormatException exception) {
            if (throwOnError) {
                throw new IllegalArgumentException(class_2561.method_43469(messageKey("editor_invalid_count"), MAX_COUNT).getString());
            }
            return;
        }
        if (count < 1 || count > MAX_COUNT) {
            if (throwOnError) {
                throw new IllegalArgumentException(class_2561.method_43469(messageKey("editor_invalid_count"), MAX_COUNT).getString());
            }
            return;
        }

        this.countValue = Integer.toString(count);
        this.previewStack.method_7939(count);
    }

    protected void tryApplyDamage(boolean throwOnError) {
        String value = this.damageBox == null ? this.damageValue : this.damageBox.method_1882();
        if (value == null || value.isBlank()) {
            if (throwOnError) {
                throw new IllegalArgumentException(class_2561.method_43469(messageKey("editor_invalid_damage"), getDamageMaxForField(this.previewStack)).getString());
            }
            return;
        }

        int damage = Integer.parseInt(value);
        int maxDamage = getDamageMaxForField(this.previewStack);
        if (damage < 0 || damage > maxDamage) {
            if (throwOnError) {
                throw new IllegalArgumentException(class_2561.method_43469(messageKey("editor_invalid_damage"), maxDamage).getString());
            }
            return;
        }

        this.damageValue = Integer.toString(damage);
        this.previewStack.method_7974(damage);
    }

    protected void applyNameToStack() {
        String value = this.nameBox == null ? this.nameValue : this.nameBox.method_1882();
        this.nameValue = value;
        if (value == null || value.isBlank()) {
            ItemStackCompat.resetHoverName(this.previewStack);
            cleanupEmptyDisplayTag();
            return;
        }

        class_1799 withoutName = this.previewStack.method_7972();
        ItemStackCompat.resetHoverName(withoutName);
        if (!ItemStackCompat.hasCustomHoverName(this.previewStack)
                && LegacyText.stripCodes(value).equals(withoutName.method_7964().getString())) {
            return;
        }

        ItemStackCompat.setHoverName(this.previewStack, LegacyText.parse(value));
    }

    protected void clearCustomName() {
        ItemStackCompat.resetHoverName(this.previewStack);
        this.nameValue = this.previewStack.method_7964().getString();
        if (this.nameBox != null) {
            this.nameBox.method_1852(this.nameValue);
        }
        cleanupEmptyDisplayTag();
    }

    protected void applyLoreToStack() {
        List<class_2561> lines = new ArrayList<>();
        for (String line : this.loreValues) {
            lines.add(line == null || line.isEmpty() ? class_2561.method_43473() : LegacyText.parse(line));
        }
        while (!lines.isEmpty() && lines.get(lines.size() - 1).getString().isEmpty()) {
            lines.remove(lines.size() - 1);
        }

        if (lines.isEmpty()) {
            this.previewStack.method_57381(class_9334.field_49632);
        } else {
            this.previewStack.method_57379(class_9334.field_49632, new class_9290(lines));
        }
    }

    protected void setLoreLine(int line, String value) {
        while (this.loreValues.size() <= line) {
            this.loreValues.add("");
        }
        this.loreValues.set(line, value);
    }

    protected void removeLoreLine(int line) {
        if (line >= 0 && line < this.loreValues.size()) {
            this.loreValues.remove(line);
            this.loreScroll = class_3532.method_15340(this.loreScroll, 0, Math.max(0, this.loreValues.size() - loreLineSpaces()));
            applyLoreToStack();
        }
    }

    protected void moveLoreLine(int line, int direction) {
        int other = line + direction;
        if (line < 0 || line >= this.loreValues.size() || other < 0 || other >= this.loreValues.size()) {
            return;
        }
        String value = this.loreValues.get(line);
        this.loreValues.set(line, this.loreValues.get(other));
        this.loreValues.set(other, value);
        applyLoreToStack();
        method_41843();
    }

    protected void copyLoreOnly() {
        if (this.field_22787 != null) {
            this.field_22787.field_1774.method_1455(String.join("\n", this.loreValues));
        }
    }

    protected void copyFullTooltip() {
        if (this.field_22787 != null && this.field_22787.field_1724 != null) {
            List<class_2561> tooltip = ItemStackCompat.getTooltipLines(this.previewStack, this.field_22787.field_1724, this.field_22787.field_1690.field_1827 ? net.minecraft.class_1836.class_1837.field_41071 : net.minecraft.class_1836.class_1837.field_41070);
            List<String> lines = new ArrayList<>();
            for (class_2561 component : tooltip) {
                lines.add(component.getString());
            }
            this.field_22787.field_1774.method_1455(String.join("\n", lines));
        }
    }

    protected void pasteLore() {
        if (this.field_22787 == null) {
            return;
        }
        String clipboard = this.field_22787.field_1774.method_1460();
        if (clipboard == null || clipboard.isBlank()) {
            return;
        }
        for (String line : clipboard.split("\\r?\\n")) {
            if (!line.startsWith(String.valueOf(class_124.field_33292)) && line.length() > 1) {
                line = class_124.field_1070.toString() + class_124.field_1080 + line;
            }
            this.loreValues.add(line);
        }
        applyLoreToStack();
        method_41843();
    }
}
