package io.github.seraphina.infinity_item_editor_re.util;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/** Experimental: removes server tracking keys so a modified item is treated as a new item. */
public final class ServerTagStripper {
    private ServerTagStripper() {
    }

    public static boolean strip(class_1799 stack) {
        class_9279 data = stack.method_58694(class_9334.field_49628);
        if (data == null) {
            return false;
        }

        class_2487 tag = data.method_57461();
        List<String> removed = new ArrayList<>();
        for (String key : new ArrayList<>(tag.method_10541())) {
            String lower = key.toLowerCase(Locale.ROOT);
            if (lower.startsWith("wlprotocol") || lower.equals("display") || lower.contains("uuid")) {
                tag.method_10551(key);
                removed.add(key);
            }
        }
        if (removed.isEmpty()) {
            return false;
        }

        if (tag.method_33133()) {
            stack.method_57381(class_9334.field_49628);
        } else {
            stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        }
        ModSource.LOGGER.info("Infinity Item Editor: stripped server tracking keys {}", removed);
        return true;
    }
}
