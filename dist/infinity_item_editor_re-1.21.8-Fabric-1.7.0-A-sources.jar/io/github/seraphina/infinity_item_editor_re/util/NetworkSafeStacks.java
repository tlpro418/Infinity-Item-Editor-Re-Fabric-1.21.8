package io.github.seraphina.infinity_item_editor_re.util;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.netty.buffer.Unpooled;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2873;
import net.minecraft.class_9129;
import net.minecraft.class_9331;

/** Removes components that cannot be encoded into the creative-mode slot packet (prevents EncoderException). */
public final class NetworkSafeStacks {
    private NetworkSafeStacks() {
    }

    public static class_1799 sanitize(class_1799 stack) {
        if (stack == null || stack.method_7960() || encodable(stack)) {
            return stack;
        }

        class_1799 copy = stack.method_7972();
        List<String> removed = new ArrayList<>();
        for (class_9331<?> type : new ArrayList<>(copy.method_57353().method_57831())) {
            copy.method_57381(type);
            removed.add(type.toString());
            if (encodable(copy)) {
                ModSource.LOGGER.warn("Infinity Item Editor: dropped components that cannot be sent to the server: {}", removed);
                return copy;
            }
            if (copy.method_57353().method_57837()) {
                break;
            }
        }

        ModSource.LOGGER.warn("Infinity Item Editor: item still cannot be encoded after dropping {}", removed);
        return class_1799.field_8037;
    }

    private static boolean encodable(class_1799 stack) {
        class_9129 buffer = new class_9129(Unpooled.buffer(), ItemStackNbt.registryAccess());
        try {
            class_2873.field_48219.encode(buffer,
                    new class_2873(36, stack));
            return true;
        } catch (Throwable throwable) {
            return false;
        } finally {
            try {
                buffer.release();
            } catch (Throwable ignored) {
            }
        }
    }
}
