package io.github.seraphina.infinity_item_editor_re.util;

import io.github.seraphina.infinity_item_editor_re.ModSource;
import io.netty.buffer.Unpooled;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2873;
import net.minecraft.class_9129;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

/**
 * Removes components that cannot be encoded into the creative-mode slot packet.
 * Only components that fail on their own are dropped, so name/lore survive.
 */
public final class NetworkSafeStacks {
    private NetworkSafeStacks() {
    }

    public static class_1799 sanitize(class_1799 stack) {
        if (stack == null || stack.method_7960() || encodable(stack)) {
            return stack;
        }

        class_1799 copy = stack.method_7972();
        List<class_9331<?>> broken = new ArrayList<>();
        for (class_9331<?> type : new ArrayList<>(copy.method_57353().method_57831())) {
            class_1799 single = new class_1799(copy.method_7909(), 1);
            setRaw(single, type, copy.method_58694(type));
            if (!encodable(single)) {
                broken.add(type);
            }
        }

        if (!broken.isEmpty()) {
            for (class_9331<?> type : broken) {
                if (type == class_9334.field_49628) {
                    preserveLegacyDisplay(copy);
                }
                copy.method_57381(type);
            }
            if (encodable(copy)) {
                ModSource.LOGGER.warn("Infinity Item Editor: dropped components that cannot be sent to the server: {}", names(broken));
                return copy;
            }
        }

        // Fallback: drop components until the stack encodes, but never return empty unless unavoidable.
        for (class_9331<?> type : new ArrayList<>(copy.method_57353().method_57831())) {
            copy.method_57381(type);
            if (encodable(copy)) {
                ModSource.LOGGER.warn("Infinity Item Editor: dropped components until encodable: {}", type);
                return copy;
            }
        }
        ModSource.LOGGER.warn("Infinity Item Editor: item cannot be encoded even without components; dropping it");
        return class_1799.field_8037;
    }

    private static void preserveLegacyDisplay(class_1799 stack) {
        class_9279 data = stack.method_58694(class_9334.field_49628);
        if (data == null) {
            return;
        }
        class_2487 tag = data.method_57461();
        if (!tag.method_10545("display")) {
            return;
        }
        class_2487 display = tag.method_68568("display");
        if (display.method_10545("Name") && !stack.method_57826(class_9334.field_49631)) {
            String name = display.method_68564("Name", "");
            if (!name.isBlank()) {
                stack.method_57379(class_9334.field_49631, LegacyText.parse(name));
            }
        }
        if (display.method_10545("Lore") && !stack.method_57826(class_9334.field_49632)) {
            class_2499 lore = display.method_68569("Lore");
            List<class_2561> lines = new ArrayList<>();
            for (int i = 0; i < lore.size(); i++) {
                lines.add(LegacyText.parse(lore.method_68577(i, "")));
            }
            if (!lines.isEmpty()) {
                stack.method_57379(class_9334.field_49632, new class_9290(lines));
            }
        }
    }

    private static String names(List<class_9331<?>> types) {
        List<String> names = new ArrayList<>(types.size());
        for (class_9331<?> type : types) {
            names.add(type.toString());
        }
        return names.toString();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setRaw(class_1799 stack, class_9331 type, Object value) {
        stack.method_57379(type, value);
    }

    private static boolean encodable(class_1799 stack) {
        class_9129 buffer = new class_9129(Unpooled.buffer(), ItemStackNbt.registryAccess());
        try {
            class_2873.field_48219.encode(buffer,
                    new class_2873(36, stack));
            return true;
        } catch (Throwable throwable) {
            return false;
        } finally {
            try {
                buffer.release();
            } catch (Throwable ignored) {
            }
        }
    }
}
